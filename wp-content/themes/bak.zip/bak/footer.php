<div id="home-slogan">Bếp An Khang - Nâng Tầm Bếp Việt</div>   
<div id="main-footer">
            <div class="container main-wrapper">
                <div id="footer-info">                                            
                        Bếp An Khang © 2017 Privacy Policy
                </div>
            </div>    
        </div>


<?php wp_footer(); ?>

</body>
</html>
