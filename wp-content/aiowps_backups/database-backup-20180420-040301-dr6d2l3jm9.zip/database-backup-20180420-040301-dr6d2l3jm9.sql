-- All In One WP Security & Firewall 4.3.2
-- MySQL dump
-- 2018-04-20 04:03:01

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `bak_aiowps_events`;

CREATE TABLE `bak_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_aiowps_failed_logins`;

CREATE TABLE `bak_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_aiowps_global_meta`;

CREATE TABLE `bak_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_aiowps_login_activity`;

CREATE TABLE `bak_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_aiowps_login_lockdown`;

CREATE TABLE `bak_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_aiowps_permanent_block`;

CREATE TABLE `bak_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_commentmeta`;

CREATE TABLE `bak_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_comments`;

CREATE TABLE `bak_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_links`;

CREATE TABLE `bak_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_options`;

CREATE TABLE `bak_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=899 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bak_options` VALUES("1","siteurl","http://bepankhang.test","yes");
INSERT INTO `bak_options` VALUES("2","home","http://bepankhang.test","yes");
INSERT INTO `bak_options` VALUES("3","blogname","Bếp An Khang","yes");
INSERT INTO `bak_options` VALUES("4","blogdescription","Nâng tầm bếp Việt","yes");
INSERT INTO `bak_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `bak_options` VALUES("6","admin_email","ptson.snh@gmail.com","yes");
INSERT INTO `bak_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `bak_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `bak_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `bak_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `bak_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `bak_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `bak_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `bak_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `bak_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `bak_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `bak_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `bak_options` VALUES("18","default_category","1","yes");
INSERT INTO `bak_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `bak_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `bak_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `bak_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `bak_options` VALUES("23","date_format","F j, Y","yes");
INSERT INTO `bak_options` VALUES("24","time_format","g:i a","yes");
INSERT INTO `bak_options` VALUES("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `bak_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `bak_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `bak_options` VALUES("28","permalink_structure","/%postname%/","yes");
INSERT INTO `bak_options` VALUES("29","rewrite_rules","a:185:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:42:\"wp-types-group/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:52:\"wp-types-group/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:72:\"wp-types-group/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"wp-types-group/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"wp-types-group/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:48:\"wp-types-group/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"wp-types-group/([^/]+)/embed/?$\";s:47:\"index.php?wp-types-group=$matches[1]&embed=true\";s:35:\"wp-types-group/([^/]+)/trackback/?$\";s:41:\"index.php?wp-types-group=$matches[1]&tb=1\";s:43:\"wp-types-group/([^/]+)/page/?([0-9]{1,})/?$\";s:54:\"index.php?wp-types-group=$matches[1]&paged=$matches[2]\";s:50:\"wp-types-group/([^/]+)/comment-page-([0-9]{1,})/?$\";s:54:\"index.php?wp-types-group=$matches[1]&cpage=$matches[2]\";s:39:\"wp-types-group/([^/]+)(?:/([0-9]+))?/?$\";s:53:\"index.php?wp-types-group=$matches[1]&page=$matches[2]\";s:31:\"wp-types-group/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"wp-types-group/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"wp-types-group/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"wp-types-group/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"wp-types-group/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"wp-types-group/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:47:\"wp-types-user-group/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"wp-types-user-group/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"wp-types-user-group/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"wp-types-user-group/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"wp-types-user-group/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"wp-types-user-group/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:36:\"wp-types-user-group/([^/]+)/embed/?$\";s:52:\"index.php?wp-types-user-group=$matches[1]&embed=true\";s:40:\"wp-types-user-group/([^/]+)/trackback/?$\";s:46:\"index.php?wp-types-user-group=$matches[1]&tb=1\";s:48:\"wp-types-user-group/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?wp-types-user-group=$matches[1]&paged=$matches[2]\";s:55:\"wp-types-user-group/([^/]+)/comment-page-([0-9]{1,})/?$\";s:59:\"index.php?wp-types-user-group=$matches[1]&cpage=$matches[2]\";s:44:\"wp-types-user-group/([^/]+)(?:/([0-9]+))?/?$\";s:58:\"index.php?wp-types-user-group=$matches[1]&page=$matches[2]\";s:36:\"wp-types-user-group/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"wp-types-user-group/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"wp-types-user-group/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"wp-types-user-group/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"wp-types-user-group/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"wp-types-user-group/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:47:\"wp-types-term-group/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"wp-types-term-group/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"wp-types-term-group/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"wp-types-term-group/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"wp-types-term-group/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"wp-types-term-group/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:36:\"wp-types-term-group/([^/]+)/embed/?$\";s:52:\"index.php?wp-types-term-group=$matches[1]&embed=true\";s:40:\"wp-types-term-group/([^/]+)/trackback/?$\";s:46:\"index.php?wp-types-term-group=$matches[1]&tb=1\";s:48:\"wp-types-term-group/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?wp-types-term-group=$matches[1]&paged=$matches[2]\";s:55:\"wp-types-term-group/([^/]+)/comment-page-([0-9]{1,})/?$\";s:59:\"index.php?wp-types-term-group=$matches[1]&cpage=$matches[2]\";s:44:\"wp-types-term-group/([^/]+)(?:/([0-9]+))?/?$\";s:58:\"index.php?wp-types-term-group=$matches[1]&page=$matches[2]\";s:36:\"wp-types-term-group/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"wp-types-term-group/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"wp-types-term-group/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"wp-types-term-group/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"wp-types-term-group/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"wp-types-term-group/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:52:\"thuong-hieu/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?brand=$matches[1]&feed=$matches[2]\";s:47:\"thuong-hieu/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?brand=$matches[1]&feed=$matches[2]\";s:28:\"thuong-hieu/([^/]+)/embed/?$\";s:38:\"index.php?brand=$matches[1]&embed=true\";s:40:\"thuong-hieu/([^/]+)/page/?([0-9]{1,})/?$\";s:45:\"index.php?brand=$matches[1]&paged=$matches[2]\";s:22:\"thuong-hieu/([^/]+)/?$\";s:27:\"index.php?brand=$matches[1]\";s:52:\"nhom-san-pham/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?product-category=$matches[1]&feed=$matches[2]\";s:47:\"nhom-san-pham/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?product-category=$matches[1]&feed=$matches[2]\";s:28:\"nhom-san-pham/(.+?)/embed/?$\";s:49:\"index.php?product-category=$matches[1]&embed=true\";s:40:\"nhom-san-pham/(.+?)/page/?([0-9]{1,})/?$\";s:56:\"index.php?product-category=$matches[1]&paged=$matches[2]\";s:22:\"nhom-san-pham/(.+?)/?$\";s:38:\"index.php?product-category=$matches[1]\";s:36:\"san-pham/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"san-pham/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"san-pham/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"san-pham/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"san-pham/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"san-pham/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:25:\"san-pham/([^/]+)/embed/?$\";s:55:\"index.php?post_type=product&name=$matches[1]&embed=true\";s:29:\"san-pham/([^/]+)/trackback/?$\";s:49:\"index.php?post_type=product&name=$matches[1]&tb=1\";s:37:\"san-pham/([^/]+)/page/?([0-9]{1,})/?$\";s:62:\"index.php?post_type=product&name=$matches[1]&paged=$matches[2]\";s:44:\"san-pham/([^/]+)/comment-page-([0-9]{1,})/?$\";s:62:\"index.php?post_type=product&name=$matches[1]&cpage=$matches[2]\";s:33:\"san-pham/([^/]+)(?:/([0-9]+))?/?$\";s:61:\"index.php?post_type=product&name=$matches[1]&page=$matches[2]\";s:25:\"san-pham/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:35:\"san-pham/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:55:\"san-pham/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"san-pham/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"san-pham/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:31:\"san-pham/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"qna/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"qna/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"qna/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"qna/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"qna/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"qna/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:20:\"qna/([^/]+)/embed/?$\";s:36:\"index.php?qna=$matches[1]&embed=true\";s:24:\"qna/([^/]+)/trackback/?$\";s:30:\"index.php?qna=$matches[1]&tb=1\";s:32:\"qna/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?qna=$matches[1]&paged=$matches[2]\";s:39:\"qna/([^/]+)/comment-page-([0-9]{1,})/?$\";s:43:\"index.php?qna=$matches[1]&cpage=$matches[2]\";s:28:\"qna/([^/]+)(?:/([0-9]+))?/?$\";s:42:\"index.php?qna=$matches[1]&page=$matches[2]\";s:20:\"qna/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:30:\"qna/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:50:\"qna/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\"qna/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\"qna/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:26:\"qna/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `bak_options` VALUES("30","hack_file","0","yes");
INSERT INTO `bak_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `bak_options` VALUES("32","moderation_keys","","no");
INSERT INTO `bak_options` VALUES("33","active_plugins","a:5:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:14:\"types/wpcf.php\";i:3;s:24:\"wordpress-seo/wp-seo.php\";i:4;s:31:\"wp-term-order/wp-term-order.php\";}","yes");
INSERT INTO `bak_options` VALUES("34","category_base","","yes");
INSERT INTO `bak_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `bak_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `bak_options` VALUES("37","gmt_offset","0","yes");
INSERT INTO `bak_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `bak_options` VALUES("39","recently_edited","","no");
INSERT INTO `bak_options` VALUES("40","template","bak","yes");
INSERT INTO `bak_options` VALUES("41","stylesheet","bak","yes");
INSERT INTO `bak_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `bak_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `bak_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `bak_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `bak_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `bak_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `bak_options` VALUES("48","db_version","38590","yes");
INSERT INTO `bak_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `bak_options` VALUES("50","upload_path","","yes");
INSERT INTO `bak_options` VALUES("51","blog_public","1","yes");
INSERT INTO `bak_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `bak_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `bak_options` VALUES("54","tag_base","","yes");
INSERT INTO `bak_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `bak_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `bak_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `bak_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `bak_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `bak_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `bak_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `bak_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `bak_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `bak_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `bak_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `bak_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `bak_options` VALUES("67","image_default_size","","yes");
INSERT INTO `bak_options` VALUES("68","image_default_align","","yes");
INSERT INTO `bak_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `bak_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `bak_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `bak_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `bak_options` VALUES("73","page_comments","0","yes");
INSERT INTO `bak_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `bak_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `bak_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `bak_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `bak_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("79","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO `bak_options` VALUES("82","timezone_string","","yes");
INSERT INTO `bak_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `bak_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `bak_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `bak_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `bak_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `bak_options` VALUES("88","site_icon","0","yes");
INSERT INTO `bak_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `bak_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `bak_options` VALUES("91","initial_db_version","37965","yes");
INSERT INTO `bak_options` VALUES("92","bak_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:74:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:26:\"wpcf_custom_post_type_view\";b:1;s:26:\"wpcf_custom_post_type_edit\";b:1;s:33:\"wpcf_custom_post_type_edit_others\";b:1;s:25:\"wpcf_custom_taxonomy_view\";b:1;s:25:\"wpcf_custom_taxonomy_edit\";b:1;s:32:\"wpcf_custom_taxonomy_edit_others\";b:1;s:22:\"wpcf_custom_field_view\";b:1;s:22:\"wpcf_custom_field_edit\";b:1;s:29:\"wpcf_custom_field_edit_others\";b:1;s:25:\"wpcf_user_meta_field_view\";b:1;s:25:\"wpcf_user_meta_field_edit\";b:1;s:32:\"wpcf_user_meta_field_edit_others\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `bak_options` VALUES("93","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("94","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("95","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("96","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("97","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("98","sidebars_widgets","a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `bak_options` VALUES("99","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("100","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("101","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("102","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("103","cron","a:7:{i:1524200497;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1524232707;a:3:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1524233715;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1524234134;a:1:{s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1524237902;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1524283297;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `bak_options` VALUES("128","recently_activated","a:0:{}","yes");
INSERT INTO `bak_options` VALUES("136","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("137","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("138","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("139","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("140","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("141","db_upgraded","","yes");
INSERT INTO `bak_options` VALUES("142","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.5-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.5-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.5-partial-1.zip\";s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.5\";s:7:\"version\";s:5:\"4.9.5\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.1\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.5-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.5-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.5-partial-1.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.5-rollback-1.zip\";}s:7:\"current\";s:5:\"4.9.5\";s:7:\"version\";s:5:\"4.9.5\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.1\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1524196751;s:15:\"version_checked\";s:5:\"4.9.1\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `bak_options` VALUES("144","can_compress_scripts","1","no");
INSERT INTO `bak_options` VALUES("145","widget_akismet_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("147","wpcf-version","2.2.21","yes");
INSERT INTO `bak_options` VALUES("148","wp_installer_settings","eJzs/eluJNmVJw5+LgF6BwO7pWRM0bkzFuZSw2REpKiKhRVkZErT03AZ3Y2kKdzdXGbuwaAKORAG8xDdQDcw+H+eVxgMMPMmeoF5hTnrvecu5vRIpaqr/9PVjaoMui3X7nLW3/md8vjg+F+747394422mjddvWjauuo2viyP9/GHw+ONu/l0gv/ek3+Py0VJ/6Y74cZ6vPFld3zwlC8dLG6rwV3Tjudt1XWD6XKyqCf17GZZTgbzyfKmnuHV8JxZOa3oP3ePN344f/2qGBSXt1XxA9x6jrcWr82txbm7Fcc6b5vxcrQYuGfwI2gcxxvLdkIXPj7euF0s5t3xzg6ObLtpb/Dv+3A1fGg1/FDdd8NpOStvqmk1WwzlvoO99L6dcjRqlrPFDt7Y7eg4uuV83rSL4aK86WSO6uNdM3krB3jwLPOi66ZdTrudRTOvRwN4Lv0CL/zxx+4Ypnhejj7AeHWF6uPDo73dvafwryfBcuDHB3M/mnbRxOMlwRyfvr6gv8P3j6tu1NbzRd3wnO/Cg3F1Rs10PqkWVSHj2CpummZcwKCLcnZf2DcWOFVbRT0bTZZj+FNRTromvOKHpjltptOqHVWFTOU2vg7mpZ7C03VFHudW5G4+GDWzBSzcznI+acpxt7O/u3e4s/uUrhlMmptmb7C7tz2f0bIfHW/A1qrajS9xieChOJkt3K5/eOr2ld//+0fpNA7gaweT+rqiFY9XGu+IZ5Xmh+/ITi+cABnhvK1HleySvWdHdP0T3GdX7obh4n5e4ZgfP9nfwxfuZ34fLqpPi/WGEz++nl03dCf8cGF+KO7qxW0xa4rq07xu7+mSp7lXV39a1h/LCc2s+za/6492M4v5T+V4PFg0g1HZLr7ee7y/e/Ds1+V0/uXV8n44a+6+3tvgBYL1qu5gI+HU7x7/K5+J5fymLceV+SMMnWUNn0o5ljDgx3z0M7KJzkd9TDN6IKKsW7Tw62DRlrNuUvJq1cf7Mjks7fxvAy9K8LIDmVx5Uj36cA+7ZvaBXnMoAoR+xD01Kz/i349kQenv02pcl/HbH+OdR3JFOZkM6imeG/zpiQi3u6YZybEKvhGveSp7AmbsY724h50w7ZKLnvFmLEfXU/r3Hs3dng6rrCejW3gtHYS7OcgmOrLj5m5G51DX4cc+MZQ5Np8hjDKnBWbsybMHDsveswcPS+8g+s7IHnz276uyndwX9ve/99k4evBskLLGvZAIL7kKLzqKRddhRla463ktRrDl9stRtBaZVXoGc/niE4jncXHfLNsiebBo1OLqHlRHA1ZDW9zDVG4VIIQ/1qQxUL7Xs2Wz7FQ9wKXjQs/7dmYbHDz7STP6JJ7RH1PRwgbQ/gqFMJDLB9dtM9Wt/iQ2BfZXSGT9tgKfYM/A2vO+B3bZxkX5sSqmzay6pwm7LbtuUuFM8+NxbhdNUdIrF/W00sXYLn7fLEHQTyaw7qOq/ugG1NGDdBVwuGSzwX9UH6s2WQlUX3uP11Ffn7tUh3vp5sd3ODtjSPqpGrM0//F/aYN/L9rgxx/FWn2cWqtPolN1BdZbbK4+ic7Nt3JN5hAcibl6VXb1iHcq7NIOfjUGa2CK4gu7fz/GJ8manlnJac/PmJu8+tx/UH0+fVh99o7i35n+PFxTf8bGP87/SgUaG9s4AT9dgz5ZoUHpyX8fFbp39JMm9fEaKpT37cHaKlQ3fKJDD9bWofYkrK9Ej+CAvrePWThpki4DqFL8+XoJajMZ1StVseIx49WqW2H9MNCBqhhuba5JUn3RgeYeLyeicq+XMxpwOQEBvVLfPv776Nvdz9O38Iac2bnWsh7kDNCfYTUx0PLzrObPsYi5M3e0u4738tln8unfaCs9/kxTaaWtst9vqxysYascRmbI0U+1QjK/kLhPzcSHvzsXANqTeGbOk8TQI7xjY40pzW7lp7uP5ekwT1f1DPZXYMaIUVKUy8Vtg+YqR23mzV3Vwo4uzJIU3kDdLs4WfE0HT2hhVcpFRfE73r41KI8aA39FNWuWN7ckavEQ38Ad27/8xVfjyTe//EXxD1+NF99cLttZZ6K4dnhf7cAFfOH4mxcgx+6LakIjKOqZueeqgq+LPm27uLyFcfDWRWl6U3Wg6JpuAf8H469bxQhGfUPxa/jvZbfAgw4HiL8BxOasoM01W3TbMJKxG/L3dbvAyZuU+CY43WM4EyOOhNO9+gO+Hn68vq7QdCvGDWy7WRd8FfpPoxKv6uaT8t5OON39/t0r1MSj26Lsiq+q6TfVpxJndhuGtlN1O1/twN+2kl+uW/6lgImvZy4MC3ZTMpwtvAakyMD9ew52gX5C+OWnzQympca77c7AXdQ2k/DLfriFCQRDpPhYV3ckIic1TD5KPFoMmilZD7jsCxCGXVUVd7flAqRhOWmrcuznoxrT9fhrAaYLO544cSDDwklzAhtfN6CXwwfe3da4Hcf1Qq0c3MfycfB/Jt+ILT+6hS+vRG3sPz54Cofqq9vDbw62n20ffrUD//XV7cE3L+tPFXwu/NcvfwH3L2k/w/98NanpNzwD3bLi03TXNvBOWEnQAQvY7vjrrDj57cnvCtRJHQwOpmrZ4ch+c3l5fkGf+vum7BbFxYu3MEp4qn/+u6prJh/hIbiq8NFXNal680IbJz/YPtg+tG945TYn7Kjn0c71ZwrPcLUAPYxjLXmDyMX3OqKvduDDdXIO/ORUJXxm7/yc4V7EYwWfEMi8t3NZQVgvWMApPsG/hx70wNTbR3fVaNmSDcQ3BHPIa3RdLuC1VdvCC0flsoM/oWlMqnq2gMPSVtMGZ/p5/bF2Sjl61CltGNpxp8/f0DLTFiR1i2oe/wP/7xxNMRRduFBwDmZFB1KLxWbvGp+XbVfJEJsRfBEJabj3/DfnxdH2fva74FgsZ6CqYbXwX97gsMcJDyFvFxw6bAHQZJiFAXXD22UDD+dGcVfSTsD7N+Dk+UdsbMt7c0PAZ4p8ha0566p2wdsef8AHo5SZlhjSKOrrosYzLzIQh9zFBz98nv05uxn3+zaj7Jd/wJGeTCYNS6ZAzTVo9eGOYJVwXVeTMU3fFbgKYAOMPlRjniG4FbZLW9H8wM7heEwzu65vtj9NJzox/xCsjJxTcL6qYuO0md87JYzbZqO4Wi4WmD2BOcDpHsEVJLLsaLaDR5+Mxzjjd7DAIz5BCxSTJX1edz8b3YIAqv9MG+c6/yA5YfH5srNlzxYpWtTv4SHbzn0x6tRGV/5PS1Tic9zUfORwUODd1zM4BXDcWMS47FEHW7i+BrObJ3XZsozPvmcmp4RnFl8Gg11iLBMDl6qqO3juCB1fzU7Be6fRA93hw2d+GlUmnQWHBk4J/Rv2FM4CjX+FKD4fnMN735QgQNhazE+SFUVtxfsethyabsNXF8PLCmYf/tgdH8N+Gy7kn0N46W03/AjnCNTBpOySnfFHWG09js0EHj6vYf+Cwl/cw/LJqiSzgwp4PIVf52wCmEfCNmhJJrqD3IFNJmsmh4KFCGqQWxgtCNVqcVfBT27bkNrvmXSag67g6JaetFuYP0wJw4JM54vkpMH2m1T5id146Wf2uHg/g013c7soLsHQe8F/O2lvlmRT7sHndp2Z+Bez8fA97NQhLuHwbAwX1df3x8fDIby6W7TL0WLz0Ub/9HQlbOv6z7Be9QK+Gga5gKlH2cKSX3c3yJRy0nN8ZqklERwTnJ2yONw9ZIEOk87yHmcOb0ETqb2qQcK1KKv4Ux9+E+7Vm/IKRy1qLzBTYisythnXO03p5wQqrlwsytEtLQ1bjF7o3mLCgqd4ytst90l4AepjdBbO0ZQqulk9n4OwRl2MlqH5JLx447n7rsiGd2bSRtHQF2TVzl7WQGQpKsMqyiuYj+UC7VPQfSDiwavHjTmuQArCoJvra1Qne9kX7K5rZNGb+sXSBlmf6M+CvmurDZFNkSp3m/n9Ge3aU1Yd53jq8QCB5X5ZfmpmzVTtx9NAZ8LMXRrNqvZdE2f3RP9dgHU856XO2hS8Xfiw0Hgub8vaLVQ8dnb8xqwFSDZWnQZrwN1t8OMr8o4o0s4hGtqquWnreN7qS7JLiwvQqtELWQtfV9X4qhx9YD8QPF7RutclSKgxbmkUYLKVNaag2w/NzUUVKjsSbdYmZr+JAw/pejkVPYPdfc17hC0BfAmYuC1NAu6w0i8kLkmpa3mPF2T9UbjqGp5F3wfXOJvR6Q+w5IIbxg3ZMNUncMWisaobwutDWphMqRnYLCVNJUqJ+fCmWgxn5cchXjbky+DDF+Ac4rTCBe7H5uqPcEg/22ew7lp3y/MUfAQt/Hk1o2V6x3KjW8DM0kzOmtmAIhtk3dIE523y4rcXasfPTOhhB2MRRtvyzjg5fSlrzBJ9UX+sYh+Bn+uMHpCM7b1kam/QXlf9vKAFvoYR4FhpLUikNsmavBN3ZzmbwTbG3YxO86S6Buu2uq0xMImeTVnc1AvapZN6FD/DyQyKOoHwh6EE4cyHviI11XAGaEeQJ8rnGUQGqB38XLHhso81Eu8cJT6mNfD4vKk+LUj+so1917Qf8FEwctBjE3RY0LJtZmNUml4T0PheV9NTUEv0dHdUq3H2/STiSRjiIzdeTup58W3zaUOCvbgqL/jEwteft00gjablBzhR3uFCbdzn7lnNTWuOm8qbY6gkMd6IQyY3N4hLuQ+Mnv68ui5BTjuJyyKMHSFaVjVkekSwbnwYUVejKcGjZG18uP1MVNGi/DQkv2CDfxr+C/6j70vJm4aFWjRgz9rvTvcNivxF/jSa+wKzWAzil02DlpqTURfeLoaVKycr1JO1ZvBI6wns7J4l+5e9NDKR/Qr1xQFAeOiB42EftOjCt6CfRBdQTAmMmxK2y6jaeQ3HpCOJEj3yN3AAJmw83bbVNU5bsYmZfPjgy/LmETnf4EtOKtBVFOAdExRkzLshetrFooF3jp1GVVV2W5Uf7wsKtg/5kAxBflSw9fH85f4Oopwtqx75yVPKd+LRGOIkDsfLOcwJekYbdJT134nLjGdt3JbXLPjid7yfj8nlumqbO3RN7SreNs0HjB+ObotqBhsVjQEOspMCgHHLn4fy1741jKxf/hQXBtlw6hq/gyOFOpsmGIK27kNbuq1gPOT3uUNBghuDi8N3L16+ePfuxbse2Y+vG2OSYUSvU9ENjx+Wfyw/bT7qO5gswuUA8dSD6yNCHYQ0yW3SPkm0K42NzKK4hSwlPYPltgaFxiqknA3CMv3F7GZSd7f5VwVOr5hWYopzpK4hQywODalxt4YURrMFjs+UBzqtP1mzgvwq/Dsq5OCPC2dO5wdu3rA9bYxtmEwDzsFVRU4zHM0pfADGmu+dzdmjscwLaPiDabUozcNGzbxG2+wj6yhrKMUj/iGQhzSvzr4hseiCj0Y/zYqdX2mc71c7v8Lr8Idf+XDhusdLXBET7lYbgiyT8IC5aSNpZwzM4EfQqmu+nAV8nxmBE0PRZREyM5dFdiZ1M3vA38U4oQ9A4gLh5ISx04ww7RvwOR0dibb8BpU67k9KcNOqZQbAIhHjlFdtVX7g3WEdJ5ZyLroH0rGZoM+3gRP722oxX+8o0V5h0c2fSZKNAx+wtQdd+ZG8hYm8EVRPu7gCWZo60E/XT+GgcoVPFRWIqBl8OZyj0S1p8Ek5qm6bydj/XqO/Mr46PgbhiWCtvpkXf7LGnBmHuEC7ctoJnwGWdomWaouzVHWjYfenyeajMOF5CF9ykJ26ZYerxZ7RuMGUPUptdDkE0EaK0D+JvgAtkRk89El+Ncg3YTRjZ+UKh52bQEySFJNrt8TLlcDGAsQ5JoO9fih+R4lp4+1mB8CCuaMH3M3imXiG04fPpGONRxfkXCk7+89lu0rOkQVGCQ40Y1QYgCdffAcPwVC1RONJfaqbgPIWPIjv4NvksjQUALtwMqcrX8xIplAiF8+UMyov0UZvWF++GIOh70VVxmxT/YwqA/U7wjBQUYNfWs1G97iqGENqu1HTVtt/7LKBjdNMYOMhNXDBoVcwpRe0AdCR0agOzCB4UvQ32SWjtqpmYIt5UX+L9mZNmmC0hC0Iwwg99dxi61rDocdEAaevdX2u67Zb5Faafbu3b05fDC9OXl0WFKUtKeXGxiHvxDVFItvzGmrXTT8H+5K3vQvfJmGx7IddLWHyTGifcaC0nya4E0zKqc8he9OAZQ+iohp94LklqUHDIikJ7slKV8ys6i2IeESsalDaq0P+bPyJXvEFDRlW7QvOjFFeeEKZxZx8PfiMFLnNefjALy/5Eg1yCfk7pYjf2GM7FqOSBbP5xsR9E1u0ujPKGLUnxVdsLlEf/p8uJL/1n4vvMcfi0pEgl8u5GJIfywm8EZzN+mbmBSJ+jnWut+Ae3DBkhNE4EODAguW7F5cYWzt/e3Gptnu3XZyifbAQ8xSm/abhAOZvm+WHpji/n4EogMdsKq7rw6T+8KHevq4fwfPxzCNayidq2AWvPsG2qxeZ4PJTTZqC9IYdoOsn/+pbQ/L/YXjteBB6o7q5WQaxqNmi9DqHQMXooRA0Se6rCsGKVBbI0NRsSNrY780NmrT4RagJOBmCFskYlPYIhdK1STa3tMB01AoMbmlC17sZiVzggC56f3RxxdDa2CcQn1UdHzSaCWaSk+EZ54N0g9iZb5r2rrqpSxMD46T7RrFJGxrkl4nHuKT81fDN240evyw4ZLztljM65zTpuOy7jPzAf16Q4g6C9vvbjzGtkfWWA//Lh+U7hJyasHCnpiImZqewFViQEzoLAw8ykS2oCn4miyDY3X1nvS+toV7X8OrehZmePiQKNzhLWpw971KcfxC63EB1TZkTPaW5Y7T3WcfIp8fAEGEJbKEoKxLLxcsSLGEYOIUjMcA5rZfT/LHp03E/1GOKFWN+UvyNCzH07CYQ/clx6Ifm0+TI6YHPGVcWpAgfxuN4hcDe3H178KpMA9byWacXcXwM99FyDtOHjxDbl01fi43K42es9QPOxOhWkv1dFJpJ3Pf1LAHz+AqBqKhRBf5hLFufEujE9ugE+OiPSKTtg224G25Dly7s3YnnVUunEW2MmqP4BH4UV4uyypT7xY8tu3gfCAoFxkan0EwLOCIjSjt3Q4Q8i8XBAOjmDs2K+vo+DnXRfJroKZsFqDNdshb/MUC/b2OlE8EDi48SZQTpvH/XNDfwLvRFLjCTUM67/CHyX2jPxkvN+HFMv8dsN5a6HF94HTnd3y5r9MG20HGncwYzUrWcT4I5SkVydlSEFvyiU/OZBW7Zfeh8zk+B8fABdUv4se/lWGwqAmvRNOgRxrpEZ9Cv3BW4vx/QE2e/hmx8Flm0Miea435FJWusq4tNySqJV1hO3Om2hxKmaQ6O66J71B+7u7yr/aGG4fxf9rYP9kGR4Z762NRZaKQk8uDzAlcY5iH7tbZ08YxdDYr/o8k9qyZbPqmK2VIJqjH6ma9G1EsZet245nTFgqJRgzQ8k76b7Uq28a1ZgHbSHUnvrcDVm9TTmpN/msLFYABd2HGQxLouffI4HAfc4R32OMpHfogcPx4mJkfh2b+5hM8lP5AgWG3TsFG0xRNBVaMfxapmc0B8TDUFO/Y861jqP5cPq2cf64VEZmGmYOMMeLO3YEWBmLOnxaWD4T/X1MzvO454jSZVOQtAeuDTX+M+uuKjq+Y8vrSiOaCv1l8lGpJu5iBZUfJNFJGgLJ2KOXmXfWSPWXTVNh+qmZ5S2BQoiPE+MIcIKbb5yNkO33ydifc8r8B9B8lezJbTq4oCUJiYq9U04AiL4hJXZj5NJJ8GzZ+oyT1R0Yo30FJh0ns8/M7E37Iv8Ia7mI/XnB3gg8ApBIw6Iv4PIS4c49p/wAK5waTXp4WLdmGwg776G4+OMKJ4I2flnwvOVz0g8Yh2+os3duCvO380V2D8xuHY4T9mi0E1G2sqZVGwIH3gvSvep0GNbkenY6BZU/hTdVOO7gfjtpmjXNvhrBYOafX7nTHmdFCASRhXRART+mUnX4k1lWwqcWmubMYrc26c/4UmEKbYF2VL8g2RmEHSTyPoLQUu/D4A30L8ds3+UJ7jQ5XPOzNMGfaCyoRThSJbV5BtFhJFZVejODY7JYUn0VFL3MHmQ11JehG91obQtYqUZauPN2fw6jr0S7IfIUg9xWDzruQYkCb5CHUA2yCIYMh9oOjXCNYTxJz2WgFj6241wKmAu76noDmi/g+HtkrKFbCxOx+irTFkY7gHh48bAydpgihjzN6ZUYkMJef0FjQaed3lAubxCqyUNEeioVa/j8swEUh4Kb9qYBJQWLw/u/YaLVly6wiaUXPuwtEj1bP5ckGxKA+CJ1hxS7kzk9W7i0996a1yB7TtMAGBalVqejhFmAA+4E/j2ReMf3Hgl3XiCJQxghV7sr0HSqx14QQbk/0c3x1nmIsEfDAzEoAg/7JP1HjCVTO+dzA/hGeruSEoDxYLrGNF+q3ezghwmwuAxq69g45a0AmjRGWyUZ1dXLwFgwQFQiomfaId5PW4aXfu6umNw5je+w8Hp2HS4FbQMlJ0EdBOJztOMVqU/f1YTZo5Q2WXLUzfg1662gag6ock3iJxPcJSr5bs+6CmTQqDcChOQ/fa6T77ifFmelYkHgw0l32v3me56g+50GJ3jXWZz4r5apikxoCzCROcwT7saaBwwNB4fvb9mUnV9w5Zo46CFoxNFjZSmiV6PXXng/m0/hty8wbF+ObLK0QzxFrEvyoHXPH4ryQJXdQsgxIgdxpJeLJmQKtPI3xfdwzyneK2RBeKvREp1FBLi4KDakPjR92B7NXReKsPria80cX337EkNfb4FwpWwhod+r5pOcN3x+U9uY98MFzCX6kFN4GPxuKKIpkFhovqj5ULCCewNHk5PYhrx3wBIzwLlc41OQXNjMND+mTYB+hS2ftfO0nijKp4k7HrzbGlUxDRUttgn+LjGswxwkBjDCZgrl/yGePqanljA7bBE7iSqpHUEEttl9XyQpKGAQJ0oDnhiQcGm6HABtrgWONOPeP/2DBuDQ3PwqA5+KxfzDlIGg0WIdfX975EJfMuhBCAGKxa50dcuBI4e+4vCc3D8ibnC6SOZr+rafZSIphxQAX6/AM8oFbyYgBVjDEc6MTD1TTKYD+PH0xOuGzFjZP40fTfzXIhQSJG94JbLpoMZU+DJTvpc0u0F0C7TdVLR3PoHh/F+OWPdVm84j9IgKt4zjuoi/RiMgsumYyDMhJrVnwHC/shug3DseChfhTRTEexpkgUWrZZBE7fi31gLrLH2bFg0G81+1jDKnJZePED6yAGKRM6RaHgW+5eCnRgqgmOdyVVOb/lGl9OHmFKsGdMxvH+QqOSxTWDNhAWDcd9etVMMJIDOtw+5F11XY74jd1y1tZdtT2/nRfexFdrBZQTm10CSry720gH4/KHDsTOWWTwclDg3Q9Q7Aym4Gxi/c8fMxvR2o+nuMcwIumKXpwHIoh/To4PQZdtPirSh9G5rF0xbWDipThg5+3isSFfGE2I9KlgxoPcxJxiAOI1wcO+oiBazNgEoSe/+CRlKDbEiVd/xxRaxUvk0PImH5+NQGNhNlEUwyh49tnNrJFSR3JMjQWZQQRuuPCaswu8jTxuqg49AcJnFpoqZOFBP8C96YRReXRJJCZqnX0Ros8I0LScfBD4bvoItxyFN0LpCGLcxk83WpzLORqdgZliHvR/xtg9ZU6Oj4e4G4e8H4YMv8c6bAY+w2GtUVmgRwx7MpMJf6wohgcsHvN2SoPfTGjDibcl4ZN0P2YOhxm7S2GWlJUc1mMG8CB0nCGCBJ7Bv9fX4gNsFzRE5wv9cCrlk4viYwlfu8jrBleNEkWYWMeJQ1cwkBzRhlwBNXNOa4f1WuljKZBDmDyHGWIXOhfJ9oe00doOiSMoHhShxQShMppw8zfVVVvdbRWnt8hpUm0V29vbj9Kh0LJkcwHWLjGVJjMaQmauuIJTCjqN+f4dwlJnxea4ev7iER3s53ANODab4/L5yaMIaILhOJBaGflaEmxb2CFAeeE2IIwO/SIOsjHm/eCJnotWLOeMpq/KJewJ7wmOwMhixnP3BiEkCYn/lBASG2CCpeJVIlO4c/hc0Z7HVOo7bCv0Ulp6ldOnIBPghWTV4iQM69FkKG8cuukJr8banmunsJ2yzok2rwFIOKPvqjXjCfELJVXcFQkW21+2yfgxUSde/tJRymxgqzVtoIWuLzbBV5oX+49IEjQLr6XZf58J7Boc7EW/napS7uT8bJWFasysGwY9gqgn4kPNzTr/NQfLTw3vIEciiEbON4sZQVuTmDfI4M8aJQtG1KF8u60Zb0l5dzWV2MVmC9XWfaS2H7MGWNWF7DLop47rTiZTc5dKI1O6DE5ly+l6Hl4KXpmhzPy/a83tO/gY5crS5UoNw2tiCvC2L6kFBu2za2+2n/r4FPvmSlOKExuJapCJYoOJoqEnZramCd0ZsN497086Yax56fQwogv/usLql7QgITmDOgaHumZDQX+io1lREInCjiseTeNhr8JLhjDgxSWx5leTl8ClIzc0dA/6jtIKsAUNjh6Cif4O9lifLvJWq4hbIQ4V8z8wBD2UvCR4I/mz4BT4YHf+HSRb9c/DXITiuSlR9pomoV/AIIiJHYjC/1jWE1O1mMxTAEfumyyNl558LMdlIDUIQ1/dsOO+bUe9iiJJZO8Xl3cw3PvigpJmVTX7g4krBAC/64KKvrV8faX36AJRgXSjUh+qGk4SNxh6v564qH7+qZLWYG9dhNpbPu+M/fJOtRpvB5en2QlJ6gix0vi8bbZE/9PNv784++H330kOrW/xFBobrpv7kSGAMQlT5tJQ79iYyYSTv/lt8etJ96erL3EjIuB9cPBs7+DXLf6pYPVCW9uJ56GciKEsQS3kS2gECWUOIWaxqsOWv6FJ0feQnOOwGkJrhv8qOYvOWHZV8Iy4opwiytBpc4XlXhm/VRcUtmoG84yr7JhXOJ8/NtFrrqfwzikmnzBqMAOtebNKBYla06m0uR+k2INtmRlM6b0U5/NmwtPkCASR0klVttbI9RNHBbydI0xyysikHe2TLnCwZOVzzJnku0oqckNIFeeclFDm5sO7oG1LsCu3pFjqY2UJncCU4FMqFhOs2gchO6kXzrxUfH3RTZrApnhjYsNCCWEClLFwRPsF99EVJRVx1nMxt16AqeRMNfW88QNnZ4+Ls1evXnx38qq4uHx39ua74u3LlxcvLosvXp28+e79yXcvhqdvn7/4YiOSPhyJ4niXgIQ5GKG2lPdnukhRZ+WYGSjHLsnrXJSkzT0fQzlqwSZ2sa4VDDYhPtW+871uKBM5AKHJHFutw2F/gUxdX4BAx3AJQXg7xIy3mJu6c0r8+befsQSOApCL8Zbj8T1jQ3VRMFDuKI0ctDeJ33UBopXI5LFKjlQTVYyLSKQqKra/zEyd3sJB7Q+akhBwMlIoHfloCWsTBajeEOieDieGoigjll1Zm3WfS3K7pOhBM6qpEgVmvWVcm8GHkp8TUAf8gwXFvPC4Z41+UUDX+GYKbGor+g4OuRV3oL5iG0al/XqJsSBuaRk6OOO+oC9BKLGY8MawBkscvF40ekF69IbhrJOY7obir3/5L2czAtop05WbjL/+5b8Gxp44bb2RVC12UBWFhZ16JFiksTxH5zQovuvReRJvwal33BvIwWJzl5wf9Ub/ted2q7ucb9PjemYQgO9BGq+0PZ+rvMbnXhhhXud4SrwGD6V7nalEfRwnHFdtHjWBc2kRJQ2oZ0LA6+o7TI3kE6quqG9uxRitHTlSLeaz5AmZJtV3/fjhXHh03Ws6WXg2vNlhNKyhC1Be14EtfpItP8+QGZn4FeIdWMGJ2+V+2k63vw8hK/J2VdHE4fbjfxTBpnmRXHbrAZlswkO5IYUZ8JX5+Th0JwQON5QXMuHbYrPavtkGo2lwevIoeOVbk9Rgs4OCbTQjkVGJpJCcXgdPndBwElRCele9YTnPzghukFmaGfEbL8qQeICoD9tnH5w+8g286ROqW8xrRuwuaz7W5oUmjVZraJSEoH+8wUDEMikl/5R5VIAZSvLrWGWmv9WOKVVkUOSUknsxLi5mDdF+UgWC2yGgvX6D3DYBjeN6e5KiNSSaN7/AtVi2ky8e9S6MoHd6p46oD7+FE1jNxsN3HCjivASWkg8ldERhg8zdf2MaJpB3HKlCb2ukrjiFcIXbg74ijrVmyEPg1KO62M6HhlzpeAD3G49dyJAdFQWh9e81qmowiG5D8kPsCUomLghXbzKteCRKYzHeueQeFYDWwzOaggOd9BphGOoKqTTFkGzrSxMxhbH6qKhRLgj+K0f/INYYA4eIimPGDMmM6s19Qi/QjyWeVN1gCczFHGzD4rJpJkJiRIYZFtmjHNjOmHOUilgSi8oURtNRSS4micSQTXXz+3evVq1caywMW5SoZhelsxxziZi3aiki1sGxeQdvucx6iEiLKMGn+hOGnr5AUUSMU+gkjpboyV9/1oNe1tfpg7Agl+uNb+vxGJH4XJ7T1ePqqmyDF5yJFz8q0W/ZVDjRlnQG2CqoSkMp25lTTqFOj7Z6XGG1I4kFDWHRxN0ahL/EaXeo19B0UPpaIfG8m3MMFPSFJMtYhNvahDhTnFl1x0gA8oRQiAqzWMm1nATAHrQeHbqL7FXOaTjeXWSQhGVDofgy6PaRgSg5ZHR5hYAalQaGOZGGT7IRke0W5Wf0pSYQ4Zbej3oodP2uGlda6J5d800MdLKcen+2RWHPk/OzR9upCXy0faAeVOwnzW0ponFdL95GHIEGEhV8a/518cuceT9jv9LBqbgqSUMVliEuCQzg+feXw476A0Uea2FlHt5Wn4b0gD8EOVIufQRTnm6hI8EB9D/QIftDe3P1B4ls5T5F4ozzb766Utfh6puvduZmuSwRLgfoDKBIYbNkOLLlF5RQ5th0g4fgcsh0DYwBl+dgXtGowPsoj/8xvPnFrKNdy5lmxsHHzqDSGbLSF4pOK1/+2Fx1EU8Vepqf7sN3vaX0FMLTKE4ds6LTNJvy2N7ZhtNBWRiiE0tqqAz7fUfIRy0V63KjmfeU42YH549tfmDvOxsRZFM+FxtTKWqkBuK0uso6Z/7MbdYEHey4SqOegXe3jZ/3WqTdXXWVnn4ds5Gf+UE7KtGlXqnev7WDig1EZnooWmyhb+Qm1z/RTm3upO05Umf5d/CvXfOvQ3+tA0TrhnAcbNLxAyb17LScvWLcaiW+DtUczFiq3cJWz0ixw2AAhzoA90JP2fzulWD4O+dr8s7DsDFliYNsN5moPpqCDF+dj6koBYsBZGsVZkAkSVVU1DrHsm/ckpYP3kflzpOGMt9c05DWftmwW/TCTGhKsB1UnXV+aXyx/if+ixzM2DnmssWMx56AV0nKwSmVAp5JeVVNFOoj8SyhZWMYdd3ylR7n8o2nfTLPdL6iaoj/yNyNJz8MkSVm+Pzk8uQPLEP/ML+dH+/s0GP/kADm3UQxayIsR+0KxhxZaDH4RmBeqO7eXb6KIvDBwcC+OE+ON2RjSW8y6o4jDasowivNGvd3954Odg8Hu8+KvQPsJbZ3GDYLPDzKNSbTKNHXj3efPv21vOpr9xJsWXvdVtWgmQ3u5nCH6YqJzASutdaDLbOecMOfWcXtFnddV035tD34HgriD+Uy0zQcR9GC+wMvHMDuqTrugk79gv5Xh6Bgx/z4QFvcXFu0A2lclhIgxI3RVj052xXtyRHc7vLPaIl1QSbNkZqR24yBSq6xN7RE0uhMwgduTk7w3GxH+ex5OWO7/+sNsuiOUaZ8ufENNyjrCu5ihZl96RCC7dUEEcWqFTc19fjq6RTHvb4whb2kt8Mb6d3oNmY4fbScTMLAXVDMIr4/ft74HlYD/pvmYxsfeME/8gSVlOJpxwNGZxJdBY4WKwPZUttGTqMpuqDkIjJXpSGz5f3mmEy3PMx0sXLk8jS0Z4Ja4QLU1K1UDuJjetYHv+S5/TYS7NhfbnHLCSstwgfrFhOUKPIxEM7OE2KcyxuY/0pWTzuvFWxcBNNGn9yAd46+xNLvGQabuPjs5qT+wE8XD/6RbjDZb9uUB/Rcz9zWboqIq+B9W5wXZkIf4p4FlTygEFuuw9ne/t7hM+5wtr/9ZE36trXbbGn2LUNDVSoapla+BlK9tHT7OXLyolxITh2Lkuppwoef4TgKevRgjxRpLnPNdOvUPtmFcbK1IjpYZfYRWDUdSDUxaLfoUTp1zP6x8Ybzu1ZfKju99MVYX6zxCimXu6YmGt0CGS+KzdfvH7l9Epnaf4eOTmEPqwDppGX3lumLQys4yexzYkggAlhhSRiVHri4ae7FRLon80DY409KTlR9QvFFsmQusuShkTtYqCfg50C/H9kWwQKV+JYsWa4yZm90EjmRr5Fcxz8NnTeth9MeYsYMTWz7fV9puap/TGg4mD3Nnu0aW1qbj2SIs6NsasShHQy1txNN0GFtLF0kiNHDuOqZIvxik+PZFsPyiKSnwP93xhX932DSe0irtMCefS5VMO4kBY8ImmQZhEoJ0zx16sB6QUE22lGFkMWgqQmFyJdd5e/XKQ9hrL3zvv5Jzh5MqeDmQ0esJlJ4ixB9a0HY38AQ6VxzcMqn4syK283XBJN36l/y93pFLqUads3oJvUYtTL7OIZs0PYrtO0zemWCgQOPSiU9DnrFxeynGvjBjJX0Q1sIBxCZKqYNh0KsuUYxm0fJDNCmZ2SrOa7T7PHOPMPGkq6aBdgGM+SQRYZBZbHi2Ly+gd1mr5dXj+sixbW6XhBJa9bxleVX9yz2ZpowfUUBWYs3IdpblmmXKwuAo4VZbRSQAQVLoAG6uzmVkfA8YLlJJ7QuNLx+z6i1menVsxXKJafcqcHWbT1RaEROgZmnSPCLBNV8PqFtey2EkJarmefqnLOEr9I66dVv8cE2LlPwKSWG6axiI0weKWFjVzxN0ZK+0hTWM+uW4qkNiIVwPztzu5whqXf2dPnfKtKS5O0WibA7qjqvJ2Wr5VHYYFkTM3dhY1OZPVd+l32vJqodxD/hP+eVCi2q90y1YBzf7MNhZRth51XaUUGEBNrjEsX3D060B/4nfBc4rKuGx8VrY82LM3BSH4exwauKzbGEK8VaqCr0rO1Gs1dPOGcbihM8GLUGQ438y06DVjVjGHQ+r2ZO6AdfInz27sQakrBLRjP9Wg5aXiBZoqJUYnZNxtBgjipykTQudC18Vhy0XNXrITnN58IRjvlYRj96Nv969tExXIvPcy56ikGb+d0pYigE7U2rIZW2MecgbKOW888MYSJeWwaz88WPcud+HST9A2pyxkNgUT8VNmzSQanWqVuZazqi6mZKjw31NgTDLbbaQ3pGEGfPr3Rv8btAQtTUSRQLzUP+Xe7NllMfgpaTbUNSi+tfPk++h6xjpPursT61w0SEiCTleBWjnD6e2LpnN/jfj3IiXrGgmmUT7rJ6lgvk4PG8og5TuaYhRCgetbeShj/TnGO9LhS392SEbQ6vgy0UQKRt4DTHFuQbd//mPFx3Z1mqVSWLz1oR8/rSxtf1pg8ejAX+pSE+QBN1QeX/uCwMNMXQnbOkX7/1kqq/d5y1S4I+H07gOHTLSl3f99CMaWiJMvVtwvh5GnS+JDCMFJsnzQb2Uwjt30BxjNtRhnoudnv0ZUxx8xDJp7diXeKL0O9U7RnB3h01HLP9JozArgHkTDh7HuYCvsAiZ5A+UxAtF5feDoQHyOeuUIW9k1OHRDiuIXB0v6Ap8MVfoaP+jZBpfrVD/xImfeMj9+yh3yhAUAYvHN6uXCihov0J3K5nGcug05Pzr/9q0gk//uijFdnNnoc3KBOfpfngKo6qxEzvt446luISAl0oY/BCvAkdU5Omrx2U5HYxnThuwTVIDjU0i73Y6STqLVighd+lQOSlsWWzExDQTyU2vXh9tH8HeRbV2GOXHiurREtcrR1Wf6kJ4/S4aDiv4bUJJmpjH3yp2NjkipLs1Gsoixr7uBhEZl27Rkn5FHhRjsO6UptzkS2tNM0Utic28XgUl0RDgVzSbDikFXbOng641BqKmPd1pk2C8/a4q2QLCtMjEshUOB9pp601WOOwtg81zXIuJGQZucolFcn5YKxKpCImvi2lC2tzO4HKHnPaGWn0WvWc3aAviIInSa4now33fbUgxihUoCCsBu/OT7NP6BU30m0g1ZbONb+pP1YzZ51ixZJvIdobF1QkAOgVsUjwUdTzjbG+eBi+wDidxEVtW9yMuxGs+sHn0OiR4LLZDbdcWh2CnB2jDHmEnkN1mkpVlkTMyrk1PHTifFSZjeVmWZm9MfepwX7jpIei76fRu3m7KaqD883ebMFdA4ZXC1t4lqm6A9VOzVrHBZiMiDm5VkKty6Y4cX1nI9bFnqqGdDIcNrZruHgWWybbQ1fy5phQA0cVss5f9d5iBndLegtL94YfqvshtwLdfFQwNaehEy32Jf5IF28VsyV8HW91h4QNWIu0BHlUt6PllAPKvXX6c1Z8Gj7IkinDIK6xEpxUlzYFX879B1MNFrarKZE6FGEYAe52XtaZKbe445QVk48lkkx/SzVmG1vFhmQdf8NdL6R3rrKn8WJvFKNqMsl8bRjYJqouMjHgZpdE5G7eFNQbeT3/idMncshIgrkS6uCwr9cwKtoBXG3DKp86SGhT90Tqvi5nMJmkkcdld3vVRPWEkhV0uT9MlqtfbwpSA6nplb1mEHOFJ1rtdq1ZQVdUTdKGt3gXS4p5/kzMs2GUz0Zef9c2y7n5HKPf1YHU1dvpIXPd9/jFhyXXu7LWQAFz6hPL28SQck8nYZsXPBRDhBsMJd8Zd3oRlL89bwxxaxk42OTjoRn7vpesCKlZmWtOOuqhbSGndzkjs0/RL25f4IcQC6KG/eWKoe0jQWePSSUoVTPkp7lrwy4PwZR/RqXn6pyUixyUQWZqF20z1PyrKhGJEoxKZqxFAWsaBHPFrIxiELnnudaZJmLam0FzDn7UyZFrhKXEVLl2JColFYqZMbjgVF9XM2RZWzl4DklPVXBMsH1ACh3ozT4+f/Hy5P2rSwq/4XnT7d5kg1mv7y/+5VVxtP0kU9oBmwDXBFRMw+TSHDp8V3EGH33p598KyQsdMiEqGcD34o/S0ycz4i9O+Qnnb+mjvgg7maF6rw1qhYIU0+5mtPi02FCNwU1GM8+WzpjcoqmtrutPeosWkCl5oCtMTQpOVhDABKcZTR7cOXCViyDgoGnD4XEEv0rPrVHiK94XAvlzQsQCzyXJT/jsLzrqpIrIti7KBYjB2nh8IGPpaPeHlVYu9ECwXMOtNAXt095T19LldK6W3KWQMeMVHOb9IiI8xget+N6HFEvS68fJZmMX6jnWznSBVswARA6399PinnObQsv2fNJOtRk9j66mLdH8HoySjqsPKDzp285lR7NuwYxbHm4jqek07HLF7Rs07koNFzA8F6aLw7St47OWg42lwVzOSYZYVM/ZtFrCXo13NJIhjo0ugO649QtYdApsJcN+UEiw7wsJ1vVoNK9i9LiqJJKtMClk9IzoY4RlA1xI9uPxZ1VDMnm5MzKVQDcIOhOnCzqpshDHHr8SE3K5MaxYJ0okYyjlzuM/V9UcP2P0gTplkV2qk01FEWyYM6UiOYp4ElHmUSGC/ph6jIVbtZzXbOYSTDdeau7sqyzK9kJeX87WulVmhGhP/coDEsAs6JvqrrhqPpmKBJhvanjKGFMHtWN3ASkMrWG0XZwy5+bkPnAuaA38xTT/V/dxZbzZoQfbz8yOPMDGnUFpC58lqeDXbLCyaE+pktxR3fVuT1tkIdolosAg/YqoSgdIzCyipGHv+aLctzxx35I/U/Rz5mCF4IupYNbww2dFVWJTP6IFUx5/WC3J/bn8WC73bP0lbzRF2msno7oKmhd43m3TMd0qVXnlCL7J2BejMqnBkwq9iVDMbbxsDcHMRrhxv1oVQUrn7YQqlIuruoGFnN9SXpXwAMJVEnSUzJ7J3PppSpFMUynzMAX2DWWH5SBu8cYjXwNrj2fj/uo9QtFX0llOkdjb07HiGDhSZYnet1yPqmsMhJDPjL4YE+Zu64CPktIzyURSdJFOInUmaokHPuj9bmPBjkPWbEQuTEEmJJg4QUHEpWLdbSlc5DbijhtpeRXy5fWJs9wqcBB5UNizoTA6B6Yyn0WMTU1L2VDfRlciNpLM1pjLI8clVOK5d83ih8PnZ++Gw8K0oIVdjOaHb+bI0V7EamIVs472IBht0JGcD9UP5y+QIpfjR122kopQ+L2VVPuD3aNi9+nx4f7x3tFnVlI923eVVO4la1dSra6x+dnLqA4Onj5cRvW/yhA+twyBK7GeyFqaRRxMXawtX431RKqx8vG5uCLroTdkq7L2DnZ3fVnWZX8wUAM4t9VkTnxXUd6FqG7Ro/foLSLC+fdSl/XVWNyN8eKbS59Qe9cgRgP+xr+Nv0EqHXYROINIhBfwSeDmwNbwH8cEiFx+5R7XbRf+2Xw/wRCpN73r/6qmqovmOB5qTgtNQ5ZJ8qthZDr6U0TOCouPVfn42LaZBF9zwh9CCHCXs6MEDbVTI9u7RHhaOcHGzvfWdqPYGw5xRtmTAOvYSmCV6rO4JgzT6f7Twup/2/3WzJbS/o6oEd4NNeEMPtXuxT8tK1Ke5uteoGlmsqO3lC6lC6nARRL8aAuFCzMmvkj8LkbyNB+E04Q7Po2bLQzUUIP6u7IWqAquTDi8i3pcDa7uBxeU7Eq6hwRj/SFK8W4V980SJo2w4bdh8DpmQ3YrwebHeLv4Pdw74ga5IGRrdgQIDc/M37OqcNxP9GjU/VvcfoiS1g4rITkR/IU6j+C+iFbBkclJ309rw5kv7J9gMA7g7DCPCuV5pDxbI56mN3EZENfxJvP+HsUrqGCfbJnU/QuX2XXsCwMslEHAECJRRDdcfgjqsdLPhv/DJddJ4d7e490DLdw7soVlf4vGzKUK1i9W49oukoXDF2++P3v39s3rF28uN7xtJUThgiFX3BoyYy1n2vQMJsgetnOk65CowsKU9W8g1D0idzhTXsPSmcnW+/cQF7GzOXcEP/3u1dnLl2SC/1vWz2kaf+PtXPp7JAd3QxknJTfC7MJquVJqiSU6gT0ffh13lPNRefJvIzHZMLJ0GhAIZD/ljrSR446V8Bxn5Ak12RlaUKJydAB1S3/x8LDDbkkWx+BRQwJXyD3M598tSxjNRZf7/Ex04mi9irfwOEisj5jYqtEHibLwys2xcl6W0zd9ZbYVBY2mGJSInEUBykJg1Mw8J44U2eTCkQg7ADd+AHcOulE1qzof++BwSBXSk/CQRIDjGVdaEdmHAa4JFfpIGyhgYynBsZDdZJsE+vkOD3FU/uqC8IzEJpjouHpdkxHPFqR4V84ico4a1h8I+75vU+oY1WIwEbcc4qiBMFZHeOjMbEZovA6D6BTyAMfz7HlBnbjKMVWLkwZp0kT3v5CZYLuXKqacB0EyAmEIziEZgZtkqV/jRagsYEkq9cS/YCFtX3/BK0aVTrnhBaZ3NEa7WPjcFyRfZgFRuR6w9JkkaDBOokEorJXBcwMPuac2ZFX1Af4Lpr7utvwe4CSi7L+gA3f3ocuskcXaJaEpXZ7PLbe0FQcYDiKbhRCYLFZbAROEiDotZ1N0GEN+QnxYILoyR4tpxbWomKAyzFDIwratqC0KSblFrFZgKj9EBZYqFSw/mTDV01Gb8lGTbXbq4LcRXBt3j0c/zOMnXdzPFuUnYiGeIEuDON1a1idhGu0YZVrFrKrWNDBFzycatoCXmB1FHcmdJSQjMYiDDKw+Pah7UsWRbCHWJLkn9VOwfLucwCYG6wY7jqrRwI7mekYDAzCmQ1x6m/ocjq43KFVqqnskDRPlveGh3vB5YEuwzV9RY91r2xwB1pDpJdmmhx/JTNvCv4qbzC9hYysjYDrxkxLhkkIY0p1sQSVcw0qilgkR1YtRYC+WWvcW2oZTLLvHEbpyMjZAzXFMZpYifaawU65r8VtLxal2C/Qq6plzMPNjiAqImPHSf51fMC7/ee2aAWCEUuBxGXP+cE1uj59QEJcjvW2b5c3tKk3yPEJ0BdVxgur0SP+QnZCCM9I8rp5OQdmBZnPJRa4NfKgwxc6jPyflYsFtXjH/1WserqhVzlCEZdLQa61BsBemJQe17Wz+FkUPgtl9S8blnMKNHxFzoSCb1IiMQ5Yu9m93d4+cFcxgvk8WBUaZoxHLQrNZ6J9e1xcr2FEzxx2wnKG7Dn+Y3Ec0rhIB4gKEoKkRHZ1egLdYAF1vo6OA4wJU+d2D3nSSYH+4WMmbl3akL6tqfIVhKi4QSILPUwEvYMQJdNa96Wpsi4uIf09M3SkXIFEA8cESI1BYH2tWDtxG0YFlMUPOmCOiY0avtHSVDWHDMOZSis40nqi64zwYrii/E//HobipWN+lZbVAyPBgM7sh18/LmH9yjZCeCo+49jJDkk+OfBrzr32VNvqcRdMUIPer8b33tnxvQY9YVQYL7i2TRDB7no7S/w373xl/gBUsnQ6fpyUYD4XSe/Ilq6onDNZZYduRfuy+YBe9R9qEBk1c1jENe1mKeLuqKKmHYyilyOw/aHmZby6amxoXmmhdobIWXcV8RGjRZZ/EIcdGfRATskIf3ukE/AdqAVLXkpWnlkT4Mu0AtXpOLEa9IVgdGRJhwRNLeOvSeI9PHvstRthQHBgrhoi4P8F6ocWSq3RaablypVbZiT+PI9gn54MckXK0WJpgabQL+6vHrI9DJZJJ/xeOdIE6bOcratK5dDAuabKLHr+OyIAd9DTXsFCTu+tVGAcZQDsIx5fB/UlR4XCBvefXJyF92lCXFSrA4YBZUNh01lectKWbppL2Lhqf+YJDJF9swX9hsusLttNRj26hCID9MOLaQ2XskZC0VkM5rpYSlejvfzgTJZqAByZIJ4zJDpAIBMXIovoljhVo6nzHwWCPZKrCjN1mwu8s5Pprr+yaPqiTE5ikbWyKoR06zmydJ4GPv6lkKMhUa6nd0fY+TukIW4QMOMM6HVwhs8mgrdC7GtAwBjJPBInoq4MJadmsaqMz7qAuLy5/R30kMqVIhN9QV+Fhk4pnfV+hUT8VD2+4P4KTXI8+LOdoFmWqpvrjBtcUUdbkeybYbOIHZICKL5lBQOGupKpDtM86bCzQH5oLt7qFZyX7yITIOG/V00rU6K3cYmPMaVKCasJkDIfNMWxFdaEmAI393YXejicLs3AUPDkB79URIG3Em/sBdHUeX21RUlEob5op/sk4FPvbjz8PuGrnw9k3KPS64qZZ+DUM5BPiGr3jsLI61LyqN/QjPVed527PutXnFDdjYXOD1T9dkZuAo88+TpSPayaVP7iZuEpgI5GMER0/A49LAqomPxTAValbpwhuujVi6M9l+K7R2ybKxfJjU49tBRdlze3zfRsYfSRbW2CRMV+B8e6zm+YwBae7PsOwOOHKkbjFVvSE+NSG8pjGVGMY77lqsXYmjOCF78z0uhC4ZAhLIuNf0mcoVLExTiWsgTSPmK4nK3Om+SJEhRKV1d1tw6wTHorQNkRNi5yZy7aTFmH8rml5L2/Sfc3ZbO4bVaKY8B1tgo85WBdP/8LGqkGuVPVHxVeleyAgTm/Rg23zCb2fr6FFf4fok/FHFExjjXi/5G8QLFDmeWEfkNflqHh7UfyZxUlmQ/77aj0RrO7abYzXEHRgmLBu7dN4mEQWIrZE+GU78YSESytC7KWgVBjazu3VIiI1aggY1GXBkN/xkAm7KjtXO15iZA0HJopcGB8p+S7hx7HpmJ4pCmAKvGxMNCoPCyssqyG6n8MFAtsWtrQSKxFSVEpvAbtOvKPndXXHQm9OW4TQOQGljQ3XS+8lNK7htGZcPLO6b8CV+A6JUDADQdVNyWI9XOnw0wob2GL3HTvtrLvwMzvYlDAL67ept1wtVPyJqMpWdEnlRhdqO+1B06Py0qLA92cJyd6p7J4Laq16WV75olqttCSMw20zcSzirW4LBc7hXMaVNg4R4GZJqgouX+P/MjFvM082FE5lUCTOLWIgJ1T2VKz0rJB5wec89O/ccmXfF7LJv+KWKz9Drw6MhoJFBWPYOEEyz414PQbfhAmzzeBfhB94RPIJwe+kuZlVIYgd4Fs2TqnGCGZkI8CkrP8WcsQJIUEwDi5kM76HvokiQEhn8ArpEdDNCIUIeSDUVAuZXzbokeKGdIoXIurgmsoJyunchx4xbELunn1nPs8k/Y46fzirT4Jd9LnUTJI9qRMyGA/JZMKH7ziOBDrlnzOR6UbbE8/4VESkhpnpkdil4+nfqXhkT52on1qtFNAxqbUjZtQXu18Um3+u2uZRUXZeDTrY1ghTXDmTMK8Y+b1/eOkt5uNc0+sv+lpef8Gj0n58X1y2dSXQW6TzUMda9CvR61JzbuZmNJUAX/whlaMB6kED+87LNBH+zavlhFI41SPJ4n7LXpfUyavuSNHXPf49fpNz3YP2xIrAs1u8/FhJfSkDegnhgJp/h043WTZB7N6YmJGF+fxbZ2RiILzXtPzssq7fYMKnu++Qc1vbCnDhkcv3h0APimpSYyskk0gXR4PeAz0sxibfMvrUcE92DhnVuLo7i442XUWDc3z0P1Pp2F7gmf6E0rE1q7n2ovqof6/VXD1lWUfb++uUZR19dlnWoSnLkpesXZb1cKHNz16a9WT3Z6jM8tVIe09cZRlo9PsBiZ1sDdLeE9cRCq8sXvGVQeVRz9Oy9UZPn5kuUJfg0LApQwltavIgjhGGWGZXbVV+QJdUciZKm0/g0Ga0nGoVzReKTnB93/69lB398hcIAACJQy4eCB5XIrbFqAoUPiJSKS9I08F9AaVxBdIgUO4e3k+UCN7fRLHIpdlnz7HtExKuUyNiXyzSuUQOYlbgzN00HIw6e47vukPDr62osaRW2G0JV/L1vSJEHQzx9cU2t7iqNSajnOU8cOfX4tWgpWSQyafMtri6prTDQ3ffxcSpAqdlK78zVf8Ew5DHUi8HVpk4qh80TEe1TTwCKrP5AivkQYZ/sbyZ3H9B9T7OCd8uftPcYRuqLY28dzX5WPSQe2SJQ9dOml/dNcvJWKetE7WwnA9AWPtKFRqMq9DhYAjV626ZhpmidHj8aACBdEBcMaHX3EyGC0TGVaCRviqpDeTXGzv/hHM4rMdfHz073PjGnlaOVd4sa8zRlN/kO1I9ffKY61r2ekFrYeDLBYJsGFX1iqwPnpaTK7hyuahoKHxGKLQb1ZCsX9XhlNueh3atj+/5+2F1gnGtTfil7YzJQHGDqsU4uvKh0olBoTaYOFE2VRz5gBLYtHVIiCWGwN5nko3YLqZEvkLbyfUUV4HFvLLapVD+6nqVh1GW2eiWSv7EBfFchqbpgZeOFFeb4Kaf8MaxFjEVugVbPORZMlQKcQAuaCiBTTdF4BCYiIhh5j6YpFzQnUcFFLNqgdYR0sbGKU/n33DGkLYUlU74lLmgFMXFcURNykCTLtvB9p4n6KB/Pg3/+cSZkZ9lRIavYE/0BwpjhN7vgbvmqPeafXfNYTg2liPP/VETrhUC0Sn+Y0KlwrBaIy7IG1flRN4Ay1FPl1PHiqXW47Z7w37PoPbNoPZ6r9lz1+z2XaNX8CKAT1PzNhMyGNilpJKlO8xsoDTbmLyHTQPj1SfwujnQOXuC+uOTnvfvbT8FR0Eu6lslvEiv6VulPWRCk2t4lVjyCEOCXPNYeowHZDf9PbHleQfmeXFR0IHUAjGQ4sjd07dwKKjkGvPUoCJDX6whwm+XNxiOF5tZf+MV1dyrd52vlkTj6PQUJjVZ+AQCpbZkG0jFQVMAH12cTLrGNzkxNxnyqnrmClKzjg0p2V7HZm+wf1DsPjvefXK8v/e5js2uc2zcS9Z1bHrt+J/dndk7epz6M/+e7Av2kvZlPkbTbjArP+YdpH1xkMA2Lt7gRaFvlDwj6xY9xmlS1cxFY8gu+bG+EfyK4F+2JFN9L9YluuTsxM/uGYL778XxsXwL3yK3wKiFM4jnuA4pCi5usRNwyb8E5v2tsmOnVfdXZWumJ6Q8cO3w0AnSiSIieH5sx/fTh3b0clsDxZF2ab0yq+qb26umtdE1M5LnbTMf4OEDzT9bZr6KX8fNa+HSCZLTq7PDGNUajCnqP8aPJ4j2OHis1tF1xNk7IDpG3QYcPGO7q/6zusaOW/uaaYofLmt/+mzPW//7vf1S82D5oM4Psx3aMz7ou+UqJ5O04np1Gdga/gN1iHd7CV+IOjdIXmMbejoRt2U3RFcLy0QUAJz3Ifb+nToR+2tb7P+GXkRgjh6G5uihM0c/I6fxh/+IDsPgGwJaoOf9BxJLBa7zgBgcGIxF2fFb8r/ZnsZahDQ0j7aLjzo6+PEG2cIYg98QqmIGVDODLaNzFRlGswiSbfDm5HvG11JqVHq0ufJ/X++UzwzQif5CeJy9CyDVS2mpEs3f44eC2DZy/fcJTtM4jn6aW2EBxJzgkPzs6/uzi5PX4P/cuEJBB4PF0SA5JajIIQj14cgz78a+yqH6GCt8lUN1PFb4KofqOrh/7v19fZXDFT6GH9SzflfFPefpalflUHyJrKNxuNKHOHTveNiLOPyZvYjDn+BFHK7hReR3y/72M2GQUz8jyBULt5G6Ek+MK9GhuwCGDydenAUpbLLuFp7mi4Xmr+Usp87AY3YG9vvTHHuD3aeY5gAL8XA38gYeP+QNPA68gf3PynPkTNef3RPY3z8ST+B/z6YGU8DpfFLtbMjml3MsdsWxeI2Xx2RvK56VdzCQt4iT+10ICQlPGr1MuOFFcTAvk8Kelp0hnOQ6aQJhwW3FZj3lZEe5HNfNFhJSkQ1SLUbbj0KX2g5hy/VSuJUqA2Jb54f7BL5zqYNYPyhG8N9lAATGUyjdnMdCXxR2vsIPanAklGJGbeZfUselfy5h4VDAOgV+1tA7umGsHXtDxHq0KG+2/Fzx3MhsOvgvtRWxL8OPS4dcYtCBTRgCIvL+HutDY8QCPuRsIbikvnknJERnuMS4jjTYHCCvl8QahYxv3Yri5pxbsf/k6LGSZe1/ViX8Z2JLiBJgzJB0LbKTmSnD3b4Cd7vWwCzMlqrWcSjo3RFXszfyunsCMTcCdjOwelrbFXi3fzdeyOdX7fZCgjd4Q7+qr1okUTzpuppwAhuK2WTeaI6/Ozxop93VkHcsrIMJqoz9fHgwdjklaDN1T0Fj0jXapfNP2HVH8TA1K5KWSTrErg5LdQ8cagwi+Rwewu6owpAFdtgKNljqz6+AO8UgWOn61/3EIrd/IzeRUKfrdaLrrRYjxhC3Oq6id+Nte1POahDA03tZQkELTEE53A7ownuQrYMr6rjLTk+3YYgiljNhv7HOG/bw7CuILd1BJyoTd5Szn712iUaW/sQ11zKhP0oVuSH89FqFk3E5V3YvLg+a1FPYrbwPBKJTMq2GId6lOnuH3ie1h0yDr188PzsZfntyefqb4auz12eXHvyD4F7fAQ6mjDpAZiFb+94Jo3/GsGKeJFtIjXU7gfLzLQi40m7juVPl0YWRWt+gAEB9M0O2r8R5dV8TvZy3I+0LiQEEBdO+rD/8zt2vPjcs8jIgAlRopOPkCSVqx3mH7BxLwOZ/Glzcnm9B8NMymvSQvoSaRAnomv6s5767pj/rueeuOQw28d8360lveCDrSdesyHr6B61Me+IVz/piCfhjXyTCxxI8vLo/a+mR0P3xBg/v/HniDR5/uV68oQeduL8OafzB8dHjz0riPTl8YtGJ+59JGr/SM/z5M3kHzx5GJv4bGvWcuDuSOQDXZcDMa3kX+0hcbLQuz+S6MH2Xe1LWwUb8FD/CUTpQhswwYrv9tV280wTbD+fm5cWvwab8kjZ21qF6fLSr/tRu0HoinGiUL2pT6/8d3o2wi57qxmFzPfxYtrU4gtWi/FAxbsb9NVekuJutp2V/AjT+kgwMniYU7fQs7lcmfPtZnv2MAbmr7mL8IjyRXIbwgjLCjTEV+cWZYkdP09MZ0g/ug6cC+RqkbncbWoVqL7+f1X8CtfvPFRWiyL/OGCNZO2oK6sKd+5R9Ez905caTynACMoKec3oJaSVFD0quFlQMvC8Al3fs9bxD+X81FxLut/IKuY70GawNpLPNolmQ488tSBboptUoSxUVtre92yMVYWv2SsWDwd4zhDYc7YGoiaTik9VScX93f3/PyEV5zdrRzPxJ/vkF4i4CnP+NTiXHFeGFd00zkr5uAyt+8n0l4L9tI7jXwQ1hnHHls7OC8ODxEc7AnC3OX/+Hp/t7j7+8AQ+A/vPJl2oUTuHjMKftm98whICsw/tQiFYDHYFUyXMsyqFf3b4BCTsnCYubR9jJdswH7Gx8Y74c4bCk54MHmf23gRbz1xuzhrHncDMIDgLRoodFxTUoFEzs+vAb0n1BcVxFUT47404ebnY1RhG2nKjcYtIJxD+r1uOiNXrii7K77yPsIJZ3ea7FmbOnHvKk0cOwB1vn45PO1bA8kmS6YmQWnjxS9kxu9g7WrXKwEl3YBLsQyNu46wQ7AXXrHu3vpi7keAUySmD/xQV2gVDCS3whYf8p3+p1BxaMBTqDJ2XGPTq1G2mJkupmUgUzzu0D2b5W/I/Qq9XuYTu0cre+GNA0FLUPewErM+vY9KAVn8MHTSkv/LGiLiHxi6ljIjlblbt3u+g7hKiT+BTEAZl5M6eW0f4pW7415zFvSt1+6elQqaq1E7SH7PEY+OcOgmjejmHvGdgbrhhL3w36pMROeobMV38rt+OZ8iv6bzJyyuEMkHZ90N3W83n8+/ofcUk2zjtqHStP+h/wPdjyS+XwT12OC/uM/wHfIGd9IIHFn/gV2qjpRMOT/yP2llSEtT99Tylduxk/C6j5N6+kggVlPjNI+CEy7o36wlWd9vGJ5QjqsX8qXPxGqR5/1slJvk8jPkET2sy4c4MNle57gtmfzbhsJhDELwn7X82xYoz+b22uKhqfbcAAV2hldLfNfAvMEwqR3TSo1foMg2g+BJeK+xersQKT4zMWPdABryn1RiaKYCDnrGm4mSsXDBB2iR/FmnyBOl2KMjEr2RF3Bbs6DqgZtsJhDSXZUtfmgmvIvN2g2KsrW3O+JQUNnCkhFiBRqveUXeROocxuJMSx7js4qYrucT1bVgrOFHtRG7SpzUhWxew+Xz5nBukwn8vOz5jLFRMfBzYw23poeeFgLafdzqKZ1yM4zTehDbn2Ghq8wnIabuHn4tj4nUv2sunx0fvUOxMnM9f8+mbxZUF5RP5szOtK7r5r+Ns/287FxNBNRQvoEkJp2tClZ3roIDj06VGrbUjk1bsK82ULXleXmfEYhCzHhHh1/Ry/lkiqKzp2YUPq/M2jcvPfO9/CwE97i8LXrhDVVzNf++cKqhdLpGdsErfih1eRhZbFUwv9Mu38vS8LKtdQ5SWVuMn82xsovRjc0LMq/ob96AZOLiT/42/Yi/TRDyF+g0ANVK/q8JX9mxl3qAA6S+8F8iLmgmBP9vYVrYz9zp9FThfWYTHy8E8Lquoa4U6ba+aWXB0xMzjwnnSb9JNBhXBSRUtb5xQj/xyIQVCnfyrFtDJP0FMupIIYCisXt66uU0rflPkQJ3h/98vnbkjjhuo+kaNGn03XwCKMbptOssturN0UZ97xCxoyHhHK4eXuQviud5VgzAOuh65Ex+rKyt3CM1VSZnIySXwy50bh+jyV0FS4QoZilXbcrycL3OrPsk+I7peOdd+WH9DXUiqCLPpAdyx5Xkqt5fhu8FulMNk31lDm3ZlQ/AWYBD9/30ehTf4Watps9ZF7F86TD+JwStR1VZN1BwWnq0tPkz8T3MgcYewEopzJiMu5hmdr2UT8Pfo8W3eoDrX/GDWYT6WQoNKLHGWh0PgYOdHnNRQD0kOix7HjNP7nwe6X2y7+0xJfOodd/QnAGILUYKTb9btJc4Uzy5Uqjv/H78x7t9au+RWVabqAc2YN/5MJJP/n4qEveleJh3VVablfbPLYHhR+l9CijWNBwGNEnNAtSCtqocOMwxruUNFRvKSr1WzVrm8lJepNyylhqlY2GjcvTPKXzsMaixmQ2yikngLDUSQ/XbDXChzDLc4rvrlPNcJ85SOZVcnw6ClCIIfeqfTALGu5nW/HrVzqketNdl23nd8xAr9CuEpOlDzJCaNqHFOBTirOdAoWke509paLRH67RN7zrNB70hcJDIxVVD9O5GdwrHp4yZK2J1fmjouXYBv6mPGq7a4ZEDxACDRhnQPbulqwknStzVw3FRqi3R1qnuL7vy4I1Bc+nlr8IQiKV01JGrE3BZHF0uxhV2jusyEcFnTtpquUqB4Fe1Nn2u0S303BxcaDLNP6IqD/0Ks44Zmub2bYOfC6ctAGlbRu5wUvNSJAu8JwlVbVDsCOQVupmo2ZyEOZN8Ix+vh4Ww20nyYXwVQLCduyIVh2uousocdNezlhLxvJmCUyeLMZ8zPpGMMCQRWaAIaCLHnAtplqMspkpPK77nBMN4QNhmdusZnxs3fVXrwvvj+5dMuF/90pkXL1CTcdm3nNkja03wypzLKPlRrCayINN7073IwJdPG2mbMZWHd8qnZc1aKJUFNlZvEtrO2oiQwVHThK7llHdGcK5EQgCB5M/yChPvh9eds0rjEdNwdyFoGjz9K+HTU3mWZyNHK2jYa6gHVVUoROe6ThafOGTchMT7yNKq3vmoKpzGFar/g2LFIMgvO8y0nsTO8dZTLNmTbroy9QihfXUySSqY8jmdoTLQsyH7DAYnUstHFRSNO6KK8ygw3NLUOCv7ya1oJVpY4pVAvWZHPaxX/64RybRem4/rNJflAEhxwLxY/Ny3v2lMHXbsaMGmcGeh0Ed6WxRPHaTndKFbUPSzQFYxld11jRY4cfOgoMjvGa7/n9rJyCW3EOilir4JKXd6E4RTEaGAWBTNV2pbY0Tp+42ixz0+gEMR731sXDr7x5gdl/Jt1rTcee8IRdonUjfo/KPXXP8N8U1SXXaNGMPpi9czJWlnXSpd8hLHgWegfCj+JFiLFpCKI0p0ZqM9AXpqOiv5w6pYatfXlraPw2vxCBu21VhDRF4Hl8LThny7ttIA3JU6Mgu5Nj1HGehfaNM9rxiLAlwDYLdk2pm6X4QVxdAx+3o6nkRnmdBXBmdqORxR+NdW0VvjGVRCqF2xm3Gcraj9iEt+N+1c4IghtBZ+QE0FEkgBiZLY4OJfKx+eIQnzKE/QP/mxsNq9/j2aM1LIjX81vpekG819SxCO/0wz4tZ/h5Qh95LnExspWKTQyMcpDVcjM+gtMtxJHSC1G3iTleb6o7sb7Y0ZV8LvGPLX25E4VNGS1PFsiSSccEoxWg9hEi7eIXMLViJ6XOpoZmbBtp7jvFHodpdof7xk3NZ/gvKiPO7SlEsAgIeJhg4uwH8zkUvkY3SsCAIjzyyRTgqxeIrBHLKOprAgb19XI2tt1J+bPTVjrGUPUReYzbGN2LkJ3T16/iDofGd+Ggz82kpo4P4piGn0QShr47kEfc0VaTnzDx3SI8KA6dzo0hmQzS6g+MHdm5p0zCC+7v3tquDElZMFjA8+XCthHwaXmvwOuZ6R8fPygX8OFg1usK2V7ww2wzWf32ZWtE2nva5Ny3Vy9QsUyCgTldtbLMca3WvC7RfBEG1cWJWc2Myslo6WwJCXrwFieamCloKK1LQw/z1CXF2fs6LZ5X8Go0gqP5fF1+4hnHtiZsYoZzgtsRjchIx+lx4PGRbSjWcSNnMjcwGRXjYr3wV/xlJCwPY2HJKSpzVswya3WJX2vTiowAMkg1RpS399pq3RzTRDTsOFugTb1bu6QwnDEylumEEHmXtHPWG+NtxxURvbVOXBiY+CdvmIDIpTtjv4jWoieqInIWOcr5nGLD0eQ4mM2HS2q62UmMxR0w592psVKmBimxkjkRzCaVhqBSq8kXs/RPTA72cSzU4vfoELtG48buZW3MDoJXAToA+lAu1jWO5kVfU+q7iDDbGtO+uHEt0+mFjbsFGz8OMOX71Veuz64HIXE2H5Wxb42F3R7w3ncvLi6Lk/Oz2BIiat60bsmFnVnyOYE26/86tykoSx/6r+e8OYNggBrFjsXBay07IPyAdPBqbFqnQnj38B369ZkAvZmAJGanM1pKRkmKmdwx8gWFFciUwK58bropc+daM088fTyeSRNWA3LTBKlr8T2peSbMDP7mXHs7cxMwakwo7hdbUK7hljobuheYBH0s2Srfd1seV+K6xkfR0pAI42EdBaFXY7L53vGqTFTWJjkJ7INNZJyF0wcjv6kWQ4nvD9kXeMRjd1wtOA5mOJkxy16nEwSeNM9Rp6SLYhSjCOBADfsVoaJHlyIjJtlgAo+KhSUMEPa/CeTp7oCvH/vwAYXiA+cbO8IJDMMXz5ozn+pigXZmMjBRNSBvNDyGXUedelyw0FWeFbX1WlUgUnCebchEj3DyDjEcZN5fVVxgQXOiDhkBvjko4+xCUL1mIxO5py2mb/wcIb0Oj1ANBBe5DZk0q5wtZzftWCIMYqLYbrUaZuQdMjavD6O9+XAG7RlW7tLtw7Ep8+bJR0DM0DgKwJ0uzZjIVe5ss1yMZdQEH3BUkH3rzS5OQ50/x/XHesxhkigQ70+jmQDRmjavHQ69X/WoOPCN7QMBkYkGs4EK7ogNztr8k3VJ3FbuKmxOupAEOEYS22aSf50q/fQz2LzhYs/v/eeTNJ2W4yp8mIuS1G1h8OkkcaSLrbEYThXlzFEPaZYand/60wohm/ZH8AadnoHz5NRjvynT80JDCV4pDoMg2lAmZkjPlm0fCgFuz0zBiLa84wuHXAyvLZvlhSPLpEUGOPnelI0lWgyz3bxovJWeR5qppRx5FEkPzKHddcwh7/1egHVc1Wjpd7ReeUrhdZ7U9VqB3LWjh8jCOuzWhRanH+fLrLWPmLxuJpMaPDG+Sdamc364wOfjXWWMVtBfzMWIek4aZ1PX6NnHGgQT1S7i+zgcH9rCTiM3fjFUd3KqD/THliw56rDlfOGNaKlQ6+x5MJ4Ah4dEzBjB43MK2HClVqZ4jeXXbVqjx/4OUz5M/E1uzEj8TqE7bHYvfWAchkU7CBUoSjhCDjZl8c8vfq9b+q5k91raxYUnI0rVO3gWC4+cGUbeoJJELPErEQXR1hi/Bmc2k+Xv8nHeLjxshgwkV8iYMaOkE/zYhktQWfiCVQdE25ReNodI+P3IRWXhosUQTbBlOwGpUCFhbmDekJEZzhjPhxih3DAbxqsTglOgDTx0au7tB6DJG+TVA2PPfAmt5BidVXTPL7FfZs5PfhmmGn2pC4daWB95JULGH6sH22eXtzQ3koZ95ebL2vsHMHPhVHhhHqZLIuftgTLH8Bokl0r8Ox6wc0zNkby4cG5G6tDowugWycBx9XD0RBHL4o/lx5J1TZQc0hSnQZks3ONs8ZbyIiF/QBsGXTjeKLYMl9z+sUSW+eYDNzGa9ORhI0PyWP5jzHnGMDfrF19Hp46qtR/Dg+ZibVMYjiRRWZtwagKf5AIjbFVIOAUrXwIEmEZTrrH5RB24Hmfq2pSdkOrSNnSNqzTMQazwBMHWAAhTyaexlzgqHqgB/Xxp4xPu5dwR2fJdqbfS4xIaxu4QkWDY0m2CCDSkLkmNgL00GEiqm7eOU90ixH0i+1S37kXst3eCosTTI4ACMnlG3ZBjexRWHC6aITZpVJABvyCcDLn7tJnfs9GDTt24hYXWuygljROKHibNtEt6y5evACqQzPJNEm5NE/WqnQ5rcuhhXUcS4qK/yg338DMLt6AiOPHgRiPq1sIsXaAHpFw3s/mcX70V0WqrYUCMbiG5SZla4+55dYuajkhntoT3LkjEOvFk0BykR+ZKJxMMwwi7RIGmLd1FtrMrxwfTErL0h2Iu/E63j/QqxUPnTEiKu6/yjBzuHsYj7pGIsqedzAchJeC1SLb2xB8p8FZIqI8jHbnztZ8FtbEvEPTsOyVkdlNwWGZGxH1k3RKnzw/nQ1BBx8fymzgMsabIayBPfebFR9TT3n8iZS3YMKW0RfyKtUauLT+Ku9GQlflwDA43uJ6bj3qGzj6k0vyC4aLRQ+IDu2nZsukNkcLrFf8Gs55GtWG/UXDDeJYrZmzUuaZVRnPPmh717qY1twHyqEYK6wiHyWEuXZafdwbyYYNH34t3XH06duMBwdQzwbmFQzL+4q9/+S+0xRDL+te//FdmXACvVB8U9BOfkYFmK2HOo0xb5YCTQiCCno+xqy/++b1DPvsl7lj8Nq1Hd5pUK64m3Pe37cUfTt3mc40TRSwG6DKKV2tiV4okcgsbu88vZrfcHj1hybPWhjancFalpY3jtKcwW9hBIcjVbRIQOdaaX+1rOwuIaCzqQC0GHk4SL3LfE0l3yr0SGwYy8YcO/MPPt6Gd1ZXccZxyU4JDW7JD23iGHq18NPYxx2TsJvEQrb42lw9b78bz4oKTohfL9mN1n94EO/c47IVrmjYFbimB+lQsL6cTcLd9vNIkfMT2sTEFsPW2o1eiai2EB9XxnWYRpJFCIE2BoBzmoZsrBpR3BSWnYQiN63Iav9jA3jHUBW8nrFRqLmim2Qc2AmubgjkEtqOCkXqxtKQb0YdWDtoY9NUV7R99IQjA50mlkZTbOIsVJaMWYJae0M2/960FVXtFCw/3lQb/Ac/OuUmB4FNdWcs1992zditeE7+IEgpBINN9Y06/x7Em+/UwuC0cQomk/qKhNSQcHFVZSY6bX2PVEhqYU2dh2jE7E427L/VaaPHjEe8E0th+j+BCe42V9eSMG7yzjP3AZVeYzJTBPijfhTRA4dBK2d0WN9WsaklIowZ3BOPpOhES0TFWlpnCkhCvvQqkTQ/9VpJAooydwNgiP925L04SJ0VUsh4RuBdTpcjIE7/uh3C+g3bOVBRBbw2TEEmQvTcuo6WpHuyyuxWu68com2BCiMnGzs2/HzDBWjXZEWVXKJZbhvxOsaP+0EKlFsJu4lt/yyx4x1Jv4dFdZIepI+uk678sa9g8kvEwO/9BfgsXQNH35ePpJvRJ2UGXqyLIf8Rb/UA2y73KlSV6xBZXL0r0rGkdOlECRDczvNzKXeFMQZlU2n5tnrUGrbjMy0sapXcEdrf3o32LcTDZoFr1nn5ptD10J0hhaBK58a/PBlZ5TRku2FtpW2r2lZLfgT2qb4+Ss+6tCuX1toPSu0UHJ0bZy8/hEZfiNSKNuy5H5Cpz9CRFkHSZ0dR5bxt7PDmQkxLTWJg3jJ/qF9D9LzZ7drvaYo8yL5ZVxX5weMrBea5a8/FIPVW1H9W+6UvS9MZV2ePAaUVsdIilUl1By/8kqsAWWXDwYHGbb+gNCgIxdf4lyrYRdOkGqQl3HSH2OX1dHHY4ETBBbLH5k3FNidygB6cFYaWxmCEm/UTbIKCtnPDovbdueRULan6SDjTvHrt5Jg5Zy3KMsWRzvnfjFfKfkIPbud1Gmk8KEsXfIigxxdlgo3THEsVmFAb1tyOd2f8+RfTEVkTIPO8Uv0XCB9KntgHp3JT15239anqukJ4sXedSFhluEP+Rb+GJUxovnQv3AQ4NgOYTfN7iDs1ep7c910Jo5xtXPwXa5L6DY4jrRNY7k2Gt02R0GGJZZqll/Ra1nvqyU8e6pBKYoEWlkn6Zk1oZBrJ1x7Ccw2+xtNu3w9Hd1ovh/H1TgvNw8eIt7vdpvZweF+8ETtv5Ys4w8hpC+nIFg5GYf3AUPZVfx8VvLpHWs2Ri5TkirRrFmHcm9B6GGUosAsvI+jxYjj6Gz6tTNZwNkM+nLbRp/K0/LUuQC1j6Sgcjp1bIEx3My3uP85LaTupR5us/CXOw6KrJtXR9LK5ga37gXFV8jA+2nyU1KzYOagQeiAO8+pDlmcgyg2/C9z5ojdIT8u8LWO5D230zxTs/Uv5474KZeq2k8DbFDfbjrOLtc7IE76sF2bP9BkTAydnr4jvYl2CCFbfYo2WWSVWPWjJVGDohwKEec5jwftHeAQEJlqf1i1zZMzq9Jg7xOUfiXfURu6DivRcTBE9EYA6RefUMiy6YrjagFbUgKd7KIGFKOLM28zLp8kG8aJJtc11O1mHMQv2QHMK9rrq/3ffIeDphuKL2iUoXolj/rUyjZlvWqXyL0JZZAOH6Au28xeN/NvvY1KO1al7ELGTkVKwNSosvazHgjqNvkfeomDQ39Si9wawJ42Mbmkd0aiR6kz35edszKkrQ1Es+I7JoHETGLVpjrXdcAUdIqvGzUdViEHPF8TfxE5utjuJUZFfnM0ZTZiIl18U1ktbJcDZOIpjYIBNZNq5m2R3YA9VwyJdgkmOL2x2A913A0IWuhdZDt81EYAzOE+eAVL+nyN1sV58ydB6c2zifT3pjaGWWQIIdC6rqTt6TRK5JTNWLWEz50HL50b4980hf5yh4vU442R1VrUjlHndECvYyTz55EOTkXJWksCCYdGSW2kTYDVYIGitBQ7nCfUM4RMW9ShkFPdhTUnXCt2F0SLCL0nyh+5pcnjQqGKfxhV6igqiOth8/yr5whWyIWnpzMNOWvms0M4yPlaMWG7M+ECjQWi3ODfhiY6eSpe6I36qBFBUSDgrYcxYIGqKhiyhaHgX2Qg7vzBxl3a3R6qwRJuw2FYYjVWHYa08Il8weOtPtvfBxfYNLAX3ZjGpaButgutjJmoLC+1YRtCfkm/QF7RgDTByY6F45mWzikYFPvI8a1YmVyGpPj1bX6RNXLPHAk4QsP66pDbso4hGcNhLNw6Vw1PtNULI5uzfOnm1MYi4il3DlxCMTBfYGxxR0m1yaXZa7hsBNiCivRt7OIzgGpQ7kz8ehhx3qptxJcLZSp0UQSd4QrGCryOeurJtS4D4w2XPQPKaZZRwWq8Cn6CHzwVzS0NUdygc+QBlX3T3Zq3JMGXpKEO7FUHYeEycIONkpMl1oHedikwHUr8yb2GKC4/Sg8z+H1TEezipUeugzdvqI4Fx1fLBs0i8qhXJPCYShpqLUM8M6cmUa4GKZRxlAmqtnk4UuO0/+VjnS/00WLNHjfqKN7MtHPyNHGdIspRuaj8k1I3bElw8Gw35FjAkIiJpXf00QxMPnw8iomkdsoh8OLk9jfbhCLD3kEaykxI4V0NOEX4cIJS03gFSHdJ4Ux2VqYbAMM8qZc6XlkQufGACbsra5d5ApyjopJVyRqW/LCScKs640jF3qXpIICaold2w8IlipQGN0rH7EuGaTW6KiQSJAOvtFGEd6Xs9R5fYC1YBgCsL/soDDEGE2dVAMZxW7l28iuSa270JB/rntkI8cTYkqWumizF6VyiGKQNslzpe016lni3mZFccloJlALX5RU4+H7zMBRDdl2dD3Q5RmNJXTsv2gGMFPQvngWGM7TtYHQcQZE7DAV2TGEUOu07hE02As0bmnKtwZ6BFuqRTERRhtatRNAfntT9NJCCMhq+QYc3P3KioZdJ7ODnFF8xSETqlQV1hj5i19Mhf7ceM1dYW5dMTl93L7qzdvnbS/k16uqu2VTyPBNWTDSpveQPAhIE8/xOIs47Q8TQIarB+sxaZnKJP1DtK9vihQEGyB1kUjKxcGl3gMu+r2ecxGw0ykbRfKLKnl+mlKQoh1HQPpqdtDWMrNNpAshpD3/FQFHvKHYJl4UkmbPHq9b2A64DorvqU4Fa0zlIvrPdB3KEmOtQlyeKaMzmeGHfZE7KFx28wxq6A2UWNqUjvNjaQgJ878IvZ7y4Yklq21tPsBA5E47sP05eqVclnC/rBr+PjeY2oOp8wdbnAXTXMlpnE4LWdZjMchiNfmYGTyXRPBOoJwgcyVkNgEjWSq/shWI/iZXJnPjzwb/raYQIFPcso5zg4HQXZsCjkziJ9VPGb9FweldKbn/fSqmeSNNTX1HRvJualN7ilZQOnaG8mkaVR+rLTc1qFFRwFpd38GyBgDvQw7tfUdNFWfYBozLDlCbMzLhX3GvUsq/carcS7hF+YqelGyUbI0KC9McIa58+nvjcCqQeRwUd1Km79KUgOGfM99qvY5z70ogSB61/khSytkHaLnKAP0apEbyAiFgyK+MDydLrugljjHgCI5Gi923sjinB8tNHixt5pDIVLTVtEoqFqsAulJs+BlnJs5DjgEFfjCFgNX8HdJrT8/xWENJXQTbBhhGncGh2uiGkf3Avsvn9tbT1XmsmYH27v/+LCp32MmRDyjrHCo5txKvADPiOJxkCOnysRSI6f42Ikddxr9NsnJsHxYe+2vowpY5CMRoSdAgVQYBXr9M1/iQyVesDtonKEiyqammpsbAiQr9CakelzDhYt40eIq70Wu+Ovhpyzb5TR/b/8+xRu9behM3JhSz5sW2GjcQ7A5oBYWfOYQ4X7liFZgSa1icwLTyUcNXRGLiBpBvDDLqwVhUsfF7vbunn/Ka2IsMO8WShXPl5RrNUmmCZcjMcQtYeb0OCz8ei30x2qC35w7TYWiBPYDlTX6FtuZ4xG7T1xaWyHt75bIvwmGLtBOu66qidCTTg2KjkQpd/k2TXD4SZm5j+xnsz8p/Tf3CUXrmjm3PtMi8wSerRVK3KV9LBVmoX8tjjrxLfbEy1+UHbYKjuIGWL5gEw3UtHtBsVychxBnpxyStKubIBgd1ecrrMz0n0o2RsrKdoEVCDe3C7j6DgkwbO8wbc7al5Gwe5wL9M+YGgu+2THZV9fw6AXZ+wLXFbHjjFlp2RruSVFseUAWZXWQi1UyL5QQIaB9gh/neAXbbEQmA3J3hnADw4kkjVkeNpgvzRYKGtpRmE01CYVTblBJUcWWUaxvlnA9xiDCtvWy3WxGyByqJ9t7cZj2gcqy/e3H4LobRiEqMcfWwpy46RRz+lNd+ZzS34ywOJG7mbqaORvZ9MzIm8uhjek9k3DtMtrKvSKjKKUF+8mcrGUO8xBougvajpN+zPfVyryHYZMZMkpvvqS2WGiKhZugD9YXhEy/PTm9cEnLG4G1Wc+K8SkBIWauKC6HURd3a02rMEqQhN/SAxk0vIUWppgL3x0r+1KcobUZ+MhzEJP7dUDblGR3wpbV2eHHYUK/uUzsoUwKKOBbsA5NmStTEs0eVJkk4OAQM6bHM2VSFLifwq7vRK9eseOoNQ5ahe29eDo+7JhhiVBQoBCTf/6LmfTWzcctNeXCzK7OJcivhMIB/hbyGpG359PPqTedaE2/ERQsIGen81KdytsYkhu56UG2X31H9hIJgmeAvBSgMlrEic8/NzPRBrqRAwdTO9JF5NseSxVu0Dw5hAHmOQIsV5HSSTGlr6MU7lgPYj+KVxoshhlNji8x4Uy6mXKBCa1ENuRQE1mBHdxFjdcSvW2iaypthWshxoqFU9YLjyL/sx8XbiiHuJvD5N55H718aCHSwQre68b2eQ0+PsSeiHWX/XB1ksugrsRr2QAfI6QKFwyCerjqMmciuRZ2EQTqrsI00YqyxsA/Yrh+lN6P+IbRDVDxEBz6sAPTOylERd+W7NoHYFW+qedkrAxnvuUl2smU8QqfEua/TKnFiiMT6WtSbdhcpLTl7ykvcw/oJ8QHcUAou7vj0h4djGXt9APKJQnF39pE7YZ/IW6UZnJVtmrmfY41+bqaUkyNQq4X4J7fEFD5OM6DgOhvR7dYOJjl5QFZ1XOolESWiIJ1W0bkAwoPlJ2e62WclUh1wuzFeRDcCWczirjJDDnxvjpFktQyrzRgvVGDBn4pDGJJlf2WJYDg08Sqk2aa6nD42x2ABvNXU+I2WQWrDXjNtjLaNakR9Wa6xwlZEKbLja0svK4i6qgYcxvSS3Jn3rBNiQg7ePuJ7WAavT7oZ6SlvKE9nPe/LjE61RWvqYnGGIwabM6REsBaXWwJ+w3MulEHlRJUhuJO0TFJ9b3UULvyK9nwL2Y3IEJu8y93CH0bmAoqGmW2MJW+DcNQitOiW15jVSePM0gP8T77DEHwXQtSH/70skG7wUZn3+YgS09yvX9tIYp8QXDIhYjaWxl9Sc74WQ0FZLgxpQCjQRCPhAhaydj9eWQGEQVIRW5Y9mviiJnNPHgLUs2P1RYBpXX0NG4jhTjWJnfYVfuhrZuS0uxtP8MmQwqOa0g+ZXSgNetZd6oq/anBhaCZj+SbTdswl/P0/VTwkv0svu9veXGZgPzBE7i5Iet/vGydJnHFKVKz+kCi7qWbz3U9pGhcLqu3ZSF2MEO+V+UqmNznYTZkC0uBXHccdlUWbaxO0c5Iys7oSGCMur9UzugI9WeZTWl2n8IVyLzCaheW8ZXpqKr9qExn0Z4keg+BAI+ZunAUWhKsJnG1MHavdtty2WNNWarx2/iwZemJyXq95JB3qzeXs5x8QO680Qfbxn3TSOecJr2elDcRIWou3AYf99GiHnnmlQcFlQ+cd4ZTwof1dzIILC8sEiI4jyAtXB/TPLOoVz4OvNGzUqZf1mKlhQIGEEptFh2mh5e2M1OLvbVdu3IJQDUsGDopuNLbhuISAksV1F6e/Dcn8eM2wZHOScrmQjFEvm69cDga/IyXMFY6ltn0WFgHa2MPKJrGFOaHFaOUMiIVV9/fC1OKbzP3pD0FtA3cZto8PVoABiWkjeAKs50VxO1qHoeoK4f8h87z9NUJvpFCy8bHqwLb1RB18/CVkD63rBkkNSXrQRty+t00Ww2hFXGUkpmgYm4aQjk8UOQs5UAaVeDaIA92loK9IK6k6XNEFwmoSFsySU8wD0jPwbLWTN8+sEVjWzgITLmSq6sglGdK9oSDgOSzj4IEXC+cUDzY3vvHDO7zSX/J/KrwAT4zIk052N4vNjM1dDnhq3aCpz4jdzJLsCMa0n+z61Qt/gxozV/h6f2VagBTB0KBY8sWYEeRYcW85uZK4LzAuWQnnVKUJPaIf3hcUUtJDfuVGggsNgNqVNwDx8Wzx0/3Ulsw2rjUpJIqcsv7czwwGpzvAf+Y46OASwvHLA0gU/YwQn5Wj8K3IvdFcNKEyMF1yrYt7x3SLQDH2Rm/pU6tGJTBx+V23EMZEBOMCRMfhe3LWKaheld6mntrHt8cZIxTALORzpthTeMjx2UPw75GvjuOC+Xi4qtf5VO75VVQCbrZkyv4GV8N80rinvvdNcuWCqGy9FA///dKB21qKRa8M2Ip/fxXE11MWlHKvVz9qPoelxQ9pUia9Y1s4uvOxRXxsBL1uq38ES4ZKv5ZXmEAIxvGTsNwGevktgYF3I5u79mbJRTZI2Maj2akEtcpLGZNyHW03A2W0CG+wI+IZWRBmWQmjY0xuQsHpzOIy34K85iPTFLKTNcgMEdiiMdqUzvD2PkDgccjKXwi+/t6SUENJm5b7/N7ektoqN8lPyz/lFVmur4/Z77BoOnTfnglddiGfV6i6fIwvdFmKktJ7/grENiYU+XciACd3WEzGzrXT3Gd3bCeDV3vSss2YOirnRnA9GBpo/JAkOdp2GIaLXV0RHlJY45x4CVughsA0jQsT1m1IT67dMvDEUMQIrEtk5HOqcMYXJ8B5n72uzPwv828Z0ULjiXG/NMorilZZcKZRMBDDfn44JgzqNF4Yz7YsEdEvxLIowxK3NMSquB0tR5EwInW3DJlKr5eEkJTbsrXlDh71TEkB0Ec2+3IEn+Vif/Hq5SyS7Jhw/TUeiB6Wun5k0fBhGBule7ZVUQ6yRNc5mNVCMZAb97L4LHU8dCRhj8Toxihh8v7eYh7M7qBKiNxMrAHNcn/JAjkzbpAy1Hfx7wCjBrXhVm9lbAwn53MBnipz/Sa6l2NU3B+G97XzqnutUYzA37Q+NS4IjFkJ+Uy2wE8zMAycNc5NCE7ivAEyX0Um+/4p855gf/4t9egW6bR0iaTLOYN4Ql4+IvN1g0hH2t/+jMMiZwyFl5MSSoMBGIbsM8WpgywHOqnjU3cNBf8Ni0tM3aCbWhphJrPVUqJMvdToqQmXwp+D/xHl79w3KwKqq5fimhqyoQoAFWwR1gYXmINNKPIrNvOk9eWNyWX9OZg5UlIBz9Cq3HwWbXvlXOFLcJG7XJ65QWCFfQUMkUaZTIlsAlQPeI2JSQ6ZgllXgoMy5V9oQDSDwazYMHxQJeRjD1dT8CVT3I4MHImbtKb8csBtZ1ORQcphXdg2hvsW7agbhFZHhRVPgD6CBIrOUsbXjzk8Ob2HzvihrZd13DVMAgsmotdHw9ImVXVuM9vKcOoj5KTCx9Ir9nQR3NB6QBfpRsokeAB7uYs0THXEeuFyIVYmvS6i8FqZQi+5iOXD9Npxa4djBJJ2mStageSq/OKrQI2axA9DTMmuIWyoEQslzz1ZepSLfQ4hXp5q3KtGDxnnGZhupOVi7M/Ng+297af+dYh4QBiNI6bgtPA+QmDLTH1GSOjwL5wPHVi5l+gFyiAQTX1mXslM+nnHnyU468qPRAnamQGwqcAzeFlT21CX1ysNc+LHR3mbTO3kTS/33y3NY19O6GYRssxTEwVgP/oh8oj1823bCd0RWYo8cr358M14CqqAofoKvGcMWBLkYWkhzzTijWKjRDe5TTFpcV+EdeTp0ExOMPUEv8MPYgDPK/GYyQX7onGd4t7Ah/yXVrqHGxNW3yYOvsxGrZbVyJHQS/Pl6oQDqJuzczchcsi9kSg2ASRBMvyJol0lUHb4XVJ9XOnOwao+KMWneo8llRIVQL5bva8IyC27S608XWEDT4U7yEzX6Z9bZ4oxSXlDdosCQfT+nVzZPP3Xpoc2mkfdG1xm7Cz/U3NPjj4g82botmMu6dNQl5cPlquu3KAuyzbDB9p735wt7FqQ6ogcEsbwu/Az89fXJzmNkpSLSdVwtjFmpst9MFNo2Xe/lRsJouz5YEiOWXvuydZHi2DTsT3ZOt8MFen1sXkXvBBMI2qCPHTjnKvXClXaZ/dN0uXWypVrHohIIWqWyJkxblKavbV4+nd/CsHErcm8eNgyeDRkjzO1G2fO5YrvuRzR+Dep74FKcYqIR+3TS4eYu14eO7L5L221iRdAzeYuecAMZUpK0ejFgDBWv5l4RJqzJCn4nsCv1auzCVLIN+PeX6chBu8keUk7Dr0EN5JStXudlFt32yjJ1N8/+a50LPP8L+PX7x/F/ZFwL10sLu1u7t7vJdbIApkeX6XhMI6w25gla+zfWz3h/LGpj2D2cnjFXqom7n/jCZ5Q55fkwX3SfDcG+Mc+wsJCsSi1W3PUPol7Qyz/LVhOIqjg1L8GYFVFTeWVGC5M8V7/q7JxaIywzjhRtFZn4eCIKAc/HI68I1ezrpjK5mOWLBn9DWGD1dbk/bIXJf1hONkaE6aKIN0J2b3T7/YUfPEbYqdSccVPzTjGL0hEcC+4SqaNjTYVnC1aRRt1hgyNmWBcCc3Z/Yu55x9Ww9bGRucm3Sg6bI+gFUmGsbAWEPxGnPix0TtfhpIBLp2EfmeiZwRCnoZCuwsKgVM2OKMmxdikVPai6i2TXpRZPPL7qnfcQz/xFiEGRBdjlAY9uBDpQXJTZneizk8UO5o4iaCax2KQxXOQmCSDj8a86RkqEUMC7grlZO0LpaleHtxVZdpW9XSdzpc9E0rAhPFkDRjzPJRrddOIZx7dfNMJopzH2I2d8vpFLWlY9lzNBYI4ipqLUfwpiXJ784F6DXtRWzPMCn59I6tp/UyyQgzMtBkdpFhAj94Yvvd+9UlGkuynDIveo+Kt78MJ+FcM7V+MUCp5LhrINM2HeeS0kU/CqIBNuJZ3Uoec60jGC4b/SezEQS9RVac9odCB0FqNSHniWKZGEH8BAuB4RY6B6VoX6SYYt2GFrrvyyhWZM0ZYIyzjSjKjy9jQgfczCBJmzIby+tllDwv267S5s3S94z+tVUsZ9WnOcPIL4fnJyevT35/9nr45sU/v3/+9hL/G1v5hG1yHm/v5Z2omIOsL/xAXf9UCrg2FjFkMebB2+61dh6oxY/UWm7mVvXueNjui6Of0rAb9Bnt2ctkzwbv7iWCO/GSkvLJ7PqscnwM/D+fNcwpw5j9RTnMezhj842Q12ZkM+ox957MKxTVOXZ7RhUWV7TNy1mV05+XnL25CXo/Z4SYvi7RH1EkQzhuet6U71kfssxFKlyYa1yTBS3Q3IziB9nThu8kiqZyTP2M67EHd5ccIaFmGxqIDwqR8VTcjYbwMse2RoZrz3tkBToToyYYctJoTELeJm3nzR3lXwkOfu5MW0vdmQhg9M2p2qG/YezKqoOcixQI866cgdD6czVkNFuUbYBnP4cLultK7nyHeFvb08C1K0BM5lTYtV255MJEx1Hdmd2A5P9MbuSf9lxxErxxGW3Mmf07YSwRS3cLTQvZYlt8+POUxj4a0S9Ew7SO83qjulLGAZs9pWSR8JF+z+4LkMRdXXJCk612fwcjleFLHQV8l8F2PE6wHbYwUL2wwMWMsV9sZqmK0EafAoHYz8wJPpk7JvFUoJDoDI0GE6NNwprYFSWpdVCC6jGK9bhSt0ZTjbig+YXi0LZz04nCV8UOA3a1LpLElyNLCS7Et9w0s2q7OEFqJrJCgtCMg2TJ+9pqoHme6tY9Jzs+y3MfvJC37Ry5i9zCx8Q8vH+Z55SSEI6LJ+vX5QZgzOw6SNTkaE5N4rAMwnwOLZZ7BbtOOAbCMegDWekKPUw/aJyKigzCocu9wkX7E/xurxTEiIqYcavKGjwZg9uYc/ySVEMkiQ7mF6G0PxOvwNnpS6UEuRznCLJgyUpphcFe3tadjz51WmqDKtm2KcK9vpyVH8Gyx3dtCwC2T5c4HB/iJqpQcqmdYcNTjpTVe69RRMxFt1fgSU6izBAHgbD/knzsruJ2+a+Z1h390E/3ltcNWHnoMGCrEe8k25JDgSEmTJ6Ja6ndE7I6RORTgGNngLX2WZ8sb3LCu7eNrsaHtH+UZiNdD/Qe4t+MaRaj/X9KVq1/ss89y2PAfn9cXFd3yKt7VfxpSWmqLeLGhTncLt7P8dWHu78CtUoFnw1yL7Q3FVcsmnN/EVEUirWFW8uxb9n6nRyFISaALCz2rft40jBWJXlDlcqHmzbe4z1RGLUSmMAyTIfLkOFYzyqH6/S7x31GMx+wCl0l/k6I8N9BGqgExcFxHurHlYs3671KUBp7pK7oNjca+bSzmRQCu28JsqvqQyAeiuqwwnSUi22QqU4tMPos3z6YVTmhSCWjrXI3XzAD51sh+WQWv1OEJBZI8GGlexNuorccPl0RfZP+vjC8s/M3GB5yZcASB/M2g/eWfTzQp+RV53M3Rqpzy73TQFtdP2BDeeOrpB8iv/nBZmcSoywK7ItxthWeBq2tY1yNpzfXyzMy7yhJ78iAqrFDNZVRmDjAmEW1MElGxq4e4pU++vHGAvESjOs89NAyMxkT+KICCYEXSY8xpb2w7dmUL+1Dda/azDJsjlBUTibVeEgG3FCNZFV4tpDYP/UFReq0LJ0rs7hcnTYbz4lC0z2eva9QnVf9r3/5L6eyz/76l/8qyC9q4rhi0+MyaZynvELTQ6uC+Z0CEqadLOdSBUBKxB9mCEE7TMYB1CjYNz0RPNo3pUdTSk+UVDaSQ5mTgdFcp/vxHPP0l8QJi90gOtZeh33w9aMkZGYeqR3RDVkv7TjZKr+HYavbR/ly3RdUq8oKuHdduP4I3eix4XWL9WIekdI/CRmBo8JFXDuqz8Ew/apJlDK0ktKQmq/34ffe/PxREgR8gJlmf/tg+1N2JA/MveIMcbrnUh/8wIy/UnE5aibL6Swf10pJ2rLP0mAjdbB0Ii9f/ZfQUrs4VP1nVcPZl7yUyi4w1ojoypUnEijXCQyUlOSqPGRTWJbby94t9HZG+B/EwS9u0RiPJbzzV/rpMu2OvDXmfEj1sxISR3m6lLut9x2JWRhybW9qdQLbE1qE4GsQuHwULMKmtfifTN1DT4NLHAhiz0GmohBD2YqCwbTn0m6XzH/gWtWgdMrHEPGRzm7rYLLIKAvRv2q6CmZbbMOQOSyKTQvHeeQr51+vRZc5aqPe+jw9HbDJ0rglPvUkUz5WeuUTxF8cgF7t0N4t0FPiYNOdFjui2VXbhzyogoh70ASCrodZlISD9bM8Rld8K+lWmnnmg5VUjjHTupG5xCY6iWY9pXTcEJJbHvnRGsqm2Lx2fYGSoMGWuvqmIeKkvHmUjMC4sh4OEWE0Zz6jZvoak72S36HqbKTxENOGIwfPFS4RKq/mNDIaz4jrdleaXffogbdzeWgyBiPRMEtBXhFduvmIvtX9EXtEyN81/WGyicKmXzQC7864XTiaH8z2ZrYFeglbezLCEG4gh8B3l9RTwCHvoKtk5sSFGkorwW6oW8A9/1W0RgPCvq1hG8yU0UJV5KoCdS+CjHv+z1Xl8je6pTC2DW/F4PYH+Nl53Rim9E2HZxT6daGRrbgIhuP4vIdXysPij6AFucwoTjSouAl7IpnAbb4tqNdjrKekp3F/mkhP8IPd1eywfz4BzkxEWuNBuX4LXRGasTje5bO78C/hhIMPoNJgAig5msUE4taz460H2SwUJ+EEUUQs+OAz2gqlbRQNSSp+85NinHTvk3JhLeXVt0J9o7UkM93X1ac5Fbt2zNyhW5z3F5z5LtyVoX7wCZT2ZjkVN6ot77jvlPBmpUrncJX/4+HkaW0nw1Q14ui/t19ggAtrrBjjxUYhncRooWi7NCDN74ILd4L9NNgcE0IYVUVo2okhSELpi2C8HjeETDbx/DnexoW4IjzDLjCxjumZiP/2vbDxxRl6lL5//ct/t6yDifsgfdlAVU8k9umM8YzH3KO2bI6R0/f1SJbCtM3LLUWvT+SKCVz2zVfAU4ay7pStNRO7jw8i7JYO9/XVPe4UDkbeNLKYV5NG12LFefTBY54mvzmoJl6BZOoD1tqzZ+J2T5pxpPxY7hgl3B0jtKsaye/mcruW/d8noYKH9tLX9xnQzZTjiYhccBWEiHeghUm7qSmMbnWXW9auaCGB4wn/t8xYxHHE58QfLmvCBp5xH+ttIuRSUEquD5J2LWT0iavvCSSTR6mYl7x3GF9fjWMTN3K401Kp/jAm+2HJh0gvSUvj0mE6Ult/JulK21Qs9EXzB/ust+mn2/NSrWvsvbUfFbbmMUQcScPyh3LcFGxiE0JknSjBF58Ie8rTQhhpW07qm92o0eFMju3iwt1igiP8uL4RpGCnkFteLQBP1O+jH3ypRIrW+d7L27DotVu0cHCRogX7Cc/FyPUUiWvWK+bhMPjC18Jlm22v65dK+DlZYJTBzis206L1R4jWAYWYf+eLXH8ZbBBmio7pV9CCAWE7qj3mgRA2YJnSiO5dVyqTrkiFEJu9CH40sH1co8EDJauOAfLXk8WXxf72/vb/Ife+2HZ6MNq5b6OdJwh7Uxbw1U1BOOZEDha120tRYecuRNiltwdtBBmUWn7ANncErevbYdsKazZvUUIL4jdI0G2Y9t4y/vsNl+Vap95HQYn7FCYJNoEkH8gVTzhBkSIvRaByP3i1tleyp2MYTwHasUDW9IiY19zULIFCzc1nx0ka8XT6emkeF9/iTU6EiluugcYQCuV1Zg8pq7GypCEb5mBjp56jXA91Psg5v+FhS16e7qMEQu9dwEyX5X76kswLRJM6078YN5Vh4hg18/uoIiksIApOarZ3kouuvvLuIm0HB8ylsH4X6rgsrMQHrWXYQY1LrhWvKdfG7oWCbnE1K6UpkYoiBnL7awJUnhCbKzl8rnloQPsm5q09w0TJi+Ud1EOU3nBtgnPLTgEsWfB18Ph0fwqajLSnYmoDcOs69CHh8pziUkt2MIp+533HnqDSc+6Z2qdS9MSokPv61zcg/A3+KQZOn2DAyfV8Nolj9rnlQA65sYarTorlG6mJXoj9qtdQrGOIQm6IcsDtWhC3q6+GXYYm8U8fktuCjs2iDsgsjCErCbtxW7IiQFtHM3ewCo7Bj2f7Ah2FHq4yzE2FB8srEykybrx8cJ/Tf+5CG09DVL096fMVAdJr12jbdYA9nQP9C2oQS7YFYSVQTkZZSRwQDqjHiqFcyOCsUxowepJGr9i6y3QUTqXwKdNaFC856J9mUFL1dOJRcCg/kK/UO85hu6/VPkIgtmMH+CJpVBGtXtSHwFbQOe4/TfZsp3aNs2SoZlvX5UFOWrkeW5f9f/9f/0+WSGRK1AFsck3gTjquLg6px7hwHalDFGlo210XpI3kTIYPdegFnCeH1ZXuUlWHA1e3yMWIklqTy7ZZYjPa26ZhZZnpXinpfGOS46Z8m28VH+ALm3mGdTm0sPf+0SMf/L1OkSAV/RJLJjkkEmkTuk18Fr+bYG2DFTHFFreNhDOTqmXaMBa40F+waXd8tN/7IZuNa/GNJGpkmEqCMUVkUlkmReaW2lpxFNElGFBUQzDwj9wr+7v3Z3T96zAP3sT0anpdEqnpsAwIfXAu2EGXOTHC83nB5IxplhG7Nbg8PojHWVB33DNl7Aedvn41vMQKoeNjpx+G+oIhzeJm+bGpx7Y7BXekNKO+wEIxlt+2IFN6YVOUqdfQfV7NkcCbU0F8jFZ0w2wjlss923sQO1sYLeXp1fFTnfHoAZ5UnmG6UCLGiqDCDPYAsWEkz/OG+0uQ7eENReoV5XNZTLKUfqVS+YE0HE2qEtN9BeGkxIqDv5Ocgf/b4WSaRjDwAfgrmgnoGwdhaEE3hELltbhujHDDPONdW2PXde/uIB/QfDoZMCaE+6RSyrf6hLqxNirwFQLzYQDPZQWdd4GDkjgyGxt5U9b2nPcOUFL3zUyirq67Yj+4qxL3UpRdLF6imIbvq40hdyX8qbP9UUIYzQ/UAOZ2DpOCjcn+tKROCUi9lAePCJSBriJ/3ZSQhAEhM7wokBr3HCpobqmvupvSIPpGWOsMop2JFkrJljda1ODy2OPG6GM17AJUtxmFmWLYYwIm5tqAIOKbaHGyalU23YJuUFimS6b3udXOtyheUaGDR84uZyHXghhJsSv4Gs5Z66qEQ/+F2y7QqYf9xSzyvUalfyRMmPxxoIIRlydP/xDPxXbwHBK3Oho61I14hjIaOQu4Ru7RDIfAMC45NfCbsbWlpzkDYV2Tp07Snf2pcOfgS5NDZgT5P1azR1q+hsCEnnRbf0XFvyxr2H8UTQ9rVmVBKCYaH134olMUo2gpzzT5LTPxw+nwgrO/w9+UWOXdHh+Dxtx8FEzDy7Q9SNBtgLgcOBkCL0EZLDMWPMUFv+sYkOdou1gJ+p0Ou7Ke0C9tdQ1qybW6jRYeDA8Ywgnuet07pWsaUfmSUWRDNANS49xkSaQdY+7YmXIEaiOXDyqpuZMEZk2JK4GSSVD4bmTwT5PCOvPaFT8IDxbFWgOJd0ztBBimyeYJrGoZNJPQciyYCIVRRY9ANCBcCG+hxPP0ntcT39pkS87Yy4bf3V+oNo8DSWHXnGD56W3nriqASG9vCaegrJ09UPQ1vZj1l0HNYlVix0adYZBTZMa4wiKSKJj0EET0mEwMLJyycBScTfrqJoSaS2BUcNOBE0A/8Gbuzzr7TsfCcCEYZvYobsElCMtr3dXahCzHAp1nQFDzyWuh/IIrt3aarAk8sJfEl18ubuPqe2lfU03Fvdr+9CjeQ+6TW4IWmjCQIxUOaFNi9R8/8LvYPOAjhfCiTKXNcfH8ymadpOH4A8CMsHTOC/vo0bnMQpVJZljWzCCqFA+1cik74yoRlENjzfU1CVjQbNQzIV/zdq2IM9sGGVYboXHwf7aj1/pUrjtZXKxpECzVOIV2IP6F8VBBSNk7dGE1YtRYzo1tM3LR0z30c8/zubbmc1GnJCfm8qwa3ncOk09swE09bYoSFRw5yKJTLUc+rEsmBoBHVHhw6xRb7o19AiRnlZj0zsoM8pQoiyVadi1uH3LsJxZsWLUwum06PEmhy5J5ge4OriTTTeEyuLJ8O579IvWTTPBjPwn3ZX2dfOxNHl0v0pZBPyH/u7+9u72/mxniwwnf5RyenYlLGaM93CoCjzl2FQsBDfDccgmt8YyEa9zrDv/UNEQUMydTMjBI1Rabvj1ffHxfsB1O59FUtyahdLEiEKCEHXDZcTNVbPmim2N2xqSJHwM80aMPQ70P9y9gEy3ywzmBiuAmxpUYxrxsSHmF4AoiN0T0HWYs1Ue0AcymjQf43mVNsBJZ9rjjUrVieIR8Hmgv4MaZ1E6pMXdr/gmxnOSy17bC+sTONGjE5zj2t8ZMbbyHzOFIgvUG9xXZaZs1eD4cCCM+BJ3dR8W3Ly5P0u3Z22kPwQFnYL2/wiAdRg035z2t78yefbsy3miPAvGcGw9lpf3qthZh7gm3T+36ugjaXi1Q2t6if1cLR4j0dc1J/uOcFvQFg+7wZG+1xZY33GDF5UPYRQkyIp1w/N3TgaD+fp2Ues4z2AZ+x8Xingg1dA8Sx5BSQeHHnbTlVT2K70WLDDtg2hh5QG/Hzn32lSk7h6o01j1cNCheLXXDC4NQFmFoHmtg7xNHdaNBKP3xOTU2JMrS9AjsJocAVCT3lDY9Tf74L0tMu7h2SxPQ+ZsJAykNKXDqHIMybfXxw6HRnp2ACyspoFPDj48OiCttbnoTqPw8C8URmCgOTtuMa0LqrEcqSwSmq5Az81GCtpQnkgLp5s3MdjY29mHEgpZAHaTsYVLfzFwOAAwupl3awZYaaH5J8iem5HgQn8AT8TzZeeG2W1U8EOy9OoW4cOjYELnkM5sGzeNX9oxDyhzicIxCkiolFkbvNd/D4K8T9pl3VddMWMas6AQNGrADZ/WqbAOkBSl+o+UcW1L/9BIPHAZZRgRa3Ix673pyZdqsye35A3SW8HsXm8YkItkW9D2XXC1VDuGhe2TT3ubCSiQk1XCalo/ygUbCvPCFd8fYEomg9olLtf7meycmSgR+ZjN/UyOKpUIMELTtXoBpEDE0CRH3KJp0FCnSlYMd1QD2QVmozX9kFrRH7pAjJNEhJrVnm5mAyYhTTDVXJhoMLRxXxCHczgsqxNcbzij4cX2vcgBG9WGGySCtg6PSXYzqwDfVoEuXsM0dJxWW5fdyBxSbFo7u0eEYusO/wGsy7X2S3j6tQjEx8Yn/jSmG60lzl7ddqrK7z1YB+MsNKiXK7qcwhTwKIB72fgahCicDFAj1PqQAmMVPZYtJg0NFhA1zj0nrbGpiIowXTLgQpikry4mhpC5Ci9EVpd/vYVk63srh7NCFwJyhG4RmAQjsGZUfXSAZusGjdv5sI1UbseHrkQ6/VHzu8o/lJ/cA1lZFUEsVLXTAed9SmztnAxabt4vF/Hhn5+7ubvuuaaSSEyTrjp77nSu6Z8fIsjPkc4yqKKzyfZGqJho8x7dKWxq2lL49uF9zPO60OYw/xdUvaCCI9xWmu3P7LXaQaQFKJOhTC02gA5bM1Bu2RmgIDTkcTnzE5hiVEEmPBkTGI1UKtANoT/lklnFctatYAGnRTrgBbDexCJk0F+/Essl2hokndINDJozwBCYYpv0MhklAMLNMCAKJeY/SRgv7yTF+VwmnctB1e2aCipzNURpfj/yhkxcygoZlQSe+LBSzhmNFuohv480cZkcXEyHiLakXaFGYTaytA2PgEmaDeaFTL4cwTORGuf5/liSctqRNZwVsg8ZZMi59aTjyCRsnyrKPav+5ARQKQa2PcPramujrA5i1fxgCTwIsvGnvIRDKoE1AObWBBwss8IkplkUpyj/vPCE8HKdhVn505St1EAJ2UdFQhqqPrAroNJaaZq/GIuBcCRwc7b5mDzWv5DDieaUjonhqwyuG/W0hmU+KhjDeGK72ETcztPgoojHmcTwaMXNdZ8XaCCY+kMMSY5EiUYpSZUC4r9BePS+7DhSta9Od+tMepiUusQ+32OOcsxiOizkmom1VgvTvMLEk2Pfu7TfgcSKb6YKJURHc1+UfTNI3rnFwGSyEirWWPmE/t1/PPAzrmEnTf3uxc3pxwfKcnhX01TQrFhteOE+h+MXBhfQN+V1kSxr5RjL30HTtUYVuPbAfARXo0Zpwl1y7KUguOCOBMCk6sh9Oi7DmB3ecWtzYXTHKU4ltFp5AfYNL1kqZQpd7w6nirUY+F+omdC9hGWHBMNVKMT1Ohn02RcoYXXlZfhC04IK8UmaMl23W0fSmnfmYNSIpjiQHiMgMWSVGPRRWGQtmh3U2R/CgpnYzkFm+fE+/8E465wIz5Fhax/AyaoFhiJr94gXERJHdgT6CkJ4mVK583EBJhLudDaGpJeJ0QKEInihazucMHVqE6qBh2OYpCuHrqo/EEO32HLHWCv7XBLVwu21H2xB2oXtZyMdE/OFkXMGB0ApsUc2JFbWXVhcTLDHuKSyCjgCeShzpSHys4A0+U5zppDGLS5yFZlb2XpkjWL2BZpoevp1kDD2idec/JpOWij6CmHkcSUC7GlHpqJ3tjWBqp5LUi4sRXEcAP3sqaZIln26Mi50LtW+YHV05AWfNbLACEIafO9e8rINA+HJXTH+yeXVLbaQitgsaTMyuoa/zp8sX1ZbdXTWZxMeVC62V9jPL3d3bkzN6Fq5sWkSEXrRPLW9eaydFlIuP0gd0tl014leWE20abaPPvc95VyHaNdMTjGTYMUf6/B/rAPURL/4WC76rCgQXptrKrq7aWCS43W7aiPAOFSMqL4oEkMaSQ3329SWSEQY9TU4ImWxpC2JfI4dGidUABxpRBXCIMzq92euFb4lrZaSA3OW8oq6uovv6tI+r1eH0lOtdn5o0Se8vDvNhb4WyrXriKeIjqSxIepbcccz4istqXEg8zuOmS5KwX5BCv60m8+vlpBg3I6KkkWWgcHsXa/8pWBJsMNg+4eYzwkhlfPs8mY8Vq2Z3ZBUSONYGRBw7cLLR0uGpdjVh4B6jEn5Juu9I9a91yulpRCCYievt5fyYahznWHu2WsYDN1+0IjRUJcZqDjbFF/72wtPkJyR78cXSxfmG+BLdlZuzxvUcV4/sEZ/K+AHv54MORH23c4oqjf9bg3WbSrM0meRM2SRp4PuY36WJBku/2FZzgRbZMZlFyrgu/vnviJOVUtALMOf0oe/fvYoH5DWM8pzH9CTqthNKI5untVjDloU4vEkXJ5NQyz3Arcxn3Mq2ONUbB5SOPBTzoPADDELSKXZJx6Y9fOKZ302adb+k7APovco3jKfLN77sjp8cb4hnjf86Ot443N7ffob/fXi8gboK/3N/73hjf3fv6WB3b7D/rHh6fPCknBbfvb7EHw+ON5bthJ4F/4kx3u54Z0eJHbptdPuRNKrbbtqbHQ4q7JjK3IGNbGzT67f/XM/xgXvwwOu2qgZgWt3N4faNL+vjPfjh6fEGzhamPGh8MNa+J8pHYpBlVtG/9naPN2QN5LP34H7qCDKUy7qNL8vjveN/pVkAxVm6f4fz9Yzna293cLW/8eWPP/KQZaoHhNihqdzdP94IvXjOqP1pca8hSF55solK00aUqyti/Gvk2wuVEtd4FQfbB5QH8jUY9NQ+VfpcVopptDwQVlgpIly8pFefuyGNG8RqBkAtzaIzkC4cK7cVddLRBwOylA/+QvguhdsRIpiwROQ1YXUaEnOaCHdIE5jjp5D9Dwu2D3v+pgUrf3GPIPcu2jyw7PuyD9xue3y88R3fgW2SwZx/He03uBjdfrp49eNhw8DZMr4NnagD2EQnTOcoBcXcrAlD0cGbt0x72jBA2IC9MSJDbNpt//IXv/zFJT9oQb1Z6BBuIdL2C2wqUMHq4hu+6IqvwIOAnflNrvxdfqI9qdfZXAxDMdEO8deySd9tF2+pIpHr77Dn1U2jOfHcoxyExj1pGwmE2soNWispgi/dKpBg6D7xOuWs8kGZNLwy8D/HG2JTb+9xhxMdi5BPd+71OIV4gH/5iwL+x0YIFMk1UiAlLhXx0Xy7rJn4sOxYft+Bd93ekJmFDXTzDAO/5N2JL4T/1PEwdX/vYEzVbX8HxYtl+7G6xxz84G3wLjcJR+EkRC/lV/6DZGCoAEb6eWL7IaHejTPncoP2+qIhjk0V6FZPVy8yQ2dV59oD47wOTqk8lwMnAzXR4q84XPkVwXdYg5gaLGPlmUu81wk+XLy7+I3sk7l/sj/w1fybr6709VfffLUztwtHr6eCftq5BegMAR/e1mC4JQ0RSDxv0SYalbOIsYLhRDhlGxelMCW5au9XcEm7IY7HI/2Awnx/2DSO5LxmjUxgitfl/aymbiZwllpYatCF+SnZW3creZSyg2/61BDHq22YaNvuqreUH5vWMxj2lRZ2ZIezG6zQs+BfT92/8sOlnzNjFhgQ81VIVWwnFuZYEvK0usfCIhCGxrQZoNxgvwtJaggeyDiLTwt1G91N4FhO7lM/N/rsJzR06sclRgnLSwSR0El0k8aZuZ56e1Ig1GfO9UbOpG/xG/9lWf9ZzibddKFSWiXv9nTMRoZCfhhuoxSxatzj5zEeGk8l2zfb+lUiqvE7JwanRTXO1EyT2uu02wisYflHcxPMDEu6H5r2Q2fENpNuyCWHwSbhI27BDkjyIcQr+ADQLk29HIHFV2xKT1R2JzEH/0gfs9/zXkwc6l7tvWTPRoDeKxsHBg3OWQAH0AiRmXSnxCnk9Sm3emjP7IEJ/mkbV0+ayNAWcQ/Z63kIReblSfwgkaP4o/jj7inrPyO8se/lhEYKvoJDQrIGWlEpTGf8NPCVZDK9n+chhgyx+AJTDR/I6pCgrNy4727EojNfU2w1LhE6oznmhGVBm73VKJ17Wn7R95EFlfXdFRzG7dRjA1uUzZfIZdt7Ri7bk8Hus8HuYbH75Pjw4Hh3L3TYDh97hw1PD3lo/6Su29dPnz7d/7W862v/lqxXtpvxyh4yfX+aW7Z7/K99ftY+ftD/f5pw5MvAhJej62nebTmAX0+U2ERCoS/5fK7wX/wjs67K3j6sGumXL25Azn2h8pzDmfVCgugBoNrMsfY8QlVTS79rBT9Lu1C6OD/unFW/d3B0xFb9rmi/QG27xj64kt39aEaxwI4iZIjSWorBY7G2XESnechb2AkbSMm24VlAjdbdNdpJ3nrmG68H7SwmmL/kr02foi02UqNj6jre2XA5CB7WRVRemntgz+M8lNnc73hEqB752k5bAcPGvsg+2GsNF37op0l9fc1qnjvs0hCNdZHeMi0/UWuuWcVliJPqYxUYpJbHi4OPyIOMI0u/9TD/rQHhv2toypEYpBHiGmQhbvQAsk1YpwEyMsAMtBgScbd6PNWj9Itk1lx0nayqpLVsZtH+wce0AxUtdFU933wQf3OZPOHk9CVCmNQBkP/BayXIs/nI1YWRXcqNs1zHk4b7uNVjqpOxlkbIsygD4Jydhdg+tG778TdwS26krGB6G95Y7ptca/R8FIIDDC7esV2ccXExxkH8FpXO3hhnk0RNF9XLbAlQjt41hFkc/u7V2cuXw4v35+dv3106AsFlxVQ7QrRD9ie+ISMkksOtOFcbpjXbyRUKiYRKYvPmBKPhgh3gjrkb3FtatS3WZ6/q2Yet4l0lWZvber5VXAowG//O6xMqltjkAM0LsjVvb1CIeO9xsfv0+GD/+Gj/s+yNvd1nT46ePnMmh7xlXXvDqqqf3bTY20XT4t9MlXBoEvQtOTWYLR7dguQfwDGGOcjrdxjga7jwFC+M4P2rApT9L8lrfJwe0vh//ct/QZ2PDQr+dq3fN3I5ullVf6iKXs9TNqFBP/dZx3t7g/0nBXzm4TMwkKLd+nT1bj083N/ft7tV3rO2fbxq5n/2DQxPwAwF/gzjCHAXw6nNcOC7qBdLye+iP9fHzx4f7cF/066DvQdTed8NJZHrng8/wYzLX4fia0Vvh3ulhs+9QIYNv0zL9kOFinE4moe/aMoSZot+AcNTBkt7iuiAdap4VvUvn2H4WhGyVpj/Ri+G/+4rhpZL70ZiRR/JkJH//WyKmsxNHEUwJpNB7f+8L1efvr4o3pQf9W9M6AZO1Yz/hpuJJ8KmAeAmOTlCANfy9n8iF18s6tGHe9IKnew6urDjjzpwl8VuTnAxDXRfn5nXxfaGxZSzHHahBkaZSZIQ9Wd+RXEH0zrt8IyNrvVau4AoEHv9z+gdZikPj/qTifw+86u5X9f3IF3Inejf7svya75/EK5vPB+Z5T+EOUK6VUq0BkPGq3bcT/qMeEfsP3WLiTtiQDwH0XvDzXFw6O7AzbFi/cJ9cqBvMjcMpm6f9NyLW+ZHmmZQmrf0HJiFw3FV7V4/eTq+fvz0qDo63Nt7Nr56cnD49Nnu/pPHT8eckoVnLJpmAirWZnXR4Kd/H+Af4GH1mCZyz109EAA8S2XNYg/G6Jk0c93URgMfombke4tBcS7FeqE+i+42km2gj3ninhLqI1Raqo9kiFg9peIH13j4oQKp7GdzKLfiYmVu3RGECe2PbkcHJPb1ECvGjGiHhdM8D07cE9QKB0fP9h7v8r/MLO49dfsLOYsI/dTeR9O1r7J7UJzGl2UMDxkFTALV/+mnPT7Ifxqb4Whn7IDniEiEHdD4+zu7hzvcd3mAYPO97flM4xyUBSKEwR4H1pjSCf+yf7T7eO+pzIEoIq8wez5W95b5ZLxUTKCHP3gPBRj3cv7H4oR7RV9TS1rBBdHOoqdNagrTF78H70YxbEo5J+lhAQeSZyDcDfSfWu+K1VPMoK99qW1Kf1vmiMB+NDgwrFSVWGNiiC/AKTt6jDiV4/39zO9DDM1GWyCdkfjJyPGqmubC/KDkCQVZLfcqztK3IozqYzmRoyf7yZ+vo56d9E+Yz1g0VLvz9cHR3uOjI0JXXy3vh2D7f70nhwM2S3VXWkMM/ricgwoaV+aPMHoRLPi3AzxFuzy5tDYKccGDSH8Y8HLQNhTloAJKeYoH8OWkO36k8+GwN/6lsJO43nKDbTh+574RduCotOD6Dagm3A3iKLmAzLgfYSxP9549PUpOPnzdpAQne9FFpx1+eOV/yGx3PMjPq66+mRVY/txWwh/ueq5jjGJWE+akLW8GsGMHSJNruuNl5UOP6FshH+QDVgiIg3UFBM4+TtbR3uFuKiYfo7XCixvMFfz9xP09M1W4U0/lsN5h5ZdHCCEXZEcZYjnFDXFZtjSZ+Qn6OwjQ3c+fn4Nnz5L5gSkB6TWOZgf+8/Tdi+c9c/PkGaYA5uXsG4rdS3Y96B+Msk7bmagvSrEk4jgdYChIc/30oOys7X32rOGnrJiz/Z8yZ0+SOYNnYjlevKXgz9/rn3OzdugO36ICQewKpZW1SecJA/ST6hPjNDAYisIXQ3MSLUZ8b36b7X/OhO3twJzRd/wcatrN2O7j/fQUeskbz9il/jmnnR+jw8N577oLK1mYInZUUdMqPoZSQ4gnkXQ4lg4vwYHotgx1HGtknHa6RirkvVanwJJR7Qi1R5S50j6gV7KcocNqwr7L6c+1HqyOetfj6WdZTX7WM3bSAcz3S5wCBSfyrLzErylWisb9A/hQvYsmxZo5W4Xa5982zQLXa46wsikjZm7KembWC2/WfD+9eYuWkJLZMLbt4gdvReGKo9CVQPEo4hVClJNr573FK8z5X3lIz6j0sVckypgMqMNdJS8gDfkTbLPDZ0cP2mbB/v83t8V6dmdoiz199uzw5zPFDntNsWcY0IOtiXmMgWIY27UsMnCRZP5sTEEk9L+lucZnMWOuLbyvGZprxgnNyb8n8DdWsWKu3VVXbLG5vnNx99GcrigoljwHWXjL/BIEMOr4XG0VpLS2ClT4W3Lyt4rXXCcm1J+rD7UYnT+D6fNkZ/exXkZScLv7mAjBw6NYCu6mApCDqDAaGMtsdD+wxyPvN8K1JzfCdXkVxeP7PGUvEmB3HD5bKRCeHDx5UCA81jGslAg41N9XZTtJh7qOJICPPnpyuPsTPLPHB3sHu49/PnGw58/d6gO+F4mMfX4pbCI55iID9v1TpuWc/n4YeUywEuIVk7FI9iiYowPmwMLfH/e4hrp87g10RCSw5tTzCkn2bI0P3e0XZWKOYeqBhq6//5sJOQ6uXJVdPVrjPMGl3+KlP/E4PX7oND1bR73SCP6eh+mnhTjoIP3EEMfeA5LtyecJNqx13C9H0Uqss0b01Xt7e6vtIBZ7P5Ogwdc4W35IBlA1Zg3w4/+SLv9zSxdKXcYv2peCMLusdABWfmmuosgkDlym8sUnzQfZbP2qJ+cdomdPJV+vkV4uLELXYkF2eiPdATkB5ZhpHY2ThoYratGOxQl198tfMM3nRyJUurqPzL3fvX4lT6ayHTTvwBciTC3/WcMw/E5msMCnEgyrVneZKA8wntVccxBLJmmAafQx+8d4qfO1kccei4GoO67ehEbpL3+htuetNEhoiL5S6diUASYLNDja0zqh3QdgO9sPImfgGbKkKVJ3b7B/WMDxhEXeX4FFCASTgyMcPjk62NszcF12AdfFIqzeVz87GgG99LWn8ccoWhAfnz1zfC5NJMdgWBcrIjlHR+jKYLWOFqLZZxWTavH/+d/++n/9f/z1//a/8alBzpaMgx+yLzAbHadcnOevFW+RX7RdnATRbUcfPUGGMooBSLAXqSfuF9SXj5wsRJASwfK2KVaZf/OLr8b1R+4e8/VGNb2CtfxYT6tmo+iQrfrrDTRCBkQMfFyMsBty++XGN1/VJLyLrh197TYb9dRut+l22nGI2Gl29p48Ptx/ChO3gZQPi9uvNx6D0V7cVvXN7eLrjYPH8A962hV5Rl9vwL/BP/xQL+hYY3kHtxMups2f4z9F/4ZP4pHBf8B3cZnz6dvX569eXL4onr89ff/6xZvLk8uzt2+2ivO3P7x49/L9q+Lk/GyruDjDq4il9OXbd8Wbt28Gp2+fv3h3ISXS828YEii11K2IkDl2kiQhjGwFkrJFR9Nfyi1LWoT3LyrZKZjCaqvbikM0X5XFbVtdf509twEnxA5vFOpSOiAXekBJj8H8dr6jNNndzgYej683Zs11gxO08Y1sNfjSr3bKb7Z55effuHDhdU28OYuyxiYcN8t6zBV6P9PIkvEIk0PmbJhD4WlgG99XbEC0g+U3Jhh6zJ+jNdM/05g1BzBwUe4B/ga2DN81oO4B6aedukYqLjpORdV0r/3iDj/D1zD//YZtxjvAWR4g3wPy2q09+HidCn3C3/cTZOCo2AfYrQAhuCvGLKOkHmd6+d95jmWHDpBF8KFprcyGJoLLdA6ZmmH+DZVN/52OHpZNBULA6LJiugSbbVGNbmfUUatbLK+v8fiBrm1n/+RrtS+18G7VKJNXi7bEt2sdsFdcHLjWzlVG8ZlIIVpmUg0o7WNVAcrXoLh/f3H59nXx8uzFq+cXJMtP3765BLG/VVye/O7tm7evf19cvnj3+qI4efO8eH9hRbxT44n6NuVp3DVkc1qVCF3csghU/GVLCK2MWleTmETco61wHwhPHBqvnL+hjCyyH7qiQUZiIEV+kLx1m9x//Mnp6YuLC/rid29f0dfzRLhP5K4pKzcXsoq56CUuCNgOMxB1/0G8vHhZOdbKQvk+Byux+WdX65Cmoak9JBXhgSsn0d678n7L5TYQNMxlT7YWggr5B8SQSbJKuijQcyWBghWw5LsycwVc1Shdbtu5g/CSugGXuAG3fGtH3pfYghPL9hAHTzuS233jf7mIdfTV3IfA3EaFKryHyDpDk8ytve9ry0zt5j5VieZL/Yq/e/Hq7ORbsFykxMDvZU76BWzYrGLnXN77x0ZygSs3A6UFMyLNCAmbQCTJ4tOQ6m7pNdzmD1eKbFJ4uTOZYGCYoMTdidM+rrDZRwtrXCFfba39RWsJ1jvijp6TH51plyyw81GiRVr54mF71Lcjo0LJLtgEmGDqDk1jY0w7JSN/4c5T61z5w+8vzn74/XdevG56mfJ93SE890XcuUHvpV6gV82nBwfCfez08qBmPb7hXTmuGz5dK6563jbzAXWeviDCpRWXUtNEzo+suOpsSmwzbhKilSuLtrlCeldKzAxgdpDJkRnLuQF5heTIVWaSnlNzFvdg88jfXlDrogHSAle5+aWOXSsG/YaqeVdccH4L53zF7xcf4DNX/E5MV72/noAF3Kz4/Xv0wVb8/gJdPuJEQ8T0igtPm0nT8iyt+tiG+KNItI/slDM0i1f0nBJexQ5sRs5V+xKjrvCI1EeRUSSeU6CPmafGtDwJlfGA+sqS1N9C7UEkZFhbg+xnMY0I6luOE6GSlzowzyA+uZekvhSdMrOGfrgnOdMyTSWjicXT+duLy+Ly9+cv2AARm+TsRa8VghUyTDiMXMWxx2Q9pboyJoSAObHY3VztWlc4s0OsKQklulAeajAxKytWV6CA5hX1a7GC8SVagarhMcgnFyekeidd17ALbKIctreoH6WhKwbD6aYV2lzzjnAX2H5x3rBInueIz759f/bqeQGakyIBJ6/A+b/sn38Basx1146SXesIM3MvpxXxoYBgNbFcdNFgcPyelgP/w/0hPBf4M5si8+auapEtkiEdbn+9fv/q8uzV2Zvv3sMXvXtx8vz3sQ7shCoH3p+GoMwmkfAvMsU7gmp89yJgjhoQgdJ2cbbAwNI9oYCvWbvTsgZmhSmMSkwJhPU6u8HPlLGlfGmYD2tZNJTnbxA6DXESYlSBWlsDh+UjhA6GFYRFd+53yCWZzxeXJ9/CrF5mJnOOXGzEGXxdTnFRkZaYA/x2cIRaxjeL+7PlbJ6xLDo3sOXoeDJrd3fbML7b6qbp7jtwy7usa/V2Bi7Zd80FX8Kz+XbZuj5AtGn47Bzt7m7t7u4Wkhmhlik1dZGISYOpR7LzyE5fX2wXPxCR8R0YTciNqIQbW/gXbDwk3QVA4hIhwZat5Mbny9+5LZFShmBl5AhxHmBNblOtU2NGjuxft2CK3NxGUbMF139vFf9yEj0PpPV9VyNt/zVyhLBA8gHjOfMZJrH7/aePJXy/j/wnefZcUwWvwV8L6EuJ+eH/xaSvTLNouo4Qvc3yalKPQrlycn7GM+rYZuHYwlZhlleE+BERSq/USJjjS0eoylXSiIqeKyu4NFVxJvKmpnBMLX9zfV3jlpk44CDt4nvw0x7pqZthS/TrZURdT9OnXTvhsiE3q3ZswJxzwfunqMsXyOn0H2t4eHtDoY70Uc89p7rrEMjMytR9AL7mCfLZ5FYk32qm7G/e9m1V4tkRko+E6XZmr6X0BrVIAZnV3WoXCD5df1pSc1Zlr6BeXCmXPE6Dbi88tBOi3Majxyzj+TsMOQlsqu9evf12+O27k9MX2SnIs666L1k4Z126iiPPNGbyfE8yZqfH1ROqx7v5Yki3DCVZlnTKy02X9pO5oTYSyinWUTiLJb+oXmyF+oksATBFMeL+5ruEwDV8dEKqQwC0BVoenE7MzcxeyooaPtkv5gFWa4MWuEda1naBbGedNhwUp84QGMTvebrGeyRQ3rhGrCNx4MAQaclN2xG+2+BFPfMhJa1kpYuV03Avsk1uMOdl/+H20+39pMEbjfvJGuMWMnzeQCPtLYDdEWgXM30SSnArBgnBRxuN23ubI6+kgHSj+Ot+sPC/qvZjJU2KMx2qSActPAmxXcQyXCo8mqdiHlxqFDwrRYQIMpUijqFuBpKrBaFuWKWIo7A0lqI0Dy4YUY/NKuDXJhF3q4QTSYvb6gm7L+bO52IYU0QRDSCps5butdKUhmNhKm5U75IAKIVa0HeGkrgc7PflhCk7yutr4jzHSm1WxIuSmhSpfZqZuaOeZl88d/TqUUlT9cMpWE+UuCeW7xA977hrTWZferf1vHfNt15qxPXneW3clcN1+VrFve5VGaULcNczgabSPlMcRDYtMURLZ1ncbNlh9PQD0IPraP9hO52ZZ1NxBzIHlp0rslourp9Orw6NZKXAfualsfHjv51Zqx2NoNhB5s35yUwbB7MGlKYKxBI6X3a3EldFfAjzjFaK8BU3vxbnsm58v0yGi2jPWCIaXvDlsSklqo+2AA5gpww6FmmfLOyNXaFFk/2WWAmHfbMtWzPCmpFtLxWJL0FYFSd3FQXGYTgqUA+3nyAKJdxUV23zoWJ+dtxZolkDo3Ohyn05I5uU2o9JwnJtkXTRTOpJ86flfXEBu9FZTMHXx3rWNzcSv4JTHizCOOtSasEVDl4llkdBgP8kjU6yPZPU+xBEzyKEG5WkfwqKC3vVcsJZOkkIuMIwB1zXQTw3majwzTbiTGkbQ1RPKilolIMabKwG1eXtcno1A3vLdJuWn4SzbsznRX+nTmhRrpbSKoKXaJKuOP70zAYi9Xx4xn2lIyTVnuGz/AsyD5bx6tFjMFhC4Dt1nyAqKtV/gSXjzCCaUcOt6S0lbPte7Cp4QAVY72NJ/Cfr7tnlQDpgskC/g1h3USYzKQ2bLjo9sJt4Ls9mbHnU2lX3M44QxQ0kFCNMv9SGlQWw75aNhfzqetWjyVBJYyXsKfY07CvHBhVkzySjKcGqzxjf+646md2T9JFoae6QP2zktgqKwQXDLyEFph1JJZPnszLh4ZIuB7zph6Ouy7QVdHHMoQjUSsNalNoWa7L6JHy1K2bDcB8ry+LifkKpB2nMPRuL47mXmcqbCbY+wk96WbfVNezev/7lv5cUor2aIHUoLBktcgN+nNLoj2CZKXANW+ivf/kvFx9ARL+sqjG6TH/9y3+FJ+SmvcdGL34L7tsFQdosY54awtcTbCyl2WnZU4Fy4MnBnbXigN4yIzUvIX0Q9e7gzqQjl4HidycHlq4nlyboja1fYGxp33kI0+BboH3BIdoqCHfGpbuY3XBBTrJTXRqCIk3cMwqMp07L0WYDotszPKxbyKhcuPwyXUzCYt7UzBwHnkU5umU+OCcyiWaoeFVftdglelOGzUE+L2Yo7SKpMfgHbtC6mz7KyFHt24ZqgY7L61qMF5WcYhmqpBBVL/2mTJgxu3Kz3nP+vP5Yq12MCrZZouCuZmAYL2tu+ohj++O/LDHM9v6s+N6vUCgY4H/9QIbrDE60a0bHMWfnQAthsrVuKbwoZa1USYxpCwIz3hIZdOc7vVCoglhwJwsKC/dv09XbW3YxaDaYS9/b1jFqkt1HHHhjDufTW6VnTClJAnyci6Bfq8amL0t7Mo4L6dMu4pByV4ZQ03TnlaG/9NF71j+wl5A4OycQYl9Vrcczxd7jF+2ByQi+WdSHQ7qYWXJZfHso+h7UHHSfaM8tmR+G3eMOkh8GtU/4yI+3IBX8/F9VpM1GzY20/sWM/uh2vbejRt2ShS2LFif17DmGk0AH4G6VTe5674kbIEYy7Q3f1RlDp5j9zs527GeCrgycfiPE2uXEyzBdb3a+McArGHzuneJr6C9fPY8b9rGLYA4u03pGr7JK7TewcyZVvMCm7Z1viwtSZ1flDKUFtKEg2xIs6cn558BPvYgNr6QdKGycm2pArcIpYIKSQcNRoYXCy4AQCA5d2Y6HwbQn3S85tS1dM31cGb1lMy8wUjP5Kw140zwvzKp+nh8gU8p9hmlOXRNK/Pk/8pYbRFsOjz2+b9himLcdOpm5+chHwHER/hNd9p+9UE0Gg0aKYjwV9FQomMwIJubZYbFZosM7KzEyV1TdqJQmoKKzLFCUjV7XI1c0BPUzDBx79HjJJGP1Ro0lKzYWXMcWbGlA3hlLRd4ZhKhlqjlLbbqJisGSE6M3Ra1kqpLYTs+eW9X6Qk0+1tWkuueMYLCpVw6N2oAAosRroxU0T6lLXBNj5bxqCZ4USqZePWv7aKT1ANQ53Qdnn6z/XMZcGbaC/3g3H0r04sGnmhFI/Q89c1LdlKN73cbM9ku1crqfg27j1m/p7mfYuldsaG0iuFzMQaj97vWrZABwaOv50lLXotrFID4G3bzzJ+6CB3lQe4CuntaTknSb93wydr1jc5GgW9hHmGw/ROuxmMNEsulqR4MgFE+yudOUIe1hU0mVMzj5BXYbY3lK8ljYL7hs5G/OtCf0QrWVa4LnLTcCytCf9yVcmTyTzouGXMy5odbUGom0IyPf37S7iQRyPuKoCsdlbFnz5FN10RMSOcukunzwuoxsVv/9yqB7OOKddK13nYdkkmwwLb+ovKcTcUs5BNTGtq10srOpF01seDvzKk2PuLo/OsmrttlI25fSmYi8LjEx0Ce4qphrm4A9VU+8NbuE2PiNMaUyKGdHZp6R1comxifHn4z3Ldu+GezEcu60mpr0MuuBA1AHDkMa/SO1yTm/Icr54Z9rEoIV5dhZGvbcdV3PKAY6ZNNmSKbrkOOReHMpehetIixnLTmPiZOjgFrkztwGRTWKWhwig2a12Nl78nQvFb3GPydq/HokJ48ASdyrmxwDcMTamnc4yZcBpT1h27ncebpZXDtim62zbksia11yzJvEzrVxUqBvU7IknZH9MAndWGxCXnxHlp5zZF1okXKBxIlPUn3G6G9aeTGS64XJRfW8Hu57d/nKd/aT8VC8gbslscNMp4HT7fM5T+gIUxMTvaqZBcLP5TVXHsbEoqAFu3dNd1Z3Ag+fZeSvOdFamhr1A1Or5IpDtPFjgxZOpreD1Ho7NZCP9tgsezl1jgvmGLWbc2DEE0zxtrp3POg82/ISyrmQkuWMF87ZDirWHfrilVom3+PXJwWMlEptcjVTmuIWo7t//ct/e+lsAcme/vUv/z2Zg1A+oPAY0qIK/MGe0BXyhSmdaWq4hDvwEfxad54GSqYzBfb41Abmoey9ogVg78KlfNzilvH0iBAZ5AId2KFgUo8WncsPmjIwW6XXSoN1tBXSAaq4h8UlR45iF3zu5TjKcBlCoyFWhj2BwQSv4sRct7yasndJ5SAojVhSfqxdZAb/iLundxRNLqmqm8AesmaynBKczybMF1gppZhNMv9uBRwzEm8mTLcUq8aRT9RQVXvXGFI99MU+mWMGW5WcYQkC8TnnbuRobvPACQilaA/3tYHVf4LAANzjkrzYQrzcTD743iEAPOxHW9Hzw1btxHFFwMEyCCnndEX/nVbcrrx5pXcdO870VOM0Z/xRApLqk94wjiPNwjH6X/6egavAIv1A22bhGuIxCaDZ/sHcZyB3JUcCMdlFPAjcW4p0IOw+/B58zZtSCmOM+QRPzo+pX8bpCOjkmRY+sg1Vc0vkQCfkmpoqgpAb2MRgl3/5KalUfCNRh3OTXoxbdvpypyKkkyGddcycmKJArE7PPD81xaOe7YEOEpeUS3MZmbdl3R6JdfMvmbfJYb2tSkKDlIybv90LHnK7n7lT8nogWKsZcZm5PGHm4vO3lz5p7NvE9Nj+3oRjB4jkkneCJMlLYBeH4RETgUPL9IRBiglY9daZbj+czCW63PQXRESHpQppApJDBGq0sFnQlag+u0yuInGmGdjEK9FplEOyWrAobQMLeEvWHQL0KyIgkpabJPoY1tPwlQ/acUyn7T1kPREnICGL7ya4tX0IxJ1plKccBqHmfCgRwWaFj+z7PsagOdCc4rg4LKy1GnBkwMYf175zkgsPdzUF9OiKn/AKezsPm/Mukc3mVUU0Jrxl2b96K1+N1gNP+O39HLHefm8gfpwVUPi+VavmEIhUPMLYkXDHmQ7hGN1NDKz8I/UIobpg34liJK3J1kXgx5XPtAYbKvEAPCl0uk6iuM7qMm/gE0cqyJjHu4mB/E76u6JwOS72d/ceD3YPBwjU6h1eHeMYAsLEzEvXe+WeTXN+LKfodLFmPDUL5gLv4v5yKiSxANIxinW1FVmsq+NX7nlqQvHhxza7mGJz3fM8PiEs67cm5QNBmrajtKVESHnjOAQZYezFlkVNLUF0icTNl33OLrtkdIpSIS+A1ORWbD13hdQfqnJ7wwKi4NdRD8L2pml6lLgazdrbfsb5xmfbe34G6PDQGztEw1JjNnU68oVvko0w9W8rNzFTB4E34QKn7jA5Mi2KME3BcjDGI+awBoquX1imaznaksDLOmjp4qStXrlvoRdEbksRoDnIgGkPtpXxlnVfgxs2fYX3K8RByybc9lwv2uScj4ODfjDYfRqP84/gT7CdiucWVwbVDVH0JybCivCSOqehb5qBM+Jm8dYjGGzt4goLy8s/lp8KPGtpToAGQMdtUqPHCXtlfzdpZt6nIiaSyQGLywVE0iAsV1kw6w4hCrCPIgZk4Zb0BQm0rx5xUOpBIyR5FDi6sJXZZ2avS3A4ocW24JYBxsIITP08SiotXyCqJJGLUlOiZ14sC4bQ8CxcNQv8TBF4KE9XmmWc70jmJhV+AkLyRhvXrYt0U4YPFFNcmMwutY9QqS/9LtlePXUu6v7DlyxnGG0c2/INKdvQOg4NfyBAwCUWQUE8DLby05zMMsKgONlBJ+khUOVna6RUG1nxsIYRsD/AchId1Jvq7tgLOJJO5PtupiwsKiFtPvd1+UfE2IraIfwC5Ti16UcvzjZo9ZZ6+SbOkrr6bCzQvnPhdnRz0YobwkleoKeL4gf+hv8cIhiC/O3Gb5CH4bRJiIQgnVXO7dbQUAdv2aJ/oClihkHp7jA4wI9HJGJc0jW6Hgo0kpr/DUl+DZsZZUCCnK+AVgivQnyRHO/AiJSpOGIiH3ws7FrzSIthsAUW5ccGqwDHpu2BxkO4REMJXyy11qqJA91eX98buJhJJG2Z4x4CvktXSb/FDC4grvycr45lufoDLzhzBsvp+SXzCnB4HJ9O1kXFFZaSQzHsR7DXlub+c5jZRnwqbV5vn+eMPCIB4Dr/1BJ0IA1wRBoOlyiWIQ4DgaupsS+Ht4U/w9Aw3KK/aC79Xrt4ovOLkPsEi464IO6x7HmPbHtlPS7ZhKZdAtoyo4mkjQjl10wqDxNUHAfJBxB0N5PmimrTqplr91Lyr6C/UUly3BROtnAuhdPOs0OYGAY8SZlXZ6NPmCO0dg/3T+7UN53oUPtaQSRFaYUWFPDHsdHMKjQInFrEy6xbEviN7nObmzRgK+aTjFTiypecRaL/jWEUmkykbsTULO9yoascN7BhbOG7NCKjq+3yvPhE+SU6xZy7JEJEV1YhWHrZfC6uodSJiRGlhRUxayCSayHKF0fFFLGBWeZUsUd1CNlHUGdJMsJuLnoSQ8ao/XcyHnh2KQ8VI4SAt1JMPy0pWY1VSNGTcfvPsXTOVZkZkCevAwGhLB4R98mxBpfYfLT7iFuzzU2xCUWiF53LOnYLPPDw3Bj2iY94g76QGZKkQRVQ18yC0XXuqMt+qTuus2kopFG88fuMpKfjckKWDYR5Fm/+cc9fY/cz463pu6Nhhkipe8HW7AhDsYbe6tDCLG2KmYQRGTLE4iwOf4m+8pVPIRm75mmuBi0ybY4Ge/uD3Sepv5IFpVrMpTV1gvrABxBf/DAD5jq0T0VVYbh1+uooGMtgqiNsva2rskUQg0YXSL2QeU0iD24hs8RYI95YqzP5W5rOB8NFR9h+ee9pPOqMrYKu5FDKQTjn41/eFyTDMTxorPIQTEGdZoo8glr1FCOp0yux5y/8HFz2NDeYuGgmP5jdfWvQSkIIlNAQlc6QDGD9F6n8LETtga94DKPJjfBJgurJjXF3sJ94/iSaGGEtcQr2gyx4rb7mY1FnKsHdl3ZL8hHLtgWLBGUu/ce0ajmVy3bjpCFJxcG6ni9Z5zDDl+zGu48kv2g+PAOepQbGL/LfctfA14DqRle75ZSqQFjzw1prUHvJ9JbR5Lo8GBpuWV86usPxVlCaOKiMx5Odq1vgtfLVtFuIG8JFKr7CV3+DVWmLzUdf7dC/cK3k4PLPSAw0dNM05HSclLHJPZ+zYZ+wMGMPDhz+5ajSMm6yUxyM7vwsO/OP19nau88G+88emMmwUjMo1HxoERQHL+eBue5nWjVhIwLR0NfYyzj0h7bNTbUYCjwy8Ms6BmD5uWeFkT9ZccnJw2NxZxu+G/aake2sjMmkcX6FmWP6YQi2znAeVsNm4NwE1MksANmjdD1Nt5AHIaKc0u7X3GygcVCMPyIXoRz9W66koNQ+FgP01FJm5B4Hazir5Za3mmiJPwEB9BQ65KqvVkAbLB8woEqru4pIQN+jtS9Ym0rqQmy6hCE/XCAHP5E/8dDwY3kSLH1c/5Jf+t0k5RS9wxZ/O90gi+rsRAnwXi/Y0hVb9aHhf/ajO+4+kf3cuO6k53P3/sd9Lh3bk9+e/E7hqptgufn6hbHGfqjazv40um3QPrYx0q2iWoy26X8lBDE4GzHoOzcbTwcHD82GZJ987kn8i3IJfrMk9uF8aOyb/rrKwltHqj8d7Cc2e++xNVmxFx998Sf9d3GKrZXGpQB4MU/OYF0ZrvT8WTXedUQ5jPdorfHuc7oM1tjMZ+61a73Uxmyz9Aqya2xcVdnkMKlKLvu5Y3Q4z+ZfE8YGMhPJJVYsISG+xU/m7zrP1Sdnn0eZluZasqopf2gQEyblAE5+8lB1o525VwY3pnFBl3zATJsqKvGrNTxlHfwm+ToNUOUxdDNBQyrTD3GHBJ+iiob88NmirTNzX9pQ8F//8t/ItcJkW32j3F7DTXSvHuXCyIq/GzUOIEakT5SA73iDYlxCEfuZxVK97nDm+JQP1T26nmhqrvRMzTd78KP/26VNrva9WY6NvlpDjy5nqYt07pKVGRtVnkW8IosIM6flay7LEMf3jBUTBcOxZmTWYbHYbJRfPXZNsmvvnqXahoDX7GZhkRNdhBO7ygJggwGXwGYQlfVCtrPmyyyulYuFt2yBFUpFMlBkjAILw6J7sH3C8SuYXMGoaw0x7AFahMc4KzMZP4yb0wMEHKB8eEMZ1mGNTJtmg4cI7/xwbAklAQ0oYklZCNrGrtrCFLM8vA4TEnqmDpL1ZLBFiVWBUpCbWpWihKzK8b5o5vVoJ+kWEljPO48yo3FZ+ObaltUaVhYqhkrIACKKGC0oZ67zKINNoLHsXoAZzGwfaxSDv+K3fcXsmdhqALs4b8UNmUHaETvz8P3Fi+HF5e+RUXf44vnZ5dt3mELDkwfKgkQAN38Fmbg9v53Hcsx5x+n2M9/i5RN+Ryyg8pb9a3rstGw/VAsuwRVSNxWLCk6u4LLfVJP5P7kMXXkVTD9Cmvz8Y3nAm+ouVEpcjYjExX4skoFxMug+s6ZmHJhAHnBANhSn5rZL0MaYMQd9PFVeCzanYnxOuAnOW9UxWwVlJ3z3OsxWGJo99OlA5i5HXHV26zVx/tH9oG7VOgHxFkIxchBhUxiK4FTYhiL1mSn1Ti74ViY7H5R4slbEGQyz3VXWoIF0/eaSIjaWYyL/2jUis/japDzyb3vtGsHYv8Nb17N9dw/it4ZBMjwaP5wXh1j96itcg3Z1RlXT2FzJFZcnEAA6ys8GA10jNrj7ZLD/kIOFO/A7yQpdUANLOLZwVtu6nORfvE5E50kQKX0wWneYidYRGY7LDrHNs5DmRFy47AJ6/zMPc50gyZPB3kMOXigQv/OIOVtKhDnLTVJ4j7hmpMOa1FSpMoFqsaITDFsJ/hnI2aKduugEDOgZAy0gG1wtb3Zyn79O0OTJYPfZZ6zSXu4964QjHmf86Fwslyz5k8nE2OaUWbtiXuis57HOdHKNK2qhAT4PO3cNyI9jPoLs/K0Tz4DvCsQVaaHslzkPzVu0El6cxzZ8JjIpHEDuQ8MyZ6nNkm/l9i2yVZrFABP82K0su3jrqD34yIcCic5qOzt9NcRuD+fvXlxcDL9/8e7i7O2btYbNjY73ngx4SQZ4AtBgxBbD/PABse+BW0CPGMre/Fun33b6cgbtzzHPaHU5ILVgNSwlqgq834f2sYBNZr6o4u620aZlW7xRCJ9D7a+Sw7AVGbm1+ZOBHBu7/jWq7e8CVLXdImttECtEfTSIggkKWjKI7yi6wEEFF2Ow/G1rHG08LQPePDU2ymYo2HhQD0a4Z9hxHID2hd0D11zdD5DV8aZp71GwwjgG4GZgUg5sg53cVzgiBYLfBWBNLvvqtDhF40vr+B6JpXK1nHzQukyNhiya7NLZEojPfI6lJv/pT/F7a/VTKCToKHs5aIIpZQ4vcFRDJ01LH9FZz4DeQqfVl+n64F2ASg+Z2oIBeWZPgWRnw1nrLJkZ9otPo6qdL0LpIvv81MUWuxWhUwuy4Cp3EjDDaflpSI19w1CIlnIyHJSEmG+Kx9ENuovAZoRm7Cuc8UMwVJHEcHEvYD6aBWmn+cBOf/C4ypMHo/lCG3oO8JGDshtwyM4eQs8GJiveZDz74MNc7WkG2n0qfM+yLobwqiPKKcaddjVmo1jUPxTIiscSS997u48SC9IPWir0G2xXeUeYetVboI/+7M8DZaVsCAgO0mckQj3tY7h+zAn+0jKQJJt2S96+1AYj+bDGlos2IeDMmHLmLONPURRku3h46yjB44A1L4h3VLtX8F9stw5ogCDx224xwFjczgMTM/UdBAWA4Qpk71qmKKHrzotNTJiD4p7fPmKXclHePDxg//wBtfnmrQbbHqxQhvgN3HMHWN2cDDgYrsIfaYAj5FFhbUn9OjDsJbmM5ID0ZDSytLKlIIQ16HVXdjFmG4t6p8upAPios6MvgVKmBiGSJEhgxqx4jP9vPdMi4VjP2XeaLXfgBbAg1tpTWqk/EHqOAQbFBnf3XX13zx1+84Nfx7k8CnzgzODfz0blErG+77Sl3wt0So5ppVCIScsBsYTXsIZmsM/g1sEN+W/3AyapHSxb+OOi51PWcRSPMvWr+inMrbIjbCukTc8vA6Ks3qAQvn4d//EwkzcOBbFvtoUkz3ASxImlGOA5RyzP82V2j9eEJB0+tBepDSdLUdbOgl5hiLWC36uxJzE+NxkEPKprrPDe4DH8v66qph02pbqCM/ZhwJQCIl/IIhaGSziOg3I2ML5KzyZYxxE8zATngglQG8FVFcdVY/nZX+/VvfsvAuL1SASCz8aQuzXmmxikB/i0AT6OXD0mVFs4cSHhGZUa7BP+seMQQyLUGaQotTHyDUJQu0azJ+ez4l6iphjKkvHQl8wbInoEe4sMAhkmOEFocw6W0wGldhIfyMIOuOelHu9GSeWYDDyKUfSOo56Vo9ESSYid0BVtw1tXyyZEbQ1KNBaTYdnAv7eIEvWWhf3Jtjy9uDBMFhS+FiYcdC00ZStg0o4bCDVBA+yY1CJPFiXwcGoKgn+TU2JLQVc9g3tZOpIadD3RX/XsOmvEv8bjgZi0A/hhoGVhw9GVCS8qyH/VFsAPQgvoyJZ1RfS69tT3pFhD4X1+KY0l1/kUMvLQvMNt0cHYceh8+4CrXQctEmAuUDwKfoR/T79LzpxzCXg9eEt3zh/CRLKYxYKSUXJq17BecsHwAeTAzdshvA/sqI7T2EyxQABqWHV1qPHU5C7nDuozdcjWmBTs7E2fy67Qsu5uB87PHdAHURw5oRZYedoFmhY4YAbYUBN6xpYFGk9z9YpL5iiE39Ir0evAf28Xbx0GZFXFJgcVDBtxCsqIMtjJyLTcph84BP//Jon73wkAdDQxs8T8LOjIZVVd2pcrp+z2B/tJ6s3H5OdE1YSMuwwgXj3T6qRx/FFpP9yUvMNoo28NA1JK4bWCIdHApVYKrJG6oNTMgDlnB9TSgxXhALM1dVsNkYVwwFX5A2zFgUJefhsPuHSV3jo0u1NzE8vFdChNHUShM8uVr9KPUm62e0PeBF3HlN/PlqbUsxD7vEWRB7Q65Ti0TBnnqHy4MpONQ6rIoirmZU31buUkk8A055HI81KejiaLwqYzuI5NEAmEwbipOjAccWAGpFIRAHMgPFcYRZW/VB3Fx5sdCQyIEYO1x/yfm1L6ROsqnzvETxnWs2EwZsHEbmmx1HDIBXdDmhn59VHa7TIC+WLQEkcyKS2sNz9L+XCcbz3GiT3EqMvmclAPR4i7bCfr2DwcsrBpvLojWxJZE/AA8BXI+zvA7xg4iH6XyGgTtzQVC1thfa3ITvcRVCJIWDSNu7u5Ueojkm4ku9Ywi+F8DzSLTjZFupXYKxFt91AwRimwA3Uj38RWHh8Yw7qSod2l2IUqKI1hMIor1GPcsgUhQwRXUuK2Vegr9vFgesDWxMTreds4LMyD54yuG+izkslwpcKun3wsW7YZ9bAHV2AJQYWeLhkq+CXX5QeOBaHV0M1DMoaMVtBuOSas6iuW2X9bYw/IdsY70aAEqTAHMxnEA8oGL9Fr2ijmkx10i9hw0Pojilb6x6XDQDE9CNHMxw3NYCaIW654f7byMz31L5JNsth11cKWltD0WdysbraLlxiMuX308BQE9qWan8QSmvte3ZjuBAZb8qYvB7dGiOaQqidTbH3AP2L6F0e0T6YNAWUerU0nvTDnXJ/BxpoLYIQEHz7k+P7M6d0YlZgbmQot27xKITQi7RQ3nO0658GM3NdqyzEyRsmddTwMHUQorlUvouNBaPQB9a0YCB0KWt+SkR5giGZ/5+EXcdbSvc6nktk8HhhXZxefj8lK/eJUnAYTiv1HtEUmB4yxyfvdTNvVTRgjy822GlZlwgRIxIJrSLTbeZqqpxbSg1vUBLVGnUwM1Q2WKG5MVxTNZo3HzIDwXdPcEKZz7lNpPplukl7MhDIjooCGwH+UkDVeSglifq6hcRfufTAFx7lPZ6AQkcqqDBybHUzwpAZgZGwwO5iaJ2VvcKxnSZnyEAU+8dJwFkAMUUcMwJOJ9JDU8syuJPiCM2oiXP+52sYtNIL5v/0TrSzIJ2wx0u08OXh2sPt4byDLDms9btiF3dl7+uzo8e7R0eMdZFmgepw1dzieB/EKKFzZgbhEZsMBptQJN0FbZ6BXHw2ePGQt+CQuU/E1Qd0H59icUIhAHX/7RDzZ23u6t3/wGRNBWASMwqA+CwTLg4aRKjFDPKy8mp66/5rCVLPBC9Bp4PwHzRt+1i3wBD7+2a778vXyoy4bKmU+2I9uQf3m3Adkclc2bcXuE2cgPY1h8nzSS2WSAUtOFjUupFDg28vvLigQqClRDmGA8VyuBwO6bpYgo5EuubutKvCI6GQO+PQNYH8r+vShqVJCFEN/GTD2flxLLDttwjpKtEmVh7aYhL8nCTCqV/m5WsLUBO0jkNdkiaQ4GvnirjqSdmC3JMWcRBbtw1+D9qMkN8DwDnBW7CXx0AajRapkMnBckkFz7ArS/oyn4tkeHInHR3vrngo2RzXacjcf8J7z/lzMsZXH3HnXz3t+QW0bmXLq5LlK6o9Vwoxz3pI3L0G/rsr2JbHva8K3xRK2H6w1FyEvKYggb4XZrGrgks2uzYr+bhY/E8kd32ML3pGtWIe/fyqELWsHybRgv974mjnsW2EgIOuF0TkhIS8b8FsGnwbyFnrJAF6C6qwcYP1Hzg8IjAOZUnDeOIJCHg9Im1HdVeuHxT3rKJmJVxWmqggo3FxzoBxHNCetic6rtH57WPsoF2vI5kSCVm1RLN53vysLR9aPeTDXe0hUIAc5YaXePEY0ug+m+/ysuyMaf0oBFt2y/VgxrOxa2viKcqlbzsR6BAsvf5+HYosdtGGeJQ+64e4C/7ULVDMRO0pE2blJ1G+F9ZjFYqztYrNrQC8cmJfhmRhwC4GBtOegdM6cbY0ZVh/VoADoeK5aafeBQgFtXsGMmfCZi6CZjOsB4rCzn/tlqqjMy/xJ16+SV1rrEH2rhz6FN4cfubbqWc6wJRRnctj9RxmZEMiasMjqz1xnSvnAYLcDF3Bh3lQe2lXFTHpk74+FPIJaVkvnJI5a4CWd02HWSFjHV+NBDfbFpWRj3MyiIwahFyDAeiSlWB+qofDuOZYSp03v5uOr42PkQMLrct0++mclMBScWbCCjnqOzjXJdLYCvSNFhT0DwyT5sGMVDYimlM0CqUAWX5htL+7FXDlsHFl0SNG6noWIT+eHD0ZdN9CnDWC/z5dXIJBzkvJBQMohsROkHDngQiO7EHrznFyPr3AsGNqG15D/ORRFYsJgQIEr30N2yNzYH8xx8dgTQAfGVq9L7Kp4f3zMARz8E61w8Jt8Av0orYwa6V3W3XdolKWudDO7nzZgsbptHKg5gW7wuUpmzC3g9qgj5sRaGpaz3e+OpWwhBFrME5dDO7qG8+7VkJv7zJR+9oRm8/ag79vSZZ8NTVQ1/SaBm3y1A39lHkbfN0qMqxCRsipnJQHlhD3afTs1N3NNTaiDyWSJzSuz5AEpXwVb0cjTvem5JbCWHP/2aCUIyT1VuyEpg2Fg/U4yYOkML55J4RNxL/tHPdS9AtM2FzKQgGTiTt4HkDZM1Ljlz6VLAGmcx4eGkNa00U7prv/pXp5ZXScAO0S7Jl3VZI5cl21dkZvNv+Zb6Mje5u5qeqLAHORjSKQMTVu299IlF5tDC6aRZqOiyB73NcPsxbyaEX8zXI0FITCEvEYJX6h0B/mXXS8nE4fi6SU2EEJL5dy2zZZXIljkYCAoh9z0BZU6MPcsMTSA3Dza7sOuaTs2F45w2gc/yG9otFtJxuF6OjKVLEI9fPKNJMPx4x15OQNRPlT3nYaDuTOyTz5ltWb4ZE6esbdC1d6YerqGvea5Qhv+I5ETJPAN5wzJzLO5Yzp0OTplNNombITJoS/1pj5OAFk6l28hVIYg/EemNY5pNBTmYvKQE/WT27Im+17aVDLdMvW1vDeRyBCFItCLMCjp+95xvV/MJ6zV/vDtNcUndpYz999cr0AnoRrHiW3lMuHe0fCBf0w6FejD/0/VFaiFSX1FZ4eCBpI8wf2gdH4yMXKZpRa4q8oPsiA7cjCjSkbUzItbxtVjgpbbhUxl5LiI8V7raWHsL3s/w/oUAnzS05i4TQebtB62cs4ys0lrXJzJOtw8vggkfoosr+Y3dUVNWUa5HNfNFotknE9k5VZFmmr3o6TITmyWkU18UYxoyK3QUgp9/6tXOZ/oszbhnLawRXGq2kf/abXBKk7Ojr3nPyfCV2LM3fLmhkgfa5ZL7u/1IpNIV5+YiBzCFomkw5v1jmAmy8tBS+9D1IKr5FKELK1xKr8Dz2+7uMAdW2PjFplgz/ijQtIpd4PyRqLtFnVPpjE9dQUoXskx6/AA+5GSqlYIbR4w7GveVvK5BCCQ1SrMUfCEE68Nma7rT9bEGRhQnLipoLI1O5HrAiFHufxocQZsZU0dri/rR9M9MqrYKdc18A96SDnXY9VzYVSTAVr8KR+xZfB12Q9c7IJ4GKUsNEBSIyCvxJVsmzkVtn5wsfNnuwJcyljLKoBH4AN+oBCFw7JJP6xwNTN1ZEF/A9qiK1mrD7CnUCYyd5S4GCdKt4D8lkRAy1Q8S6leNhTCuPlrgSeOP388fYJCCdVxAMgDwDQ/bHakZyRv9ni60QhOwxPLPzfeOko3ojwItXuL+DuDhmCcam4yY0Sh8xokeTtD/TNRM97panZgGQ/mPigx1r0TRZYqC6bxsnK98lKnQRreSVMifxblv7TQnIVtj7q7QPxY8ASVB57KX4jo5ao+4XMyRmpXXGmSiDQt1O8+mBZzvXgKhEc20DZppmDy7exLWTPhDL8M2UTGBbNOvXj97Yvnz188H75/98rTFpAlRUY4vsf74G4foN0Qtf9kLAIeggTMhRNCekihUdEUs8APl0P8oeRZ3lrV2taFEI3Z1kRhYyKy/8iW7DtcacSNPkmLPF3bxbgXAu253iObf6qFFCms7+/1GvU9/sY3kGizzQF+4vPQqMnc0Tm2TbAKqwWjSDK7Vx5C1GpYLcJPQOvVlTgLxGm+vLpC40uiyOMWhptRqlw56v0fBXDGlxrMrgcBa9sCRv1kBV+MUzsFDU1GH9vWUXKUy45BEdR/JreU5IK9Jnh2nDuS8yFvkMSFYZbGZNe9W0wp9Ig/FK4c+anBekzihgDjDB/NPBFx8tP5t1SvnQQSEAJFLVBco9XE7kgFhuwR6R9JkpTyE1ydLCpKYzpykXc4koAlBbRczzWV//gd1vmVIpas+BKURtrjkFVx2actnOESdLun7rLC2GZowuKb4TgvKi2Eo1xoOcFJdp8S32ADSbKG1ojVmSKMUE6vwR5H14f4ZGSH6C73FOnEOGarBhP9anqj/3BweVqcPn9T3HICmnY3RTkQYZcJVfz2wnqOczCiUQvORkYFqZ3IgHPYXdfMDcH9m3C1cuclziBonCs4c6RDKJQtbBFtcVtR+6FaVh++OFFK/BCdcPzqOtlFlqUA6aR9E77cYOOUgYcJEkQRhJ9l7KRov4sQtB8J/Wes05z8yJpkjpS7OMUieo7fJ5vMXfQ9+vH9P5+g29//8ws1MMgTjK97r6aC1+CyQ4Vgga7Q3Zk/fJjsvsPIYGh04/zLszjekezxnMU45JiCMErbPe7RwvF9HlBEFs6cfasRCJq52zacr8MIPybA4CcEFpNA4rOS5P6DhlPKZqFdpHwzdmqRlER8fFbGfsF9VeKWnN0kb6NOA+o6DNkFOjk/owAvZyKH9FKK8lPzBh8plmZb8Ukg/UPSz8gnggaAokGC+Yk1NbJ3s6dMJi4bkEwVwuHMeZ2Rj+Zmnxmdjf04jCGbv8s+V4B6xaQZYaGBxi0spsh9C/6SfaLL2LpeJLZdfceMq8RjLptVr9MWoLhlWWDpu+pO1Ur+GwQe65pba1WBiy1zE0L61PyyzeSTw+mg2y4NI/Br1/rJ5TeoXC77UNfE3DwA4y1MAdGxgfeTX+GMCXM4JMnExc5uJ7YUXTGortb/yLZmnztsOyj49XqDrokg8HW9QlBbxmvHQj9y913qmQdmEA79zpgYf7lzqYe2x7Sdlp8m1eyGaZVwoP3WlBarko/RsW2tASUOAStIrlOfDnNZFJC29lY2txz4dwvY1zdE68L5aXGNb1ykkBQEHWPVFlwUhUGFs+fJs8OKJ+rIGgf31MqX/y4wGk7kk9oOkB3XZOGEfVLi8mrnSlkBevNd6FRPVznVTIlk54qcGAd06b3RVs58xv2u9YUELv5ctY0C26TZIU7uA7dV3cqrhWfZvufzLn/g+fbkTst7Dr042oK+ZEPsoX1PzSD3tg9Cm8G/DC0PjjAXm2TMfPf+bEua9FCpmJrJVNTkEqxbPp9SY8pqEZ3xR7HilQ24bCd5C/zM2389ty7KFmzi/N0Y7cnee4KJz7rj0H54nqWDpLUpQKYofiSjeVJvQE6g2Mtg3HQwiZpupQg8O75K9oaXgOwyk6O2/3I2mFUoKzF5IIdSJCUnFt4TEECIRIIP9bBT71yggKF2NfbQWFfC+LNBM4SobS+RbfFWTB2AtkbAjZUQkZEb30KNoHS00hBolaHiXWzjbfz2wl/2nMAnVgajanWv2JTgP10mIRkz96f+IKrKZp0ZRFDEHPW3kY7v7mej27aZaZCXpy2GwZhG26g91F7Z7LEMtgKTAYYx43fDDww+IWVIZrL58dE6K4ODHvTYkum+viyvMP3KadZUyMShmvQBnnk0/zKeKQt06STbBa5g/hZhKtBIqzsIyYXvqhLBd+DzolJaceGsGcJGWTQjZEwIGE5ASuU1y3NuRMjzikv+3HYm9Fd/y5EOiRTjI+lC7qPIuzL7aM5cd0k6/MTtY/F2pKChzGxNPGWscXmraKPdwGfMDsEcCI2eoPmB6tM5pmIhkgJWdEU02PBhvY/yekMgtDOXe40/XOO2L4XOpey6ZlTz5uFP1XHVM+Eri4fz24tg3SSubuRb3rEJCJo5OG+ibdzVC9bMCvSP3BVCqWeccus0lDJGmBjHNRIJycNyal4KNxeaO84E9c6N1LdxWJB+aj+D472cYPQfJoHjd15Bm2O9v73XE6hJe6GNqQ5T54K6EhGVO3gi0yQrIUyCbEUzvLL6NKoQCLVbbOKeSGRYW959LQmoRbt0tUl0ovkJVLAre2mhnsYKhKsN93u0gsBKJyCYl2EEzzIO6M8CGPZAeVxRfZZ9QfI51RwhN63zt2fjIgtUskcpXJp8eDzNvp6cvtzShmquixpBzw2jI3svAqOh7KLDFCow5aEqpx+aRlj5qoJaknesqeRh2OqR27YiojEjq9JVeeCFXeIGerBvI35vuoDRQ9jrIUNP9YK0jXjgxsTTU36nj0P3U/oI58nwBjABIsSa+zjJiJtXPTAGOOT3WEaF/zdId694sXsdCtvKNP/CnT3OBr7tvstqegrJk7Jupd+GdF8yWzwW4cxS4ut6H7g8iEfqHvEYCc9EkI39q5HQcHs6y2Sq5XLuCId94snfyoc9YeGx/otLSrgeTHkKnmdc0ajJ8bT8UGHxUhVXpxg8NGe7M2TVWMOgrXjitXYRTVoDcXDS3ZpxOToCB02vhvBc1ujw39JXzblBiR4FF/CCu7gp5D0VdjO/LYxPCHsQIRaLLBze3f22ByQcX0fuDUHxqb4Xh29dg0S8mF5kGHEvZ9oLFmYnQ2L8nEHjwc9CZhy/hEGRahV5Kg3X0E3rlz/jxlwWlw4Ds4ikJxWs8sT5D2wKi2wgQ8SgdI7yz8unmETnVlM15JDamAA4mAOiXl74Oew54T9XnW0tzA1ISaTo/yO4vQZ/EQ0urxDDLCHCEM/N90UC0oC9JBrWCkdSwwQQ1UzIITFEzJ3KuyY7nAc9IpeSQy27qJKEIY8LnTyevVtBIDmfIAkooRLophj7Jj8Z77qZIFbNPvYC/FRWBBoJosHGX7Cb7B1ESMI0apQKi0mxaN4cbqUI9R0AHNu12vb21EYPlCRENiZ1YebNDzvT4GQ3ixroZMJDjZu7O97gYUt2Xb6sAs+Eui2MsBrBAk9W3HUeE4h4BtCbhmqO4KDf3OZaq/ZhHRgioQW9KkB4NgwbVP6+UbOcLQLfqDFFePGdFwtO+fU1GZa/+0rALQ+DU5KsziK7E0S38UWxOQp5j+JJ7trkgwXP5pY4Jya6wBb2Z2iLF0TD6OgyIuy1NHWRudHa9+XtpZnJnJIhIPKJt0fO5NCaVaFXSyvy8g8XvDv1VqfMuhM9VYpRSIXUzaS5wkDhBBxsFkNYAMfsppPUkpDADCriICq6wvhI34lp4pOL07OzCIWCvGH4CUm+2Ppx+ICLeTmru9stYfXaKr6r0B3eAgOqXSxvwJ+qtoqzBagZbLIDH/V8CULyJ4hTt867288yYCjVLH8EC0n63KKSCclF52YJouflFVpJRIdCQODN+oR/KPvMB7VSUpIWiiTF3/k+kGS8xUtCtjMGDScYw8TnUn8Zz/rlm5+bmnlP/tq0VrKAlpkiLGpsKtZZn2BuIvedh1lLBU/5NRVaZ/oA8m19U+76w44tn7RPMSuRtKtKpWBOIlm7hisDnQwnS4l8f8GhVVz7xb1UA059Xxq9Ku2n7VoNkcyt8hbTyMSxdO2Ts3sv3skZweLUSublOAvC5eHfQ6ij1OzyYtcH93/rDwy51BRdCMJk2VHnba7SwbcVSoEbLt+jNCNKM/daermAkTAvy5SiyVMORtVn7Or5x7yY1FPiNRsrB0YnsDrM+CF7G2/+cBdy7WGkLzGP7PDGcI7G94wcjupxhWGMYJQu1QO/mjCmL7XL4PszNjkuSD5YoBGGYPiZF0nTaINp0pgu5n5jHsMoByQfjS6t51Agu9mj3ILOY+nOVFGROEcH0SR3fKgVXE9taojmQarqFne1RffZe5ifFV0ejeyiay/6Od5YKEMHUruc1Kvmxx9nfKISt2C1YtnHL32RT+ifuNpmqQt1gPRMbdFlTkeUxfa84WKAOKbDvperMMoMNhHTLWsqrJK3l2982R0/Od4Qokb81+Pjjf1t+H8H+I/D4w3cGfif+3vww+7eU2o98bjYOz7YnU+L715f4o8HxxvLdoL/dXR0vKEldRh2xxxstx0W17ExyFx42/yy7T/Xc7x9D56ELZ6QC+IOFuJm48v6eA9+eHq8gSEOPIj0muMNul3Gj3nCWUUD2Ns93phTicNCvmgPvoIq/YdyGdxVHu8d/yt9H2js0v07mYqD7d3B1f7Glz/+yGOTKUTqJX750bPjjQRS6jkKtf6SU9ytjejK/P9I33Y3J24kHtm+DE0/Fl+sD/qer6Lf0enf+DK6Hy6HlTIcMvSnp4+jRyg2z+k7Z2Y4EiOTseowf4D6Fs4kwkyLO9Bs1MecKPG3f/mLX/4CSRNO5WGXXnkiaYKnnpQw3lxxj3gTjSe8EKETHSP8kaQcP+EZr/JNNWnoo/cPDp/uH2/gft934F5ciF/+4h9sAj1o5oTfd4HekXDJwCfxbNyV3ewLpBRcSGcwbUOGtdfEfCKNHUx0DobHN183Gt7VHtsWu0VClc2pYGiOZEdkkHDruCy/QhoEkTe9IguPbdkS0X6+ernnk50Kwy/m2kb5bh8nICmLFE2jkvjjr+7Tj+j/hvBdItm6CmtlycJalB90WkbLlsxXlxmiuDp2KF/Oso+OFGn0TS9mJdETKifGQ1PgF4TjZRRra1pHFHpf3DSLQjvCuHmmIYeV5OrxLhou8lW57u3PYESBun5/VsCLOduo/Iq2BaqMt27HSHcOXz3nRauZt7L3uRmbgxqK4hFcaNNi2rEvl9S/+Ft+5FbxbVXieZZ/SwXXt+Bxt/fUHsr9Eir5TapCaEE5f193S9DOpzACkATtIx0kyTc9nXvx6YSnzIniCYdJy+iDtnZC8K0nH8txKRdZCnpmO9PMBf/uZxfFGW9xdpi6nn1i0Dz3uPuRsVv3LJiUI/QJJCuywaG8IUrajcJin6gckq/B/BbHm4b4n3jt0O2+IYcbNiQilRmSovgzm7/TsGQw4bn55tm+3SOsmnQJ7CyYSGqK4Aq48fbgm8twBZwRBD/BBVjGO7sRZBw9Xv6yBYvh6Av0sldEZYsX7m25K9FBxKL/LsxT0WtdO1UURSScK13ViSKMEsXCO9XtxxNuIdRtF5e3NRbQg7HECqqcRVtEXzev2oE6X3wpmaNb6IR69925gxzuhqdp+1t/jTyRtKA2L76uZ7y5eWrfyks7geojKwj8eNUsUGLK/oo/Mv+NYadMeulLmkukdrF23pbsf5lxZmUKdBV4T8e//AUfy4I24VdlcdtW119v5CjUxs1oiTuHjuZOWzG7J7K68rN2CL2njKDMR1qi1cO/72x8c4L/+mqn/EY27c/xUn0dTNagRFHBPwilckd/135OunsGEoofwKGEIePI8M6feWSZ6bipZhU2+iJj2E3Ld/JXcbT+LtMzrj/WAyNa4bXP4U8/89t00vE7QapGL/yO//r3n+ZmBAIAuVVlgt/iv384Ny8mcfnLX0SCD53LD9VcwvooFDomM+BXbRdn12L2El/VPWa3p3jSuYYHm7NQzRGHvERloVgTPngnfChAnB54+mty4rcolkwvc9aGG/Id0kZfkU8MWq4S0kTkNa3G2yzdCWxCtYjWmoikPMsKDYI4mUExsfA+wValMvnYSVwQ9NQcDiZAIL2R1sIvDU2PQHpiMa8wpWknvYwKcLyl/+//uyqf0LyRUBYfbdVE8EB/PR4BvdpdItOGylPmARXzPWxBRqxbyBTN3fMl5ffGoLsnzXxK2Zu7SuqCI3bFmQDKKGG0jFGGpElxULDVJFRKQ2SyB6y65gBraaxzBajUrdteTavIyTtpP8susRo21ac5FaVI+mObXyJcasLfp5oPEz5LZKCazVGtSxTM56umce+JLV4ztcSI/KP70xLP1lWLfeURWHdD5btCsslOB4yfWgnDXTAMPG3flh03lt9i9cawPIagEHE+TcVkwopW3Fu/OrSlyB6o0Y26xzXBUdTCgcATGflrvM7b2KlZ9af/UcX32HDmuq3nMU7i0eqOc07XEgtVqJZEb9JBX5gtpbfBPHCtNdnIzVyY2K9KMNv11KcDwlIo/CL+DJyBYBYr86suQBcvjzQvdZF109iQpBl1teFdYjcOe6TFRRNsT1r/r/A/v/nXfwWTWOrnsZLgxx+/2qEf4FPQ0O6K9Ao6jPvffLu8oVQ4nLj9b0Kb5bXCCatPi3EzxbyAohQZm+OBNGzTY8KPYgtdh4EpidBRIZnZPIGG0nf8BqkAsaFuwEOTSvLw7otm8jHrlhITHDVooOw2s92wS9oSykJlLWeKWZWYGsOy2DhfCs/BhhS1bREfkXW5uZNRKRTldGS1bAuuxhY4kr2+XpJla5gW9QtyfvWsuuHqJk5RdNqAjqaaj44t5spPiRONxq1OJT3rE3XLQ8WxpfVf7t0lvb2YNHBmaMooCOkEGp8UTMJmvzFAirvhiXNCryHLnc+0EIkG4CMvLnySyZUBYZiH061KEcShhdUbxkwOvhzpTj+Ch9PV1lnewlWNuxhQKKYOmG1wDlQt+HFZIEPp+8Jws095Tui19u8M2tqmaMs9TCHevso+cP5YSVUKv8apXE6QBcGM0zGdZhzfwzTQ4OnSzbpsOCFD7AzNskNaiQ8btJP8j9g7XH5wcQfO/jA4jiI+M1CEN/wnOr6BT6/ZXvDKdl6VVCKqkTsf4OOWEQv1As0lfQ/kfgmikDWOdIXqpaSYrsYrJBu9w/uQ/nuDDY627jj8SRFRPzPfvT/LvC9QALgfTMM9Uk7cEJaIA12yTWKjSl2xIij2O94PlAJ3AJpUCCh2RRVvYj2Db9nd9r/H60oyM7C6ejl336BdSdwedTBXKgaxTHS5h2NS+ho3iMy9mNPZIIXfREyDiyJ32aJdPLZ5Kzl0YBy1oLT0q0mYeyLhMn82wwGSLoSldcUQRHas2UI2vRgWpOx1WnfjWUeDJyPZZC1fzh0ZLA/CvXZ0ZlhKvEyunx2FnpmdnlyaWkiPtf0iHjHG+l67/rFx/I4puKVpNZHbGJT9lTCtCFbRRbhJ+MJsobhWC+wW4QamIRz1Q6weDnrjFPxwcFp8zwV3tJtaKfJAM5jGN2YHIdhnsv9MoZ4tiaNW3GUAQ7e6DZu49ZgcK0eKAl7FF9iQ4xF+dbe8Yrup82D3rrxGOczEwdw9FavtHG1zkMAg0rCRFzyUM2fzlekF9CvWGmNsSMMWLCfNjTsPSKymWYsPVUUc4vXC6bbOtkYiv4RvpyQHtiZeOYoWjJqWlOAMu/IqmzotzcbLt+9OXwwvLl4NT56/PnuzoXIQqWEqxmK45VXbEF87RtZfOAq/ubw8X2sKvm2aBYbK5sULdaPU4CATUDtdVabTmYS5qR0mmwpXvpYENz5DZvy8cB0980HfF9IdbZ3RyRZ1TNtGY3WwGrOqjfs0hfSmLlj7M75Mmx/bI/bg891ihRI3sFK41M41yXT84Ql9+APfkYhBreyQ05jqO3knuR1eYW2ZlF0z+8jCARY7dJ0fGlFGKZmJxbmtfYSFgBFcrvzulU/g+Ya82fQdnCR8gTzPTbUnC5NZ5nd4uOaWtXZd+QlXZpYcVNdIARyR5Qhdlge/N+NSuHoWPhGloelmjgGSPmut7QYKRPKNZ2JD+j+Q2QLu9SRneWES3nUdsBY4/tiylb/Q340T22+UnNpw0rGv7M4KVpEpnOgnIVljeShYtGAKvCRGnSh5Zo1tY2oXxlj0sst0qRWvG+n9YjsrkJoZ+zh0NzyHVJhjt6UJySswvuSAUFu2Gi3svxa8KTDvvhOudF+C6+KSfYYjT3F2pYrINfEOWz0bTZak5tnGV+tUktZGPJHRrVhPmNutiIigXqzxObLbOFbi5nMLJ4ygiu5HV+2N4d+bijDd1N9OAB2d4VJf9X0K8HCWLDh2i7I14TSOAEnoglop//jjlo0LlcsFjPTHH2kF+O98VW/wJkyVGweuA9OrUiQEcjf7PYSXvqqnNWv1t9fXFFqU7J2ned6Syh1nSbN5ZraxcsASwhztAKYKQky8I3rODlSwKDzSenaNqryioEZn7V0zM1fN+D6YBu+GTSRtEHGHiaTLB3vSboF/5n62NHXkg+8b20+2PUVd7uo/o2EZBcloaqjymdNExaiaTNZ8NWoeF1IWM/NbFl8oZmBiFcMUZxqYoJg4ojRYUklV50Nxu97R/OpXb05ev/jVrwLPmOpjY2HgSqI4cqRnh570q1+dvn3/5vJXv1ovoqJl08ZjcPBXmRFmQfOOrqB5eI/AjzfNYqBhT2ogCdtFJAxfAxq7Si/pO1hr2zobFxStnIASDLp4CezKFL9Mm7G4ltTL3Vm3FCyStNudxLmsM4MnC0vLmehUmcfXGG/pqZt+Bz7X98sJTp6mY/w5I7/GeyCNFfJ6utITnXujriNXwksKxLqt/FDMHl2LgbjmvG/EGn4jcBtc0G889rHEKGMmrAmYTb0qc+CSg16o3b+NvMiNKIn6BYLUnckEWtc17m8ahyTsBnLgom7TDu/kBMdou5/jHckbtL/lT3sRXUAQEO+YlpM7wm/OiIHHIOI4WywpLnmYZpX73+8B54zOzEUzZ+VHSWVc3QvwxxkSI2w8hukorpniIm7ZimvZ9AFeS/YQB1kMIQ7luTAIYYKSkX2Uyb6LPKAbJdJhSgLWApDJgOTUYUJGI+saqmpGoyXpBQR2m9GgScsbnpkn4L8SJ22lM+IArvxWmQXqXcVh+MAu7YlMupIrCZWoBvkdtxRTCcLNl9dyjV5QXJFCsxsGdpt5t8ooBuJKGLj3uqo1BQRS+pnBThSvUlMjN2Cbf2Dw6axrJrq12EV0tY0KeVMRxcyq3AIXE60M/7DaoPeV1Scy+CVGS7YhHYzKFH4ZE49+sxpZPStu38DMNprewvZhbag/+ncOZxgNaxZ+gvJmJzxd1Cdkitg/aXpTaxOb89DxuavHN5W6Lg+Poiyu2uZDxWYr70aUJEK32m15g0B5NfnKuuMthpCGVoe96nVNSP0ts2hMZ9ZFGP3RE+qa2Jp+5IzjMUz22VAI9jz7Qfi/I5OC1xb7FMFfgoXVanF/rWPV8NxbXCOQeSlNEWf5b+ub2wlSWJNwnHnyB0NMwV4+OX6omVwIgpivXcQHS1xyJkFPJKBfV3n8eQ+Ms8eRHJVzo358HX3gK7Hwp8z0qbCmsbdqvHKMXFEdocmf9r3U9likxmz35iA4Dyv/IVsRbtpBsQ+3d+kWXJw4pZp/9f+vvW9dbuPI0vw9jvA71CA2LKlNkLjw3rYnaFJSs8eytaJkT+8fRAEokiUBKDQKEEV3dIQfYyZiNsLP4kfxk2yeW+bJrKwCaJM9O7vqH24BLGRm5eXkuXznOxkF9TlSRMQnEguICT7/usOoPyutEvI4MwdmWBjFK9a9hnAoAQSlqdrIYmM2a2DQU9kqW5yhiiKQlrlakeKPC8QcHjHvNNgArDlrJd/y5P2tM06kM8tpt/JpdbVPIxeZgvq99sptuBXNdb7MxAzIPnBsSaIq6COwQZYt9s2vJN4nYZac+LXugkupZlSyO9VLMsObJPVIir3jUJWEG2xIAsOTmEi5TCKQlC3mSzuhxC4p1h5kWcDFwaonP+NgY6FUxK3ATerNEBtcTM+wiiV+61lppRen3docXx7r+ut0JNiBU9CaKv3XRLTWu8vmqSRoas4Q51uCnMBcXPZQzRfylN7H5QkVu9W1/nh0VP2SojWI7MKloUrMprniXSllr+iMKG6d1PORU2/CloRra9mrWkAhBOf+D252rIJz/ysTHwS7S0DHSMcjwGOQbs4IQo5ai48N9ZGSgUdmBu7UZ5x4EtM5+cVdc7vb+4LdueWSRjfiCR67WRoVi0xi4w1+ww28/EKqgZeCB63xwpdFKP2a++HGEVkAsSHrErWYEJR7yPN5pWq13bV1Z1FyY2JXs0AhmCTtJRVKEr+CiyRFXJ+bjkEZbmRw88VuifKM7M4xl4zAzwGOlCSdU8Ca/NXKuuSTQS/oHxprcLHm43YXbJuG9j2DPua8K52ZBZWJ0zmfDyet2XtTNKtCDWNQFx2w2coeBFm0RCdCqhMsdQkLLDd+nWUYWkK+Z6rdgl5XDIQ3dDvMrtP3eUGcNoGPBjbMDNnn9AIQOmACr0WzlQNrxGoxqpvhINspMrm0acELYuuPy4uC2aDYtWdySAEPNwI20AyLQwimjy7kDNR4WIHYSaF6r+I1bpgaBm/JStDvwCmIq8Gcq8j8AAFKUpj01aLO3Z12AlNHXJAiZu8a12lqIUq0Ug1t6TxCs1oQMPCTHWsiw6aza3JIS/klLRSloBNFFRer0oo5XEZcNJtn1DA6MyOAwUfOWjdQ3FeRnMxKUKN26BlsEwcW44KmfgYHIqSxkFYsqYLuf/Zsw1GPB0WI68e64JCZb4fZQKYZuOrzknGz2SIV3CzrfliXDJVIxrFhvA1cwT+QMLHm/aUtcGTrI6t6uv6gcNXJvDfWwfjL1v/gOOIA3r+lNX4pUMs2MWeBIx0s0iRWMqyjnnd8O2GBNVJshd4f8gdBxMpBJLiGRxRwwjqN63NDd3/lfvIytl2sjxF6Ck9i47Z/XRXxoBddPQ0J2GdM7sBlWITiy0UaQA+FQvbQn33YGc6VnRffZbVjkDRT8hvllzDRRvKZETwzxtRl8WHLXNdUEK3MKEkFTMfMVpRnPBE0IrAKKiZ9x4GEQsX6YWVPgQOM1UmbtOK58mPggA1WIejYIdds44i5lgJ0sCXIroKPXvzcj6tvGO3zmANYFTKneqIhme/zMrfyseJvd/xe1vUuCfUJcwOhaMyqYMfk/KxmcEbXvppxUSBvw56f2ZDTvZsbdSdUosA6K7xcpoulfIAb08HO5VuzbP4DDk53mVvQnyOWFFObSPzRKVRjLIdyknbrODOCYWKnQtXjuLSOMty/bhxc14fsJ6rp5h5NS9VG4+3hJTbki3FCtAdKhd8KmCkkkEhEe2UWuDLcnmpcIf5N66UzpmERLhAQUhr9gxSPljrOLUuJxcncLYsHMTdAiumdsN9BSUMEqnVVR34pUfBUKiQ17yc3CHrLc6cxtCgdKS15YVgLlCLpOAh7M8mq0HFdevnwdv2iO+am8EgIYCx1WShBsoqmvGbFB5M7KBFulC3gUkpG+WK0mnJseIPJEJvdQ9B5Hj3GTfO2sTkOiH3CzQzJYcjJWVxeqowU2UsWboXFxxQUe7Oj75ETu/0pKu0Wv0ckvmW1XoUHs3RxjmXEnUirGEHxQCDl2GyEqLeklvO79QJqqZo+X3uxOut+kAsXIml39eDX0rLQFMuWcOIFcSj2feS4jlJyfHt82ewFx2UiSB81Jnw6qUtgXkrJemFuaL7qlJgkfrDk9Jvz5DEkoENHqEBDLilwcD3R255o8WTw42w0Qag2kYU2zkxwdqpefR+pjLvWGY0iIuGVjZYD36Z0T+PscTqguLks/rte97DKNG6QV7AodmPAYhF0fDQxo5F7CNReCj1MciwUCKJVDqjO49jk/asEmwHASsJp0k91wrQHD0EGxTTb+RrcOHoemidAqqdkY80MTWq+5GXM/Hm1NS4sJIPfBTgCRCylyzsMIpga9GnzEdDgp6iHYQXudXLCp5OySCbxdkSoWpYBtMgaNfTKLiFyWyU6zewXdneAUbCA+fLcyPaKWM0BNbEa4uytsb1IfuogJqVqIMDCKkmsmsa85zajZpaVNpDMCHN7WPDLa/ErIX6zYaU8rgqKXMvheemCLy3/1rKK9ISiwBR6t6owRpbXAct8+AJd/QTBMasP2okQiQF/xnunNdpYU5hIHros1y2Fw22hBJqsrioRypcnLBsFVoPHFh/lWad8WvoK38hIJ0Q73uHd/Wg7KRnwzcF2d8vbEiq/ji5VBBw2prgSJaXsL/Xua8OXsLyMALWRFEYQUGyOQAWy++hP8COUK4s0eqVXJfTCNIBldPk8+W6FlocpRAFuRTdprLZynCvjtv7U+1dSxcutPQ2l9SG78C+nGvIGpKXxi6U74EUkIhtTLaiQnzcsMVJjuQGVW6YkcrelgvuTr5fOrWMVYBkqldzN3dc4ON+SCUptKCix2ysSXrf6HzrOHD+uvB0DK7aIbQE59WpmKlBqvFg3jixbTJFYX3gH57RBMHsMClomZyevn9Kqbe4pEV5sNL+zq3R0yxLmRTrHm7TNFhhZgSSakACPKy6Bt0aky/OigB2FPz15eb75KCplmMKsfiYO9W5luxlcoYAFROudmq2gML0qOraRGFjFAA/ioMsaOuGkv72/3anHaUqGB5YxFNWhKs5rj9BnEyQD+ePNfDpp04b/bEFf6SPuLlYug6OJTr3KBqnHxndf/SuGBRlJxdB1x5XDAlHP96YDgybelgOQl0tk+HPydSBFYL08JnySB+nqGUO1L3N23SaqB6jHdBdqznmcJ7p8akMSleoFAYeMtiNVAeu1KAVmo7lwCxXPMKiuGm0LfQwBpoyhkPU91vu0+YIR5Ekz5KLhlZwXSmQPzeppMSkWAP0f3rJXmZJ+yKpbf6LQeIULBSEb7xXRbjm6NiqaML1CIiQDBZfXmWAsxEN6lcNFjRDljdDJrv8YAh8VYPti02IMRbedI1nw+xRm/e09hMEd7IhBtZjwoSoKaSqmGBpd5PsYOPScJpOPshBaqXfm0Kw9xCcxF+vLFuTODSzovlXdo2vf1a98TMcRRA9c78SQBfla0RuCsxXok/p318tjwNuMsMBftubd1ldflHPgsqQvSvPFG9Q6Gi4IIOo0v/mqOgg9BKrA8kM2QapTIwOE57OzlZz860lyurxeTa5XXLippwYJc0O8TI5ykhxWBPefrBzZHVYLUYLJVv9BbByRzGGsbAF3CdPWoMOR5tAOHsZgR28+yKydjJHeJsqDK4BH1BjoVG/Lz3VbUvym6fL13TK7231gzZoBtpnbUA0KZ/ypS4StXPsAn6WH8dEX6VsA8c2FkJ9Xw6I09Aynruq4Tei0RWd4PIc8BLNOVEtKvqdVfwkjCCvdohMNJAu0aPntZRIJrUCtHPjT5bAkyDUbEhuLB5FWoEo9vwfU83vbvYB5vnskzPPdducw6Rwe9/eP+x2fd3734DjKHvkvQkL/Zb9z+Bl39qXtJso336nyzQcU6w9JOd/b3m8Pdxso54+6wHv+kek85k/+yHT+ken8v4TpHAs5wMEUHtqpuWvi1Rx6rhTDC3zIK+ZQbSNa0WHP/ORpWuaTW1ddwdywCK2gfHGLxQLGOWcxR4sp9DsHHaql0LW1oar5HKo4e2CCwxbBTDOjZV/NID3B3u9qE1VsdW9lpSA1gPFcPrDlfeEjByQoTELrIKyIQ7MkdvhmmFXJ8PvPRMOu6T2ypzi87bgs4PgapbhgNL/prpFkoEYnY2pHV8lFyvSYy8KdE1j2uLMrQG5Cvu6HOdTxAKoiKpGtO5YGzQ5BhTzq3XyVXaYjQmWhkmZ0sOuCay65ItfJylxjsD7pAnCFGekSlsf0XLCAx46/NCeuZCSqhIPtCjKx3pwS7BS8vvMtoxXANSf1fyuTWFwSA7LNjUqQ6/Qx0ocgb+UTC8KFOrLqhMUcRLoIMBvB6XgMJ37T2KUlYRLvQ9tqY8K96+yRM38FuJWbQovrxxBdQBIBCWXKFxzSfNI8MHvvA+KcIxwq+xUCDAX5QI2Rj7fwRXpphl8xUrr1RIoq/yMDF2NFELzLbjmbGcMl1oamii/EtAOmPm5/T8xzMsUbswemt/YdWsFuwXM/j7qRqIGLOUA4LiH8YRRzs1nZiT7BnBxIx02xFdwAFJCapAgDYNGynZxSDQKhFBUuOkyL1/wNRg9HiEtsGJYShOk/cIJymPJlNpnkxPVtvqT0JAgWFWksYdEI9IIBm1ztCYVF5ElycJS8g0YrIlIC0B1spR+LYtoGZ7okXxApNDqnRAsEaFwRTZMNV9l6YwtbQYxv4JIEsZzEx/3tfmf7Q7UqSLeWP4glYHKVFXYjS82FNi8SVTiFeRVlC5FmXB4Zf/J4vCKw9KK4AUG5IP5sALiUEszzWK4uLr4JDpgbTyBAzThS2Uf8DYxY7ibWLO2PqP4hOm7mRT6rTa4iIgqX8QfvZ97zMeTFt9EHM35ic1gogVwmK7ce8s0a/+VnWDd7p87ZxQNDpxtX7t8/X3z3beD/CZKKwJ9VePtT1xuF8yrqvyjENVBPqiUKG16ceHjDxTd+s2xGcWwM5UXmorHmBMN5+8z8F7fQ+VmV1arr5bJq1ad6ocsNQ24rcOwcVMVAw+/EzdIHD0z4uzDMYfbpdF06Wekz0EQVavWmkVAFFwG1VAVeWeKYpMcbjsaQlxIxW6IbbIuKF4MC+JYtTYosws5YIsfVjMp30ye6Myl1gVnLyiaN/zngxhHrewPbBhj0ro2pGH1R7eTxnEfeX7qhI8xzG3Uhfgz+sK8XK6MkTEpNLp/SwRY3WKiAaKfNUBwxW+T2moUleqQCkC7Vs62LJXvF/JjIcDVxTKbehNGEknuW+TFQT6SrS2W8bEf9MWgO1Ppjeu3eftLtHHf3jruHQR3Azlp/zN7+wV7fumRsT5u6ZGKG0m/zy3SO/1bna+l24CcfTaGPptBHU+j/N1MIXTpGonBNo7gzZ885c76R5zx/jm4g6sk5MF+dQDUGksxA0c3WjeZbpugsldWxk+u8VJQSFXPtdPf7+wdSJ7Ny43+9umqb/XucVCqXCrNyYblOAHVSiuWFn/D+Qep2VrKxRksxz2YuDCY0JuacmJH6FDD1vev4PSBKOZB4PkVHXfEhOc0mE78ubuAiDtr2uMkEUMSVL8psmo+MscGhKqKhAsANsFRdp4uk9RkEl1sbjn1S0N5i0jILQNVoiDMovtHUHh9EFJXWkUzFqCyrjvf7NxJ7OTaKEKw/KOcpbJQECu8VhEY0q/aXYvV6BSX2QkYk1cI5/A40D7DIgbsvIJKD6jOwQVCqFY7jnV+ZtwiZ+/zGypDWfBdSLYvoI6pG/RuzrdrWBDCzY9QlsolB7PoW82vMZwgYcCPLz9XAvPwHvLYRmGr+M0zFC+wwCgIN0lDMSET1nmsuRosp/vJzpOxitTqj/OVjFcY7VWGUKRcZ7IFbWZQ77palNxVS92D7Y1XGj1UZP1Zl/B1VGcv/x6syViqatZMojWpqQVjgwOS87isX1RWEVT67fXH6VG5eI9t8MUbXFvQiLDXPMEH4qRnWU3rCEvOCm9LVKBTy1e36IaKCg+ki3CeCvAsO7WPKEfEnEjmAImQ2JtskH+UQKwANunVWADYBXJPUaUv36hcwePl9XdUtlxJkDRRMvvi6gMKWjjhxVn+/1/XKWPbXUO/oB2I29Jh1wWWrfCr83ojmMV//8rPbROzK8+PWtf2+MKuYco9U3w8AP+wl5YGgPrfxIsEAdju7jP641OnWC+bUhLNV3x5RV4Dxb9oAT4qQrmAuDX5vqVxhqZlExo3QaDFBk7/87O11SYZAffyC033ttrebjcPyvIsrs+ATeRqj6EpUcVdiz9ZSkqP/jdvylUJ1OFbIKJEkBZg8GQxNM6afS9kZZ/maHx14Y3N4Kc4z4zfmJZLMfSS3FOAw8dtY3EN2uWTiL8y3E2yN/JQOde2+upmDtT7/5efHbmei/Q5gPLMR5tflLz+zqvWEs0nkDyoLk0A24TJApy9SUKlhC9j0UVffCMiwUArM/rrKVtlY6tdNUgwk3U5snvY1Ww46x4pWJxutFjiBTsk+Tl5SXIupHlBgKso9Fpl0Y4G0gtNs7piUKhqcyvd2K/2OTiJvLUYOgS998kzzP7h5X2aI3piBwfMdrDf8TmhhYRXOz9A5OJfaj1YNtQqq0IgBIoqzH83ugeJ6U3MBLG6FGgYYpxcQTsqGPq0KDyUwS/XegtQfvHGNpp9iHdrg/NjLx0GPYFg2Qx2n296yQtQLTag4TzgOub9SyhjKR0kLvN9Gwxgvr1tupvCyhwgEtHhpzoaUNe1X8N187KabvX1BjHsqs7vFAbNW8vz8Gb0sG8KI0wZqakxyW1CSgbNalf3YiURj6Nwd0yGyLPVw2CaeuKHltTXX4PYFGgY4TdY6oYqdHKfzRLwf7q3v019b3ut6LcOVzGd36VC7HLgBUJ1gk4qtJ45ueXt1v6BmsUMkRIkxs/KssSwOLWcEdlfaTCUr0UFDopEVCwsevr+m0/I2OcuvcmBOEZqcMtZP1LuhZ82ovPk0FQPbH4HllDbv8PrGPH+bXOQflmY0W/YzijP8hi2CLSqdvYVFfs0HMBPpj7CcCV8XUB4FFHmjkjV6blheKiQxMQmA84d4q5P0LRYlNrdBuSTO28V7qnYoMofS8ETsPDZCdwuPfD7e0kLyCWw+jIQmVYKd6Oi+Ae8YK2XkL1uae3CRQ0IEYVc425uCO2WkIEDFVcU7oZxmmL2j9Yc3s3Gx8yobFxaPkYcqe7DJqJVSmr0E2CoGzG0HDl27WUPiJhSHIL22OA2NxjKS76rVYtPZ7bQIOPpPXp6bRpkrUHKbCzHAJsjqQznmqprxCnalkICw2lXbqITXCLpjtPeRaO+60DAIPpkBUGvQqg+DSFWfaxkkCdq2JRkQtqun5auig+zcxQoHvDmxrCdtbNo4jfux3p2sjRQZCuUq+9YFjY80Q/yzM3VU6mv7zv1r3YO5/8mfSx0CfmnCeH9KjSznBfnVz757ISBgFY78XZMxMua2uc5uLQyGtWx3KVpRQYZsMTcThGsxnBTIR0HRJE7mV/o6pVHZQKFDcVf2ZP3wrq7B0CSwhjrQ2myxjm4UK+xeJCvMu81DlY7Uhw/M9GIT5i33i8RZSIG+5X/eEqTfCDLA0WOqoOsE3LQQoKZRgw9nMeZ9a2W1wyGNtQZHOpjlhrGpbCnUEgHPKmny1LLQZ3BFEko9IAQ+8FhSLMafl023A94gzhChyNgHWyrRXKOl47u/SMoZMP4QP/ULgCWBzktLEKg310ioJAzqNFiwkMsVeKyJnwqizk0DJR8I3hckRxU3WaVD8VosEiQ9BV548B5xElWT2BoS18I3EZ3QcgppukPLWACQAE4AH+dj8LxQUfklMFGoamVbxA6QX+rNdZOWul5agbBIlobrRotrR1xbJETQCgUMu0/q6enHleS4UPMSxBVNayTZIENFhvUjSnhB1JIiWyawKBHLy4QaCbeasMcwL4NEY4ZksO+DUQF+cDoYply7MB7AEJ6+enqWgO5AU0H7zcuDVJsF9vHrwNbjaAu/CtaadUmQqFeh+WHm4lpqUsLNhZeE/FYDrgrEH00CpdrTJ/0XfP7G3NGvAZhmb5jAp4iEcIHMCJwcVBXabzg4T4pY0IutMtuf64Idtu4Kv7g29wCqcXMu+D65tTwgvoSP9hx4fxy3F1aB/CCfJkqxp8PvBsj6jrCH/PKzLQs0W+Zcf4XSN5D2Qw6xTY+EpI6lAAGF+qtu0FBcakzzgWKRr28FQJKy3pYdHHUJ+wv7Z1WmARaOno73+n26gJkN1VLOOqye6Mp5DhVoOtDg6QQfHYcPdXnRyWoK0bz8R9S0eEd5g4s3ibWM8EYzlsgyn0P7f13lo3cT4UzOpDw3+u01rZzLqyFyEryCGvsUj8UYiREo7O1yo6hkISIosSoJcTdzsL3ASkvCnOD9BoU3aT+BtKko+FrSyv7Hbmbg+bIGyMhx8sP3qCPZPs1QzMzTxAuynn6BXhxFXtIk+2LGsXeyPL0bY8vuM9eqYCIXryJmSIiZK+43uV91lUw6oeabm6Jo8y3WRp+14j1CfFW5/nVqzAYJKAgcJHSP0IVPzDFNnYQQboGHU/DKFcdTbDEpXSoQ9djBmwVvAbOhxhkw193plfDKZBgxqhGCDtfkfBhfkTsK9xnMso8XB0OO6wIx24wZseUDu8seFXGG9aEx5IfQR3A7U70fSkmY1vUfwdrbcYSrJIWLucIYYJHSK/Q/J4zrGuTjL8/PWs0vm7TG40mbOV35mhgMbwfwvgOQ+i2VSyDXCJrMQ0rso7RYi2RHqfOI12B5u0MIrXmaL5quMcVY5c4KJ7Fa96GXqv04277ajm5r+tmTpu7AcNhBUA0y05HVr9VT3rmWkvUb9eKSlLLB+6hIRvhy1ahEVfWuIsaPqmkAoRIXOLq9nAeMxvEDKE/F/KJLPlD8XcECcg4rjOxrxRBFr9Dkb+LrEulIkBePIxNogAD6q+nHckkx7gxspgvGi0d/H6xExcsV8xijVwJO2uWkuInNer0LXPs5xcHiQLjQGeNpYMAvclH8yY263kkn0Hg9+kpIRVvxDvq4Ytwj+scAxUNbWwST30h0Bi+YNkWu1UXGNWHJ/QImOuWxywD4jNq8Gvp+ncVcSqY32dsnYxs7B1SnV3RQ6RbwLniZ2Dx6olonNQVAFY99b+OThnGEZI0qFd/XCcRT7vm+ZlRAKPSLyKw0gT+zBTNKesjlmoa26EhidRieM/d7t7TKLSOFORarmefDbvA2BpBEaWwFrh9l1FR2Gj7NYbVFISVE2XID8dLQo+xyNQeYOIKhM9MaFFfj0h6byMhKimi9dNZoWqMBw8SKrmK6elXcbCWv0yEu8YlkFxDsfkNHEAMz0MSz6+omkt1s6u7ReZyhBbZpp+gjE6rzheDMK65Nm55FHNOEjsZzdmMuKoAxGStkwy5ZQwDfAx4+r28M7oASC4zgFASlACQrN5HcqKO6VH8P0KvB546JGn2WpP2rVDOvSGS0GqRgKW1hPvFjRH5EBVG1YgmqfSiZuQzHDKkT5WkOzlapU3k4HFSEwCXHozTx9ui6ANdoBV5KA2YV2NmiLLtrUlTgaE3RlePKCgktcxATt1o1LLfQXhPJWZitYpv36sfQcaDLsBJyDX448SS3Khc0JQKr0NbVfnEfEduQmyP8f6oUhS0PU26pTi+zbCwwPZvUQx1DSWNjD5DkbeirTqRzYh1WJZPDR1E9a9rXtMpGJ+w8OsZbNrW79QyEJyM7WJy1aFeDb5TLFIFAqV03N8ESz6D3RWVChBW9i56pVDkIGLvEOpZEL0KRVjOC1hkdap2Y2uLqCwCCh4qeWxB0p3CXrW/gdNYllV8B/ScsaCLgo3jXFaQUFp9l91M+A2DsGFR3EjNAT8fbgtHa6JjhmlCz2FQ2bJOYnbHllzJlSlgocLCUaG/JCVobp86BEr8lo/Qg96zYo+Kg+Ck5Io4QfDr0kaRn2yPStEIaLkp5DUNzVQZsBiDu+V9/+s/x2Nqf8tSvP/1vmFzzx0H8r/HuA5AP3GJmz6gucbXMgYZif4zGRVWj5nXE78xBU4A/rUnymsnc8iFUjgEZHCQmUTogTO0G6WyAhlq6JCfJVTMftOdxOi9msHUpNrC+WSq+aXYAxHfmRrtXlazhdiCfL0wPCg/dFct+CrFCOTw3o5h9PyaDw2lysdGgC5nNAMfvaEsD6SzE9S/DGE9UNTacVkivWnDRPkFQEScZ2ueZAm+uXXNHysx+LtELUisqFeiSq0GB/eLn+NUP1sl8XWxeh9Bclan1rQFUlAgqWVvCPDiFJ+eU+VhLURiRbXVvu7fhj5Qrj6JfdM2I4sMKakQ/PPQJDQ89hdE30Z3ijuvBEIUFA1PFRMo+zM1G3jH7YZLOmTqEP+DNAvGNuC6M2w2lvss/JuiPkXdGm1jmYEoKTXXE4nBL6ZXhUp6S7EM2WhNuVXabvxdxJz6TdFX3yUX2cA2CbbMOe2Gb8VANtvZZKsS5NDHKtXZdTLNqJF2QrMcS4edSAZyly7UlxyxSLHiV4dEBOovQlf9mluD9agKYMElPnkntIbQrMec2urUOaw3IV/iyHP66pENlZlAIZrPxFRWD8UJaqfJo8EUA0ZMtPy6g6sTob8VmawrnM97bPO72zA5swSmXwMNuY2+632gql7EXo8JNmIBOmAxml0W621nbce2adzZyG/Y+B2uir/AKowWlPRc66RtSfDE/GvlfWNsjI4Vuw5wZc1IeKPliCjIImB+AqAPNTvRH4U3DXpxwBBhUdHAXFX/xa4DLB29IxNcgiY4E/sxCPF/kdLXHutv1JFff+9TzPmkakEP17wP1b1pDCHMjuvZSsvssEYc5jBlPL1b9eV/wxuToekCPGgTUsY+9gF3XCtcztiaYp5FzVjkJxNqtyl/ug3mNGs+hFRenU0xCgF0oUNknfA5lRbH1iRdGrFU0f1QlMoDnxZ4TMSLZl/5jlAYlZ+wFYS2kpmTsKitm1m6lODw2phaed1mQQWu+x2JNWCakrMJDiBCTs2GN4jzMSsyUhfyu4sY5CS6gfF/mGDkl2ZZ502jP/aEJzieIRPPwMW5tRD1ZFtSxV21g+9NPwsaus/zqGh8wZ8TcpiNygEtSO+otVTKXPjDLbkSt2+sH1LqH66hcep39o/2+Yte9E5GLz5DwsNS6/faw20Cte7i771HrfqRH+EiPEGnhIz3C5vQIyKLSM8fYCKtxW1xEbXqXtQS5oAAHhCr1bUXpVfY7lihXqAVQ3iLXSoY0Kl6sVhXORaq6KKfKQefoUPhyj6pqjU/m5NwZGOhKR9dkuy4y8aXOC+if9AZgMTKn+X1mq6qjPoS+HmF21/kzUQppbz1RRCliZGM6xiIBHiGj17bIA+Rv892VBQJkx0YW55PxAM7QgOplEqqZam+bvTvIx1hFjVBx+I12S9Yaz4RjIaUHQSYX4tEVOObMI7O2tXloBPqXUP+3xPCn021sje7k8b/4o/3yydqxSdyWUsml1jR7+UhRHlBu4Wwsc5fxNxW3s79vaOn1ziGMspoNOxG2hjgcyZeIsTDbTCNy2B8i48XqWDlxWDS+JLp2nQkqr0i1OcEV9VKiM+Sh+m74Fo0DYnmdcSnASjU/FYShysFW4AG2ZU5FZFvPCy4Gpyufbm9vt7ZsSBpNaxzaRUOlEL9sx3jMydQS/zEHAu0NXEVAfRPNGtRfzkod+R2yX54gWwNCsxSzDfcwjvWU3JTM36jYVYYMA/a2ElFqyVbFtFxXpQ9PGQuu9a+NjXtXFGf0sJZJJwKzvSi5nfTwWMOtCwTqSjyslagSyiH7lqr3YVOIiANB8pTd3MAhwf2Es4NbF+CePizYx+hUI9BRtK7tR0GqsQgwA3CDUnQgSgUIkSbOziZPcHwklSjqq+y9US74BtCzj9eORVaQ+4gegBUlBxdh6YMh1/G6KkZmOUdI2H+rsoNRe2B1A47jkr2n+H21Jqt3feGasMxxtQR0uR8VB0oxS7Mg9ryReReUedGxWwJdxQvEIkqKN0kI7def/rPdbkvRpcT8GyIWFDYJoPas2glDGpdzpvnFfUWn22jf10bvgkoreLPNyHWhOD6wgmBa8W17U4Nn0Bn1w1uGTYtnkeZaVr5ggcjrTIwYeIVxpdw4K663lUnoULUhoyhgLXhqiRIj8Ts6cBKl5DwNQnNzJSuYDkRwEIrHqDU3G3QuCBPdyzKHImIZh/ONnA4Ued5jLMNAmzWaVbyvyxRSYNkNZIVW2GFYBRf6/xHr314awT4ZFlBed0sdo5MVBFImORBGL+uq2FYpDVtmmVpKNABMJR3nBQtvKd/tEi0oEqEYSWDiqcQ4udkubbvTFtNGrh/KGRTnHQlft+AOWHg6VbWCRGOeizxeQndNwRGX7axwHevHisdBVxgFrBgxcLhJIU6b55y6T7I+A7krSVatL1u2WuoGJI8Mu2MjjoLA7OoHYeSAEDdcNR4BegVEnvAHnkZd/26njr8BU8kckA0TLNllfpP7mtqfXkpkUqnON2kZVgOML5ILHFHWiM3dQuZ9f98xmyjJTQhrrw+jqeQtc+lLXT2SkhhQNlu+qvFvMldAWzoswLOrqvCZJrgMb/3bWtrpyO5O3S3plcCiU+mIPaV+POFp6vsSb75XEpi4vDF9SLboxTvwTtcFMY62e1UtJKCmRTvpUqgz5rgtQRK5vFiOO0HejSRSggWQRxUwSjKOmXul8zBKdbFDoyXFzEWYgW/vtLfwroRUguoea8bwvuHiuNAgJt5cQqilvDVWwwcpIPDMfHVyk+Gr7X6+Vp1F5CuHIoQFhMelo7TFTGlWaxv12L6ZAPd3tUox1qwcpXgD+HWQc84Wx6Yajll9w76kLZEekfkLqKQvkA4ShooKLQpcOLhS72C/PEPVheEpq8lY2UMSQnT1oPVu8U2d1xWM5aYvaN8B7v0NmoDZMNrjOanZSAB2Cso06I/zYt5ezbkKNrkkHfhOcz6m3kh+z8JwTiDvrVi5s82XJtaXY4likUliUdLuL9Oc8L8kjOiPuYMOc0roRljfqAHC/QejomqPSPZEe8V7rTMKd1wWVI8ZYX8iLrlStA+8cWJPVFwIiUIGaR76U8TS4LSgH5m6YuzjrzQ2heakeh5/Q7PiIrOQPLzcOGnQuqnMhZClUmE8kcq5/n1zT506vjOY4pQURrzpmWa6tpzsC2DdcajVWYEs8mMhJAx2LaYik3QGFZSWkmkQQVMfF5yQblQ1SDziuhB+6netNFpkp+nc/C7lsWQZoxWGyCiOIXIIKwAORI4BuihBXg/EDff4CddlJnrWuCOsWU3O2kaCFMImuWl5vrm2pBHVSH4nLGm7AjZEvCwJQMG+d+VMZXOqRBxG7bg9sw01JpbDEPmFPfBjtijgRqduBIDoUKuliHNXX5u8ftbYZEWsFIfCRjMo45L0DrbLJ7ZcM1nnTCtsqwSQduag2FLMYI65chT8aZp8urAmWbpgHAnfUG8d8meYY6yr9G53m/26tnHHl5GZoUkJVk6Zztj+E54sLR0baxzXdBGaxKoXa+hfYgjSgWiLTSpES0wzUKl4K7Bbl/eTeUvQRePO3Vjj5HWVRE4g3/zLxfkPf3kuvTh0ljG6OUYyxd94l6e4E1B5KkfZDJLOY8i1o4AyovFUQohk3S2T887gwC3mTjS/MiTOQV0KlUOdiyYifUmauS2fsLwZZbYv2oUY3lq/fCISZEY5KFwENrirGGkeBSDpfCPBRTcjwaw4D2tBJYnMs9d5tsAE0hHwj4ktKUSvYJbxYH7vSKgsslPKadurVGRCQ/0oKpDNAkdXhoQqxpTggFQYcCPZufb6DyKlwi4RenTdqpJnzxJcPF+k72EDkdYcrGJjDg5QyFv4zKm/GxWKvLqLZi7Jyyy7WSWMeuKNUrVZqK8XhS0w40K9sMYw4DZuQAjrla4y+EuPm67BN0NdWjO+FIcJ0TGKzosn+V9nxegd5JG8Lfm5DRwNq8WEgnfOTacNNUxBtadoU08PIwuC0mOskD51UvcMa6+nE/Nm6QbOMeXid7EdGeUVJgvSjhUz9ASZkZBwBhGeG3bBm9IHK/PRQ/yvCu9sgob33UIY/YMjxOHglZCQ8X3gFOcNcNEgycMJNbqsud1h10oSgaNJsEoyRi3w0mvwJ1ddk0Camk5u0ttSkC34t86W5ZTwEiQ32CtKEGF4DvRP2+4jnJ9HYXhpfasVH/v1gvjmKh5y4c0Daxid4HRVbzBwtgT/zahYBKLb4DjbzQDSQTH78JwyK94Gx1YYKbgIQpmN0RByqBe6VJTvgsR8RdVsRhPX3WR8wtrgZ5MEOVu3bhFr+qDWw0doYh0lcBG7rSgNkwL6wB/Oz9aE4GeEUiFHBAetoaYIFRbfwLcVNpFPmn8oPmeleiNgpu4HKL+n+QyhCEKU7B2g5tscbVgI45DzlT25NobMwGSJH1s9l9WG0Fkc3Rr74Q1L7NJftsAV2b5BPOVxstvp/LH11RflHENFdX9XNcIwUUxSGbk6lWDKKeQ6G+vdrsdKQ4W+vtIj9up+/I5Rei5ovyKXSnwtFmPi6GT+M8fTYfOg9Qh/76BiWwBoLbRzkS12nLXzM1x2huxwHV991tIgSP4w440cCKPGAuCJpgrUoweeqbViwOIDWaWY/iPWzgo2Tk7ZEvYVB+dBT9CSkTxQLGQkCMF/xOCkl+FXlv0JXZxf7AzXtqnoU6XGBlW6wxxRm65L2g9Kd2sLbzmMjRMIv/70n8juMAZoK/ifg4vAc8A+9OSQkJ2kw6yS4iZknaKea/eR2Fn/gBG6pRu5cOIm68Z2qvMmkHaCrWi0hFovNJFn3vFR6ZluJMjF1hF/hITqNtpM4smDHJEZumj+AXOIWwodvG4v251ZVakpY09gbvZr0FqciqxzEBHSwdD26xw8vA+zM8wyARo7nWVACsYjqMY/NM4yCKXd/5iAf7tO6Xnoda29AC7dFQprgx5UokDy7MiHuCNjrnKF1VFakBQ5YQPXMt3/o0YVuR0AbGhmh7CkBxsdaJ5Wp6f6YC9RV9kG34IwiOtvkZ2evHx9+qeTjbp6cKGx6TSdfH9ydpLsbXc+32jcaFltqXRz9JwZIfQiRxPWpjNUtODGfEGfD8c/CAiwoyBCxFDxDqqyRa15AwdpKrTQDRmF4YBiLWOjattHmq68EjHizwXmBQtvY7acTwQloQUR7We/AJad8E+NzS8UXiYC6K+xs37DiFEMqSx3Z2NjFATw45BXR7qiuTrquiDcNgkLdJQpUDZOq7NOG5sgmt4dLkLmF162tyIDAbxrBXmoYruhQhJIMVo1q2QTslvea5TiRCWqhxE7WVNbjQA5YWfUEq6kyTA3xsC0WBHZEd0A4voX2+hZ6NX2c5npFoWw6RUUUVsuOFYFSvujEqBP8PaPakeIE0eORwBXeK+oUs/stmK+U3oVG0I0elUsfBj6NjldxxpdLH2fP31NSRwZpvmj1uepK0Q0kd3EHBKBN2IHPRFahwwqu8Hfm5sRBy6m03ptWNxuOhvLIcgovhNPA4lRyihw10FsU1bwV7Z61RKkcwbLHvtdbQp0NYr2iooaWny2BVNbj7uVe547jJP5raLNgUU6JAKD0OHgKNRKjbqani1p1D0/jdp0GqXSUBqK4/Q2ZykA5KOgvaDDoTg5cUA68bgOJkNpLjbjhLSzpygB/oS1TBZMR5+Ox5TxDgXPzLeadAwlRk2+ELJoVEAOyXVRvBPKuLLglClSSpQK/3JRXOGO+prz+p7BEryxQp0Qz59+EssBNo+vplDOdJ6PdgCL0U7bmJzHCaLGKthZm2Lkw4WsJVpafCSdZQv+8tGuNqC40RBVV21oW4rQUmPtdJG1BcjeLpdGMEJycJvVOCiLt2z3vDd6M8u5xAtqgdbQMpvNTPtMPFrEU2RF8iZjjSXWta2gw9CcGZjRu2Ch6CMXXb3O6CNadE3z73SzaLkEKZDGAAQiRjfzPQPvznsrk06m6Y/mZxd9PCynk2I1Jj4NqN8EvDfbG7xtio20yz5EUbI26RTr986lOYrJY2DE0DHoJw7QfGOBilyIiLFXAGgBpMtaJ/VLD5Ol4N0u/Uy5Eqg70IFI3MGflUKgSzluMit4lkCatm04ti0gMdqzQF9O0cSyjfVJwAxpY5AoMnvafP+mGEGo3PJWniDtG6V3GWn9zGG3g0Augzg2Gf+E+sja/BsSDrhr4UxF19dWTKcjhcm+A7r7KTsTTkPLanAU9ZZzB1V5S9BvP0iSrXZGmpffeNapxzZ0ZiRBMW9LU4D7Ws0jQwefAF0j6WxZZdvCWbQJ0/rAYRUJvA48UbguqjOaUBlCi0hwhO8eUpeI5CKMSJyWAyreRhgQrdGZWzIy5DrVqAzMQJ0Tkhrt5JrYo8G9WNtQdTxnFg3C0gAvN3sApXwCeOqYImO2klLt18UqjqlptoZbz7MCIOKMgmiJ/2KDXeXgZu23mOBLp7QtgIh2DjwZVFuoPU7L62FhZqxNHMnt4S2enUaJKINEi8VbLdTMVPYpP2KTLjH2ppt+pdAulKyEdIPANoihd6CeW8DqRRHesBs3mBEjfxfpanFlLvq2k3Qo5AAkar6F9YMiDUI/z/f0mnthpiKvKD1Aex8gwshz66Nihlx2tpTkJgvpAgltjE7CwsGdO83HRpdrF5csp7l65vpLzFsZ0ap1Ap/AFgCuufZksBXnHVasOuOBYp55zji/cJsvqUKIYoVqh/MJPX4djVNKjVlt1JL0JkV+e9aDt1wJpgBGDhIKSvWkt4SbCwA0mpA0g/KZjgUVIeDKs2NuQ0sGAXXiQyXHf9HudocdbaUg0RdeeehpNh0auXmdz6VertDtum6U2cAvQLEHqicNte3NCzMdA91VtvhSudT8UIgYLTmLUdkP5bZwDfXYzIneDXXbnsjEuEYxwzm3q3RBe8ctpLaoJQzqtTt7SefouH9w3N0PCIOO1hEGdY+OevuWL8h2tCljUBMFyMPyB3Xaw14Df1D3cM/jD/rvRQSCVC3AvoLB/zbV5otTtOw6ipYTfswjaam2EidnMTvlFbDY01M2F5wI9fDwXCKBukC/HTaBRBdr+XGWls5uZ49YWnrmtPQ9dzLBk9CHbSnPK84W2A3ejBEAEouwIT4Cq57BU6hLITMiPppyUKCY+U4GvJzNUZ4zvTDpOkaelOp0x/3h9Aq7lVd442rIu+rkbHVSlgEDFuiOIfTYxLFFA6aCq4pWqdJlU/mVAzTnYtI6hQ09sQxIyGJMsDSJ8FCiVR3JKL1YlUJBr01wQcC2c+UOvVcrmZnIVrOXsjbwNZiJsXLUDRPeq4wrduUKgbpyTLt7Qxbcm1l6r5nQw9iSR9a5yUsoc6haxooTRKMRaRIUR+K3o+2m6u5i6nN5Ox0CzRysE7Mmp3Oa2zyoduW5NgmCQqqJt5doYhNIHvILbcAyxSe1zk3mVnjFJZyc9gEDtnVNifoHE1L85Y/vrsoaenIZeSigSZ5r2yNMNNUa9ic6/muzhMKcqGeU0tARMLYWGWnL702y99nEbwa1bn5VKPwRW6rUXireoi0FVqno+xEPf362BvU5E2iP4nLQRiVEIeDPsVmvnpx1EUNxlkosincwel9Ji2HmFGGs1LfBIuNbAw0QWspYuPQ3g4lcgUY7PnHuo6PQkuMHpRThtyIxsQ3JdLifocmZdMPTsoKCcDCBjQCA3whDEEap8cKIeFDuxKPg3pOX7N46xZaDACA6XqmKGTv1BFTl7gFVJ9pxNtvEBi5NZknfkm+hJE3QJtL6kTgFMlxhjaPzwMcKTQZgkfJLBqX3ux31+0umZwvukha+Q0tuk5Yx89/nV2Tw4Mve2xDUoazst8qOh235iIvRWMmBqwZU+M4j1XQVV8v/RmfGiSuf/iiqd/xGCSVRmaUngfSKYy7u4xehPNpK/gTSAqYhvC5TuvrNI29KNj/lZLtNHPyofPKbltOvf+MKWvnXDdbvyCfg3KD7RgIZ70HfG1Odk7wRmXL3kQjLeVWjcxO9paQLBxXdZrxfkR9SlFpJ4TlW33s1DGSsumiRlJ+akTFvyx6KBpOGOsz9vcIsWyJdNXoVqVRUIXVdyP8CF5hcXZdY3AiS+PB5H7Ui+A3roL2fUXJeZ0yIkA+HWF3HDulCAdRffhZWgTpE8W8ajnBLV7egNSUoXd6YpCNPwklS+z0qITZZTttcQEIkBPeSSc2qq6O9EuucQ3j3Nj2WFEPoUyOiliL6JDOY3pif0Mt8/8oZXUfgILGJ9apKPTm8KKUYIUO/c9s44jcLMmF3RF4Jd1xgxUQoXmyMz2Jxa2ku7Va3MsbpcfkDbChv4hzkwZo85CcC9QbSyWAN76M3QhlVlMItLwcl+0A5KOo8WRqvh50HcAt8A+iTIDbm6ivCDX1/iuydp6O05Bz6KtLmHLZzX/Phiz4GzHmFR3LHKXgvq0DkkVzNi0s+TDLOoJBASADKoXQxuvV1jOKeloeyD12RMjPhusf764hkUZ3N9nvUq2h31l4MbIjarC+lMPc31MJDPVUlOUcavcfkvIofKVsAaLbi2IHyG8qV4nL2JanjnoHWNC4ehuMNQHfylqWHl9rjDDpzZKSieDCHwEOMLdVq+Fr/qiq3WjfYhxgkQ9mUdDSDGVL9GdY8YCHdYEDPfZCRLNIblYooZKSkcw04mOEizc/fnD/ImrmCR1DxlUdBt5a25dj3YZQi0fnBi1Emqxlg1BCL6vuA73+oOhyMktUVbaBDeb+deh7ak8hygBYhtY5Rtge1K+95Eu4+HpWormO3TABeWFrwE6nV+RCZIdGRckhxywM2ukdE4ycoT3HP44JYfUoih4kUJZ4xKxBlAJe2GfWcXDBiiKDr6SFmiOAxAUkyy0vPO00RNlXkylXJLJJH3xbWclrNxo/YPHjoAV9SlXliIBVTAOFAz0mrYjfvZzzJ/yXjYTwgf/KvItJWxQ8rtX/NDL+nOO2DXEUVwL8VZaFPjwIoa+25h5rWwMKZRCwc1DJ5sS0WjD7/A0YVekwR8F9OsdIfFRkwl3gxWTEY8iHHo7YeCz1yijoSetY4BqBhDDgyYMHYKGjCY/8gyXrBFPpuvYpOv8jfp5wx89CnQFlnXJ/P4rQICcFc/MRLS49A4Gz0zqskjXE8S85Flc64vQeZT232IqUDBYF8sEks4ERFskHBvOdxnQmHX5BJo06LTgsRs6rGZOtVE4LoxetLy3opRhGMUeXOq6nCRUUijeAhLnp4k81gvTfz0SUr0YMro0+zk2OAMWsqiamMZJfgPM4wwpnGGIJ6jqibPql/6++p2u0P2QSqgMDdzOLA/GUrOfnXE/n8fJHOsB/E4vVcApVLOVoHx8LRYwGGoYR3rI9Xcm+YhuzSFjeH6hpG+EwYBqqwmD1O20KAIeYHUn46cGWaCxJhZ1KrEjaOhKTIIrjMgWBh/XhDvZ3dFVcwHXhd0/SYV6BcTV51HuEBY7D+AHXH/NaBkdxCrSbYBkiAve2++/Gu+nHUx+BUrk8/ocdEU7DbBa5gm4gqT/FItlmdHqUzShgBDDS7fZrBGOoN+2qQ+UyyTeLeEO3rCccUfcGKaun61VhQhEsDDMyv8QOxPu32KHSCrkWcf/oJNaL4mMrKQLyLR41CpxH2OEHvD8lLBX3UMLVjLAo6Rb5GeF+qzbblogu+6L2cFDecxZwBzJhQLHJWMDUTZo9Mzl9/+ncVF/z1p/9gd/KEGlHw3mJ2mV+B62OTIXi7DJ+SI+E2wT5PwzM+VJWNDic4p6JTsMV3IwDcA4CbImqxoWZndx9rdh4ddw98CO5edy0Et3t4sK9KdtquNgXhxiCevw182zn+Wy2g9uBIALX/rRCbVPUQZojJ5qbIuNjmStFRUG1P1T306+CGFRAb2o3CbLuHZm6/mH91Anu/5DLs4I5xxlVCDdn7QBjBKgJniyXClppalaSL8xtU8TVqICASHVp/kQG+zwwyv5q5GKZD+QqT+9xMZxTZ29/tSvnF/Qh/6oY+p0hCw75HI6g83MfJM8W+OKaKGaxuWFtvBBwMkBkzEwgkyF924UveLyRFRsvpuErJWNaefkyrI7YJFzoigE1ZrBZYyriUCo3RRv984V2CTGA2NUKtNGunY8bxDDHaGJQw5HfwbXZznHwvycb6OcE8zRkrlbZ/NNpT+39tJZ320VZyfTs3QyEZG0CAYl14iYpYl69pHPmlDEXK4+HhJpJ54UKduYn9MZ9jo9HdcFAPHQ02OYSc8YY24gFq885Gt/4o7Q95dJYWmr0sWLUDXFgWsgvsAF62CxpGcojocmruA/kFoLkgZyZn2r8xZBtc3qqjXHXkR+dFZ9vve8B6uyAX6viBBHXeTORhZ8uJmp545XXZxc66Kt4FQrJXHcmuN5K+96nnfaI7+QeX/E5vDTQCikGg/u/0llLOBl6LNCQchZODXYDpS46O+gnpDtImDA4f6atHgie69ES3thFUjTu2AOEFo/SJZIPUkY4t3vEMDW+e1bqMHyNN4+rGQbvbwYyfg+N+53gvLBG+NuPnoH/U3VUZP9zRxhk/jVfevasd+7u+1vFbLhTKpjmC9zMvASCstiWZjd//B+7+fya/Sc7db/wMm7qWoxrAgVndbzIjbKAitSyKLZMI1cfh5h1JBh3qBdQkwvDh7jK/XMjlFbuU97vdfbqU+2xFVwD+IAaevzm3MssKLVtNm4L/Nv+bjX2iWMfRBCOtNuUj86EcEWTfUQULJuIRWgPki2NdMeIwCEs7awXU60g0KBos0Zn48+kBWVxuqq5yHSdCC4ZTRazagVhohh5MzVutSYiovo+7Fai0et10eZh/8786L4/Rk2xJANYwKdvDaD5uSfXvda1xyack848vsTyLJX+EtYuk0eqB1lcUlgBjv5LS8iPDivDI0EalDefvAuDIuPgGrMElQQfxayklKVlTnPxj+TjHb1eYoow+hz+9fv0SeoH/r8yUVD8l9VD3zedWZdZQCziWYlRMtBso9lYiMlxCQ/QY+jNfv8tS5KBBcx4R+Ta+g2BTmDxA1NY3fRhd1Ggy9DyfQW1q0MypHoXty6OE8pvfaMcIl5Xsmk3m5MB3PAbsStKXqE6KC4NURdB/feIyIS6CdG+i5Q+GER1FpM/ziMzllr08rGDPnbvhWRIy+l205/1AU6RZ9RHuyMHEHm5ha4OsdYC8IjFPKcJuO1EKJENE7MVpr0SzeUfEFyZ8F8jnbNdHDW83OrxQTFCp7pr51jptJcTAaommA8tn7fJ2NoKopbf5s5HNv1/bLPukbQR04t0FgacY3rN6AcTfVEtd+8IsteTC4RvUN0Tizb1w+fPBrK1pTrzpQyTQ94bFwlOAtcgDqcQnTzIbe42t4rLaPc/gYQr7WfihRz0Vbc3nDnIlXGkgHAsJJFFV6v3yMzErlsTs4vd0WvV76duLtdkyeUx2Avj2OltJthxtP4lbi5jkyNRn1i5G56mUBjPSAPy94Kllb0KN4UmhMbiySGJxbeh0bLMRU1ciA6cUWLGnKEhZbohiILA4Oeybjh0+vLLb6yKXcpt4BZYuII6Y9FFy9u2F/K1xe1DMt73IzBkb+S+J4skbrXPP1Ax7vsgLZOUzw/7CzLKx+4GkfJxNi4E5G7gJBuYJo4IMQOU3aiE9hE4ncw8gtxvSODB/nhkVvDmqVlxdnOYzehHVRAXpbXXBOZesIvXXdePK6MFWEt2MeTV2TNnT/ecL7+exCdd+NigdSWpY6GpznjRXT/AayH4CH5zDz66VTkbAQdZtjTyn12PgXbBlvaaegn/mWTob3YJLiIevomXI8wfSiSoXYv6e7Rm6jK5XXSkzt15u83OiLuVrQPlZ8+DbEiDsQIS0gmylCdP4RM9WdXpc28Gh1CwzLltIRFmoAK/0XljXJ08y0LmBBxGPm1XbdiqY2a0QH+5x764XKM0WwdIMZgG+Uf8WjO1fmzVKcsLX15DIkZdEG0GwPFabWb8KTmG6ePpd/eaqvMXawbPmb/aKGTbdqRics/erQsRLKKzk8ufDW3NnJOd0f0D2YNXB7hfLhm6FZ0qG+NRoCNjaSzbSZQLM3oo4RSI9dDwlky5MqP1oNsWteSs+dmzHOsoiqkx8ge67I4yMnib6NNaQ6HG5MJYDxazBgtF7pMD66lEMBkIAHRgilDWIB7DTBfatbt6TT+Zy09uHMjbsEbIkREZMN8m8s2y+yGD9E7mfhlJ3bpBhIXO+p9LJQJp8n5rDMpzEJs/WeS+rYqsyd5F38+cMg0kUSEKXsS9v4K1FUIUzper4IJ8XjaMN12q5Pb+e01Flym2FoYgMCcqQ3aSLMbCEwf/LbqgMVZ9FMx5VwC/Qer3tXGFBDz3r9Wp1ZLCRG8tJkzPxDEpUAwTpt+l708VslbxC0MDcK/9XcyzUhWGpMkkWQ4dqwJVVjii3qIn2t/e3O8nna5/V4KXP9cPiuLeyI0G8MniZYW1k66JN3v88thAV9vf6se5t95PPI1NEk69nSpu13v5v8Ex2VJwDPlWUuchtOp9z0bvnRQG5GyfmvN4aEQHRsauVdS8Qjz75oFBoCCrEXoHxSw8EmjlnNMVLoLXhcGegAG03LwlAn+A2XzaeiBplyFlbHhGB5wizF7lykCvl1n83fdAcdlECU8IT/Vqa3EBzjCg4bltIg05zib19+O532NeHG5603c8JMcGiytza3nmoxo76x63+dqcWqLLb7hwl3d5xp1uNHB2sBars93cPbeSIu9kYpFIfJbl/rEpA/vbfK+ZB4SozKZptE3H08WDVngtWaXfM9/QLP1QVbzXOCGfWgWEqQD+BEitr+74wkfSuV3grcufGIlNHR9AqHZ+Dqnbo1kkl2iD/Bfg+MOugelIwqxvUB2K6fklbJ7m4pqquMKDIn1+moCcR5+94HNLcVkUEcdi497zQfJbUhNfCU0CKjngvVJZF0vZgcJbzTUZmZOfS5R+WKIaZlQS5IY7ZUzrZCNv6lyI1khKMkwBLBcT2mKKfLNMrBAUB533Vu9nYOhIec+ldY56cL/850Erq2wmgxmZhyL/tS9oqSLm5mX9jJ7l6WVf5DSqdMJ8/UYIXy2jND594i4DQ74H8ts2L1KbLGat3lZlfxJqKhi91uWvqoraDNLFF8bB2h0rhkg5s5WDZJZJrY0v3hLfTQV3NnoA9qLo13dEjswBJmiTsVZMNl0ryW2IGtbiNjid06SM2xT9pZrWIYvMHJ6QoEV8DQfTewkY8wSttGeFrWller6ZDquTA+o+Vucljo5nugSqbPFEtKvjLi/RdVnOAOQGWWAMYmQshkzagrGrQNGfF7JEFATMgv5jbraqms+AyKQnSQt4urynal9pfl4glQlfDJH+XNYGFmsbQ0L9Ya8qhKh6eYCSIK5M8ZA6rbNS7nlViW4gPJWiboL7y+sMMabnN2X7EhW3KaNLBgQq1KEzed7MyhVp76fgKa0q6cuDg6nybmofac7or0FdMp8+ffDPauTrnXqe92Kb/biahPMzQ2MLogtEwQIqOI5tNMp/ctUBOKKRQgeLnWiJWTsd3EdftVuDUM/8dreiiMWqOHgFvdD/OEoWWyeQghREJZ17prQTzUC+BfXH0zq5/ED+yrD7gX6SZzWeKe8s+WRkFqyk0VOHWjgzHC6JJWYqwJJHaHD+cfu+/v0OOsKoPbnHuBwjSI23EfCUFiMrlCKOQEC/k5NNn55VAwR3H0hC0dy2dTgqs4gvpVWZZVMNcxd12YFahuHEBkqVlyHaUO5H2X1H5IEvkjqEHSmkBCxu55yiuQbkIzg8GReMiDao4RBnjwuQFwAvi6yyFSMTXoLFGnZKRKkr1sOL7DXnozl5wOIajpIg2KVUaDznofzi1+99pMeYszYky2JzfWNtfkyd0nIGjAeCvulK9B98BtUUBfepmgymMifzFJ1ywjgps/AptujzmaZWTwE6FWEGtU2Pwdrb7eFm/LTGbBHx65lpFC6qx8Zfg4r8uYNF5QGX+I4txavjz6JigILe5NyGaSu3bwHXhliT2S2tyvTxJvsPL62shkwL/NW3oHNSWGTr6C9gtngUBcnPIB+ifuPGKUBVZSdqM/TFMyni0MLqNX0bBbqI511utbv9ODeKAjF8bAR2hbTgwW30g186Ac/c5/Ek1iJd14OpoyTT3BjiUz72frlXwK78XJh2aJBIHsoyR9WtiqyQZYreO4pSlBDSA5NfhFqJNoeednFq0oVz2FzvkeHj1bN+VfEw4e3z8XcYzt6Zi11VTxa2a3S6//vQfJTe2vnP3MsZIbEMR+3RhS6zyi8Vj9gy6oNopcDJiYx2ubtvFok0s6ZGxNo1TeqCt8MPpgE3842OY34EVVaUqczGWSAog/8BiE98c7qrIsfFzW/6pToH88wXTVC8qMSUqhcFXNVtaMU+sXNK1ScFfFwWKw8+SEyMm8hkiHzhIx0GEqqak3+Sw5k3e/k80vVYOAI9R6r+uIKHUDAKLBHpcI5Cyl1JEUO9l/4W8NzmO5zR746tkepDe8GVr3pWcbf6i7Las/OdTd+rBj5Ibz+DgmzXjghuV37AGWo/81ekWvbp0C3EDN5rWblsKFJStHCZTIXpkoLwr47JU7LPAASCD8PcPb4vXZAy3k5ObDOMEMgPnMFlmAmp8N03bkaj7Ha7aQxZ4tbWCxvWsVuI5+A6vqSIQ5fJUJiDiE48pWBRAKWaOB1nMSLsasRH1650Vnn/SxmxgGeNeIgDtEpOAmaV8gaQGS5nrcocn8JqPdeEbRdhEdEGIjtTqkKzDs/o4LIA98pJSBmyZmSLql9K7ZmLkPETAJC0X2hiukHjfTZxvt0UX1IefazNGOXboUIAuj8SJvvoF5GfXxvoQHnPf8mbCs/yS95u1Ek+dkey889o4seVNvbDTLLmg4ycnYm512uoxlh6iHZzbRHP9Q62enlsdo9SGqsXDiRKiYmBJVDds2E3Zh2y0kupw4Od+7zuxHqkowGCYmdYyqFE0H4BHaADJao9wR/6DR4BrMOAJGZSr6TRd3NaORIduyLOQz2ArgSiX+jXKQPe3DqXOj+0dJuXiYQ3slUcKSdS/uh/QTDhHhBUDZKSSv0q+46uovUyHuMeHfDTBKV9cZZD9WTmVugKcnkJpHyjn8NRHO1H2QSl9UUfM+hyM1j5fdbM0ib+ipnsf7yKdIEXvsOpPIqPDNGI2ASh1OVYiek8OaEv8SYUGZ6Zj8xDxwjBG5BY8E1espZQMfLAHbAjRi9xCQb3VrERzK5tdLpzVjEQklpXOZQ/iHecpPhvcYb5Bs7e99/ndW3Dq1F5MkXylq1+cKZn32uyaORQcTqfOD0gJ4hEH/2pGDoiob3VPaceBx/cZ1zx2LflUwllKV+dQVUKbKUUs5kX+DW2CWKtzSq9NcvVur3gcgD1m1icOrzGZ+FSu/o7bU7W94dNBzDvtmfwQGkLFFzllcNBwcyKcqZi1fW86YuxI0pG3XvxU6PKPuen1fjHimR95ZFYeLq0qMyodNI+Fw7pwI+1qSAgB69jHhrTCrt5ojdSJoi93HDldRNn2mLQtC3s6ege67o58UQUw/vaO0Z/2u/u9m8hgH4q3s8hI+YOa+R/Sxcw5Fz3oP5ay5HiE050+/UR+/pruc3z2Or+6hmAPlxT/kexnc2eLyot4vdTL+DC6UHE1w2fTMnkkCpYNJmHG/yPVoUdRQ5YGb5VLgDZGExDVz89jhvdZ8c6IFTKSj5OnSPSsNb1cDge4HPVY1K4tZkgpACWFHQ04F5qCn0TsroqI3uXUfr2Gu9tdY8Hw0sWDtsfJ8wlEikCu3CzS+TzceadchQCSZ8JoHdS9iN0MZwW+M0DEVhC817e6tU4bfihWdaiWWO0JS7JaHQqUdetmM8cTaiDms3H+Ph8jDL56852GqM1w3g4/d3iTpGumsdKE3N8QWfDUPR8M7mt9pF4ospCoBlkdr9OPdFFl6ek4AbUGlWyeuUFeDgTanZWPn1QafJFjfTwYNDln3pyH9iH7mTFGrxaQiIZrRqii7ZRFRZ5yPT2IGwzdOqF3ifgpAe4XXCcP1uFTqXUc9uiJP/ImtBPv6AjJlmus4qBVgReb1vjpJ7ads9V8ko/C+DQgKsGVQgvB3hj4Vd0WdsKgLwMOnQ0ycLKIB8VsoPz64vaFIwhYOgpyMDyERgF3fOQKvrDbQ0FiRMBm4eh6231zdkerBR2JD1lVW298O+STry5ONCDO28SODyPA5Deh6AdADMR2IN64iv3ALynet+tsMgcyvPk1IGvr0azKcn+adLvNuQDRw0fYF+JJDYB8EWYPBL7V4jP77e5R0u0c7x0d73XvXMt3v7+3p4jEuKONEZp14MB7x2ce7h7V4DM/4v4+4v4+4v5+G+6PcMN9LsgtxziOGe46zLBXeT3EC1dbi2KFd41gM2fH1VkvJljvmIpreD0Rmj7KJXfY6zguuZrKtBFBwFxPyMni3zfdKsQ4mhu+yKb5akq5Ma+yKyLTRIqzSXFTkzn1LVoFx0nyZibFZo02m304JiibubTb4O+N/HrD8Pae3stIvsu2zsBcCLiP8UujPOEXlZBmz/mD1ITUgEI3GlN/u+uCo81rgvJB1qWLk3UJuhNMKmc0RQZXJdUxo6OoPibXQsut12bPvDPibZW8oOqvLW2N5CH33guk3oWf+zqM67VKwWA3CcFfhJEAzUbcJM/MJuayCxLKPjX3zlVmTwDPQo732NSGtH/5mSEiyGjgw4M0g/AG+U08vYdYrApc8Dkg+BZBvTN86uRtipR400hXdM6+lvnhS8YT4BUYAianqHxjYUI8FTogzFmBdWoDyxVX6Y3NPXldPRFk3qlDF3/p3cQ8s6V6eya6fAU32hdpcm0u+y9bO/8y/7K/f7C/22t9xXO053v3vthJzUJAmyi/NakzRshywgsz35BR5j/9BKmcBSSQTspCaDlLziDV3DB4x3iTyXmO5Mb/AkT8V3/7GwjWAVwe78wkDXiS/v73L3bw79oan43Z3+drJnAO1PxyshcXrKi929z+kHWhH2IydD67utPVq8N5rN37SwysdySE13BlBOjsgAIRzIkPlkaPhNhFZh4GA5u4fWdNl0Pf/nZX9vslMjsTB5/P3id4KCR2wDgRMKOCzTVSKYIAr5Tf9dTvMFXYmURsmvuQWnQWo99WycVsmuaTRq7AWqrAbgMzcecQmYn3j/uHdzUoDo/2jvY9qsDunQyKmPZw78bE3mHElthYTTBKk2l4/7hFYUvoC5Wl7p6jOSyXKWR7oya1H2hSXZV9dSHPRXWk3l7PKElmC2UQ4JhR3d7FzKUet4eI9SA91mZSm12Cpiwc9CuIyWAn48C7zLVFE+LMBD30psAOymMntgWU4aNaTVuPZ4UuYaVBG5K29oSimFxSyLpHzvlRJPqZTNQVofY7WwYxnW9339IH73okobsef7mmFu1LsIk/HXqfDrxP+96nPe+T32bf+9TzPumR6OfoKbx9Llfm5fEOnggSDeuQwVoeB3dTp9s5Omx9Feya4+QEXEbJM3OwyOcOS//cPhCsOJMywFWm7/H1g/nl54cdTY2MMqsr54LB2wMRQ0yQbqTQZbFaLG/b3d39fqc9XLZ720arGwFy1sgZlE0iIcjbYq7IpTSzvx+XZjfzNttMO6s5SLVyx0jGvZ3O7k5wvrfnM6LPPG6lK7PPF9LZdzMzA8+Li9sSaIDlW5xOrIQRvkk4hGujIYSd7dSRu3b22r1dlNi7x72jgEu+s05i946OjvoHSmTLvG8qsmNizzcJ40/cu1g3LRB1e7fSXxvrw0TFsTZseSsbrRSfjvOx91EoT6Dsyw3XuMHiMySFddhfmiNnhUQWSozz2jIwkiLHlE3UCuYrZZCfBEJcPOCQskRUrjfpbVQ49nu7IhxFBPW+OsuWoCbwuebaSOavPXOjEe0kiH/SMSX0gDQarFd++snEGKugmZpzaD7ll8lj0msG2QcoRvg4efTDy7OzAcv4R8mT5LN0Ov8j/if5Z2nTPc2a8GA8ngwm7kdPkr/BHUu9jIQQswh6Ztv5Mfb5zeD7p68uzr/79tHv71PbF9E0+S4rMw8mkQ4Of69Eoo3eph33f4F02gcCgW43McfOnPDdXqBP1ryvk079/m7vsKuk053UyQZJ4BdlaHru3uVUv4NOq48Hc9M+QeOGyTSrW2pn+gB80ijUUf/uwDrMc1JD+ev8eG//6NCq6D3YoLfl4IbADfbWoEuKvxXD2t0p2Lv57UQVM1CLbP4yTRfvMoi3DUZz/y8CnGlPU/yL2RJ/o00j18SJLcECJ9V+6PZ8jyvvWTCP5AxYxnHwaoR/V2YGrz/v5on71Fy2BAYZqVGiOkZwHWtsS/m3fsBSSpgHbHSod+RXn9nRH2B/V+ai32W7UEq9tsmbvcOGAv9GvT68Gb/oznjc5n/Kg/4s9Pt1BPVB+zUTssuvswPFz+RZPSMgX4wMxwnYkX+oB3lm/o5vcJ2W13SXH7c6w/FRd+/wsjM8OkhH/U5/3D0aX+7v9/rdcfdwtM97E259c+yXg0U2L0qYmDwrB5SWAaKxu9fb7e7t9o56HLQbmGM16A46A7QtzZOtPw6Pu3/8+/8BWPkIMg==","yes");
INSERT INTO `bak_options` VALUES("149","toolset_is_m2m_enabled","no","yes");
INSERT INTO `bak_options` VALUES("150","toolset_database_version","258001","yes");
INSERT INTO `bak_options` VALUES("151","toolset_executed_upgrade_commands","a:1:{i:0;s:57:\"Toolset_Upgrade_Command_M2M_V1_Database_Structure_Upgrade\";}","no");
INSERT INTO `bak_options` VALUES("153","wpcf_users_options","1","yes");
INSERT INTO `bak_options` VALUES("154","wpcf-custom-taxonomies","a:4:{s:8:\"category\";a:25:{s:4:\"name\";s:8:\"category\";s:5:\"label\";s:10:\"Categories\";s:6:\"labels\";a:23:{s:4:\"name\";s:10:\"Categories\";s:13:\"singular_name\";s:8:\"Category\";s:12:\"search_items\";s:17:\"Search Categories\";s:13:\"popular_items\";N;s:9:\"all_items\";s:14:\"All Categories\";s:11:\"parent_item\";s:15:\"Parent Category\";s:17:\"parent_item_colon\";s:16:\"Parent Category:\";s:9:\"edit_item\";s:13:\"Edit Category\";s:9:\"view_item\";s:13:\"View Category\";s:11:\"update_item\";s:15:\"Update Category\";s:12:\"add_new_item\";s:16:\"Add New Category\";s:13:\"new_item_name\";s:17:\"New Category Name\";s:26:\"separate_items_with_commas\";N;s:19:\"add_or_remove_items\";N;s:21:\"choose_from_most_used\";N;s:9:\"not_found\";s:20:\"No categories found.\";s:8:\"no_terms\";s:13:\"No categories\";s:21:\"items_list_navigation\";s:26:\"Categories list navigation\";s:10:\"items_list\";s:15:\"Categories list\";s:9:\"most_used\";s:9:\"Most Used\";s:13:\"back_to_items\";s:25:\"&larr; Back to Categories\";s:9:\"menu_name\";s:10:\"Categories\";s:14:\"name_admin_bar\";s:8:\"category\";}s:11:\"description\";s:0:\"\";s:6:\"public\";b:1;s:18:\"publicly_queryable\";b:1;s:12:\"hierarchical\";b:1;s:7:\"show_ui\";b:1;s:12:\"show_in_menu\";b:1;s:17:\"show_in_nav_menus\";b:1;s:13:\"show_tagcloud\";b:1;s:18:\"show_in_quick_edit\";b:1;s:17:\"show_admin_column\";b:1;s:11:\"meta_box_cb\";s:24:\"post_categories_meta_box\";s:11:\"object_type\";a:1:{i:0;s:4:\"post\";}s:3:\"cap\";a:4:{s:12:\"manage_terms\";s:17:\"manage_categories\";s:10:\"edit_terms\";s:15:\"edit_categories\";s:12:\"delete_terms\";s:17:\"delete_categories\";s:12:\"assign_terms\";s:17:\"assign_categories\";}s:7:\"rewrite\";a:4:{s:10:\"with_front\";b:1;s:12:\"hierarchical\";b:1;s:7:\"ep_mask\";i:512;s:4:\"slug\";s:8:\"category\";}s:9:\"query_var\";s:13:\"category_name\";s:21:\"update_count_callback\";s:0:\"\";s:12:\"show_in_rest\";b:1;s:9:\"rest_base\";s:10:\"categories\";s:21:\"rest_controller_class\";s:24:\"WP_REST_Terms_Controller\";s:8:\"_builtin\";b:1;s:4:\"slug\";s:8:\"category\";s:8:\"supports\";a:1:{s:4:\"post\";i:1;}}s:8:\"post_tag\";a:25:{s:4:\"name\";s:8:\"post_tag\";s:5:\"label\";s:4:\"Tags\";s:6:\"labels\";a:23:{s:4:\"name\";s:4:\"Tags\";s:13:\"singular_name\";s:3:\"Tag\";s:12:\"search_items\";s:11:\"Search Tags\";s:13:\"popular_items\";s:12:\"Popular Tags\";s:9:\"all_items\";s:8:\"All Tags\";s:11:\"parent_item\";N;s:17:\"parent_item_colon\";N;s:9:\"edit_item\";s:8:\"Edit Tag\";s:9:\"view_item\";s:8:\"View Tag\";s:11:\"update_item\";s:10:\"Update Tag\";s:12:\"add_new_item\";s:11:\"Add New Tag\";s:13:\"new_item_name\";s:12:\"New Tag Name\";s:26:\"separate_items_with_commas\";s:25:\"Separate tags with commas\";s:19:\"add_or_remove_items\";s:18:\"Add or remove tags\";s:21:\"choose_from_most_used\";s:30:\"Choose from the most used tags\";s:9:\"not_found\";s:14:\"No tags found.\";s:8:\"no_terms\";s:7:\"No tags\";s:21:\"items_list_navigation\";s:20:\"Tags list navigation\";s:10:\"items_list\";s:9:\"Tags list\";s:9:\"most_used\";s:9:\"Most Used\";s:13:\"back_to_items\";s:19:\"&larr; Back to Tags\";s:9:\"menu_name\";s:4:\"Tags\";s:14:\"name_admin_bar\";s:8:\"post_tag\";}s:11:\"description\";s:0:\"\";s:6:\"public\";b:1;s:18:\"publicly_queryable\";b:1;s:12:\"hierarchical\";b:0;s:7:\"show_ui\";b:1;s:12:\"show_in_menu\";b:1;s:17:\"show_in_nav_menus\";b:1;s:13:\"show_tagcloud\";b:1;s:18:\"show_in_quick_edit\";b:1;s:17:\"show_admin_column\";b:1;s:11:\"meta_box_cb\";s:18:\"post_tags_meta_box\";s:11:\"object_type\";a:1:{i:0;s:4:\"post\";}s:3:\"cap\";a:4:{s:12:\"manage_terms\";s:16:\"manage_post_tags\";s:10:\"edit_terms\";s:14:\"edit_post_tags\";s:12:\"delete_terms\";s:16:\"delete_post_tags\";s:12:\"assign_terms\";s:16:\"assign_post_tags\";}s:7:\"rewrite\";a:4:{s:10:\"with_front\";b:1;s:12:\"hierarchical\";b:0;s:7:\"ep_mask\";i:1024;s:4:\"slug\";s:3:\"tag\";}s:9:\"query_var\";s:3:\"tag\";s:21:\"update_count_callback\";s:0:\"\";s:12:\"show_in_rest\";b:1;s:9:\"rest_base\";s:4:\"tags\";s:21:\"rest_controller_class\";s:24:\"WP_REST_Terms_Controller\";s:8:\"_builtin\";b:1;s:4:\"slug\";s:8:\"post_tag\";s:8:\"supports\";a:1:{s:4:\"post\";i:1;}}s:5:\"brand\";a:19:{s:8:\"wpcf-tax\";s:5:\"brand\";s:4:\"icon\";s:10:\"admin-post\";s:6:\"labels\";a:15:{s:4:\"name\";s:15:\"Thương hiệu\";s:13:\"singular_name\";s:5:\"Brand\";s:12:\"search_items\";s:9:\"Search %s\";s:13:\"popular_items\";s:10:\"Popular %s\";s:9:\"all_items\";s:6:\"All %s\";s:11:\"parent_item\";s:9:\"Parent %s\";s:17:\"parent_item_colon\";s:10:\"Parent %s:\";s:9:\"edit_item\";s:7:\"Edit %s\";s:11:\"update_item\";s:9:\"Update %s\";s:12:\"add_new_item\";s:10:\"Add New %s\";s:13:\"new_item_name\";s:11:\"New %s Name\";s:26:\"separate_items_with_commas\";s:23:\"Separate %s with commas\";s:19:\"add_or_remove_items\";s:16:\"Add or remove %s\";s:21:\"choose_from_most_used\";s:28:\"Choose from the most used %s\";s:9:\"menu_name\";s:2:\"%s\";}s:4:\"slug\";s:5:\"brand\";s:11:\"description\";s:0:\"\";s:6:\"public\";s:6:\"public\";s:12:\"hierarchical\";s:4:\"flat\";s:8:\"supports\";a:1:{s:7:\"product\";i:1;}s:7:\"rewrite\";a:4:{s:7:\"enabled\";s:1:\"1\";s:4:\"slug\";s:11:\"thuong-hieu\";s:10:\"with_front\";s:1:\"1\";s:12:\"hierarchical\";s:1:\"1\";}s:7:\"show_ui\";s:1:\"1\";s:17:\"show_in_nav_menus\";s:1:\"1\";s:13:\"show_tagcloud\";s:1:\"1\";s:17:\"query_var_enabled\";s:1:\"1\";s:9:\"query_var\";s:0:\"\";s:21:\"update_count_callback\";s:0:\"\";s:11:\"meta_box_cb\";a:1:{s:8:\"callback\";s:0:\"\";}s:18:\"_toolset_edit_last\";i:1520619304;s:15:\"_wpcf_author_id\";i:1;s:4:\"name\";b:0;}s:16:\"product-category\";a:19:{s:8:\"wpcf-tax\";s:13:\"nhom-san-pham\";s:4:\"icon\";s:10:\"admin-post\";s:6:\"labels\";a:15:{s:4:\"name\";s:19:\"Loại sản phẩm\";s:13:\"singular_name\";s:16:\"Product Category\";s:12:\"search_items\";s:9:\"Search %s\";s:13:\"popular_items\";s:10:\"Popular %s\";s:9:\"all_items\";s:6:\"All %s\";s:11:\"parent_item\";s:9:\"Parent %s\";s:17:\"parent_item_colon\";s:10:\"Parent %s:\";s:9:\"edit_item\";s:7:\"Edit %s\";s:11:\"update_item\";s:9:\"Update %s\";s:12:\"add_new_item\";s:10:\"Add New %s\";s:13:\"new_item_name\";s:11:\"New %s Name\";s:26:\"separate_items_with_commas\";s:23:\"Separate %s with commas\";s:19:\"add_or_remove_items\";s:16:\"Add or remove %s\";s:21:\"choose_from_most_used\";s:28:\"Choose from the most used %s\";s:9:\"menu_name\";s:2:\"%s\";}s:4:\"slug\";s:16:\"product-category\";s:11:\"description\";s:23:\"Danh mục sản phẩm\";s:6:\"public\";s:6:\"public\";s:12:\"hierarchical\";s:12:\"hierarchical\";s:8:\"supports\";a:1:{s:7:\"product\";i:1;}s:7:\"rewrite\";a:4:{s:7:\"enabled\";s:1:\"1\";s:4:\"slug\";s:13:\"nhom-san-pham\";s:10:\"with_front\";s:1:\"1\";s:12:\"hierarchical\";s:1:\"1\";}s:7:\"show_ui\";s:1:\"1\";s:17:\"show_in_nav_menus\";s:1:\"1\";s:13:\"show_tagcloud\";s:1:\"1\";s:17:\"query_var_enabled\";s:1:\"1\";s:9:\"query_var\";s:0:\"\";s:21:\"update_count_callback\";s:0:\"\";s:11:\"meta_box_cb\";a:1:{s:8:\"callback\";s:0:\"\";}s:18:\"_toolset_edit_last\";i:1520619580;s:15:\"_wpcf_author_id\";i:1;s:4:\"name\";b:0;}}","yes");
INSERT INTO `bak_options` VALUES("155","wpcf-custom-types","a:2:{s:7:\"product\";a:24:{s:8:\"_builtin\";b:0;s:18:\"_toolset_edit_last\";i:1524153548;s:15:\"_wpcf_author_id\";i:1;s:14:\"wpcf-post-type\";s:7:\"product\";s:4:\"icon\";s:10:\"admin-post\";s:6:\"labels\";a:13:{s:4:\"name\";s:8:\"Products\";s:13:\"singular_name\";s:7:\"Product\";s:7:\"add_new\";s:7:\"Add New\";s:12:\"add_new_item\";s:10:\"Add New %s\";s:9:\"edit_item\";s:7:\"Edit %s\";s:8:\"new_item\";s:6:\"New %s\";s:9:\"view_item\";s:7:\"View %s\";s:12:\"search_items\";s:9:\"Search %s\";s:9:\"not_found\";s:11:\"No %s found\";s:18:\"not_found_in_trash\";s:20:\"No %s found in Trash\";s:17:\"parent_item_colon\";s:11:\"Parent text\";s:9:\"all_items\";s:9:\"All items\";s:16:\"enter_title_here\";s:16:\"Enter title here\";}s:4:\"slug\";s:7:\"product\";s:11:\"description\";s:0:\"\";s:6:\"public\";s:6:\"public\";s:13:\"menu_position\";s:0:\"\";s:10:\"taxonomies\";a:2:{s:5:\"brand\";s:1:\"1\";s:16:\"product-category\";s:1:\"1\";}s:18:\"custom-field-group\";a:1:{i:7;s:1:\"1\";}s:8:\"supports\";a:3:{s:5:\"title\";s:1:\"1\";s:6:\"editor\";s:1:\"1\";s:9:\"thumbnail\";s:1:\"1\";}s:7:\"rewrite\";a:4:{s:7:\"enabled\";s:1:\"1\";s:6:\"custom\";s:6:\"custom\";s:4:\"slug\";s:8:\"san-pham\";s:5:\"feeds\";s:1:\"1\";}s:16:\"has_archive_slug\";s:0:\"\";s:12:\"show_in_menu\";s:1:\"1\";s:17:\"show_in_menu_page\";s:0:\"\";s:7:\"show_ui\";s:1:\"1\";s:18:\"publicly_queryable\";s:1:\"1\";s:10:\"can_export\";s:1:\"1\";s:17:\"show_in_nav_menus\";s:1:\"1\";s:9:\"query_var\";s:8:\"san-pham\";s:16:\"permalink_epmask\";s:12:\"EP_PERMALINK\";s:9:\"rest_base\";s:0:\"\";}s:3:\"qna\";a:23:{s:8:\"_builtin\";b:0;s:18:\"_toolset_edit_last\";i:1524154375;s:15:\"_wpcf_author_id\";i:1;s:14:\"wpcf-post-type\";s:3:\"qna\";s:4:\"icon\";s:10:\"admin-post\";s:6:\"labels\";a:13:{s:4:\"name\";s:4:\"QNAs\";s:13:\"singular_name\";s:3:\"QNA\";s:7:\"add_new\";s:7:\"Add New\";s:12:\"add_new_item\";s:10:\"Add New %s\";s:9:\"edit_item\";s:7:\"Edit %s\";s:8:\"new_item\";s:6:\"New %s\";s:9:\"view_item\";s:7:\"View %s\";s:12:\"search_items\";s:9:\"Search %s\";s:9:\"not_found\";s:11:\"No %s found\";s:18:\"not_found_in_trash\";s:20:\"No %s found in Trash\";s:17:\"parent_item_colon\";s:11:\"Parent text\";s:9:\"all_items\";s:9:\"All items\";s:16:\"enter_title_here\";s:16:\"Enter title here\";}s:4:\"slug\";s:3:\"qna\";s:11:\"description\";s:0:\"\";s:6:\"public\";s:6:\"public\";s:13:\"menu_position\";s:0:\"\";s:8:\"supports\";a:3:{s:5:\"title\";s:1:\"1\";s:6:\"editor\";s:1:\"1\";s:9:\"thumbnail\";s:1:\"1\";}s:7:\"rewrite\";a:6:{s:7:\"enabled\";s:1:\"1\";s:6:\"custom\";s:6:\"normal\";s:4:\"slug\";s:0:\"\";s:10:\"with_front\";s:1:\"1\";s:5:\"feeds\";s:1:\"1\";s:5:\"pages\";s:1:\"1\";}s:16:\"has_archive_slug\";s:0:\"\";s:12:\"show_in_menu\";s:1:\"1\";s:17:\"show_in_menu_page\";s:0:\"\";s:7:\"show_ui\";s:1:\"1\";s:18:\"publicly_queryable\";s:1:\"1\";s:10:\"can_export\";s:1:\"1\";s:17:\"show_in_nav_menus\";s:1:\"1\";s:17:\"query_var_enabled\";s:1:\"1\";s:9:\"query_var\";s:0:\"\";s:16:\"permalink_epmask\";s:12:\"EP_PERMALINK\";s:9:\"rest_base\";s:0:\"\";}}","yes");
INSERT INTO `bak_options` VALUES("156","wpcf_post_relationship","a:0:{}","yes");
INSERT INTO `bak_options` VALUES("158","theme_mods_twentysixteen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1520006138;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `bak_options` VALUES("181","wpcf-usermeta","a:5:{s:7:\"d_price\";a:8:{s:2:\"id\";s:7:\"d_price\";s:4:\"slug\";s:7:\"d_price\";s:4:\"type\";s:7:\"numeric\";s:4:\"name\";s:17:\"Giá hiển thị\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:7:\"d_price\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:8:\"validate\";a:1:{s:6:\"number\";a:2:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:26:\"Please enter numeric data.\";}}s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:12:\"wpcf-d_price\";s:9:\"meta_type\";s:8:\"usermeta\";}s:7:\"s_price\";a:8:{s:2:\"id\";s:7:\"s_price\";s:4:\"slug\";s:7:\"s_price\";s:4:\"type\";s:7:\"numeric\";s:4:\"name\";s:9:\"Giá bán\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:7:\"s_price\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:8:\"validate\";a:1:{s:6:\"number\";a:2:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:26:\"Please enter numeric data.\";}}s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:12:\"wpcf-s_price\";s:9:\"meta_type\";s:8:\"usermeta\";}s:10:\"product_id\";a:8:{s:2:\"id\";s:10:\"product_id\";s:4:\"slug\";s:10:\"product_id\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:16:\"Mã sản phẩm\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:13:\"slug-pre-save\";s:10:\"product_id\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:15:\"wpcf-product_id\";s:9:\"meta_type\";s:8:\"usermeta\";}s:9:\"guarantee\";a:8:{s:2:\"id\";s:9:\"guarantee\";s:4:\"slug\";s:9:\"guarantee\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:11:\"Bảo hành\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:13:\"slug-pre-save\";s:9:\"guarantee\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:14:\"wpcf-guarantee\";s:9:\"meta_type\";s:8:\"usermeta\";}s:9:\"promotion\";a:8:{s:2:\"id\";s:9:\"promotion\";s:4:\"slug\";s:9:\"promotion\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:13:\"Khuyến mãi\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:13:\"slug-pre-save\";s:9:\"promotion\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:14:\"wpcf-promotion\";s:9:\"meta_type\";s:8:\"usermeta\";}}","yes");
INSERT INTO `bak_options` VALUES("183","_wpcf_promo_tabs","a:2:{s:8:\"selected\";i:3;s:4:\"time\";i:1523595362;}","yes");
INSERT INTO `bak_options` VALUES("184","WPCF_VERSION","2.2.21","no");
INSERT INTO `bak_options` VALUES("185","wpcf-messages","a:1:{i:1;a:0:{}}","yes");
INSERT INTO `bak_options` VALUES("188","wpcf-fields","a:7:{s:21:\"product_display_price\";a:8:{s:2:\"id\";s:21:\"product_display_price\";s:4:\"slug\";s:21:\"product_display_price\";s:4:\"type\";s:7:\"numeric\";s:4:\"name\";s:17:\"Giá hiển thị\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:9:{s:13:\"slug-pre-save\";s:21:\"product_display_price\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:8:\"validate\";a:1:{s:6:\"number\";a:2:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:26:\"Please enter numeric data.\";}}s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:21:\"product_display_price\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:26:\"wpcf-product_display_price\";s:9:\"meta_type\";s:8:\"postmeta\";}s:18:\"product_sell_price\";a:8:{s:2:\"id\";s:18:\"product_sell_price\";s:4:\"slug\";s:18:\"product_sell_price\";s:4:\"type\";s:7:\"numeric\";s:4:\"name\";s:9:\"Giá bán\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:9:{s:13:\"slug-pre-save\";s:18:\"product_sell_price\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:8:\"validate\";a:1:{s:6:\"number\";a:2:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:26:\"Please enter numeric data.\";}}s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:18:\"product_sell_price\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:23:\"wpcf-product_sell_price\";s:9:\"meta_type\";s:8:\"postmeta\";}s:12:\"product_code\";a:8:{s:2:\"id\";s:12:\"product_code\";s:4:\"slug\";s:12:\"product_code\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:16:\"Mã sản phẩm\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:12:\"product_code\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:12:\"product_code\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:17:\"wpcf-product_code\";s:9:\"meta_type\";s:8:\"postmeta\";}s:17:\"product_promotion\";a:8:{s:2:\"id\";s:17:\"product_promotion\";s:4:\"slug\";s:17:\"product_promotion\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:13:\"Khuyến mãi\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:17:\"product_promotion\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:17:\"product_promotion\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:22:\"wpcf-product_promotion\";s:9:\"meta_type\";s:8:\"postmeta\";}s:17:\"product_guarantee\";a:8:{s:2:\"id\";s:17:\"product_guarantee\";s:4:\"slug\";s:17:\"product_guarantee\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:11:\"Bảo hành\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:17:\"product_guarantee\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:17:\"product_guarantee\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:22:\"wpcf-product_guarantee\";s:9:\"meta_type\";s:8:\"postmeta\";}s:4:\"show\";a:8:{s:2:\"id\";s:4:\"show\";s:4:\"slug\";s:4:\"show\";s:4:\"type\";s:10:\"checkboxes\";s:4:\"name\";s:4:\"Show\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:13:\"slug-pre-save\";s:4:\"show\";s:10:\"save_empty\";s:2:\"no\";s:7:\"options\";a:1:{s:64:\"wpcf-fields-checkboxes-option-5b406ad9d0067f0e18103263d7e1c38e-1\";a:5:{s:5:\"title\";s:12:\"Best sellers\";s:9:\"set_value\";s:1:\"1\";s:7:\"display\";s:2:\"db\";s:26:\"display_value_not_selected\";s:0:\"\";s:22:\"display_value_selected\";s:0:\"\";}}s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:4:\"show\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:9:\"wpcf-show\";s:9:\"meta_type\";s:8:\"postmeta\";}s:8:\"num_cook\";a:8:{s:2:\"id\";s:8:\"num_cook\";s:4:\"slug\";s:8:\"num_cook\";s:4:\"type\";s:7:\"numeric\";s:4:\"name\";s:15:\"Số vùng từ\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:9:{s:13:\"slug-pre-save\";s:8:\"num_cook\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:1:\"2\";s:10:\"repetitive\";s:1:\"0\";s:8:\"validate\";a:1:{s:6:\"number\";a:2:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:26:\"Please enter numeric data.\";}}s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:8:\"num_cook\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:13:\"wpcf-num_cook\";s:9:\"meta_type\";s:8:\"postmeta\";}}","yes");
INSERT INTO `bak_options` VALUES("194","installer_repositories_with_theme","a:1:{i:0;s:7:\"toolset\";}","yes");
INSERT INTO `bak_options` VALUES("195","current_theme","BAK","yes");
INSERT INTO `bak_options` VALUES("196","theme_mods_bak","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `bak_options` VALUES("197","theme_switched","","yes");
INSERT INTO `bak_options` VALUES("238","fresh_site","0","yes");
INSERT INTO `bak_options` VALUES("245","category_children","a:0:{}","yes");
INSERT INTO `bak_options` VALUES("265","wpseo","a:21:{s:14:\"blocking_files\";a:0:{}s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:5:\"3.7.1\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:12:\"website_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";b:0;s:16:\"environment_type\";s:0:\"\";s:20:\"enable_setting_pages\";b:0;s:21:\"enable_admin_bar_menu\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1520528712;}","yes");
INSERT INTO `bak_options` VALUES("266","wpseo_permalinks","a:9:{s:15:\"cleanpermalinks\";b:0;s:24:\"cleanpermalink-extravars\";s:0:\"\";s:29:\"cleanpermalink-googlecampaign\";b:0;s:31:\"cleanpermalink-googlesitesearch\";b:0;s:15:\"cleanreplytocom\";b:0;s:10:\"cleanslugs\";b:1;s:18:\"redirectattachment\";b:0;s:17:\"stripcategorybase\";b:0;s:13:\"trailingslash\";b:0;}","yes");
INSERT INTO `bak_options` VALUES("267","wpseo_titles","a:72:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:23:\"content-analysis-active\";b:1;s:23:\"keyword-analysis-active\";b:1;s:9:\"separator\";s:7:\"sc-dash\";s:5:\"noodp\";b:0;s:15:\"usemetakeywords\";b:0;s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:18:\"metakey-home-wpseo\";s:0:\"\";s:20:\"metakey-author-wpseo\";s:0:\"\";s:22:\"noindex-subpages-wpseo\";b:0;s:20:\"noindex-author-wpseo\";b:0;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"metakey-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:16:\"hideeditbox-post\";b:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"metakey-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:16:\"hideeditbox-page\";b:0;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"metakey-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:22:\"hideeditbox-attachment\";b:0;s:13:\"title-product\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:16:\"metadesc-product\";s:0:\"\";s:15:\"metakey-product\";s:0:\"\";s:15:\"noindex-product\";b:0;s:16:\"showdate-product\";b:0;s:19:\"hideeditbox-product\";b:0;s:23:\"title-ptarchive-product\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-ptarchive-product\";s:0:\"\";s:25:\"metakey-ptarchive-product\";s:0:\"\";s:25:\"bctitle-ptarchive-product\";s:0:\"\";s:25:\"noindex-ptarchive-product\";b:0;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:20:\"metakey-tax-category\";s:0:\"\";s:24:\"hideeditbox-tax-category\";b:0;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:20:\"metakey-tax-post_tag\";s:0:\"\";s:24:\"hideeditbox-tax-post_tag\";b:0;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:23:\"metakey-tax-post_format\";s:0:\"\";s:27:\"hideeditbox-tax-post_format\";b:0;s:23:\"noindex-tax-post_format\";b:1;s:26:\"title-tax-product-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:29:\"metadesc-tax-product-category\";s:0:\"\";s:28:\"metakey-tax-product-category\";s:0:\"\";s:32:\"hideeditbox-tax-product-category\";b:0;s:28:\"noindex-tax-product-category\";b:0;}","yes");
INSERT INTO `bak_options` VALUES("268","wpseo_social","a:20:{s:9:\"fb_admins\";a:0:{}s:12:\"fbconnectkey\";s:32:\"c9aa8aac68bfc34b23e9106d56967e2a\";s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:7:\"summary\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `bak_options` VALUES("269","wpseo_rss","a:2:{s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";}","yes");
INSERT INTO `bak_options` VALUES("270","wpseo_internallinks","a:12:{s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:23:\"breadcrumbs-blog-remove\";b:0;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:23:\"post_types-post-maintax\";i:0;s:26:\"post_types-product-maintax\";i:0;s:34:\"taxonomy-product-category-ptparent\";i:0;}","yes");
INSERT INTO `bak_options` VALUES("271","wpseo_xml","a:18:{s:22:\"disable_author_sitemap\";b:1;s:22:\"disable_author_noposts\";b:1;s:16:\"enablexmlsitemap\";b:1;s:16:\"entries-per-page\";i:1000;s:14:\"excluded-posts\";s:0:\"\";s:38:\"user_role-administrator-not_in_sitemap\";b:0;s:31:\"user_role-editor-not_in_sitemap\";b:0;s:31:\"user_role-author-not_in_sitemap\";b:0;s:36:\"user_role-contributor-not_in_sitemap\";b:0;s:35:\"user_role-subscriber-not_in_sitemap\";b:0;s:30:\"post_types-post-not_in_sitemap\";b:0;s:30:\"post_types-page-not_in_sitemap\";b:0;s:36:\"post_types-attachment-not_in_sitemap\";b:1;s:33:\"post_types-product-not_in_sitemap\";b:0;s:34:\"taxonomies-category-not_in_sitemap\";b:0;s:34:\"taxonomies-post_tag-not_in_sitemap\";b:0;s:37:\"taxonomies-post_format-not_in_sitemap\";b:0;s:42:\"taxonomies-product-category-not_in_sitemap\";b:0;}","yes");
INSERT INTO `bak_options` VALUES("272","wpseo_flush_rewrite","1","yes");
INSERT INTO `bak_options` VALUES("273","wpseo_sitemap_1_cache_validator","5HELV","no");
INSERT INTO `bak_options` VALUES("274","wpseo_sitemap_post_cache_validator","52J3P","no");
INSERT INTO `bak_options` VALUES("275","wpseo_sitemap_category_cache_validator","egIq","no");
INSERT INTO `bak_options` VALUES("276","wpseo_sitemap_post_tag_cache_validator","egIr","no");
INSERT INTO `bak_options` VALUES("279","wpseo_sitemap_revision_cache_validator","25eF6","no");
INSERT INTO `bak_options` VALUES("282","wpseo_sitemap_page_cache_validator","5fsaC","no");
INSERT INTO `bak_options` VALUES("302","wpseo_sitemap_16_cache_validator","3jmTh","no");
INSERT INTO `bak_options` VALUES("303","wpseo_sitemap_product-category_cache_validator","5HEM1","no");
INSERT INTO `bak_options` VALUES("304","wpseo_sitemap_product_cache_validator","5HELW","no");
INSERT INTO `bak_options` VALUES("310","widget_displaycategorieswidget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `bak_options` VALUES("319","wpseo_sitemap_customize_changeset_cache_validator","o5Bw","no");
INSERT INTO `bak_options` VALUES("324","wpseo_sitemap_nhom-san-pham_cache_validator","5JCoa","no");
INSERT INTO `bak_options` VALUES("325","wpseo_sitemap_9_cache_validator","5Jwsa","no");
INSERT INTO `bak_options` VALUES("326","wpseo_sitemap_14_cache_validator","5Jvqj","no");
INSERT INTO `bak_options` VALUES("327","wpseo_sitemap_18_cache_validator","5Jvql","no");
INSERT INTO `bak_options` VALUES("332","nhom-san-pham_children","a:0:{}","yes");
INSERT INTO `bak_options` VALUES("333","wpseo_sitemap_brand_cache_validator","5HELY","no");
INSERT INTO `bak_options` VALUES("334","wpseo_taxonomy_meta","a:2:{s:16:\"product-category\";a:1:{i:9;a:2:{s:13:\"wpseo_linkdex\";s:1:\"9\";s:19:\"wpseo_content_score\";s:2:\"30\";}}s:5:\"brand\";a:1:{i:13;a:3:{s:10:\"wpseo_desc\";s:170:\"Thương hiệu bếp từ Arber của Ý nổi tiếng trên thị trường và hiện đang là dòng được rất nhiều khách hàng tin tưởng và sử dụng.\";s:13:\"wpseo_linkdex\";s:2:\"65\";s:19:\"wpseo_content_score\";s:2:\"30\";}}}","yes");
INSERT INTO `bak_options` VALUES("335","product-category_children","a:0:{}","yes");
INSERT INTO `bak_options` VALUES("337","wpseo_sitemap_author_cache_validator","5PZem","no");
INSERT INTO `bak_options` VALUES("675","wpseo_sitemap_attachment_cache_validator","5HE23","no");
INSERT INTO `bak_options` VALUES("709","wpseo_sitemap_21_cache_validator","egIo","no");
INSERT INTO `bak_options` VALUES("710","wpseo_sitemap_23_cache_validator","egIv","no");
INSERT INTO `bak_options` VALUES("711","wpseo_sitemap_25_cache_validator","egIx","no");
INSERT INTO `bak_options` VALUES("712","wpseo_sitemap_27_cache_validator","egIy","no");
INSERT INTO `bak_options` VALUES("713","wpseo_sitemap_29_cache_validator","egIA","no");
INSERT INTO `bak_options` VALUES("714","wpseo_sitemap_qna_cache_validator","2friO","no");
INSERT INTO `bak_options` VALUES("787","wpseo_sitemap_wp-types-group_cache_validator","2iD4H","no");
INSERT INTO `bak_options` VALUES("792","wpcf7","a:2:{s:7:\"version\";s:5:\"5.0.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1523517460;s:7:\"version\";s:5:\"5.0.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}","yes");
INSERT INTO `bak_options` VALUES("793","wpseo_sitemap_wpcf7_contact_form_cache_validator","2XafP","no");
INSERT INTO `bak_options` VALUES("800","wpseo_sitemap_41_cache_validator","3jmTk","no");
INSERT INTO `bak_options` VALUES("807","wpdb_term_taxonomy_version","201510280002","yes");
INSERT INTO `bak_options` VALUES("852","_site_transient_timeout_browser_cffcb8140921e0d14b31935178051df3","1524756574","no");
INSERT INTO `bak_options` VALUES("853","_site_transient_browser_cffcb8140921e0d14b31935178051df3","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"65.0.3325.181\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `bak_options` VALUES("870","_site_transient_timeout_available_translations","1524163260","no");
INSERT INTO `bak_options` VALUES("871","_site_transient_available_translations","a:113:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-01 13:40:41\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-27 09:27:02\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-10 13:42:43\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.1/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 09:53:15\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-03-21 07:56:41\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-29 05:52:09\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-10 17:55:47\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-22 16:19:20\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-07 17:05:51\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-28 20:27:48\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.1/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-28 20:27:03\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-22 15:38:30\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-22 15:43:53\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.9.1/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-06 10:31:42\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-04 09:10:37\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 14:51:39\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 09:54:30\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-23 18:53:44\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-04 09:12:07\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-14 01:23:37\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 15:03:42\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-16 03:15:17\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-07-30 16:09:17\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-07-31 15:12:02\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-01 17:54:52\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-28 20:09:49\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 23:17:08\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-18 11:09:35\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-19 14:11:29\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-03-28 20:50:01\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 09:48:14\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-02 12:37:17\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-09 09:23:29\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-19 23:55:33\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-16 10:40:05\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-16 11:06:53\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-06 13:23:01\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-02 23:26:33\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-14 13:03:07\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-14 10:14:07\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-21 02:45:34\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-04-13 13:55:54\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-08 14:46:48\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-17 09:56:44\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-14 11:47:57\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-07 12:32:16\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-09 14:06:54\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.1/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-03-12 05:03:49\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-04 01:44:20\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:25\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 19:40:23\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-03-17 20:40:40\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.7/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-09 00:51:20\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-17 19:14:57\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-03-02 11:28:24\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-22 08:05:07\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-06 06:13:30\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-22 08:13:09\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.1/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-20 23:16:23\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-28 19:24:26\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-18 12:10:14\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/4.9.1/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-19 23:04:20\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-01 14:17:04\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-04 18:30:47\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-15 20:59:00\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-08 12:38:03\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-30 17:20:03\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 23:19:48\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2018-01-08 22:15:45\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-03-02 17:08:46\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-20 16:20:13\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-05 09:23:39\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-11-02 17:05:02\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-07 09:26:23\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-28 12:41:50\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 10:43:28\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-09 02:29:44\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-17 22:20:52\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-02 09:46:12\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","no");
INSERT INTO `bak_options` VALUES("873","_site_transient_timeout_theme_roots","1524198549","no");
INSERT INTO `bak_options` VALUES("874","_site_transient_theme_roots","a:5:{s:3:\"bak\";s:7:\"/themes\";s:5:\"thsnh\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}","no");
INSERT INTO `bak_options` VALUES("876","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1524196755;s:7:\"checked\";a:5:{s:3:\"bak\";s:5:\"1.4.3\";s:5:\"thsnh\";s:0:\"\";s:13:\"twentyfifteen\";s:3:\"1.9\";s:15:\"twentyseventeen\";s:3:\"1.4\";s:13:\"twentysixteen\";s:3:\"1.4\";}s:8:\"response\";a:1:{s:15:\"twentyseventeen\";a:4:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"1.5\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.1.5.zip\";}}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `bak_options` VALUES("877","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1524196878;s:7:\"checked\";a:7:{s:19:\"akismet/akismet.php\";s:5:\"4.0.1\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.3.2\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.0.1\";s:9:\"hello.php\";s:3:\"1.6\";s:14:\"types/wpcf.php\";s:6:\"2.2.21\";s:31:\"wp-term-order/wp-term-order.php\";s:5:\"0.1.4\";s:24:\"wordpress-seo/wp-seo.php\";s:5:\"3.7.1\";}s:8:\"response\";a:3:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.0.3\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.0.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.5\";s:12:\"requires_php\";N;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:14:\"types/wpcf.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:19:\"w.org/plugins/types\";s:4:\"slug\";s:5:\"types\";s:6:\"plugin\";s:14:\"types/wpcf.php\";s:11:\"new_version\";s:6:\"2.2.23\";s:3:\"url\";s:36:\"https://wordpress.org/plugins/types/\";s:7:\"package\";s:55:\"https://downloads.wordpress.org/plugin/types.2.2.23.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:58:\"https://ps.w.org/types/assets/icon-256x256.png?rev=1625832\";s:2:\"1x\";s:50:\"https://ps.w.org/types/assets/icon.svg?rev=1009056\";s:3:\"svg\";s:50:\"https://ps.w.org/types/assets/icon.svg?rev=1009056\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/types/assets/banner-1544x500.png?rev=1681816\";s:2:\"1x\";s:60:\"https://ps.w.org/types/assets/banner-772x250.png?rev=1681816\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.5\";s:12:\"requires_php\";N;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:3:\"7.3\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wordpress-seo.7.3.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1859687\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1859687\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}s:6:\"tested\";s:5:\"4.9.5\";s:12:\"requires_php\";N;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.3.2\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1232826\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.0.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.0.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";s:2:\"1x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"wp-term-order/wp-term-order.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wp-term-order\";s:4:\"slug\";s:13:\"wp-term-order\";s:6:\"plugin\";s:31:\"wp-term-order/wp-term-order.php\";s:11:\"new_version\";s:5:\"0.1.4\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wp-term-order/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/wp-term-order.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/wp-term-order/assets/icon-256x256.png?rev=1267653\";s:2:\"1x\";s:66:\"https://ps.w.org/wp-term-order/assets/icon-128x128.png?rev=1267653\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wp-term-order/assets/banner-1544x500.png?rev=1220225\";s:2:\"1x\";s:68:\"https://ps.w.org/wp-term-order/assets/banner-772x250.png?rev=1220336\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `bak_options` VALUES("878","_transient_timeout_wpseo-dashboard-totals","1524283156","no");
INSERT INTO `bak_options` VALUES("879","_transient_wpseo-dashboard-totals","a:1:{i:1;a:0:{}}","no");
INSERT INTO `bak_options` VALUES("880","_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e","1524239958","no");
INSERT INTO `bak_options` VALUES("881","_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e","a:2:{s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:0:{}}","no");
INSERT INTO `bak_options` VALUES("882","_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","1524239960","no");
INSERT INTO `bak_options` VALUES("883","_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"
	Thu, 12 Apr 2018 20:12:01 +0000	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.0-alpha-42993\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"GDPR Compliance Tools in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2018/04/gdpr-compliance-tools-in-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Apr 2018 20:11:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5728\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:188:\"GDPR compliance is an important consideration for all WordPress websites. The GDPR Compliance team is looking for help to test the privacy tools that are currently being developed in core.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3914:\"<p>GDPR compliance is an important consideration for all WordPress websites. The GDPR Compliance team is looking for help to test the privacy tools that are currently being developed in core. </p>

<h2>What is GDPR?</h2>

<p>GDPR stands for <a href=\"https://en.wikipedia.org/wiki/General_Data_Protection_Regulation\">General Data Protection Regulation</a> and is intended to strengthen and unify data protection for all individuals within the European Union. Its primary aim is to give control back to the EU residents over their personal data. <br /></p>

<p>Why the urgency? Although the GDPR was introduced two years ago, it becomes  enforceable starting May 25, 2018.</p>

<h2>Make WordPress GDPR Compliance Team</h2>

<p>Currently, the GDPR Compliance Team understands that helping WordPress-based sites become compliant is a large and ongoing task. The team is focusing on creating a comprehensive core policy, plugin guidelines, privacy tools and documentation. All of this requires your help.<br /></p>

<p>The GDPR Compliance Team is focusing on four main areas:</p>

<ul>
    <li>Add functionality to assist site owners in creating comprehensive privacy policies for their websites.</li>
    <li>Create guidelines for plugins to become GDPR ready.</li>
    <li>Add administration tools to facilitate compliance and encourage user privacy in general.</li>
    <li>Add documentation to educate site owners on privacy, the main GDPR compliance requirements, and on how to use the new privacy tools.</li>
</ul>

<h2>Don’t we already have a privacy policy?</h2>

<p>Yes and no. That said, The GDPR puts tighter guidelines and restrictions. Though we have many plugins that create privacy pages, we need means to generate a unified, comprehensive privacy policy. We will need tools for users to easily come into compliance.<br /></p>

<p>Site owners will be able to create GDPR compliant privacy policy in three steps:</p>

<ol>
    <li>Adding a dedicated page for the policy.<br /></li>
    <li>Adding privacy information from plugins.</li>
    <li>Reviewing and publishing the policy.</li>
</ol>

<p>A new &#8220;postbox&#8221; will be added to the Edit Page screen when editing the policy. All plugins that collect or store user data will be able to add privacy information there. In addition it will alert the site owners when any privacy information changes after a plugin is activated, deactivated, or updated.<br /></p>

<p>There is a new functionality to confirm user requests by email address. It is intended for site owners to be able to verify requests from users for displaying, downloading, or anonymizing of personal data.<br /></p>

<p>A new &#8220;Privacy&#8221; page is added under the &#8220;Tools&#8221; menu. It will display new, confirmed requests from users, as well as already fulfilled requests. It will also contain the tools for exporting and anonymizing of personal data and for requesting email confirmation to avoid abuse attempts.<br /></p>

<p>New section on privacy will be added to the <a href=\"https://developer.wordpress.org/plugins/\">Plugin Handbook</a>. It will contain some general information on user privacy, what a plugin should do to be compliant, and also tips and examples on how to use the new privacy related functionality in WordPress.<br /></p>

<p>The new privacy tools are scheduled for release at the end of April or beginning of May 2018.</p>

<h2>How can you get involved?</h2>

<p>We would love to have your help. The first step is awareness and education. For more information about the upcoming privacy tools see ﻿<a href=\"https://make.wordpress.org/core/2018/03/28/roadmap-tools-for-gdpr-compliance/\">the roadmap</a>.</p>

<p>If you would like to get involved in building WordPress Core and testing the new privacy tools, please join the #gdpr-compliance channel in the <a href=\"https://make.wordpress.org/chat/\">Make WordPress</a> Slack group.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5728\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.9.5 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2018/04/wordpress-4-9-5-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Apr 2018 19:56:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:3:\"4.9\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5645\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:376:\"WordPress 4.9.5 is now available. This is a security and maintenance release for all versions since WordPress 3.7. We strongly encourage you to update your sites immediately. WordPress versions 4.9.4 and earlier are affected by three security issues. As part of the core team&#x27;s ongoing commitment to security hardening, the following fixes have been implemented [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Aaron D. Campbell\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6347:\"<p>WordPress 4.9.5 is now available. This is a <strong>security and maintenance release</strong> for all versions since WordPress 3.7. We strongly encourage you to update your sites immediately.</p>

<p>WordPress versions 4.9.4 and earlier are affected by three security issues. As part of the core team&#x27;s ongoing commitment to security hardening, the following fixes have been implemented in 4.9.5:</p>

<ol>
    <li>Don&#x27;t treat <code>localhost</code> as same host by default.</li>
    <li>Use safe redirects when redirecting the login page if SSL is forced.</li>
    <li>Make sure the version string is correctly escaped for use in generator tags.</li>
</ol>

<p>Thank you to the reporters of these issues for practicing <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">﻿coordinated security disclosure</a>: <a href=\"https://profiles.wordpress.org/xknown\">xknown</a> of the WordPress Security Team, <a href=\"https://hackerone.com/nitstorm\">Nitin Venkatesh (nitstorm)</a>, and <a href=\"https://twitter.com/voldemortensen\">Garth Mortensen</a> of the WordPress Security Team.</p>

<p>Twenty-five other bugs were fixed in WordPress 4.9.5. Particularly of note were:</p>

<ul>
    <li>The previous styles on caption shortcodes have been restored.</li>
    <li>Cropping on touch screen devices is now supported.</li>
    <li>A variety of strings such as error messages have been updated for better clarity.</li>
    <li>The position of an attachment placeholder during uploads has been fixed.</li>
    <li>Custom nonce functionality in the REST API JavaScript client has been made consistent throughout the code base.</li>
    <li>Improved compatibility with PHP 7.2.</li>
</ul>

<p><a href=\"https://make.wordpress.org/core/2018/04/03/wordpress-4-9-5/\">This post has more information about all of the issues fixed in 4.9.5 if you&#x27;d like to learn more</a>.</p>

<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.9.5</a> or venture over to Dashboard → Updates and click &quot;Update Now.&quot; Sites that support automatic background updates are already beginning to update automatically.</p>

<p>Thank you to everyone who contributed to WordPress 4.9.5:</p>

<p><a href=\"https://profiles.wordpress.org/1265578519-1/\">1265578519</a>, <a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/schlessera/\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/alexgso/\">alexgso</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andrei0x309/\">andrei0x309</a>, <a href=\"https://profiles.wordpress.org/antipole/\">antipole</a>, <a href=\"https://profiles.wordpress.org/aranwer104/\">Anwer AR</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/blair-jersyer/\">Blair jersyer</a>, <a href=\"https://profiles.wordpress.org/bandonrandon/\">Brooke.</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/codegrau/\">codegrau</a>, <a href=\"https://profiles.wordpress.org/conner_bw/\">conner_bw</a>, <a href=\"https://profiles.wordpress.org/davidakennedy/\">David A. Kennedy</a>, <a href=\"https://profiles.wordpress.org/designsimply/\">designsimply</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling (ocean90)</a>, <a href=\"https://profiles.wordpress.org/electricfeet/\">ElectricFeet</a>, <a href=\"https://profiles.wordpress.org/ericmeyer/\">ericmeyer</a>, <a href=\"https://profiles.wordpress.org/fpcsjames/\">FPCSJames</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/soulseekah/\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/henrywright/\">Henry Wright</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jbpaul17/\">Jeffrey Paul</a>, <a href=\"https://profiles.wordpress.org/jipmoors/\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/joemcgill/\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnpgreen/\">johnpgreen</a>, <a href=\"https://profiles.wordpress.org/junaidkbr/\">Junaid Ahmed</a>, <a href=\"https://profiles.wordpress.org/kristastevens/\">kristastevens</a>, <a href=\"https://profiles.wordpress.org/obenland/\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/lakenh/\">Laken Hafner</a>, <a href=\"https://profiles.wordpress.org/lancewillett/\">Lance Willett</a>, <a href=\"https://profiles.wordpress.org/leemon/\">leemon</a>, <a href=\"https://profiles.wordpress.org/melchoyce/\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/mikeschroder/\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mrmadhat/\">mrmadhat</a>, <a href=\"https://profiles.wordpress.org/nandorsky/\">nandorsky</a>, <a href=\"https://profiles.wordpress.org/jainnidhi/\">Nidhi Jain</a>, <a href=\"https://profiles.wordpress.org/swissspidy/\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/qcmiao/\">qcmiao</a>, <a href=\"https://profiles.wordpress.org/rachelbaker/\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/larrach/\">Rachel Peter</a>, <a href=\"https://profiles.wordpress.org/ravanh/\">RavanH</a>, <a href=\"https://profiles.wordpress.org/otto42/\">Samuel Wood (Otto)</a>, <a href=\"https://profiles.wordpress.org/sebastienthivinfocom/\">Sebastien SERRE</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shital-patel/\">Shital Marakana</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/thomas-vitale/\">Thomas Vitale</a>, <a href=\"https://profiles.wordpress.org/kwonye/\">Will Kwon</a>, and <a href=\"https://profiles.wordpress.org/yahil/\">Yahil Madakiya</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5645\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"The Month in WordPress: March 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2018/04/the-month-in-wordpress-march-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Apr 2018 08:00:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5632\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:317:\"With a significant new milestone and some great improvements to WordPress as a platform, this month has been an important one for the project. Read on to find out more about what happened during the month of March. WordPress Now Powers 30% of the Internet Over the last 15 years, the popularity and usage of [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4328:\"<p>With a significant new milestone and some great improvements to WordPress as a platform, this month has been an important one for the project. Read on to find out more about what happened during the month of March.

</p>

<hr class=\"wp-block-separator\" />

<h2>WordPress Now Powers 30% of the Internet</h2>

<p>Over the last 15 years, the popularity and usage of WordPress has been steadily growing. That growth hit a significant milestone this month when <a href=\"https://w3techs.com/technologies/details/cm-wordpress/all/all\">W3Techs reported that WordPress now powers over 30% of sites on the web.</a></p>

<p>The percentage is determined based on W3Techs’ review of the top 10 million sites on the web, and it’s a strong indicator of the popularity and flexibility of WordPress as a platform.</p>

<p>If you would like to have hand in helping to grow WordPress even further, <a href=\"https://make.wordpress.org/\">you can get involved today</a>.</p>

<h2>WordPress Jargon Glossary Goes Live</h2>

<p>The WordPress Marketing Team has been hard at work lately putting together <a href=\"https://make.wordpress.org/marketing/2018/02/28/wordpress-jargon-glossary/\">a comprehensive glossary of WordPress jargon</a> to help newcomers to the project become more easily acquainted with things.</p>

<p>The glossary <a href=\"https://make.wordpress.org/marketing/2018/02/28/wordpress-jargon-glossary/\">is available here</a> along with a downloadable PDF to make it simpler to reference offline.</p>

<p>Publishing this resource is part of an overall effort to make WordPress more easily accessible for people who are not so familiar with the project. If you would like to assist the Marketing Team with this, you can follow <a href=\"https://make.wordpress.org/marketing/\">the team blog</a> and join the #marketing channel in the<a href=\"https://make.wordpress.org/chat/\"> Making WordPress Slack group</a>.</p>

<h2>Focusing on Privacy in WordPress</h2>

<p>Online privacy has been in the news this month for all the wrong reasons. It has reinforced the commitment of the GDPR Compliance Team to continue working on enhancements to WordPress core that allow site owners to improve privacy standards.</p>

<p>The team&#x27;s work, and the wider privacy project, spans four areas: Adding tools which will allow site administrators to collect the information they need about their sites, examining the plugin guidelines with privacy in mind, enhancing privacy standards in WordPress core, and creating documentation focused on best practices in online privacy.</p>

<p>To get involved with the project, you can <a href=\"https://make.wordpress.org/core/2018/03/28/roadmap-tools-for-gdpr-compliance/\">view the roadmap</a>, <a href=\"https://make.wordpress.org/core/tag/gdpr-compliance/\">follow the updates</a>, <a href=\"https://core.trac.wordpress.org/query?status=!closed&amp;keywords=~gdpr\">submit patches</a>, and join the #gdpr-compliance channel in the <a href=\"https://make.wordpress.org/chat\">Making WordPress Slack group</a>. Office hours are 15:00 UTC on Wednesdays.</p>

<hr class=\"wp-block-separator\" />

<h2>Further Reading:</h2>

<ul>
    <li>The WordPress Foundation has published <a href=\"https://wordpressfoundation.org/2017-annual-report/\">their annual report for 2017</a> showing just how much the community has grown over the last year.</li>
    <li>The dates for WordCamp US <a href=\"https://2018.us.wordcamp.org/2018/03/13/announcing-wordcamp-us-2018/\">have been announced</a> — this flagship WordCamp event will be held on 7-9 December this year in Nashville, Tennessee.</li>
    <li>WordPress 4.9.5 is due for release on April 3 — <a href=\"https://make.wordpress.org/core/2018/03/21/wordpress-4-9-5-beta/\">find out more here</a>.</li>
    <li>Version 2.5 of Gutenberg, the new editor for WordPress core, <a href=\"https://make.wordpress.org/core/2018/03/29/whats-new-in-gutenberg-29th-march/\">was released this month</a> with a host of great improvements.</li>
    <li>WordSesh, a virtual WordPress conference, <a href=\"http://wordsesh.com/\">is returning in July this year</a>.</li>
</ul>

<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please <a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\">submit it here</a>.</em><br /></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5632\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"The Month in WordPress: February 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2018/03/the-month-in-wordpress-february-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Mar 2018 08:41:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5613\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:324:\"Judging by the flurry of activity across the WordPress project throughout February, it looks like everyone is really getting into the swing of things for 2018. There have been a lot of interesting new developments, so read on to see what the community has been up to for the past month. WordPress 4.9.3 &#38; 4.9.4 [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5936:\"<p>Judging by the flurry of activity across the WordPress project throughout February, it looks like everyone is really getting into the swing of things for 2018. There have been a lot of interesting new developments, so read on to see what the community has been up to for the past month.</p>

<hr class=\"wp-block-separator\" />

<h2>WordPress 4.9.3 &amp; 4.9.4</h2>

<p>Early in the month, <a href=\"https://wordpress.org/news/2018/02/wordpress-4-9-3-maintenance-release/\">version 4.9.3 of WordPress was released</a>, including a number of important bug fixes. Unfortunately it introduced a bug that prevented many sites from automatically updating to future releases. To remedy this issue, <a href=\"https://wordpress.org/news/2018/02/wordpress-4-9-4-maintenance-release/\">version 4.9.4 was released</a> the following day requiring many people to manually update their sites.</p>

<p>While this kind of issue is always regrettable, the good thing is that it was fixed quickly, and that not all sites had updated to 4.9.3 yet, which meant they bypassed the bug in that version.</p>

<p>You can find out more technical information about this issue <a href=\"https://make.wordpress.org/core/2018/02/06/wordpress-4-9-4-release-the-technical-details/\">on the Core development blog</a>.</p>

<h2>The WordCamp Incubator is Back</h2>

<p>In 2016, the Global Community Team ran an experimental program to help spread WordPress to underserved areas by providing more significant organizing support for their first WordCamp event. This program was dubbed the WordCamp Incubator, and it was so successful in the three cities where it ran that <a href=\"https://wordpress.org/news/2018/02/wordcamp-incubator-2-0/\">the program is back for 2018</a>.</p>

<p>Right now, the Community Team is looking for cities to be a part of this year’s incubator by <a href=\"https://wordcampcentral.polldaddy.com/s/wordcamp-incubator-program-2018-city-application\">taking applications</a>. Additionally, each incubator community will need an experienced WordCamp organizer to assist them as a co-lead organizer for their event — if that sounds interesting to you, then you can <a href=\"https://wordcampcentral.polldaddy.com/s/wordcamp-incubator-program-2018-co-lead-application\">fill in the application form for co-leads</a>.</p>

<p>You can find out further information about the WordCamp Incubator <a href=\"https://make.wordpress.org/community/2018/02/19/wordcamp-incubator-program-2018-announcement/\">on the Community Team blog</a>.</p>

<h2>WordPress Meetup Roundtables scheduled for March</h2>

<p>In order to assist local WordPress meetup organizers with running their meetup groups, some members of the Community Team have organized <a href=\"https://make.wordpress.org/community/2018/02/23/wordpress-meetup-roundtables-scheduled-for-march/\">weekly meetup roundtable discussions through the month of March</a>.</p>

<p>These will be run as video chats at 16:00 UTC every Wednesday this month and will be a great place for meetup organizers to come together and help each other out with practical ideas and advice.</p>

<p>If you are not already in the WordPress meetup program and would like to join, you can find out more information in <a href=\"https://make.wordpress.org/community/handbook/meetup-organizer/welcome/\">the WordPress Meetup Organizer Handbook</a>.</p>

<h2>GDPR Compliance in WordPress Core</h2>

<p>The General Data Protection Regulation (GDPR) is an upcoming regulation that will affect all online services across Europe. In order to prepare for this, a working group has been formed to make sure that WordPress is compliant with the GDPR regulations.</p>

<p>Aside from the fact that this will be a requirement for the project going forward, it will also have an important and significant impact on the privacy and security of WordPress as a whole. The working group has posted <a href=\"https://make.wordpress.org/core/2018/02/19/proposed-roadmap-tools-for-gdpr-compliance/\">their proposed roadmap</a> for this project and it looks very promising.</p>

<p>To get involved in building WordPress Core, jump into the #gdpr-compliance channel in the <a href=\"https://make.wordpress.org/chat/\">Making WordPress Slack group</a>, and follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>.</p>

<hr class=\"wp-block-separator\" />

<h2>Further Reading:</h2>

<ul>
    <li>WPShout published <a href=\"https://wpshout.com/complete-guide-wordpress-security/\">a thorough guide to WordPress security</a>.</li>
    <li>The Community Team has published interesting statistics from the WordCamp program in <a href=\"https://make.wordpress.org/community/2018/02/27/wordcamps-in-2016/\">2016</a> and <a href=\"https://make.wordpress.org/community/2018/02/28/wordcamps-in-2017/\">2017</a>.</li>
    <li><a href=\"https://make.wordpress.org/community/2018/02/15/potential-addition-of-a-new-onboarding-team/\">An intriguing proposal has been made</a> for a new ‘Onboarding’ team to be started in the WordPress project.</li>
    <li>The new editing experience for WordPress, named Gutenberg, continues to be actively developed with <a href=\"https://make.wordpress.org/core/2018/02/16/whats-new-in-gutenberg-16th-february/\">a feature-packed release</a> this past month.</li>
    <li>The Advanced WordPress Facebook group <a href=\"https://www.youtube.com/watch?v=4vS_jR5-nIo\">held an interview with WordPress co-founder, Matt Mullenweg</a> about the Gutenberg project.</li>
    <li><a href=\"https://make.wordpress.org/meta/2018/02/27/two-factor-authentication-on-wp-org/\">Two factor authentication is on its way to the WordPress.org network</a> — this will be a great improvement to the overall security of the project.</li>
</ul>

<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please <a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\">submit it here</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5613\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
				
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"WordCamp Incubator 2.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wordpress.org/news/2018/02/wordcamp-incubator-2-0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Feb 2018 22:53:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:9:\"Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"Events\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5577\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:343:\"WordCamps are informal, community-organized events that are put together by a team of local WordPress users who have a passion for growing their communities. They are born out of active WordPress meetup groups that meet regularly and are able to host an annual WordCamp event. This has worked very well in many communities, with over [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2450:\"<p><a href=\"https://central.wordcamp.org/\">WordCamps</a> are informal, community-organized events that are put together by a team of local WordPress users who have a passion for growing their communities. They are born out of active WordPress meetup groups that meet regularly and are able to host an annual WordCamp event. This has worked very well in many communities, with over 120 WordCamps being hosted around the world in 2017.<br /></p>

<p>Sometimes though, passionate and enthusiastic community members can’t pull together enough people in their community to make a WordCamp happen. To address this, we introduced <a href=\"https://wordpress.org/news/2016/02/experiment-wordcamp-incubator/\">the WordCamp Incubator program</a> in 2016.<br /></p>

<p>The goal of the incubator program is <strong>to help spread WordPress to underserved areas by providing more significant organizing support for their first WordCamp event.</strong> In 2016, members of <a href=\"https://make.wordpress.org/community/\">the global community team</a> worked with volunteers in three cities — Denpasar, Harare and Medellín — giving direct, hands-on assistance in making local WordCamps possible. All three of these WordCamp incubators <a href=\"https://make.wordpress.org/community/2017/06/30/wordcamp-incubator-report/\">were a great success</a>, so we&#x27;re bringing the incubator program back for 2018.<br /></p>

<p>Where should the next WordCamp incubators be? If you have always wanted a WordCamp in your city but haven’t been able to get a community started, this is a great opportunity. We will be taking applications for the next few weeks, then will get in touch with everyone who applied to discuss the possibilities. We will announce the chosen cities by the end of March.<br /></p>

<p><strong>To apply, </strong><a href=\"https://wordcampcentral.polldaddy.com/s/wordcamp-incubator-program-2018-city-application\"><strong>fill in the application</strong></a><strong> by March 15, 2018.</strong> You don’t need to have any specific information handy, it’s just a form to let us know you’re interested. You can apply to nominate your city even if you don’t want to be the main organizer, but for this to work well we will need local liaisons and volunteers, so please only nominate cities where you live or work so that we have at least one local connection to begin.<br /></p>

<p>We&#x27;re looking forward to hearing from you!<br /></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5577\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 4.9.4 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2018/02/wordpress-4-9-4-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Feb 2018 16:17:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:3:\"4.9\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5559\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:350:\"WordPress 4.9.4 is now available. This maintenance release fixes a severe bug in 4.9.3, which will cause sites that support automatic background updates to fail to update automatically, and will require action from you (or your host) for it to be updated to 4.9.4. Four years ago with WordPress 3.7 &#8220;Basie&#8221;, we added the ability [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Dion Hulse\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1823:\"<p>WordPress 4.9.4 is now available.</p>
<p>This maintenance release fixes a severe bug in 4.9.3, which will cause sites that support automatic background updates to fail to update automatically, and will require action from you (or your host) for it to be updated to 4.9.4.</p>
<p>Four years ago with <a href=\"https://wordpress.org/news/2013/10/basie/\">WordPress 3.7 &#8220;Basie&#8221;</a>, we added the ability for WordPress to self-update, keeping your website secure and bug-free, even when you weren&#8217;t available to do it yourself. For four years it&#8217;s helped keep millions of installs updated with very few issues over that time. Unfortunately <a href=\"https://wordpress.org/news/2018/02/wordpress-4-9-3-maintenance-release/\">yesterdays 4.9.3 release</a> contained a severe bug which was only discovered after release. The bug will cause WordPress to encounter an error when it attempts to update itself to WordPress 4.9.4, and will require an update to be performed through the WordPress dashboard or hosts update tools.</p>
<p>WordPress managed hosting companies who install updates automatically for their customers can install the update as normal, and we&#8217;ll be working with other hosts to ensure that as many customers of theirs who can be automatically updated to WordPress 4.9.4 can be.</p>
<p>For more technical details of the issue, we&#8217;ve <a href=\"https://make.wordpress.org/core/2018/02/06/wordpress-4-9-4-release-the-technical-details/\">posted on our Core Development blog</a>. For a full list of changes, consult the <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=4.9.4&amp;group=component\">list of tickets</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.9.4</a> or visit Dashboard → Updates and click “Update Now.”</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5559\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 4.9.3 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2018/02/wordpress-4-9-3-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Feb 2018 19:47:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5545\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:372:\"WordPress 4.9.3 is now available. This maintenance release fixes 34 bugs in 4.9, including fixes for Customizer changesets, widgets, visual editor, and PHP 7.2 compatibility. For a full list of changes, consult the list of tickets and the changelog. Download WordPress 4.9.3 or visit Dashboard → Updates and click “Update Now.” Sites that support automatic [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Sergey Biryukov\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3421:\"<p>WordPress 4.9.3 is now available.</p>
<p>This maintenance release fixes 34 bugs in 4.9, including fixes for Customizer changesets, widgets, visual editor, and PHP 7.2 compatibility. For a full list of changes, consult the <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=4.9.3&amp;group=component\">list of tickets</a> and the <a href=\"https://core.trac.wordpress.org/log/branches/4.9?rev=42630&amp;stop_rev=42521\">changelog</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.9.3</a> or visit Dashboard → Updates and click “Update Now.” Sites that support automatic background updates are already beginning to update automatically.</p>
<p>Thank you to everyone who contributed to WordPress 4.9.3:</p>
<p><a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/abdullahramzan/\">abdullahramzan</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andreiglingeanu/\">andreiglingeanu</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/bpayton/\">Brandon Payton</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/coleh/\">coleh</a>, <a href=\"https://profiles.wordpress.org/darko-a7/\">Darko A7</a>, <a href=\"https://profiles.wordpress.org/desertsnowman/\">David Cramer</a>, <a href=\"https://profiles.wordpress.org/dlh/\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/flixos90/\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/frank-klein/\">Frank Klein</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jbpaul17/\">Jeffrey Paul</a>, <a href=\"https://profiles.wordpress.org/lizkarkoski/\">lizkarkoski</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/mattyrob/\">mattyrob</a>, <a href=\"https://profiles.wordpress.org/monikarao/\">Monika Rao</a>, <a href=\"https://profiles.wordpress.org/munyagu/\">munyagu</a>, <a href=\"https://profiles.wordpress.org/ndavison/\">ndavison</a>, <a href=\"https://profiles.wordpress.org/nickmomrik/\">Nick Momrik</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/rachelbaker/\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/rishishah/\">rishishah</a>, <a href=\"https://profiles.wordpress.org/othellobloke/\">Ryan Paul</a>, <a href=\"https://profiles.wordpress.org/sasiddiqui/\">Sami Ahmed Siddiqui</a>, <a href=\"https://profiles.wordpress.org/sayedwp/\">Sayed Taqui</a>, <a href=\"https://profiles.wordpress.org/seanchayes/\">Sean Hayes</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shooper/\">Shawn Hooper</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/manikmist09/\">Sultan Nasir Uddin</a>, <a href=\"https://profiles.wordpress.org/tigertech/\">tigertech</a>, and <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5545\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"The Month in WordPress: January 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2018/02/the-month-in-wordpress-january-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Feb 2018 08:10:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5541\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:339:\"Things got off to a gradual start in 2018 with momentum starting to pick up over the course of the month. There were some notable developments in January, including a new point release and work being done on other important areas of the WordPress project. WordPress 4.9.2 Security and Maintenance Release On January 16, WordPress [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3840:\"<p>Things got off to a gradual start in 2018 with momentum starting to pick up over the course of the month. There were some notable developments in January, including a new point release and work being done on other important areas of the WordPress project.</p>

<hr class=\"wp-block-separator\" />

<h2>WordPress 4.9.2 Security and Maintenance Release</h2>

<p>On January 16, <a href=\"https://wordpress.org/news/2018/01/wordpress-4-9-2-security-and-maintenance-release/\">WordPress 4.9.2 was released</a> to fix an important security issue with the media player, as well as a number of other smaller bugs. This release goes a long way to smoothing out the 4.9 release cycle with the next point release, v4.9.3, <a href=\"https://make.wordpress.org/core/2018/01/31/wordpress-4-9-3-release-pushed-to-february-5th/\">due in early February</a>.</p>

<p>To get involved in building WordPress Core, jump into the #core channel in the<a href=\"https://make.wordpress.org/chat/\"> Making WordPress Slack group</a>, and follow<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>.</p>

<h2>Updated Plugin Directory Guidelines</h2>

<p>At the end of 2017, <a href=\"https://developer.wordpress.org/plugins/wordpress-org/detailed-plugin-guidelines/\">the guidelines for the Plugin Directory</a> received a significant update to make them clearer and expanded to address certain situations. This does not necessarily make these guidelines complete, but rather more user-friendly and practical; they govern how developers build plugins for the Plugin Directory, so they need to evolve with the global community that the Directory serves.</p>

<p>If you would like to contribute to these guidelines, you can make a pull request to <a href=\"https://github.com/WordPress/wporg-plugin-guidelines\">the GitHub repository</a> or email <a href=\"mailto:plugins@wordpress.org\">plugins@wordpress.org</a>. You can also jump into the #pluginreview channel in the<a href=\"https://make.wordpress.org/chat/\"> Making WordPress Slack group</a>.</p>

<hr class=\"wp-block-separator\" />

<h2>Further Reading:</h2>

<ul>
    <li>Near the end of last year a lot of work was put into improving the standards in the WordPress core codebase and now <a href=\"https://make.wordpress.org/core/2017/11/30/wordpress-php-now-mostly-conforms-to-wordpress-coding-standards/\">the entire platform is at nearly 100% compliance with the WordPress coding standards</a>.</li>
    <li>Gutenberg, the new editor coming to WordPress core in the next major release, <a href=\"https://make.wordpress.org/core/2018/01/25/whats-new-in-gutenberg-25th-january/\">was updated to v2.1 this month</a> with some great usability and technical improvements.</li>
    <li>The Global Community Team is <a href=\"https://make.wordpress.org/community/2018/01/16/2018-goals-for-the-global-community-team-suggestions-time/\">taking suggestions for the goals of the Community program in 2018</a>.</li>
    <li><a href=\"https://online.wpcampus.org/\">WPCampus Online</a>, a digital conference focused on WordPress in higher education, took place on January 30. The videos of the event sessions will be online soon.</li>
    <li>A WordPress community member <a href=\"https://wptavern.com/new-toolkit-simplifies-the-process-of-creating-gutenberg-blocks\">has released a toolkit</a> to help developers build blocks for Gutenberg.</li>
    <li>The community team that works to improve the WordPress hosting experience is relatively young, but <a href=\"https://make.wordpress.org/hosting/2018/01/25/hosting-meeting-notes-january-10-2018/\">they have been making some great progress recently</a>.</li>
</ul>

<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please <a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\">submit it here</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5541\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
				
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.9.2 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2018/01/wordpress-4-9-2-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 16 Jan 2018 23:00:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.9\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5376\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:360:\"WordPress 4.9.2 is now available. This is a security and maintenance release for all versions since WordPress 3.7﻿. We strongly encourage you to update your sites immediately. An XSS vulnerability was discovered in the Flash fallback files in MediaElement, a library that is included with WordPress. Because the Flash files are no longer needed for [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Ian Dunn\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3946:\"<p>WordPress 4.9.2 is now available. This is a <strong>security and maintenance release</strong> for all versions since WordPress 3.7﻿. We strongly encourage you to update your sites immediately.</p>

<p>An XSS vulnerability was discovered in the Flash fallback files in MediaElement, a library that is included with WordPress. Because the Flash files are no longer needed for most use cases, they have been removed from WordPress.</p>

<p>MediaElement has released a new version that contains a fix for the bug, and <a href=\"https://wordpress.org/plugins/mediaelement-flash-fallbacks/\">a WordPress plugin containing the fixed files</a> is available in the plugin repository.</p>

<p>Thank you to the reporters of this issue for practicing <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">responsible security disclosure</a>: <a href=\"https://opnsec.com\">Enguerran Gillier</a> and <a href=\"https://widiz.com/\">Widiz﻿</a>.</p>

<p>21 other bugs were fixed in WordPress 4.9.2. Particularly of note were:</p>

<ul>
    <li>JavaScript errors that prevented saving posts in Firefox have been fixed.</li>
    <li>The previous taxonomy-agnostic behavior of <code>get_category_link()</code> and <code>category_description()</code> was restored.</li>
    <li>Switching themes will now attempt to restore previous widget assignments, even when there are no sidebars to map.<br /></li>
</ul>

<p>The Codex has <a href=\"https://codex.wordpress.org/Version_4.9.2\">more information about all of the issues fixed in 4.9.2</a>, if you&#x27;d like to learn more.</p>

<p>﻿<a href=\"https://wordpress.org/download/\"></a><a href=\"https://wordpress.org/download/\">Download WordPress 4.9.2</a> or venture over to Dashboard → Updates and click &quot;Update Now.&quot; Sites that support automatic background updates are already beginning to update automatically.</p>

<p>Thank you to everyone who contributed to WordPress 4.9.2:</p>

<p><a href=\"https://profiles.wordpress.org/0x6f0/\">0x6f0</a>, <a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/blobfolio/\">Blobfolio</a>, <a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/icaleb/\">Caleb Burks</a>, <a href=\"https://profiles.wordpress.org/poena/\">Carolina Nymark</a>, <a href=\"https://profiles.wordpress.org/chasewg/\">chasewg</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/hardik-amipara/\">Hardik Amipara</a>, <a href=\"https://profiles.wordpress.org/ionvv/\">ionvv</a>, <a href=\"https://profiles.wordpress.org/jaswrks/\">Jason Caldwell</a>, <a href=\"https://profiles.wordpress.org/jbpaul17/\">Jeffrey Paul</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt/\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/joemcgill/\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/johnschulz/\">johnschulz</a>, <a href=\"https://profiles.wordpress.org/juiiee8487/\">Juhi Patel</a>, <a href=\"https://profiles.wordpress.org/obenland/\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/markjaquith/\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/rabmalin/\">Nilambar Sharma</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/rachelbaker/\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/rinkuyadav999/\">Rinku Y</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, and <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>.﻿<strong></strong><br /></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5376\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:33:\"
		
		
		
		
				

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"The Month in WordPress: December 2017\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2018/01/the-month-in-wordpress-december-2017/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 03 Jan 2018 10:00:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5424\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:311:\"Activity slowed down in December in the WordPress community, particularly in the last two weeks. However, the month started off with a big event and work pushed forward in a number of key areas of the project. Read on to find out more about what transpired in the WordPress community as 2017 came to a [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4711:\"<p>Activity slowed down in December in the WordPress community, particularly in the last two weeks. However, the month started off with a big event and work pushed forward in a number of key areas of the project. Read on to find out more about what transpired in the WordPress community as 2017 came to a close.</p>

<hr class=\"wp-block-separator\" />

<h2>WordCamp US 2017 Brings the Community Together</h2>

<p>The latest edition of <a href=\"https://2017.us.wordcamp.org/\">WordCamp US</a> took place last month in Nashville on December 1-3. The event brought together over 1,400 WordPress enthusiasts from around the world, fostering a deeper, more engaged global community.</p>

<p>While attending a WordCamp is always a unique experience, you can catch up on <a href=\"https://wordpress.tv/event/wordcamp-us-2017/\">the sessions on WordPress.tv</a> and look through <a href=\"https://www.facebook.com/pg/WordCampUSA/photos/?tab=albums\">the event photos on Facebook</a> to get a feel for how it all happened. Of course, <a href=\"https://wordpress.tv/2017/12/04/matt-mullenweg-state-of-the-word-2017/\">Matt Mullenweg’s State of the Word</a> talk is always one of the highlights at this event.</p>

<p>The next WordCamp US will be held in Nashville again in 2018, but if you would like to see it hosted in your city in 2019 and 2020, then <a href=\"https://make.wordpress.org/community/2017/12/19/apply-to-host-wordcamp-us-2019-2020/\">you have until February 2 to apply</a>.</p>

<h2>WordPress User Survey Data Is Published</h2>

<p>Over the last few years, tens of thousands of WordPress users all over the world have filled out the annual WordPress user survey. The results of that survey are used to improve the WordPress project, but that data has mostly remained private. This has changed now and <a href=\"https://wordpress.org/news/2017/12/wordpress-user-survey-data-for-2015-2017/\">the results from the last three surveys are now publicly available</a> for everyone to analyze.</p>

<p>The data will be useful to anyone involved in WordPress since it provides a detailed look at who uses WordPress and what they do with it — information that can help inform product development decisions across the board.</p>

<h2>New WordPress.org Team for the Tide Project</h2>

<p>As announced at WordCamp US, <a href=\"https://make.wordpress.org/tide/2017/12/02/new-home/\">the Tide project is being brought under the WordPress.org umbrella</a> to be managed and developed by the community.</p>

<p>Tide is a series of automated tests run against every plugin and theme in the directory to help WordPress users make informed decisions about the plugins and themes that they choose to install.</p>

<p>To get involved in developing Tide, jump into the #tide channel in the <a href=\"https://make.wordpress.org/chat/\">Making WordPress Slack group</a>, and follow <a href=\"https://make.wordpress.org/tide/\">the Tide team blog</a>.</p>

<hr class=\"wp-block-separator\" />

<h2>Further Reading:</h2>

<ul>
    <li>If you’re following the development of Gutenberg, or if you want a primer on where it’s headed, then <a href=\"https://wordpress.tv/2017/12/10/morten-rand-hendriksen-gutenberg-and-the-wordpress-of-tomorrow/\">Morten Rand-Hendriksen’s talk from WordCamp US</a> is a must watch.</li>
    <li>The annual surveys for WordPress <a href=\"https://wordpressdotorg.polldaddy.com/s/2017-annual-meetup-member-survey\">meetup members</a> and <a href=\"https://wordpressdotorg.polldaddy.com/s/2017-annual-meetup-organizer-survey\">meetup organizers</a> are available for people to fill out — if you’re involved in or attend your local meetup group then be sure to complete those.</li>
    <li>10up has <a href=\"https://distributorplugin.com/\">a brand new plugin in beta</a> that will assist with powerful and flexible content publishing and syndication across WordPress sites.</li>
    <li><a href=\"https://make.wordpress.org/community/2017/12/07/should-we-change-the-default-wordcamp-theme-to-campsite-2017/\">The Community Team is exploring a move</a> to make the recently developed CampSite theme the default theme for all new WordCamp websites. This is the theme that was developed and employed for <a href=\"https://2017.europe.wordcamp.org\">WordCamp Europe 2017</a>.</li>
    <li>The team working on the multisite features of WordPress Core has recently published <a href=\"https://make.wordpress.org/core/2017/12/19/multisite-roadmap-published/\">their planned roadmap for development</a>.</li>
</ul>

<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please <a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\">submit it here</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"5424\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:4:\"site\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"14607090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 20 Apr 2018 03:59:19 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Thu, 12 Apr 2018 20:12:01 GMT\";s:4:\"link\";s:63:\"<https://wordpress.org/news/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20180420035603\";}","no");
INSERT INTO `bak_options` VALUES("884","_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1524239960","no");
INSERT INTO `bak_options` VALUES("885","_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1524196760","no");
INSERT INTO `bak_options` VALUES("886","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1524239962","no");
INSERT INTO `bak_options` VALUES("887","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Gutenberg 2.7 Released, Adds Ability to Edit Permalinks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=80121\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wptavern.com/gutenberg-2-7-released-adds-ability-to-edit-permalinks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1977:\"<p>Gutenberg 2.7 <a href=\"https://wordpress.org/plugins/gutenberg/\">is available</a> for testing and not only does it refine the visuals around block controls, it adds the highly requested ability to <a href=\"https://github.com/WordPress/gutenberg/pull/5756\">edit permalinks</a>.</p>

<img />
    Editing Permalinks in Gutenberg 2.7


<p>A new pagination block is available that adds a page break, allowing users to break posts into multiple pages. The block is located in the <strong>Blocks &#8211; Layout Elements</strong> section.</p>

<p>There are a number of changes to the link insertion interface. Gutenberg 2.7 brings back the option to have links open in the same window.<br /></p>

<img />
    Toggle Determines Whether Links Open in a New Window


<p>When editing linked text, the Unlink icon now stays in the toolbar instead of displaying within the link options modal. When adding links, there&#8217;s a URL suggestion tool similar to what&#8217;s available in WordPress&#8217; current editor.</p>

<p>What will be welcomed news to plugin developers, the <a href=\"https://github.com/WordPress/gutenberg/pull/6031\">PluginSidebar API</a> is ﻿exposed and considered final. According to the pull request, this change does the following.</p>

<blockquote class=\"wp-block-quote\">
    <p>Refactors all the existing Sidebar components to share the same set components and removes duplicated custom CSS styles applied to <code>&lt;PluginSidebar /></code>. There are no changes to the public API of <code>&lt;PublicSidebar /></code> component, other than it is going to be available under <code>wp.editPost.PluginSidebar</code>.</p><cite>Grzegorz Ziółkowski<br /></cite></blockquote>

<p>This release, like the others before it, has a changelog that&#8217;s a mile long. Please check out the <a href=\"https://make.wordpress.org/core/2018/04/18/whats-new-in-gutenberg-18th-april/\">release post</a> for a detailed list of changes and links to issues on GitHub. <br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 20 Apr 2018 03:05:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: WordPress Accessibility Team Is Seeking Contributors for Its Handbook Project\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=80068\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"https://wptavern.com/wordpress-accessibility-team-is-seeking-contributors-for-its-handbook-project\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1210:\"<p>The <a href=\"https://make.wordpress.org/accessibility/\">WordPress Accessibility team</a> is seeking contributors for its <a href=\"https://make.wordpress.org/accessibility/handbook/\">handbook project</a>. It&#8217;s a collection of tips, resources, <a href=\"https://make.wordpress.org/accessibility/handbook/which-tools-can-i-use/\">tools</a>, and best practices. The goal is to educate users through summaries, articles, and reference materials.<br /></p>

<p>The handbook was created after the accessibility team repeatedly noticed the same accessibility issues cropping up and not having a central place to send people to learn about them.</p>

<p>The team is looking for people to review articles, discover resources to add to the handbook, and suggest topics to cover. If you&#8217;re interested in contributing, please join the #<a href=\"https://wordpress.slack.com/archives/C6PK2QCTY\">accessibility-docs</a> channel on <a href=\"https://make.wordpress.org/chat/\">Slack</a> where you can ask questions and learn more about the project.</p>

<p>Also, consider following <a href=\"https://twitter.com/WPAccessibility\">WPAccessibility</a> on Twitter to keep tabs on team projects and links to resources. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 20 Apr 2018 01:57:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WPTavern: BuddyPress 3.0 Beta 2 Released\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79984\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wptavern.com/buddypress-3-0-beta-2-released\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1844:\"<p>The BuddyPress development team <a href=\"https://buddypress.org/2018/04/buddypress-3-0-beta-1/\">has released</a> Beta 2 of BuddyPress 3.0. BuddyPress 3.0 is a major release that contains some significant changes. A new template pack called Nouveau will replace the bp-legacy template packs introduced in BuddyPress 1.7.</p>

<p>The new template pack has been refactored to be semantic, accessible, and use a new set of markup files. Loops, members, and activity areas now run under Backbone to provide a smoother experience. JavaScript has been rewritten to be more modular and have better structure. <br /></p>

<img />
    BuddyPress 3.0 Customizer Options


<p>BuddyPress 3.0 utilizes the Customizer by providing options to manipulate the Nouveau template pack or the site itself. For example, you can modify a user&#8217;s navigation options from the frontend. There&#8217;s also an option to adjust the number of columns for the Members loop. </p>

<p>There are <a href=\"https://buddypress.trac.wordpress.org/query?status=closed&milestone=3.0&page=2&col=id&col=summary&col=status&col=milestone&col=owner&col=type&col=priority&order=priority\">138 tickets closed</a> in this release. In addition to what&#8217;s noted above, 3.0 will <a href=\"https://buddypress.trac.wordpress.org/ticket/7722\">remove support for WordPress 4.3 and below</a> and BuddyPress functions for bbPress 1.x forums <a href=\"https://buddypress.trac.wordpress.org/ticket/6851\">will be deprecated</a>.</p>

<p>Considering the scope and breadth of changes in 3.0, users are highly encouraged to test <a href=\"https://buddypress.org/2018/04/buddypress-3-0-beta-1/\">BuddyPress 3.0 Beta 2</a>. If you encounter any issues, please report them in the <a href=\"https://buddypress.org/support/forum/how-to/\">Troubleshooting and How-to</a> section of the support forums. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 18 Apr 2018 22:55:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"HeroPress: Where WordPress REALLY Matters\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2509\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:127:\"https://heropress.com/where-wordpress-really-matters/#utm_source=rss&utm_medium=rss&utm_campaign=where-wordpress-really-matters\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3591:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2016/03/041818-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: The silence is there. But it no longer scares me.\" /><p>A couple years ago I was given possibly the biggest gift the WordPress community has ever given me. The organizers of WordCamp Pune called me to speak, and the community sent me. It was an amazing experience that changed my life.</p>
<p>While I was there I met Mahangu Weerasinghe, a wonderful man from Sri Lanka. He spoke about things that really really resonated with me. His talk was about linguistic accessibility to the Internet in Southeast Asia. Many people told me that English is enough to communicate to all of India, but Mahangu pointed out that MILLIONS of people in Southeast Asia cannot read or understand a single language on the web, let alone English.</p>
<p>WordPress can change that, and that&#8217;s where WordPress really matters.  It&#8217;s wonderful that people around the world can make a living with it, and it&#8217;s wonderful that it gives creative outlet to so many, but <strong>important</strong> that WordPress can give global voice to those who have none.</p>
<p>Mahangu felt for a long time that he had no voice. WordPress changed that for him, and now he&#8217;s using WordPress to change that for everyone.  He&#8217;s been hugely inspirational to me, and I hope he is for you as well.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/breaking-the-silence/\">Breaking the Silence</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Where WordPress REALLY Matters\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Where%20WordPress%20REALLY%20Matters&via=heropress&url=https%3A%2F%2Fheropress.com%2Fwhere-wordpress-really-matters%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Where WordPress REALLY Matters\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fwhere-wordpress-really-matters%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fwhere-wordpress-really-matters%2F&title=Where+WordPress+REALLY+Matters\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Where WordPress REALLY Matters\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/where-wordpress-really-matters/&media=https://heropress.com/wp-content/uploads/2016/03/041818-150x150.jpg&description=Where WordPress REALLY Matters\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Where WordPress REALLY Matters\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/where-wordpress-really-matters/\" title=\"Where WordPress REALLY Matters\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/where-wordpress-really-matters/\">Where WordPress REALLY Matters</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 18 Apr 2018 12:00:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Abstract Aluminum\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48051\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://ma.tt/2018/04/abstract-aluminum/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:346:\"<p>You probably haven&#8217;t thought much about beer cans, Abstract Aluminum Space, the Midwest Premium, and how it all ties into Goldman Sachs, so you should read <a href=\"https://www.bloomberg.com/view/articles/2014-09-03/the-goldman-sachs-aluminum-conspiracy-lawsuit-is-over\">how the Goldman Sachs aluminum conspiracy lawsuit is over</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 17 Apr 2018 21:57:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"BuddyPress: BuddyPress 3.0 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=272059\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://buddypress.org/2018/04/buddypress-3-0-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3509:\"<p>It&#8217;s with a huge amount of pleasure and excitement that we&#8217;re announcing the Beta 2 release of BP 3.0 today ready for testing and feedback.</p>
<p>BuddyPress 3.0 will be a major milestone release for us and one we&#8217;re all really excited about, it&#8217;s been a long time coming but finally we are close to releasing the first template pack for BP, this is a completely new &#8216;theme&#8217; or set of template files and functionality designed to replace bp-legacy which has served us so well since it&#8217;s inception way back in the  major release of 1.7 where we introduced &#8216;Theme Compatibility&#8217;, and we&#8217;re all really eager for any feedback during these beta phases you may grab a copy of our beta1 release <a href=\"https://downloads.wordpress.org/plugin/buddypress.3.0.0-beta1.zip\">here</a> to test with.</p>
<p>Nouveau &#8211; as our new template pack has been named &#8211; provides an all new clean set of markup files, refactored from the ground up to be semantic and accessible. Styles are re-written and provided as Sass partials for developers if wanting to build out new packs. A lot of core functionality for components has been re-written and re-located to be sourced from include files by component in the template directory which allows even easier access to modify functions by overloading to a new theme or child theme. Our major loops, members, activity etc have been re-factored to run under Backbone for a smooth Ajax experience and indeed all the Javascript functionality is re-written to be far more modular than it was before and has a far better modern feel to it&#8217;s structuring.</p>
<p>For the first time we have brought in the Customizer to provide user option choices and a range of layout configurations may be selected. In our initial offering we have provided various layout options for the main BP navigation elements  allowing for vertical navs or horizontal, tab effect where suitable. for the component loops such as members, Groups we provide an option to display in a grid layout &amp; at row quantity options or simply as a flat classic list layout.</p>
<p>While we are really excited about Nouveau 3.0 also has many other improvements to offer and you can <a href=\"https://buddypress.trac.wordpress.org/query?status=closed&milestone=3.0&col=id&col=summary&col=status&col=milestone&col=owner&col=type&col=priority&order=priority\">view a list of all closed tickets for 3.0</a></p>
<p>As always your feedback and testing is an invaluable part of our releases, helping us to catch any last minute bugs.<br />
You can download the beta release for testing at <a href=\"https://downloads.wordpress.org/plugin/buddypress.3.0.0-beta1.zip\">downloads.wordpress.org</a> and install on a local copy of WordPress ( please remember this is a beta release and should not be run on an active production site). Any issues found can be reported on our Trac by creating a <a href=\"https://buddypress.trac.wordpress.org/newticket\">new ticket</a></p>
<p>If you&#8217;re a developer comfortable with SVN you might like to checkout a development copy which you can do <a href=\"https://svn.buddypress.org/trunk\">from this link</a> patches can be submitted to existing tickets or issues found reported on a new ticket.</p>
<p>Further guidance on contributing to BuddyPress is covered on our <a href=\"https://codex.buddypress.org/participate-and-contribute/\">Contributor guidelines page</a> in our <a href=\"https://codex.buddypress.org/\">Codex</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 17 Apr 2018 20:30:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Hugo Ashmore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: Talking Gutenberg on Episode Eight of the Drunken UX Podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79942\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wptavern.com/talking-gutenberg-on-episode-eight-of-the-drunken-ux-podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:738:\"<p>Last week, I had the pleasure of joining Michael Fienen and Aaron Hill, hosts of the Drunken UX podcast, to <a href=\"https://drunkenux.com/podcast/8-sweet-home-automattic-where-we-use-gutenberg/\">discuss Gutenberg</a>. We covered a lot of topics, including, why Gutenberg was created, our experiences, its timeline, pros, cons, resources, our biggest concerns, and what developers and freelancers need to know.</p>

<p>The show is one hour and thirty minutes in length. By the way, please don&#8217;t criticize my drink of choice.</p>


    <blockquote class=\"wp-embedded-content\"><a href=\"https://drunkenux.com/podcast/8-sweet-home-automattic-where-we-use-gutenberg/\">#8: Sweet Home Automattic, Where We Use Gutenberg</a></blockquote>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 17 Apr 2018 00:14:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: Plugins Hosted on WordPress.org Can No Longer Guarantee Legal Compliance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79884\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"https://wptavern.com/plugins-hosted-on-wordpress-org-can-no-longer-guarantee-legal-compliance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2105:\"<p>The plugin review team has amended <a href=\"https://developer.wordpress.org/plugins/wordpress-org/detailed-plugin-guidelines/#9-developers-and-their-plugins-must-not-do-anything-illegal-dishonest-or-morally-offensive\">guideline number nine</a> which states, <em>developers and their plugins must not do anything illegal, dishonest, or morally offensive</em>, to include the following statement:</p>

<ul>
    <li>Implying that a plugin can create, provide, automate, or guarantee legal compliance</li>
</ul>

<p>Mika Epstein, a member of the WordPress.org plugin review team, <a href=\"https://make.wordpress.org/plugins/2018/04/12/legal-compliance-added-to-guidelines/\">says</a> the change was made because plugins by themselves can not provide legal compliance. <br /></p>

<blockquote class=\"wp-block-quote\">
    <p>Sadly, no plugin in and of itself can provide legal compliance. While a plugin can certainly <em>assist</em> in automating the steps on a compliance journey, or allow you to develop a workflow to solve the situation, they cannot protect a site administrator from mistakes or lack of compliance, nor can they protect site users from incorrect or incomplete legal compliance on the part of the web site.</p><cite>Mika Epstein</cite></blockquote>

<p>Since sites can have any combination of WordPress plugins and themes activated, it&#8217;s nearly impossible for a single plugin to make sure they&#8217;re 100% legally compliant.</p>

<p>Plugin developers affected by this change will be contacted by the review team and be asked to change their titles, descriptions, plugin header images, and or the text within the readme.</p>

<p>Instead of claiming compliance, the team has published a <a href=\"https://developer.wordpress.org/plugins/wordpress-org/compliance-disclaimers/\">frequently asked questions</a> document that recommends plugin authors explain how the plugin will assist in compliance. If you have any questions, please leave a comment on the <a href=\"https://make.wordpress.org/plugins/2018/04/12/legal-compliance-added-to-guidelines/\">announcement post</a>. </p>

<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 Apr 2018 23:35:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"Post Status: All about you(r privacy) — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=45249\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://poststatus.com/all-about-your-privacy-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2485:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p><span>In this episode, the two Brians discuss the current conversations and controversy surrounding data collection and visitor privacy on the web. The duo dig in to the General Data Protection Regulation (GDPR) and what it means for you both as site visitors and site owners and, in particular, how WordPress core and plugin authors are (or should be) responding to the new regulation. It’s a pretty deep topic with many implications and ramifications. Be sure to follow the episode links, too, so that you can be best informed and prepared for when GDPR goes into effect on May 25, 2018.</span></p>
<p></p>
<p>Links</p>
<ul>
<li><a href=\"https://www.cjr.org/tow_center_reports/understanding-general-data-protection-regulation.php\">CJR report on understanding the General Data Protection Regulation</a></li>
<li><a href=\"https://make.wordpress.org/core/2018/03/28/roadmap-tools-for-gdpr-compliance/\">Core&#8217;s roadmap for GDPR compliance</a></li>
<li><a href=\"https://core.trac.wordpress.org/query?status=!closed&keywords=~gdpr\">Trac issues related to GDPR</a></li>
<li><a href=\"https://pagely.com/blog/gdpr-wordpress-2018-resources/?mc_cid=a002d1fc74&mc_eid=58d2ea272a\">Pagely&#8217;s GDPR guide</a></li>
<li><a href=\"https://www.smashingmagazine.com/2018/02/gdpr-for-web-developers/?mc_cid=a002d1fc74&mc_eid=58d2ea272a\">Heather Burns&#8217; detailed GDPR analysis in Smashing Magazine</a></li>
</ul>
<h3>Sponsor: Valet</h3>
<p>This episode is sponsored by <a href=\"https://www.valet.io/\">Valet</a>. Valet helps keep your clients happy &amp; coming back. They offer expert services and keep the websites they manage functioning flawlessly. They offer preventative care that provides peace of mind around the clock. For more information, check out <a href=\"https://www.valet.io/\">their website</a> and thank you to Valet for being a Post Status partner.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 Apr 2018 12:56:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Matt: Russell’s Treadmill\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48043\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"https://ma.tt/2018/04/russells-treadmill/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:704:\"<p>From <a href=\"https://www.amazon.com/dp/B015D3X0YG\">Bertrand Russell&#8217;s A Conquest of Happiness</a>.</p>

<blockquote class=\"wp-block-quote\">
    <p>It is very singular how little men seem to realize that they are not caught in the grip of a mechanism from which there is no escape, but that the treadmill is one upon which they remain merely because they have not noticed that it fails to take them up to a higher level.</p>
</blockquote>

<p>He also says later, &#8220;﻿There are two motives for reading a book: one, that you enjoy it; the other, that you can boast about it.&#8221; <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f602.png\" alt=\"😂\" class=\"wp-smiley\" /></p>

<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 13 Apr 2018 20:22:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"Dev Blog: GDPR Compliance Tools in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5728\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2018/04/gdpr-compliance-tools-in-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3913:\"<p>GDPR compliance is an important consideration for all WordPress websites. The GDPR Compliance team is looking for help to test the privacy tools that are currently being developed in core. </p>

<h2>What is GDPR?</h2>

<p>GDPR stands for <a href=\"https://en.wikipedia.org/wiki/General_Data_Protection_Regulation\">General Data Protection Regulation</a> and is intended to strengthen and unify data protection for all individuals within the European Union. Its primary aim is to give control back to the EU residents over their personal data. <br /></p>

<p>Why the urgency? Although the GDPR was introduced two years ago, it becomes  enforceable starting May 25, 2018.</p>

<h2>Make WordPress GDPR Compliance Team</h2>

<p>Currently, the GDPR Compliance Team understands that helping WordPress-based sites become compliant is a large and ongoing task. The team is focusing on creating a comprehensive core policy, plugin guidelines, privacy tools and documentation. All of this requires your help.<br /></p>

<p>The GDPR Compliance Team is focusing on four main areas:</p>

<ul>
    <li>Add functionality to assist site owners in creating comprehensive privacy policies for their websites.</li>
    <li>Create guidelines for plugins to become GDPR ready.</li>
    <li>Add administration tools to facilitate compliance and encourage user privacy in general.</li>
    <li>Add documentation to educate site owners on privacy, the main GDPR compliance requirements, and on how to use the new privacy tools.</li>
</ul>

<h2>Don’t we already have a privacy policy?</h2>

<p>Yes and no. That said, The GDPR puts tighter guidelines and restrictions. Though we have many plugins that create privacy pages, we need means to generate a unified, comprehensive privacy policy. We will need tools for users to easily come into compliance.<br /></p>

<p>Site owners will be able to create GDPR compliant privacy policy in three steps:</p>

<ol>
    <li>Adding a dedicated page for the policy.<br /></li>
    <li>Adding privacy information from plugins.</li>
    <li>Reviewing and publishing the policy.</li>
</ol>

<p>A new &#8220;postbox&#8221; will be added to the Edit Page screen when editing the policy. All plugins that collect or store user data will be able to add privacy information there. In addition it will alert the site owners when any privacy information changes after a plugin is activated, deactivated, or updated.<br /></p>

<p>There is a new functionality to confirm user requests by email address. It is intended for site owners to be able to verify requests from users for displaying, downloading, or anonymizing of personal data.<br /></p>

<p>A new &#8220;Privacy&#8221; page is added under the &#8220;Tools&#8221; menu. It will display new, confirmed requests from users, as well as already fulfilled requests. It will also contain the tools for exporting and anonymizing of personal data and for requesting email confirmation to avoid abuse attempts.<br /></p>

<p>New section on privacy will be added to the <a href=\"https://developer.wordpress.org/plugins/\">Plugin Handbook</a>. It will contain some general information on user privacy, what a plugin should do to be compliant, and also tips and examples on how to use the new privacy related functionality in WordPress.<br /></p>

<p>The new privacy tools are scheduled for release at the end of April or beginning of May 2018.</p>

<h2>How can you get involved?</h2>

<p>We would love to have your help. The first step is awareness and education. For more information about the upcoming privacy tools see ﻿<a href=\"https://make.wordpress.org/core/2018/03/28/roadmap-tools-for-gdpr-compliance/\">the roadmap</a>.</p>

<p>If you would like to get involved in building WordPress Core and testing the new privacy tools, please join the #gdpr-compliance channel in the <a href=\"https://make.wordpress.org/chat/\">Make WordPress</a> Slack group.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Apr 2018 20:11:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:103:\"WPTavern: WPWeekly Episode 312 – Dragon Drop, WordPress Accessibility Statement, and WooCommerce GDPR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=79862&preview=true&preview_id=79862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:108:\"https://wptavern.com/wpweekly-episode-312-dragon-drop-wordpress-accessibility-statement-and-woocommerce-gdpr\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1888:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I start the show by sharing our thoughts on Mark Zuckberberg&#8217;s congressional hearing. We then discuss what&#8217;s new in Gutenberg 2.6 and describe our user experience. We let you know what&#8217;s in WooCommerce 3.3.5 and discuss what the development team is doing to prepare for GDPR compliance.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/gutenberg-2-6-introduces-drag-and-drop-block-sorting\">Gutenberg 2.6 Introduces Drag and Drop Block Sorting</a><br />
<a href=\"https://wptavern.com/theme-review-changes-place-more-onus-onto-theme-authors\">Theme Review Changes Place More Onus Onto Theme Authors</a><br />
<a href=\"https://wordpress.org/about/accessibility/\">WordPress Accessibility Statement</a><br />
<a href=\"https://woocommerce.wordpress.com/2018/04/10/woocommerce-3-3-5-fix-release-notes/\">WooCommerce 3.3.5 Released</a><br />
<a href=\"https://woocommerce.wordpress.com/2018/04/10/how-were-tackling-gdpr-in-woocommerce-core/\">How WooCommerce is tackling GDPR</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://atomicblocks.com/introducing-the-atomic-blocks-plugin-and-theme/\">AtomBlocks by Mike McAlister</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, April 18th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #312:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Apr 2018 01:05:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"HeroPress: Growing Up Rural\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2503\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://heropress.com/growing-up-rural/#utm_source=rss&utm_medium=rss&utm_campaign=growing-up-rural\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2947:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2015/10/ImpactForOthers-HeroPress-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: I hope and pray that in some small way I\'ll be able to take what I\'ve learned and make an impact for others.\" /><p>This week&#8217;s throwback essay is titled &#8220;<a href=\"https://heropress.com/essays/i-dont-know-anything-and-thats-ok/\">I don&#8217;t know anything, and that&#8217;s ok</a>&#8220;. It was written back in 2015 by my friend Kyle. He and I grew up in similar circumstances; far from a hub of civilization, in a relatively economically depressed area, without the best education opportunities.</p>
<p>Yet he and I both managed to find the web, dive in, and find home. We support our families and find joy in the work we produce. I&#8217;m not sure there&#8217;s a better way to live than that.</p>
<p>Check out Kyle&#8217;s essay and let him know what you think.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/i-dont-know-anything-and-thats-ok/\">I Don’t Know Anything and That’s OK</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Growing Up Rural\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Growing%20Up%20Rural&via=heropress&url=https%3A%2F%2Fheropress.com%2Fgrowing-up-rural%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Growing Up Rural\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fgrowing-up-rural%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fgrowing-up-rural%2F&title=Growing+Up+Rural\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Growing Up Rural\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/growing-up-rural/&media=https://heropress.com/wp-content/uploads/2015/10/ImpactForOthers-HeroPress-150x150.jpg&description=Growing Up Rural\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Growing Up Rural\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/growing-up-rural/\" title=\"Growing Up Rural\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/growing-up-rural/\">Growing Up Rural</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 11 Apr 2018 12:15:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Theme Review Changes Place More Onus Onto Theme Authors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79771\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wptavern.com/theme-review-changes-place-more-onus-onto-theme-authors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2093:\"<p>The WordPress Theme Review team has <a href=\"https://make.wordpress.org/themes/2018/04/09/changes-in-theme-review-process/\">implemented changes</a> that simplify the process and places more responsibility onto theme authors. Theme reviewers now only need to check the following items to pass a theme.</p>

<ul>
    <li>Licensing</li>
    <li>Malicious or egregious stuff</li>
    <li>Content Creation</li>
    <li>Security</li>
</ul>

<p>Although the bar to pass a theme is significantly lower, theme authors are still expected to follow the <a href=\"https://make.wordpress.org/themes/handbook/review/required/\">required</a> and <a href=\"https://make.wordpress.org/themes/handbook/review/recommended/\">recommended</a> requirements listed in the theme handbook.</p>

<p>Moderators will check themes after they&#8217;ve gone live to make sure the author is following guidelines. If a moderator discovers any issues, a request will be made to the theme author to correct them. Failure to do so could lead to a temporary or permanent suspension.</p>

<p>Justin Tadlock <a href=\"https://make.wordpress.org/themes/2018/04/09/changes-in-theme-review-process/#comment-43128\">clarified</a> in the comments examples of egregious issues.</p>

<ul>
    <li>Illegal</li>
    <li>Dishonest</li>
    <li>Morally offensive</li>
    <li>PHP Errors</li>
</ul>

<p>In the past two years, The Theme Review Team has battled the theme review queue with moderate success. <a href=\"https://wptavern.com/wordpress-theme-review-team-making-progress-on-clearing-out-1000-review-backlog\">In early 2017</a>, the number of themes in the queue dropped below 200. Although there has been some work on automating the process, it&#8217;s largely reliant on humans.</p>

<p>Even though it hasn&#8217;t been updated in more than a year, theme authors are highly encouraged to use the <a href=\"https://wordpress.org/plugins/theme-check/\">Theme Check plugin</a> before submitting themes for review.</p>

<p>With a simplified process to get a theme live, reviewers are hoping it will free them up to focus on larger projects.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Apr 2018 23:45:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: Gutenberg 2.6 Introduces Drag and Drop Block Sorting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79658\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/gutenberg-2-6-introduces-drag-and-drop-block-sorting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1729:\"<p><a href=\"https://wordpress.org/plugins/Gutenberg/\">Gutenberg 2.6</a> is available for download and with it, comes a new way of sorting blocks. In addition to using up and down arrows, this version introduces the ability to sort blocks by <a href=\"https://github.com/WordPress/gutenberg/issues/6041\">dragging and dropping</a>.</p>

<p>If you hover the cursor over the up and down arrows on the left side of a block, you&#8217;ll see a hand icon. Simply click, hold, and drag the block up or down below or above the blue indicator.</p>


    


<p>In my limited testing, I found drag and drop to be hit or miss. Sometimes, when I try to drag and drop a block, the blue line doesn&#8217;t show up.</p>

<p>The hand icon for the cursor is different for the top and bottom of the block. You can drag a block by hovering over the bottom of it but you can&#8217;t do it from the top.</p>

<img />
    Hovering the cursor at the top of the block


<img />
    Hovering the cursor at the bottom of the block


<p>I also found it difficult to add a new block manually. For example, when I add a paragraph block, I don&#8217;t see the Plus icon to create a new block underneath it anymore.</p>

<p>Pressing enter at the end of a paragraph creates a new Paragraph block automatically. But I don&#8217;t know how to transform it into an image block. I&#8217;ll need to do more testing to figure out what&#8217;s going on. <br /></p>

<p>There&#8217;s a host of <a href=\"https://make.wordpress.org/core/2018/04/05/whats-new-in-gutenberg-5th-april/\">other improvements and bug fixes </a>in this release, some of which I covered <a href=\"https://wptavern.com/an-update-to-my-gutenberg-experience\">in this post</a>. ﻿<br />. ﻿<br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Apr 2018 00:09:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Post Status: Designing the news — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=45154\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://poststatus.com/designing-the-news-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1904:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p><span>In this episode, Brian and Brian discuss a variety of news topics spanning design, development, and business. Tune in to learn about the history of WordPress and the web, the newest TechCrunch redesign, a WordCamp for WordCamp organizers, and more.</span></p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://zeen101.com/for-developers/leakypaywall/\">Leaky Paywall</a></li>
<li><a href=\"https://designintech.report/\">2018 Design in Tech report</a></li>
<li><a href=\"https://gutenberg.courses/development/\">Gutenberg Development Course</a></li>
<li><a href=\"https://techcrunch.com/2018/03/13/welcome-to-the-new-techcrunch/\">TechCrunch redesign</a></li>
<li><a href=\"https://thehistoryoftheweb.com/the-story-of-wordpress/\">WordPress turns 15</a>, via History of the Web</li>
<li><a href=\"https://make.wordpress.org/community/2018/04/03/want-to-help-organize-a-wordcamp-for-organizers/\">Proposal for a WordCamp for WordCamp organizers </a></li>
</ul>
<h3>Sponsor: Gravity Forms</h3>
<p><a href=\"http://www.gravityforms.com/?utm_source=post_status&utm_medium=banner&utm_campaign=ps_ads\">Gravity Forms</a> makes the best web forms on the planet. Over a million WordPress sites are already using Gravity Forms. Is yours? Thanks to Gravity Forms for being a Post Status partner.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Apr 2018 18:36:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"WPTavern: An Update to My Gutenberg Experience\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79564\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wptavern.com/an-update-to-my-gutenberg-experience\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2508:\"<p>Not long after I published <a href=\"https://wptavern.com/my-gutenberg-experience-thus-far\">my experience with Gutenberg</a>, developers reached out to me to work on some of the issues I mentioned. Riad Benguella <a href=\"https://github.com/WordPress/gutenberg/pull/5902\">figured out</a> why meta boxes were not collapsing or expanding.</p>

<p>It turns out that some meta boxes depend on the post script which has a side effect of calling the window.postboxes.add_postbox_toggles( postType ) twice, causing meta boxes to break.</p>

<p>Gutenberg 2.6 <a href=\"https://make.wordpress.org/core/2018/04/05/whats-new-in-gutenberg-5th-april/\">released earlier this week</a>, fixes the issue and all meta boxes function properly again. This also fixes the issue I had with the Telegram for WordPress plugin. <br /></p>

<p><a href=\"https://wordpress.org/plugins/public-post-preview/\">Public Post Preview</a> still doesn&#8217;t work in Gutenberg but the plugin&#8217;s developer, Dominik Schilling, shared some experiments he has conducted with adding support for Gutenberg on Twitter.</p>


    <blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Can\'t wait for seeing Gutenberg in WordPress core. So many new possibilities. Even for Public Post Preview (<a href=\"https://t.co/Xsw9hugxKT\">https://t.co/Xsw9hugxKT</a>). With just a few lines I was able to create this: <a href=\"https://t.co/fxyuBIMPOl\">pic.twitter.com/fxyuBIMPOl</a></p>&mdash; Dominik Schilling <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f30a.png\" alt=\"🌊\" class=\"wp-smiley\" /> (@ocean90) <a href=\"https://twitter.com/ocean90/status/980420608822562816?ref_src=twsrc%5Etfw\">April 1, 2018</a></blockquote>


<p>In the preview video, you can see Public Post Preview&#8217;s options added to the sidebar and in addition to generating a link, you can choose when that URL expires which is better than what&#8217;s currently available in the plugin.</p>

<p>I mentioned how Tags would sometimes disappear and there overall behavior was inconsistent. This <a href=\"https://github.com/WordPress/gutenberg/pull/5913\">pull request </a>that made it into Gutenberg 2.6, fixes the issue by only including the term in the Tag selector if it&#8217;s known.</p>

<p>Although I&#8217;m still bummed that certain plugins are not yet compatible with Gutenberg, I&#8217;m pretty happy that two of the major pain points I experienced have been fixed. Thanks to Riad, Tammie Lister, and others for helping to solve these problems so quickly. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 06 Apr 2018 21:29:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"WPTavern: A WordCamp for Organizers Is in the Planning Stages\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79513\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wptavern.com/a-wordcamp-for-organizers-is-in-the-planning-stages\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2684:\"<p>Last year, Drew Jaynes and Carol Stambaugh <a href=\"https://make.wordpress.org/community/2017/08/16/proposed-event-wordcamp-for-wordcamp-organizers/\">proposed</a> a new WordCamp event geared towards organizers to the WordPress Community Team. After fleshing out the details and discussing the idea over the course of seven months, the duo <a href=\"https://make.wordpress.org/community/2018/04/03/want-to-help-organize-a-wordcamp-for-organizers/\">has announced</a> that a WordCamp for Organizers is officially on the table.</p>

<p>The goal of the event is to provide an opportunity for meetup and WordPress event organizers to share their experience with others in the community. The plan is to host a one-day event a day or two before <a href=\"https://2018.us.wordcamp.org/\">WordCamp US</a> in Nashville, TN, later this year.</p>

<p>&#8220;The idea for WordCamp for Organizers – what some of us affectionately refer to as &#8216;dotOrganize&#8217; – was really borne out of many conversations I’ve had over the years with others in the WordPress community lamenting the lack of a ready knowledge sharing opportunity between event organizers,&#8221; Jaynes said.</p>

<p>&#8220;One common thread seemed to be the idea of common lessons learned, and how awesome it would be to just have an event for organizers to get together and swap tips and tricks. </p>

<p>&#8220;We’re all here organizing the same community, maybe we should get together and trade notes! And so we now have a new topic-based WordCamp just for organizers. </p>

<p>&#8220;It’s kind of meta – organizing a WordCamp for Organizers, but I really feel like this could be a boon for anybody currently organizing or looking to start organizing in WordPress. Exciting!&#8221;</p>

<p>Some of the session topics that could be presented on include:</p>

<ul>
    <li>Spreading the word about your community events</li>
    <li>Tips for wrangling speakers, volunteers, and sponsors</li>
    <li>Conflict resolution among organizing teams</li>
    <li>How to respond to a code of conduct issue</li>
    <li>Finding and using official organizing tools and resources<br /></li>
</ul>

<p>The team is seeking volunteers who can spend 2-4 hours per week to help organize the event. Although it&#8217;s focused on organizers, those who have attended many conferences, including WordCamps, with little event organizing experience, are encouraged to join the team.</p>

<p>If you&#8217;re interested in volunteering, please leave a comment on the <a href=\"https://make.wordpress.org/community/2018/04/03/want-to-help-organize-a-wordcamp-for-organizers/\">official announcement post</a>. </p>

<p><br /></p><br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 06 Apr 2018 00:22:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: Jetpack 6.0 Takes Steps Towards GDPR Compliance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79459\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wptavern.com/jetpack-6-0-takes-steps-towards-gdpr-compliance\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1148:\"<p>Jetpack 6.0 <a href=\"https://jetpack.com/2018/04/03/jetpack-6-0/\">is available</a> for upgrade. It comes with improvements to the social media icons widget, enhanced brute force protection, and better compatibility between WooCommerce and Jetpack.</p>

<p>Its headlining features though are privacy related as the <a href=\"https://www.eugdpr.org/\">General Data Protection Regulation</a> (GDPR) is set to go into effect May 25th. In 6.0, Jetpack has a dedicated privacy settings page that links to privacy documents and includes a way to opt-out of activity tracking.</p>

<p>These settings can be accessed by clicking the Privacy link at the bottom of the Jetpack Dashboard page. </p>

<img />
    Jetpack 6.0 Privacy Settings


<p>The &#x27;<a href=\"https://jetpack.com/support/what-data-does-jetpack-sync/\">What Data Does Jetpack Sync</a>&#x27; page outlines what data is used, how it&#x27;s used, the relationship it has with the WordPress mobile apps, and provides an inside look at how Jetpack works.</p>

<p>These are the first steps towards GDPR compliance with more updates planned before the regulation goes into effect next month. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Apr 2018 23:20:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: WPWeekly Episode 311 – Jetpack 6.0, WordPress 4.9.5, and A WordCamp for Organizers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=79447&preview=true&preview_id=79447\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://wptavern.com/wpweekly-episode-311-jetpack-wordpress-4-9-5-and-a-wordcamp-for-organizers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1628:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I discuss a <a href=\"https://glueckpress.com/9336/amp-and-wordpress/\">great article</a> published by Caspar Hübinger on AMP and WordPress. We cover what&#8217;s new in WordPress 4.9.5, Jetpack 6.0, and a WordCamp geared toward organizers.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/wordpress-4-9-5-squashes-25-bugs\">WordPress 4.9.5 Squashes 25 Bugs</a><br />
<a href=\"https://wptavern.com/try-gutenberg-prompt-pushed-back-to-a-later-release\">‘Try Gutenberg’ Prompt Pushed Back to A Later Release</a><br />
<a href=\"https://jetpack.com/2018/04/03/jetpack-6-0/\">Jetpack 6.0 Released</a><br />
<a href=\"https://make.wordpress.org/community/2018/04/03/code-of-conduct-survey/\">Code of Conduct Survey</a><br />
<a href=\"https://make.wordpress.org/community/2018/04/03/want-to-help-organize-a-wordcamp-for-organizers/\">Want to Help Organize a WordCamp for Organizers?</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, April 11th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #311:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Apr 2018 01:15:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"HeroPress: The Year I Got Cancer Was The Year My WordPress Business Took Off\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2497\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:204:\"https://heropress.com/essays/the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off/#utm_source=rss&utm_medium=rss&utm_campaign=the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8809:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2018/04/040418-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Take care of yourselves and of each other, it\'s very important.\" /><p>In 2010 I was beginning to take on client work creating WordPress web sites when I was diagnosed with ovarian cancer. Ironically, at 43 years old I was more fit and healthy than I had ever been in my entire life. I had been running road marathons and trail ultra marathons for a few years leading up to my diagnosis. Good thing too, because surgery and treatment were obviously very tough.</p>
<p>I was transitioning my design studio from analog to digital. Previously, I was working as a professional artist and illustrator creating commission portraiture and college mascot illustrations with some moderate successes. My background is in Fine Art and Design. I studied Drawing, Sculpture, &amp; Time Arts. (2D, 3D &amp; 4D &#8211; 4D can be described as: Length, width, height, and time/ motion) Naturally, as a Time Arts artist/illustrator I love the web! I love designing for the web and mobile too. Web work is immediately gratifying. I do design for both the web and print but I have always felt drawn to the web as it is more accessible, more fluid, dynamic, interconnected, animated, media rich, and well … if you are reading this then you already get the picture. <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>
<blockquote><p>To get through treatment it was important to me that I still work every day.</p></blockquote>
<p>Some days it was just a couple hours in the afternoon but it really helped me to cope and endure unplanned surgery and many painful chemotherapy treatments. I had recently completed a couple of websites with the help of my mentor Jerry Turk. Those sites had good reach. I mean they were the kind of sites that groups of people used and managed so I got some attention for the work and word of mouth spread locally.</p>
<p>It was while getting through that period of treatment and the shock of a devastating diagnosis that my digital design agency really got legs. It could not have happened at a better time. So, my studio, C&amp;D Studios &#8211; <a href=\"https://CandDStudios.com\">https://CandDStudios.com</a> continued it’s move towards being 100% digital. No more analog photography and not much more drawing at the drawing table either. Now my work was nearly 100% focused on screens and it would also begin to pay the bills. That was eight years ago. I was very fortunate to learn using reliable frameworks, themes, plug-ins, and hosts that would also stand the test of time. Thank you Genesis Framework, StudioPress and Gravity Forms to name a few…</p>
<p>Fast forward to 2016 after having been cancer free all those years and cranking out a lot of agency work, I had a cancer reoccurrence. I never wanted cancer to be part of my story and I tried to deny or overcome it in all ways but it had resurfaced in October of 2016. Professionally, I was involved in collaborating on very large scale enterprise sites with teams. I was spending the year testing the waters at a new level of production. It was not good timing to require another surgery and 18 more rounds of chemotherapy. Fortunately, I found support in the community from other designers and developers whom helped me to the finish lines with 3 large projects in areas of e-commerce, college membership and enterprise site work -one with a large volume of SVG animations. After surgery, in February of 2017 I completed 18 rounds of chemotherapy treatments.</p>
<blockquote><p>I have survived and am cancer free once again!</p></blockquote>
<p>While going through treatment the second time I was not really focused on what good thing will I be able to grow towards professionally. Honestly, when you go through these things in life &#8211; you just spend your energy getting through as best as you can. I think it is worth noting here that while a positive attitude is great and it can improve a patient’s overall experience. Please don’t tell people they will survive cancer because of their positive attitude. Cancer is horrible, it does not discriminate and when people can’t beat a disease with their mental attitude they end up blaming themselves unnecessarily. That is not good. That is not what people intend when then try to offer support in that way but that is something I wanted to share.</p>
<p>Now I have landed on the other side of treatment again and as I reflect, it’s been a really epic year! Our WordPress community has been open and supportive, welcoming me at conferences, online, and in slack groups, whether I had hair, energy, or resources &#8211; always welcoming and always encouraging. Over the years I have made some wonderful friends through WordPress! Some of us have been at this for a long time and we now have many shared experiences and skills.</p>
<h3>Having Survived Again I’m Launching a WordPress Product</h3>
<p>Having survived again, and having been inspired at PressNomics in Tempe last spring, I’m busy launching a mobile product/service with my team Dr. Kendra Remington and Rita Best called <a href=\"https://docswithapps.com\">Docs With Apps</a>.</p>
<p>I still accept some client work, and some retainer work but I’m pretty selective about the projects we work on “in house.”</p>
<p>I love SVG animation work so in 2018 I’m overjoyed to be doing more contracted SVG animation work with my collaborator Jackie D’Elia. Hit us up!!</p>
<p>These are some very wonderful times in technology and within the Internet of things. I feel very grateful to have been able to ride the digital wave into the present and future. At WCUS in Nashville I began the process of contributing to make WordPress after having spent many years empowering others with it.</p>
<p>When I was young I needed a way to get my portfolio on line and that is how I got started. Thank you for the opportunity to share my story, to publicly thank my husband Dominic, my family, and friends too. The future is going to be awesome!</p>
<p>Take care of yourself and of each other, it&#8217;s very important.</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: The Year I Got Cancer Was The Year My WordPress Business Took Off\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=The%20Year%20I%20Got%20Cancer%20Was%20The%20Year%20My%20WordPress%20Business%20Took%20Off&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fthe-year-i-got-cancer-was-the-year-my-wordpress-business-took-off%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: The Year I Got Cancer Was The Year My WordPress Business Took Off\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fthe-year-i-got-cancer-was-the-year-my-wordpress-business-took-off%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fthe-year-i-got-cancer-was-the-year-my-wordpress-business-took-off%2F&title=The+Year+I+Got+Cancer+Was+The+Year+My+WordPress+Business+Took+Off\" rel=\"nofollow\" target=\"_blank\" title=\"Share: The Year I Got Cancer Was The Year My WordPress Business Took Off\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off/&media=https://heropress.com/wp-content/uploads/2018/04/040418-150x150.jpg&description=The Year I Got Cancer Was The Year My WordPress Business Took Off\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: The Year I Got Cancer Was The Year My WordPress Business Took Off\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off/\" title=\"The Year I Got Cancer Was The Year My WordPress Business Took Off\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/the-year-i-got-cancer-was-the-year-my-wordpress-business-took-off/\">The Year I Got Cancer Was The Year My WordPress Business Took Off</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 04 Apr 2018 12:00:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Cathi Bosco\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"WPTavern: WordPress 4.9.5 Squashes 25 Bugs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79399\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wptavern.com/wordpress-4-9-5-squashes-25-bugs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:940:\"<p>WordPress 4.9.5 <a href=\"https://wordpress.org/news/2018/04/wordpress-4-9-5-security-and-maintenance-release/\">is available</a> for download and is a maintenance and security release. WordPress 4.9.4 and earlier versions are affected by three security issues. The following security hardening changes are in 4.9.5.</p>

<ul>
    <li>Localhost is no longer treated as the same host by default.<br /></li>
    <li>Safe redirects are used when redirecting the login page if SSL is forced.</li>
    <li>Versions strings are correctly escaped for use in generator tags.</li>
</ul>

<p>Twenty-five bugs are fixed in this release including, improve compatibility with PHP 7.2, previous styles on caption shortcodes are restored, and clearer error messages. To see a full list of changes along with their associated trac tickets, check out <a href=\"https://make.wordpress.org/core/2018/04/02/wordpress-4-9-5/\">the detailed release post</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Apr 2018 23:02:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"Dev Blog: WordPress 4.9.5 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5645\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2018/04/wordpress-4-9-5-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6336:\"<p>WordPress 4.9.5 is now available. This is a <strong>security and maintenance release</strong> for all versions since WordPress 3.7. We strongly encourage you to update your sites immediately.</p>

<p>WordPress versions 4.9.4 and earlier are affected by three security issues. As part of the core team&#x27;s ongoing commitment to security hardening, the following fixes have been implemented in 4.9.5:</p>

<ol>
    <li>Don&#x27;t treat <code>localhost</code> as same host by default.</li>
    <li>Use safe redirects when redirecting the login page if SSL is forced.</li>
    <li>Make sure the version string is correctly escaped for use in generator tags.</li>
</ol>

<p>Thank you to the reporters of these issues for practicing <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">﻿coordinated security disclosure</a>: <a href=\"https://profiles.wordpress.org/xknown\">xknown</a> of the WordPress Security Team, <a href=\"https://hackerone.com/nitstorm\">Nitin Venkatesh (nitstorm)</a>, and <a href=\"https://twitter.com/voldemortensen\">Garth Mortensen</a> of the WordPress Security Team.</p>

<p>Twenty-five other bugs were fixed in WordPress 4.9.5. Particularly of note were:</p>

<ul>
    <li>The previous styles on caption shortcodes have been restored.</li>
    <li>Cropping on touch screen devices is now supported.</li>
    <li>A variety of strings such as error messages have been updated for better clarity.</li>
    <li>The position of an attachment placeholder during uploads has been fixed.</li>
    <li>Custom nonce functionality in the REST API JavaScript client has been made consistent throughout the code base.</li>
    <li>Improved compatibility with PHP 7.2.</li>
</ul>

<p><a href=\"https://make.wordpress.org/core/2018/04/03/wordpress-4-9-5/\">This post has more information about all of the issues fixed in 4.9.5 if you&#x27;d like to learn more</a>.</p>

<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.9.5</a> or venture over to Dashboard → Updates and click \"Update Now.\" Sites that support automatic background updates are already beginning to update automatically.</p>

<p>Thank you to everyone who contributed to WordPress 4.9.5:</p>

<p><a href=\"https://profiles.wordpress.org/1265578519-1/\">1265578519</a>, <a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/schlessera/\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/alexgso/\">alexgso</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andrei0x309/\">andrei0x309</a>, <a href=\"https://profiles.wordpress.org/antipole/\">antipole</a>, <a href=\"https://profiles.wordpress.org/aranwer104/\">Anwer AR</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/blair-jersyer/\">Blair jersyer</a>, <a href=\"https://profiles.wordpress.org/bandonrandon/\">Brooke.</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/codegrau/\">codegrau</a>, <a href=\"https://profiles.wordpress.org/conner_bw/\">conner_bw</a>, <a href=\"https://profiles.wordpress.org/davidakennedy/\">David A. Kennedy</a>, <a href=\"https://profiles.wordpress.org/designsimply/\">designsimply</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling (ocean90)</a>, <a href=\"https://profiles.wordpress.org/electricfeet/\">ElectricFeet</a>, <a href=\"https://profiles.wordpress.org/ericmeyer/\">ericmeyer</a>, <a href=\"https://profiles.wordpress.org/fpcsjames/\">FPCSJames</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/soulseekah/\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/henrywright/\">Henry Wright</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jbpaul17/\">Jeffrey Paul</a>, <a href=\"https://profiles.wordpress.org/jipmoors/\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/joemcgill/\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnpgreen/\">johnpgreen</a>, <a href=\"https://profiles.wordpress.org/junaidkbr/\">Junaid Ahmed</a>, <a href=\"https://profiles.wordpress.org/kristastevens/\">kristastevens</a>, <a href=\"https://profiles.wordpress.org/obenland/\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/lakenh/\">Laken Hafner</a>, <a href=\"https://profiles.wordpress.org/lancewillett/\">Lance Willett</a>, <a href=\"https://profiles.wordpress.org/leemon/\">leemon</a>, <a href=\"https://profiles.wordpress.org/melchoyce/\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/mikeschroder/\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mrmadhat/\">mrmadhat</a>, <a href=\"https://profiles.wordpress.org/nandorsky/\">nandorsky</a>, <a href=\"https://profiles.wordpress.org/jainnidhi/\">Nidhi Jain</a>, <a href=\"https://profiles.wordpress.org/swissspidy/\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/qcmiao/\">qcmiao</a>, <a href=\"https://profiles.wordpress.org/rachelbaker/\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/larrach/\">Rachel Peter</a>, <a href=\"https://profiles.wordpress.org/ravanh/\">RavanH</a>, <a href=\"https://profiles.wordpress.org/otto42/\">Samuel Wood (Otto)</a>, <a href=\"https://profiles.wordpress.org/sebastienthivinfocom/\">Sebastien SERRE</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shital-patel/\">Shital Marakana</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/thomas-vitale/\">Thomas Vitale</a>, <a href=\"https://profiles.wordpress.org/kwonye/\">Will Kwon</a>, and <a href=\"https://profiles.wordpress.org/yahil/\">Yahil Madakiya</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Apr 2018 19:56:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Aaron D. Campbell\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: ‘Try Gutenberg’ Prompt Pushed Back to A Later Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=79273\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wptavern.com/try-gutenberg-prompt-pushed-back-to-a-later-release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4312:\"<p>Last week, <a href=\"https://wptavern.com/in-wordpress-4-9-5-users-will-be-two-clicks-away-from-installing-and-activating-gutenberg-from-the-dashboard\">we reported</a> that WordPress 4.9.5 would ship with a call-out prompt that asks users if they want to try the new editor experience.</p>

<p>Within the comments of the post, Gary Pendergast, who works for Automattic, is a WordPress core contributor, and a lead developer on the Gutenberg project, <a href=\"https://wptavern.com/in-wordpress-4-9-5-users-will-be-two-clicks-away-from-installing-and-activating-gutenberg-from-the-dashboard#comment-246119\">informed us</a> that the prompt would not be in WordPress 4.9.5. Instead, it will ship in a later version once it has gone through a few more refinements.</p>

<blockquote class=\"wp-block-quote\">
    <p>Change of plans, this won’t be happening in the 4.9.5 release: there are still a few issues we’d like to fix up the callout happens, they won’t be done in time for the 4.9.5 release. I expect there will be a smaller 4.9.6 release that contains this callout, and any bugfixes that happen to be ready.</p><cite>Gary Pendergast</cite></blockquote>

<p>Reverting the call-out has <a href=\"https://core.trac.wordpress.org/ticket/41316\">extended the conversation</a> surrounding its implementation. Jadon N who works for InMotion hosting and is a contributor to the <a href=\"https://make.wordpress.org/chat/\">#hosting-community slack channel</a>, says the hosting-community group is working on ideas to help test popular plugins for Gutenberg compatibility.</p>

<blockquote class=\"wp-block-quote\">
    <p>We have been working to expand our collection of data about how well plugins function with Gutenberg. To help with that effort, we would like to explore using feedback collected from WordPress users through the Try Gutenberg effort to add to the existing database on WordPress plugin compatibility if that could be worked out. </p>
    <p>The goal of this project is to make sure everyone can use Gutenberg without having to worry about plugin incompatibilities.</p><cite>Jadon N</cite></blockquote>

<p>The <a href=\"https://plugincompat.danielbachhuber.com/\">Gutenberg Plugin Compatibility Database project</a> launched by Daniel Bachhuber last month attempts to determine which popular plugins are already compatible with Gutenberg by having volunteers test them in a sandboxed environment.</p>

<p>Out of the 4,213 plugins in the database, 84% have an unknown compatibility status. Out of 610 plugins that have been tested, 82% don&#x27;t include editor functionality.</p>

<p>Pendergast <a href=\"https://core.trac.wordpress.org/ticket/41316#comment:92\">supports the idea</a> of hosts collecting a wide range of testing data and turning it into actionable items for the team to work on. There&#x27;s also been some discussion on creating snapshots of plugin compatibility and filtering those results into Bachhuber&#x27;s project.</p>

<p>Chris Lema, Vice President of Products at LiquidWeb, <a href=\"https://core.trac.wordpress.org/ticket/41316#comment:98\">responded</a> in the trac ticket with a suggestion that the team place as much emphasis on the Learn More and Report Issues sections as the Try Gutenberg message. He also added a prototype screenshot of what the call-out could look like. <br /></p>

<img />
    Gutenberg Call Out Prototype by Chris Lema


<p>\"The reality is that people don&#x27;t read a lot, so people may not fully grasp the &#x27;testing&#x27; part given the proposed design,\" Lema said. \"When there are equal weight to the design, the message also carries with it the same equality.\"</p>

<p>One of the best suggestions I&#x27;ve read comes <a href=\"https://core.trac.wordpress.org/ticket/41316#comment:98\">from Bachhuber</a>. He suggests displaying the prompt to a small percentage of WordPress sites to prevent thousands of users from re-reporting known issues with Gutenberg. It would also help lessen the load on the support forums.</p>

<p>One of my main concerns with the call-out is the lack of upfront information to the user that it is beta software and it could cause adverse affects on their site. Lema&#x27;s prototype does a great job of informing the user of this possibility and a link to known issues is a great enhancement. What do you think?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Apr 2018 00:13:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Matt: Goose-down Nape\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48011\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"https://ma.tt/2018/04/goose-down-nape/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1378:\"<p>There was a <a href=\"https://www.nytimes.com/2018/03/28/magazine/poem-the-nod.html\">beautiful poem by Kayo Chingonyi in the New York Magazine this week</a> titled The Nod:</p>

<blockquote class=\"wp-block-quote\">
    <p>When we’re strangers that pass each other<br />in the street, it will come down to this tilt<br />of the head — acknowledging another<br />version of events set in a new-build<br />years from now, a mess of a place filled<br />with books and records, our kids thick as thieves<br />redefining all notions of mischief.</p>
    <p>Perhaps our paths will cross in a city<br />of seven hills as the light draws your face<br />out from the bliss of anonymity.<br />Maybe you’ll be stroking the goose-down nape<br />of a small child with eyes the exact shade<br />of those I met across a room at the start<br />of this pain-in-the-heart, this febrile dance.</p>
</blockquote>

<p>When I hear \"seven hills\" my mind immediately goes to Rome, then San Francisco, but <a href=\"https://en.wikipedia.org/wiki/List_of_cities_claimed_to_be_built_on_seven_hills\">Wikipedia has a helpful list of cities that claim to be built on seven hills</a>.</p>

<p>A friend pointed out <em>The Nod</em> is a <a href=\"https://www.familyfriendpoems.com/poem/the-invitation-by-oriah-mountain-dreamer\">fine complement to <em>The Invitation</em> by Oriah Mountain Dreamer</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Apr 2018 00:05:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"Post Status: Contextualized Learning in or around WordPress — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=44987\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://poststatus.com/contextualized-learning-in-or-around-wordpress-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1838:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p><span>In this episode, the dynamic Brian duo discuss the highly-anticipated return of WordSesh, the different ways in which we all learn the same, and some of the problems we face in skill building. The guys also spend time finding and contacting the addressable market around WordPress, characterizing a business as WordPress-focused vs providing WordPress services in the context of a broader market, and some of the nuances of providing contextualized services (whether they be training, consulting, or otherwise).</span></p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://www.nbcnews.com/health/health-news/scientists-say-they-ve-discovered-unknown-human-organ-could-help-n860601\">New human organ</a></li>
<li><a href=\"http://wordsesh.com/\">WordSesh.com</a></li>
<li><a href=\"https://wpsessions.com/\">WPSessions.com</a></li>
</ul>
<h3>Sponsor: OptinMonster</h3>
<p><a href=\"http://optinmonster.com\">OptinMonster</a> allows you to convert visitors into subscribers. You can easily create &amp; A/B test beautiful lead capture forms without a developer. Be sure to check out their new <a href=\"http://optinmonster.com/announcing-the-inactivitysensor-activity-logs-and-more/\">Inactivity Sensor</a> technology.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Apr 2018 19:31:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"Dev Blog: The Month in WordPress: March 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5632\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2018/04/the-month-in-wordpress-march-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4323:\"<p>With a significant new milestone and some great improvements to WordPress as a platform, this month has been an important one for the project. Read on to find out more about what happened during the month of March.

</p>

<hr class=\"wp-block-separator\" />

<h2>WordPress Now Powers 30% of the Internet</h2>

<p>Over the last 15 years, the popularity and usage of WordPress has been steadily growing. That growth hit a significant milestone this month when <a href=\"https://w3techs.com/technologies/details/cm-wordpress/all/all\">W3Techs reported that WordPress now powers over 30% of sites on the web.</a></p>

<p>The percentage is determined based on W3Techs’ review of the top 10 million sites on the web, and it’s a strong indicator of the popularity and flexibility of WordPress as a platform.</p>

<p>If you would like to have hand in helping to grow WordPress even further, <a href=\"https://make.wordpress.org/\">you can get involved today</a>.</p>

<h2>WordPress Jargon Glossary Goes Live</h2>

<p>The WordPress Marketing Team has been hard at work lately putting together <a href=\"https://make.wordpress.org/marketing/2018/02/28/wordpress-jargon-glossary/\">a comprehensive glossary of WordPress jargon</a> to help newcomers to the project become more easily acquainted with things.</p>

<p>The glossary <a href=\"https://make.wordpress.org/marketing/2018/02/28/wordpress-jargon-glossary/\">is available here</a> along with a downloadable PDF to make it simpler to reference offline.</p>

<p>Publishing this resource is part of an overall effort to make WordPress more easily accessible for people who are not so familiar with the project. If you would like to assist the Marketing Team with this, you can follow <a href=\"https://make.wordpress.org/marketing/\">the team blog</a> and join the #marketing channel in the<a href=\"https://make.wordpress.org/chat/\"> Making WordPress Slack group</a>.</p>

<h2>Focusing on Privacy in WordPress</h2>

<p>Online privacy has been in the news this month for all the wrong reasons. It has reinforced the commitment of the GDPR Compliance Team to continue working on enhancements to WordPress core that allow site owners to improve privacy standards.</p>

<p>The team&#x27;s work, and the wider privacy project, spans four areas: Adding tools which will allow site administrators to collect the information they need about their sites, examining the plugin guidelines with privacy in mind, enhancing privacy standards in WordPress core, and creating documentation focused on best practices in online privacy.</p>

<p>To get involved with the project, you can <a href=\"https://make.wordpress.org/core/2018/03/28/roadmap-tools-for-gdpr-compliance/\">view the roadmap</a>, <a href=\"https://make.wordpress.org/core/tag/gdpr-compliance/\">follow the updates</a>, <a href=\"https://core.trac.wordpress.org/query?status=!closed&keywords=~gdpr\">submit patches</a>, and join the #gdpr-compliance channel in the <a href=\"https://make.wordpress.org/chat\">Making WordPress Slack group</a>. Office hours are 15:00 UTC on Wednesdays.</p>

<hr class=\"wp-block-separator\" />

<h2>Further Reading:</h2>

<ul>
    <li>The WordPress Foundation has published <a href=\"https://wordpressfoundation.org/2017-annual-report/\">their annual report for 2017</a> showing just how much the community has grown over the last year.</li>
    <li>The dates for WordCamp US <a href=\"https://2018.us.wordcamp.org/2018/03/13/announcing-wordcamp-us-2018/\">have been announced</a> — this flagship WordCamp event will be held on 7-9 December this year in Nashville, Tennessee.</li>
    <li>WordPress 4.9.5 is due for release on April 3 — <a href=\"https://make.wordpress.org/core/2018/03/21/wordpress-4-9-5-beta/\">find out more here</a>.</li>
    <li>Version 2.5 of Gutenberg, the new editor for WordPress core, <a href=\"https://make.wordpress.org/core/2018/03/29/whats-new-in-gutenberg-29th-march/\">was released this month</a> with a host of great improvements.</li>
    <li>WordSesh, a virtual WordPress conference, <a href=\"http://wordsesh.com/\">is returning in July this year</a>.</li>
</ul>

<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please <a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\">submit it here</a>.</em><br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Apr 2018 08:00:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: WPWeekly Episode 310 – Community Management, PHP, and Hello Dolly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=79249&preview=true&preview_id=79249\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wptavern.com/wpweekly-episode-310-community-management-php-and-hello-dolly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2325:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I discuss the news of the week including, the removal of offensive lyrics in Hello Dolly, a request for plugin developers to stop supporting legacy PHP versions, and changes coming in WordPress 4.9.5.</p>
<p>We also talk about community management, the difference between comments and forums, and finally, John shares his concerns on how the Gutenberg call-out prompt is being built into core.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/a-plea-for-plugin-developers-to-stop-supporting-legacy-php-versions\">A Plea For Plugin Developers to Stop Supporting Legacy PHP Versions</a><br />
<a href=\"https://wptavern.com/without-context-some-lyrics-inside-the-hello-dolly-plugin-are-degrading-to-women\">Without Context, Some Lyrics Inside the Hello Dolly Plugin Are Degrading to Women</a><br />
<a href=\"https://wptavern.com/why-gutenberg-and-why-now\">Why Gutenberg and Why Now?</a><br />
<a href=\"https://wptavern.com/noteworthy-changes-coming-in-wordpress-4-9-5\">Noteworthy Changes Coming in WordPress 4.9.5</a><br />
<a href=\"https://wptavern.com/in-wordpress-4-9-5-users-will-be-two-clicks-away-from-installing-and-activating-gutenberg-from-the-dashboard\">In WordPress 4.9.5, Users Will Be Two Clicks Away From Installing and Activating Gutenberg From the Dashboard</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://wptavern.com/how-to-disable-push-notification-requests-in-firefox\">How to Disable Push Notification Requests in Firefox</a></p>
<p><a href=\"https://addons.mozilla.org/en-US/firefox/addon/facebook-container/\">Facebook Container Add-on for Firefox</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, April 4th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #310:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Mar 2018 21:07:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"WPTavern: My Gutenberg Experience Thus Far\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78991\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wptavern.com/my-gutenberg-experience-thus-far\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5397:\"<p>Ive used Gutenberg for several months and during that time, there have been moments where I love it and situations where I&#x27;ve had to disable the plugin because of frustrating bugs. </p>

<p>One of the most frustrating aspects of using Gutenberg is the lack of support from the plugins I depend on.</p>

<h2>Publish Post Preview</h2>

<p>I use the <a href=\"https://wordpress.org/plugins/public-post-preview/\">Publish Post Preview</a> plugin to generate a preview link for posts so that people can see what it looks like before it&#x27;s published.</p>

<img />
    Publish Preview Checkbox in the Current Editor


<p>In the current editor, the checkbox to generate a link is in the Publish meta box. In Gutenberg, that option doesn&#x27;t exist. According to a <a href=\"https://wordpress.org/support/topic/compatibility-with-gutenberg/\">recent support forum post</a>, the author does not plan on making it Gutenberg compatible until there is a finalized API to extend the sidebar.</p>

<h2>Telegram for WordPress</h2>

<p>We use the <a href=\"https://wordpress.org/plugins/telegram-for-wp/\">Telegram for WordPress</a> plugin to automatically send published posts to our Telegram channel. The plugin adds a meta box that has options to send the post, configure the message structure, send a file, and display the featured image.</p>

<p>In Gutenberg, the meta box is open by default which provides access to those options. However, when I edit a published post, there are times when the meta box is closed and clicking the arrow to expand it doesn&#x27;t work. <em>Since the Send this post to channel</em> option is on by default, ﻿saving changes to the post will resend the post to Telegram subscribers. Something I don&#x27;t want to happen for simple edits. <br /></p>

<h2>Edit Flow</h2>

<p>We use <a href=\"https://wordpress.org/plugins/edit-flow/\">Edit Flow</a> to collaborate on posts and often use the Editorial Comments feature to provide feedback. In Gutenberg, the meta boxes for Editorial Comments and Notifications do not open when clicking the arrow. Therefor, we can&#x27;t use those features. <br /></p>

<img />
    <br /><br />Edit Flow Meta Boxes are Broken


<h2>After the Deadline</h2>

<p>I&#x27;m a fan of <a href=\"https://jetpack.com/support/spelling-and-grammar/\">After the Deadline</a> which is a proofreading module in Jetpack. It checks posts for spelling, grammar, and misused words. When activated, a button is added to the visual editor to perform the checks. This button is not available in Gutenberg, so those features are not available as well.</p>

<h2>Adding Images to Paragraphs is a Pain</h2>

<p>Adding images to paragraphs in Gutenberg is more cumbersome than it needs to be. In the current editor, all I have to do is place the cursor where I want to insert an image, add media, choose image size, align it, and I&#x27;m done.</p>

<p>In Gutenberg, you need to create an image block below the paragraph block, move the image block to the paragraph block, align it, and use handlebars on the corner of the image to resize it. </p>

<p>I realize that there are a few workflows that I&#x27;m going to have to change because of how Gutenberg works, but this workflow doesn&#x27;t make any sense to me, especially when I can&#x27;t insert images without creating a new block. Thankfully, the Gutenberg team is on top of it and is <a href=\"https://github.com/WordPress/gutenberg/pull/5794\">working on a solution</a> to add images within a paragraph block.</p>

<h2>Random Blank Paragraph Blocks</h2>

<p>I recently copied a large amount of text from a Google Doc and pasted it into Gutenberg and was surprised by how well it worked. Blocks were created in the right spots and I didn&#x27;t have to edit it much.</p>

<p>I opened the post in the classic editor so that I could use the proofreading feature and it mangled the post. I opened the post in Gutenberg again and noticed a bunch of empty paragraph blocks created in-between paragraph blocks.</p>

<p>This resulted in having to spend some time deleting the empty paragraph blocks and questioning whether I should avoid transferring posts between editors in the future.</p>

<h2>Tags Sometimes Appear Blank in the Meta Box</h2>

<p>When adding tags to posts, sometimes the tags appear blank although they show up on the front-end. Also, deleting tags sometimes doesn&#x27;t work. I click on the X and nothing happens in the back-end, but the tag will be removed from the front-end. <br /></p>

<img />
    Blank Tags in Gutenberg


<h2>Gutenberg Has a Lot of Rough Edges</h2>

<p>If this version of Gutenberg were merged into WordPress today, it would be a disaster. It&#x27;s clear that the project has a long way to go before being considered for merge into core. Most of the issues I&#x27;ve outlined in this post are known and are being addressed. <br /></p>

<p>Gutenberg is supposed to make everything we do in the current editor easier and more efficient. If it doesn&#x27;t, then I have to ask, what&#x27;s the point?</p>

<p>What concerns me the most about Gutenberg is plugin support. Some of the plugins I mentioned above are active on 10K sites or less but are important to the way I craft and publish content in WordPress. <br /></p>

<p> Without them, using Gutenberg is not a great experience and instead, makes me want to use the current editor where things simply work. <br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Mar 2018 20:28:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"HeroPress: Giving Back In Your Own Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2490\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:133:\"https://heropress.com/giving-back-in-your-own-community/#utm_source=rss&utm_medium=rss&utm_campaign=giving-back-in-your-own-community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3298:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2015/11/GoodtimeToBe-HeroPress-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull quote: It is a good time to be part of the global WordPress community: the costs are low, the developer community is strong, and job availability is at an all time high.\" /><p>I was delighted to find several years ago that there&#8217;s a thriving WordPress community in Nepal. Via Slack I got to meet Sakin Shrestha, and learned all about what their group is doing in Nepal to create jobs and keep the Nepali from having to leave the country to find work.</p>
<p>I recently found out that Sakin is finding a new way to give back to his community: <a href=\"https://sakinshrestha.com/events/announcing-my-new-venture-aksharaa-kindergarten/\">opening a kindergarten</a>. In order for any country to grow strong it has to have good education for its children, and Sakin is working to make that happen.</p>
<p>Read about how the Nepali WordPress community is working to build their own country.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/doing-our-part-for-the-community/\">Doing Our Part for the Community</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Giving Back In Your Own Community\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Giving%20Back%20In%20Your%20Own%20Community&via=heropress&url=https%3A%2F%2Fheropress.com%2Fgiving-back-in-your-own-community%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Giving Back In Your Own Community\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fgiving-back-in-your-own-community%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fgiving-back-in-your-own-community%2F&title=Giving+Back+In+Your+Own+Community\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Giving Back In Your Own Community\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/giving-back-in-your-own-community/&media=https://heropress.com/wp-content/uploads/2015/11/GoodtimeToBe-HeroPress-150x150.jpg&description=Giving Back In Your Own Community\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Giving Back In Your Own Community\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/giving-back-in-your-own-community/\" title=\"Giving Back In Your Own Community\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/giving-back-in-your-own-community/\">Giving Back In Your Own Community</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Mar 2018 14:21:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:119:\"WPTavern: In WordPress 4.9.5, Users Will Be Two Clicks Away From Installing and Activating Gutenberg From the Dashboard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78827\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:129:\"https://wptavern.com/in-wordpress-4-9-5-users-will-be-two-clicks-away-from-installing-and-activating-gutenberg-from-the-dashboard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3920:\"<p>At the end of last month, Matt Cromwell, Head of Support and Community Outreach for <a href=\"https://givewp.com/\">GiveWP</a> and an administrator for the <a href=\"https://www.facebook.com/groups/advancedwp/\">Advanced WordPress Facebook group</a>, hosted a <a href=\"https://wptavern.com/matt-cromwell-hosts-matt-mullenweg-in-qa-gutenberg-interview\">question and answer session</a> about Gutenberg with Matt Mullenweg.</p>

<p>Mullenweg was asked a few times if he could provide a concrete date on when Gutenberg and WordPress 5.0 would be ready. While a date was not given, Mullenweg said, \"For those who want a concrete date, we will have one or two orders of magnitude more users of Gutenberg in April.\"</p>

<p>It&#x27;s now clear what he meant by that. WordPress 4.9.5, scheduled for release in April, will <a href=\"https://core.trac.wordpress.org/ticket/41316\">feature a call-out prompt</a> that has links to information about Gutenberg and a button to quickly install the plugin if user permissions allow. <br /></p>

<img />
    Gutenberg Call-out in WordPress 4.9.5


<p>The core team added a Try Gutenberg prompt in October of last year but <a href=\"https://wptavern.com/wordpress-4-9-beta-4-removes-try-gutenberg-call-to-action\">it was removed</a> in WordPress 4.9 Beta 4. After discussing the subject with Mullenweg, it was determined that Gutenberg was not ready for large-scale testing.</p>

<p>The prompt in WordPress 4.9.5 changes the button text based on the following scenarios.<br /></p>

<ul>
    <li>If Gutenberg is not installed, <em>and</em> the user can install plugins, the Install Today button is displayed.<br /></li>
    <li>If Gutenberg is installed but not activated, <em>and</em> the user can install plugins, the Activate Today button is displayed.<br /></li>
    <li>If Gutenberg is installed and activated, <em>and</em> the user can edit posts, the Try Today button is displayed.<br /></li>
</ul>

<p>If Gutenberg is not installed and the user can not install plugins, the button is hidden from view. If you&#x27;d like to hide the prompt from users, David Decker has <a href=\"https://github.com/deckerweb/remove-gutenberg-panel\">created a plugin</a> that&#x27;s available on GitHub that simply hides it from view.</p>

<p>One of the concerns about the prompt is the lack of warning of the risks involved using beta software on a live site. Gutenberg is beta software that&#x27;s still in development that could <a href=\"https://core.trac.wordpress.org/ticket/41316#comment:75\">adversely affect sites</a>. There is no warning on the call-out box and in two clicks, users can install and activate Gutenberg. <br /></p>

<p>Whether it&#x27;s Gutenberg or some other beta software, this general advice applies. Create a full backup of your site before installing and if possible, install it on a staging site first.</p>

<p>I predict that the volunteers who manage the WordPress.org support forums will have their hands full once WordPress 4.9.5 is released. The support team <a href=\"https://make.wordpress.org/support/2018/03/agenda-for-march-22nd-support-meeting/\">is preparing</a> by brainstorming user outcomes, common questions that may be asked, and potential pitfalls users experience after installing Gutenberg. <br /></p>

<p>If you&#x27;d like to give them a helping hand, check out the <a href=\"https://make.wordpress.org/support/handbook/\">Support Handbook</a> and if you have any questions, stop by the <a href=\"https://wordpress.slack.com/?redir=%2Fmessages%2Fforums%2F\">#forums</a> channel in <a href=\"https://make.wordpress.org/chat/\">Slack</a>.</p>

<p>The Gutenberg call-out has the potential to pave the way for large audiences to test major features in core without needing to use or install a beta branch of WordPress. However, this convenience comes with risks and while they can be reduced, WordPress needs to be up front and center to users about those risks.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 27 Mar 2018 22:55:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"WPTavern: Why Gutenberg and Why Now?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78707\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wptavern.com/why-gutenberg-and-why-now\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:17921:\"<img />

<p>Tevya Washburn has been building websites for more than 20 years and building them on WordPress for 10. He bootstrapped his website maintenance and support company, <a href=\"http://wordx.press\">WordXpress</a>, that he’s worked on full-time for more than seven years.</p>

<p>Late last year he launched his first premium plugin, and presented at WordCamp Salt Lake City. He lives in Caldwell, ID and is the founding member of the WordPress Meetup group in Western Idaho. <br /></p>

<hr />

<p>It was only a few months ago that I knew almost nothing about WordPress’ new Gutenberg editor. I had a basic concept of what it was and this vague annoyance that it would mean I’d have to learn new things and probably put a lot of effort into making some sites or projects work with it.</p>

<p>I kept hearing all of the frustration and issues with Gutenberg itself and the lack of information on how to integrate with it. At <a href=\"https://wordx.press\">WordX</a>p<a href=\"https://wordx.press\">ress</a> we recently pivoted away from designing websites. When we designed them in the past, we used premium themes. I figured Gutenberg was the theme developer’s problem.<br /></p>

<p>I still had this feeling of dread though, knowing many of my favorite plugins might not add support for it. I also felt some apprehension that even if the themes we use did add support for it, they might have a lot of new bugs through the first few releases.</p>

<p>Then I launched my first WordPress plugin, <a href=\"https://starfishwp.com\">Starfish Reviews</a>, and suddenly they weren’t someone else’s problems anymore! Now I’d have to come up with a plan to integrate our plugin with Gutenberg. I installed the Gutenberg plugin on a test site where we were testing our plugin with the nightly releases of WordPress and started playing around with it.</p>

<p>I was pleasantly surprised at how intuitive and easy it was to use! Now it wasn’t (and isn’t) finished, so there were bugs and annoyances, but overall I was impressed.</p>

<p>Around the same time, I suggested we should have someone present on Gutenberg at our local meetup. My brief experience was more than what anyone else had, so the responsibility fell on me. Preparing for the presentation forced me to look at Gutenberg more carefully and pay more attention to the information and debate going on throughout the community.</p>

<p>I started reading blog posts, paying more attention in podcasts, and even looking at what was being said on Twitter. I watched the State of the Word at WordCamp US where the general tide in the feelings toward Gutenberg, seemed to turn, though many people still remain skeptical, critical, or antagonistic toward the project as a whole.</p>

<p>Today, I saw someone suggesting legal action if Gutenberg caused problems on their sites. That’s ridiculous on several levels, but shows that there’s still a lot of suspicion, frustration, and outright anger around Gutenberg.</p>

<p><em>A couple notes: 1. the graphs below are for illustration purposes only, they’re not meant to be accurate to any actual data. 2. If you prefer listening, you can </em><a href=\"https://www.youtube.com/watch?v=S4ZqrVJ465E\"><em>watch my screencast version</em></a><em> (13:12) of what follows. The message is the same, but differs in many aspects of presentation.</em></p>

<h2><strong>Finding the Why</strong></h2>

<p>Simon Sinek is known for <a href=\"https://www.youtube.com/watch?v=u4ZoJKF_VuA\">his Ted talk</a> where he explains that most people explain a new product or service by talking about ‘what’ it is and ‘how’ it works, but they rarely explain the ‘why’ behind it. The ‘why’ actually resonates with people the most. They want to understand the reason and beliefs behind it.</p>

<p>In my research, I couldn’t seem to find a clear answer to the most important question: “Why Gutenberg?” If I was going to present to people who knew little or nothing about it, I wanted to provide a reason why this major change was coming that might cause significant frustration, work, and pain for them.</p>

<img />

<p>I found a lot of ‘what’ and ‘how’ about Gutenberg. In some posts by <a href=\"https://ma.tt/2017/08/we-called-it-gutenberg-for-a-reason/\">Matt Mullenweg</a> and <a href=\"https://matiasventura.com/post/gutenberg-or-the-ship-of-theseus/\">Matías Ventura</a>, I found hints about ‘why’ Gutenberg existed, but no really clear, simple explanation of why this whole project was happening. Why would Matt and others want to seemingly force this major change on us all? Why does it have to be such a radical departure from the past? Why now?</p>

<p>I was certain the conspiracy theorists—who seem to believe that Automattic’s sole mission is to make their lives more miserable—were wrong. But what was the purpose? Could it really just be a <strong>me too</strong> attitude that left all of these brilliant minds feeling like they had to keep up with Squarespace and Medium? That didn’t seem to fit. Especially since Gutenberg is already leagues better than Squarespace’s convoluted visual editor.</p>

<h2><strong>Innovative Disruption</strong></h2>

<img />
    The Innovator&#x27;s Dilemma Book Cover


<p>Taking cues from those hints and suggestions, I started thinking about the innovative disruption model. It was popularized in business circles, starting in 1997 when the book “<a href=\"https://en.wikipedia.org/wiki/The_Innovator%27s_Dilemma\">The Innovator’s Dilemma</a>” was published by Clayton Christensen, a Harvard professor. His book was an expansion of an <a href=\"https://hbr.org/1995/01/disruptive-technologies-catching-the-wave\">earlier article</a> in the Harvard Business Review.</p>

<p>At the risk of oversimplifying the model, innovative disruption is what happens when an existing company who is the top dog (either in sales or market share) gets comfortable with their position at the top along with their revenue stream and quits innovating. They make small, incremental updates to their products or services to keep customers happy, but fail to look at the future of their industry.</p>

<p>This makes it easier for a startup or smaller, more innovative company to bring a new product or service to market that completely disrupts the existing market because it’s better, faster, cheaper. The established company doesn’t see the disruption coming because they feel secure in their large market share and steady sales revenue. They often respond with “why would anyone want that?” when approached with the new model that is about to completely upset their business model.</p>

<h2><strong>Blockbuster Gets Busted</strong></h2>

<p>The classic example of this is Blockbuster Entertainment, Inc. They had over 9,000 stores at one time, allowing people to rent VHS tapes and later, DVDs. They had a huge portion of the market all to themselves and it seemed nobody could compete with this juggernaut.</p>

<p>Then along came two small startups: Netflix and Redbox. Netflix comes along and says “we’re going to stream movies over the internet. That’s the future and the way everyone will want to consume movies and TV in the future. But since the internet is too slow right now, we’ll just start by mailing DVDs to people.”</p>

<p>Blockbuster looked at this and said, “the internet is <em>way</em> too slow to stream movies. That’s ridiculous! Who wants to wait two weeks to get a movie in the mail?! Hahaha! Stupid startup, they’re wasting their money and energy.” In hindsight this seems ridiculous. At the time, most people would have agreed with Blockbuster.</p>

<p>As you know, people started changing the way they rented movies. Once they tried it, they were happy to pay a subscription and use a queue to get DVDs delivered in the mail. Ultimately, making the decision of what to watch ahead of time was better than wandering through a cathedral of DVDs only to find the one you wanted to watch has already been checked out.</p>

<p>Consumer internet bandwidth speeds quickly caught up. Netflix even invented some of the technologies that provide high quality streaming video to your home. Now, most of us can’t imagine having to go to the store to rent a physical copy of a movie. And those that can, get them from a Redbox kiosk that has a limited selection, but is much quicker and easier than a video store. Netflix now has a larger market share than Blockbuster ever did, with <em>zero</em> physical locations.</p>

<img />

<p>There are exactly nine Blockbuster stores still operating, mostly in Alaska. From 9,000 down to nine in only a few years! This is what failing to innovate does. This is how comfort and confidence in market share and sales blinds people and organizations to the coming innovations that will disrupt their market.</p>

<h2><strong>Literacy, Disruption, and Gutenberg</strong></h2>

<p>Disruptive innovation doesn’t apply just in business. I have a Bachelor’s degree in history. So one example I love to use is how literacy and education ultimately toppled monarchies and traditional power structures in favor of republics and representative democracy.</p>

<p>The choice of Gutenberg as the name of the new WordPress editor seems prescient in this example as well. The name was one of the clues that led me to answer the ‘why?’ question. It was Johannes Gutenberg and his movable type printing press that was the innovative disruption that changed everything!</p>

<p>Before that, the vast majority of people in Europe were illiterate and uneducated. The scarcity of books and written material made it impractical and prohibitively expensive for most people to learn to read. It also allowed the Church and aristocracy to control the opportunity to become literate. That meant the rich and powerful were the gatekeepers of knowledge. Most riots and uprisings to this point were about hunger.</p>

<p>The Gutenberg press changed all that. Suddenly books could be mass-produced faster, cheaper, better than they ever could before. Literacy caught on like a wildfire. The power structures thought they could control it and maintain the status quo. They outlawed printing without state approval and did many other things to limit the spread of ideas through printed materials.</p>

<p>But it was too late, the power to spread ideas that the printing press provided was much too viral. Many printing presses were operated illegally, then destroyed when they were discovered by authorities.</p>

<img />

<p>The tipping point had been reached though. The ability to read and spread ideas via printed documents was much more powerful than the money, soldiers, and weapons of the monarchy. Though hunger might have sparked riots and uprisings from this time on, those tiny flames were fanned into an inferno of revolution by ideas spread through printed words. <a href=\"https://en.wikipedia.org/wiki/Thomas_Paine\">Thomas Paine</a>’s Common Sense is a great example if you want to learn more about concrete examples.</p>

<h2><strong>The Pain of Disrupting Yourself</strong></h2>

<p>I don’t have a business degree, but from my understanding, <em>The Innovator’s Dilemma</em> can be simplified down to this: to survive, and stay on top, a company (or software, or community) must innovate. It <em>can not</em> be incremental innovation. It <em>must</em> be innovation that disrupts the company’s core product or business model, even to the point of entirely replacing it.</p>

<p>Blockbuster tried some Redbox-like and Netflix-like solutions, but they were too little, too late. The only way they could have survived would have been to disrupt their own business model and service. They would have had to say, “in five years we will close all 9k stores and completely shift our business to providing video online.”</p>

<p>Who does that? Who thinks “we have built an empire, but we have to completely change it and replace it all over again”? That’s “The Innovator’s Dilemma” that the book’s title refers to: it’s incredibly difficult to think in those terms when you’re on the top. It’s nearly impossible to say, “we have to disrupt ourselves. We must compete with our own business and products and services.” But ultimately it’s the only way to survive.</p>

<p>…Or you can buy an innovative company and let them disrupt your main business. Did you know Blockbuster had the <a href=\"http://www.businessinsider.com/blockbuster-ceo-passed-up-chance-to-buy-netflix-for-50-million-2015-7\">chance to buy Netflix</a> for $50 million in 2000? It was pocket change, but they passed because it was a very small, niche business.</p>

<p>Had they bought Netflix and allowed it to continue innovating and disrupting their core retail rental model, Blockbuster might still be around. It wouldn’t have 9k retail stores, but it would have an even larger market share than it ever did renting DVDs.</p>

<img />

<p>In either case, the process is painful. That’s why it’s called disruptive. Not because it’s a walk on the beach or small speed bump, but because it takes a lot of work and forward-thinking and causes a lot of pain to create and implement.</p>

<p>If you are the market leader, you can’t rest on your previous success. You have to change everything once again, like you did to get to where you are now. Despite the pain of doing it, you have to invest yourself and your resources into hard work and difficult questions and challenging thinking that goes directly counter to our natural tendency as humans. If you want to stay on top, it’s the only way.</p>

<h2><strong>WordPress is Ripe for Disruption</strong></h2>

<p>WordPress has a 30% market share right now. It won’t be long before 1 out of every 3 websites is built on WordPress. No other platform is even close.</p>

<p>As WordPress professionals and community members, it seems like we have all the momentum and benefits of being the leader. “Surely nothing could displace WordPress!” That’s what Blockbuster said. That’s what monarchs of past ages said. The truth is simple: “yes, something could. In fact, something will, if WordPress doesn’t innovatively disrupt itself.”</p>

<img />

<p>Is it going to be painful? Yes. Is it going to cause a lot of work and effort on the part of the community? Yes! Absolutely. But the alternative is to learn a totally new platform in five years when WordPress dies like Blockbuster did. You think this change is going to be difficult? Try throwing out WordPress entirely and moving your website(s) to an entirely new platform. Because that’s the alternative.</p>

<h2><strong>Good Arguments Against Gutenberg</strong></h2>

<p>I see many people listing a string of bugs in the Gutenberg UI/UX and concluding that Gutenberg shouldn’t exist. I see others critiquing the underlying technologies and claiming that’s evidence that Gutenberg is entirely wrong.</p>

<p>I’m sorry, but those arguments are entirely invalid. They may be great arguments for how Gutenberg needs to change or improve, but they are <em>not</em> valid arguments against the existence of Gutenberg and its inclusion in core.</p>

<p>Hopefully, I’ve made it clear that WordPress is in dire need of innovation. If that’s true, then as I see it, there’s only one really great argument against Gutenberg. As one person in one of the meetups I presented at put it: “is it the right innovation?”</p>

<p>That&#x27;s the crux of the whole thing: <strong>WordPress must innovate to survive</strong>. Matt Mullenweg and the entire Gutenberg team have looked at the past and the future and decided that a better, faster, easier user interface and experience, are the disruptive innovations that WordPress needs to survive.</p>

<p>You can argue that it’s not, that there’s some other innovation that will completely change WordPress and thereby save it from disruption by outside forces. And that&#x27;s a totally valid argument to make. But in my opinion, <strong>you can’t argue that continued, incremental changes are enough.</strong> You can’t argue that the path we’ve been on the last five years is going to keep WordPress on top for the next five years. It simply won’t.</p>

<h2><strong>I Like Gutenberg, but I Love What it’s Doing</strong></h2>

<p>In my experience thus far, I like Gutenberg. I believe it is the right disruptive innovation WordPress needs at this time. It will make WordPress easier to use and help its underpinnings be ready for the future. Being easy to use is what got WordPress where it is today.</p>

<p>It’s not very easy to use any more. There are significantly easier options out there, that could disrupt WordPress and replace it. I think Gutenberg will allow WordPress to disrupt itself and keep ahead of other disruptive innovations. It will save WordPress and allow us all to keep using it and building our businesses on it for another 10 years into the future.</p>

<p>I like Gutenberg, but I really love what Gutenberg means, what it represents, and what it&#x27;s doing. Gutenberg is bigger than just a new post editor, it shows that the leaders of the WordPress community are willing to make hard decisions and innovate even when it means disrupting their own work and previous innovations.</p>

<img />

<p>I have huge respect for the Gutenberg team, who have not only had to rethink everything and do all those difficult things I referred to before, but have had to do it all very publicly, while navigating a gauntlet of criticism, personal attacks, and much more.</p>

<p>I hope this post shows my thanks and newfound appreciation for what they’re doing and going through. Flipping the phrase from <em>The Dark Knight,</em> the members of the Gutenberg team are “the heroes the WordPress community needs right now, even if they’re not the ones we deserve.”</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 26 Mar 2018 18:20:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"Post Status: The Future of Content Distribution — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=44599\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://poststatus.com/future-content-distribution-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2385:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p><span>This week the Brians put their brains together and discuss content distribution across various mediums and platforms as well as subscriptions for both digital and physical products. The conversation shifts between different tooling and platforms that exist for enabling content distribution as well as some of the societal shifts that have shaped how we share and consume both content and products. </span></p>
<p><span>This is a good episode for anyone who is developing sites and selling solutions around content distribution or subscriptions as well as anyone who is running (or looking to run) a business based around a subscriber model (paid or otherwise).</span></p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://make.wordpress.org/marketing/2018/02/28/wordpress-jargon-glossary/\">WP Jargon Glossary</a></li>
<li><a href=\"https://www.blog.google/topics/google-news-initiative/announcing-google-news-initiative/\">Google News subscription initiative</a></li>
<li><a href=\"https://woocommerce.com/2018/02/succeed-with-woocommerce-subscriptions-technical-tips/\">Brent&#8217;s blog post</a></li>
<li><a href=\"https://woocommerce.com/products/teams-woocommerce-memberships/\">Teams for WooCommerce Memberships</a></li>
<li><a href=\"https://www.recode.net/2017/12/13/16771646/target-shipt-acquisition-price-550-million-grocery-delivery-same-day\">Target acquires Shipt</a></li>
</ul>
<h3>Sponsor: Pagely</h3>
<p><a href=\"https://pagely.com\"><span>Pagely</span></a><span> offers best in class managed WordPress hosting, powered by the Amazon Cloud, the Internet’s most reliable infrastructure. Post Status is proudly hosted by Pagely. Thank you to </span><a href=\"https://pagely.com\"><span>Pagely</span></a><span> for being a Post Status partner</span></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 26 Mar 2018 13:24:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"BuddyPress: 10 years\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=271550\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://buddypress.org/2018/03/10-years/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5437:\"<p>In 2008 (just 10 short years ago) <a href=\"https://profiles.wordpress.org/apeatling\">Andy Peatling</a> made the very first code-commit to the newly adopted BuddyPress project, joining bbPress, GlotPress, and BackPress at the time. As most of you can probably imagine, BuddyPress was a different piece of software back then, trying to solve a completely different decade&#8217;s worth of problems for a completely different version of WordPress.</p>
<p>BuddyPress was multisite only, meaning it did not work on the regular version of WordPress that most people were accustomed to installing. It needed to completely take over the entire website experience to work, with a specific theme for the primary part of your site, and blog themes for user profiles and everything else.</p>
<p>There was a lot to love about the original vision and version of BuddyPress. It was ambitious, but in a clever kind of way that made everyone tilt their heads, squint their eyes, and ponder what WordPress was capable of. BuddyPress knew exactly what it was trying to do, and owned it without apologies.</p>
<p>It touted itself as a &#8220;Social Network in a box&#8221; at a time when MySpace was generating 75.9 million <em>unique</em> visitors per month, so if you couldn&#8217;t imagine how different BuddyPress may have been before, imagine how excited everyone was at the idea of owning their own MySpace.</p>
<p>Since then, Andy invited <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone</a>, <a href=\"https://profiles.wordpress.org/djpaul\">Paul</a>, and <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">me</a> to help lead the project forward, and in-turn we&#8217;ve invited several other prolific BuddyPress contributors to help with every aspect of the project, website, design, and so on.</p>
<p>The BuddyPress team has grown in a few different ways. Most recently, we&#8217;ve added <a href=\"https://profiles.wordpress.org/espellcaste\">Renato Alves</a> to the team to help with WP-CLI support. Renato is a long-time contributor who stepped up big-time to really own the WP-CLI implementation and finally see it through to the end.</p>
<p><a href=\"https://profiles.wordpress.org/slaffik\">Slava Abakumov</a> lead the 2.8 release, and we finally met in person for the very first time just last week at WordCamp Miami. He&#8217;s another long-time contributor who has always had the best interests of the project in mind and at heart.</p>
<p><a href=\"https://profiles.wordpress.org/offereins\">Laurens Offereins</a> has been helping fix BuddyPress bugs and work on evolving features since version 2.1, and while we haven&#8217;t met in person <em>yet</em>, I look forward to it someday!</p>
<p><a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a> (who you may recognize from bbPress) also works a bit on BuddyPress, largely around tooling &amp; meta related things, but he&#8217;s fully capable and will jump in and help anywhere he can, be it the forums or features.</p>
<p><a href=\"https://profiles.wordpress.org/mercime\">Mercime</a> would prefer I not blather on endlessly here about how important she is, or how much I appreciate her, or anything like that, so please forget I mentioned it.</p>
<p><a href=\"https://profiles.wordpress.org/hnla\">Hugo Ashmore</a> has spent the past 2 years completely rebuilding the default template pack. This is an absolutely huge undertaking, and everyone is really excited about sunsetting ye olde <code>bp-legacy</code>.</p>
<p><a href=\"https://profiles.wordpress.org/karmatosed\">Tammie Lister</a> has moved on to work on the enormously important and equally ambitious <a href=\"https://wordpress.org/plugins/gutenberg/\">Gutenberg</a> project. Tammie is wonderful, and doing a great job crafting what the future of democratizing publishing is.</p>
<p>Lastly, a few of our veteran team members took sabbaticals from contributing to BuddyPress in the past few years, which I see as an opportunity to return with fresh ideas and perspectives, or maybe moving onto new &amp; exciting challenges. This is a good, healthy thing to do, both for oneself and the project. Space makes the heart grow fonder, and all that.</p>
<hr />
<p>A small aside but worth saying here &amp; now, is that leading an open-source project is everything you think it is (or maybe have read already that it is) and like a million other things that are hard to understand until you understand. The one constant (and subsequently the hardest and funnest part) is how to provide opportunities for personal growth, without prohibiting contributions, while also doing what&#8217;s best for the greater vision of the project itself, amongst a completely remote group of bespoke volunteers. I think Paul, Boone, and I do OK at this, but we are always learning and adjusting, so please reach out to us if there is anything we can do differently or better.</p>
<hr />
<p>BuddyPress is my personal favorite piece of software. It&#8217;s my favorite community. I wake up excited every day because of what it can do and who it does it for. Put another way, I love what we make it do and who we make it for: ourselves, one another, each other, and you.</p>
<p>Cheers to 10 years, and here&#8217;s to another 10!</p>
<p><img class=\"alignnone wp-image-271562 size-full\" src=\"https://buddypress.org/wp-content/uploads/1/2018/03/Screen-Shot-2018-03-25-at-4.38.12-PM.png\" alt=\"\" width=\"898\" height=\"452\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 25 Mar 2018 22:54:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"JJJ\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"WPTavern: Noteworthy Changes Coming in WordPress 4.9.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78611\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wptavern.com/noteworthy-changes-coming-in-wordpress-4-9-5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2401:\"<p>WordPress 4.9.5 Beta 1 <a href=\"https://make.wordpress.org/core/2018/03/21/wordpress-4-9-5-beta/\">is available</a> for testing and brings with it 23 bug fixes and improvements. A release candidate is scheduled for release on March 20th and a final release on April 3rd. Here are some notable changes you can expect in the release.</p>

<h3>\"Cheatin’ uh?\" Error Message is Replaced</h3>

<p>The \"Cheatin’ uh?\" error message has existed in WordPress for years and for some, is insulting. The error doesn&#x27;t explain what went wrong and accuses the user of trying to cheat the system.</p>

<img />
    Cheatin&#x27; Uh Error Message<br />


<p>Eric Meyer highlighted the error in <a href=\"https://wordpress.tv/2016/06/24/eric-a-meyer-design-for-real-life/\">his keynote</a> at WordCamp North East Ohio in 2016, when talking about Designing for Real Life. He also <a href=\"https://core.trac.wordpress.org/ticket/38332#comment:11\">contributed to the ticket</a> with suggestions on how to improve the wording.</p>

<p>In WordPress 4.9.5, the error <a href=\"https://core.trac.wordpress.org/ticket/38332\">has been changed</a> to more meaningful messages depending on the error that occurs.</p>

<h3>Recommended PHP Version Increased to 7.2</h3>

<p>Inside of the readme file in WordPress, the current recommended PHP version is 7.0. This version of PHP reached end of life last December. In 4.9.5, the recommend version is PHP 7.2. This is the same version that is <a href=\"https://wordpress.org/about/requirements/\">recommended on WordPress.org</a>.</p>

<h3>Offensive Lyrics Removed From Hello Dolly</h3>

<p>As we covered <a href=\"https://wptavern.com/without-context-some-lyrics-inside-the-hello-dolly-plugin-are-degrading-to-women\">earlier this week</a>, some of the lines displayed in the dashboard from the Hello Dolly plugin are inappropriate without context. In 4.9.5, the plugin will no longer display those lines.</p>

<p>There&#x27;s a possibility that in the future, there will be a musical note icon or symbol placed next to the line to indicate it&#x27;s from a song. In addition, the lyrics are more in line with Louis Armstrong&#x27;s recording.</p>

<p>To see a full list of changes in WordPress 4.9.5, you can <a href=\"https://core.trac.wordpress.org/query?status=closed&milestone=4.9.5&group=component\">view a full list</a> of closed tickets on Trac. </p>

<p><br /></p><br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Mar 2018 21:32:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WPTavern: WPWeekly Episode 309 – All AMPed Up\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=78601&preview=true&preview_id=78601\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wptavern.com/wpweekly-episode-309-all-amped-up\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2180:\"<p>In this episode, I&#8217;m joined by <a href=\"https://medinathoughts.com/\">Alberto Medina</a>, Developer Advocate working with the Web Content Ecosystems Team at Google, and <a href=\"https://weston.ruter.net/\">Weston Ruter</a>, CTO of XWP. We have a candid conversation about <a href=\"https://www.ampproject.org/\">Google&#8217;s AMP Project</a>. We start by learning why the project was created, what its main goal is, and the technology behind it.</p>
<p>We also dive into some of the controversy surrounding the project by discussing whether or not AMP is a threat to the Open Web. Medina and Ruter provide insight into AMP&#8217;s transformation from focusing on the mobile web to providing a great user experience across the entire web. Last but not least, we learn about the relationship between Automattic, XWP, and the AMP team and how it&#8217;s helping to shape the future of the project.</p>
<h2>Notable Links Mentioned:</h2>
<p><a href=\"https://wordpress.org/plugins/amp/\">AMP for WordPress Plugin</a><br />
<a href=\"https://github.com/Automattic/amp-wp\">AMP for WordPress GitHub Repository</a><br />
<a href=\"https://github.com/ampproject\">AMP GitHub Repository</a><br />
<a href=\"https://www.youtube.com/watch?v=GGS-tKTXw4Y\">Video presentation from AMP Conf 2018 showcasing the work that&#8217;s gone into the AMP for WordPress plugin</a><br />
<a href=\"https://www.ampproject.org/latest/blog/standardizing-lessons-learned-from-amp/\">Official blog post outlining the future of the AMP Project</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, March 28th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #309:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Mar 2018 14:34:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Matt: Don’t Like Change\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47998\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"https://ma.tt/2018/03/dont-like-change/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:407:\"<blockquote class=\"wp-block-quote\">
    <p>If you don&#x27;t like change, you&#x27;re going to like irrelevance even less.</p><cite>General Eric Shinseki</cite></blockquote>

<p>I actually heard this on the <a href=\"https://www.fs.blog/2015/06/michael-lombardi/\">Farnam Street podcast with Patriots coach Michael Lombardi</a>, but it seems like General Shinseki said it first so attributing it there.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Mar 2018 00:01:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"HeroPress: Keeping Community Alive\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2487\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"https://heropress.com/keeping-community-alive/#utm_source=rss&utm_medium=rss&utm_campaign=keeping-community-alive\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3425:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2016/09/090716-David-Laietta-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Be a pillar of support for your community.\" /><p>In the last year or so I&#8217;ve been a lot more involved with the business side of WordPress than the community side. The business side isn&#8217;t nearly as loving and supportive as the community side, and some of that is out of necessity. Business is business, and people need to eat.</p>
<p>The problem comes when people get so focused on the business side of things that they forget they&#8217;re dealing with people. Recently <a href=\"https://twitter.com/carlhancock/status/971182969514799105\">Carl Hancock mentioned on twitter</a> that there are things that happen in business in the WordPress community that would horrify people. I don&#8217;t know who those people are that do those things, and I don&#8217;t even know what the things are, but I have hope that the community can be bigger and better than that.</p>
<p>There will always be selfish jerks who abuse the system for personal gain, but I have hope that the WordPress community can generally rise above that, and perhaps even change the hearts of poor players.</p>
<p>This week&#8217;s HeroPress replay is from David Laietta, about how our community changes lives.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/a-community-of-acceptance/\">A Community of Acceptance</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Keeping Community Alive\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Keeping%20Community%20Alive&via=heropress&url=https%3A%2F%2Fheropress.com%2Fkeeping-community-alive%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Keeping Community Alive\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fkeeping-community-alive%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fkeeping-community-alive%2F&title=Keeping+Community+Alive\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Keeping Community Alive\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/keeping-community-alive/&media=https://heropress.com/wp-content/uploads/2016/09/090716-David-Laietta-150x150.jpg&description=Keeping Community Alive\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Keeping Community Alive\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/keeping-community-alive/\" title=\"Keeping Community Alive\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/keeping-community-alive/\">Keeping Community Alive</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Mar 2018 15:39:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: A Plea For Plugin Developers to Stop Supporting Legacy PHP Versions\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78533\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"https://wptavern.com/a-plea-for-plugin-developers-to-stop-supporting-legacy-php-versions\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2188:\"<p>Iain Poulson has <a href=\"https://deliciousbrains.com/legacy-php-version-support/\">published a thoughtful request</a> on the Delicious Brains blog asking WordPress plugin developers to stop supporting legacy PHP versions. He covers some of the benefits of developing with newer versions of PHP, what Delicious Brains is doing with its plugins, and using the <a href=\"https://make.wordpress.org/plugins/2017/08/29/minimum-php-version-requirement/\">Requires Minimum PHP Version header</a> in readme.txt.<br /></p>

<blockquote class=\"wp-block-quote\">
    <p>While we wait for the Trac discussion to roll on and the WordPress development wheels to turn we can take action ourselves in our plugins to stop them working on installs that don’t meet our requirements. </p>
    <p>We do this in our own plugins where it is strictly necessary (<a href=\"https://deliciousbrains.com/wp-offload-s3/\">WP Offload S3</a> relies on the Amazon Web Services S3 SDK, which requires PHP 5.3.3+ and will we will <a href=\"https://deliciousbrains.com/wp-offload-s3/doc/php-version-requirements/\">move to PHP 5.5</a> in the future), and the more plugins that do this out of choice will help move the needle further.</p><cite>Iain Poulson <br type=\"_moz\" /></cite></blockquote>

<p>Poulson mentions the <a href=\"https://github.com/WordPress/servehappy\">ServeHappy project</a> in his post and it&#x27;s worth a mention here as well. The ServeHappy project was <a href=\"https://make.wordpress.org/core/2018/01/09/servehappy-roadmap/\">launched earlier this year</a> by a group of volunteers.</p>

<p>Its main goal is to reduce the number of WordPress installs running on unsupported PHP versions through education, awareness, and tools to help users update their site&#x27;s PHP versions.</p>

<p>This project is in need of contributors. If you&#x27;re interested, join the #core-php channel on <a href=\"https://make.wordpress.org/chat/\">WordPress Slack</a>. The team has meetings every Monday at 11:00 AM EDT. You can also follow the <a href=\"https://make.wordpress.org/core/tag/core-php/\">#core-php tag</a> on the Make WordPress.org Core site where links to chat logs and meeting summaries are published. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 21 Mar 2018 00:31:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: How to Disable Push Notification Requests in Firefox\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78475\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/how-to-disable-push-notification-requests-in-firefox\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1246:\"<p>Have you noticed how many sites ask if you want to enable push notifications? I&#x27;ve answered no to every request but thanks <a href=\"https://twitter.com/tkraftner/status/976116234365358081\">to a tip</a> suggested by Thomas Kräftner, you can disable requests from appearing altogether in Firefox.</p>

<p>Last week, Mozilla <a href=\"https://www.mozilla.org/en-US/firefox/59.0/releasenotes/\">released Firefox 59.0</a> and added a <a href=\"https://support.mozilla.org/en-US/kb/push-notifications-firefox\">new privacy feature</a> that allows users to block sites from sending push notification requests. To enable it, open the Options panel in Firefox 59.0 and click the Privacy&amp;Security tab.<br /></p>

<p>Scroll down to the Permissions section. Click on the Settings button for Notifications and check the box that says <em>Block new requests asking to allow notifications.﻿</em></p>

<img />
    Settings panel for Notifications


<p>Click the Save Changes button and enjoy one less thing interrupting your browsing experience.  To accomplish the same thing in Chrome, follow <a href=\"https://fieldguide.gizmodo.com/how-to-block-super-annoying-website-notification-reques-1797499616\">this tutorial published by Field Guide</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 20 Mar 2018 23:32:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"WPTavern: Without Context, Some Lyrics Inside the Hello Dolly Plugin Are Degrading to Women\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78372\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"https://wptavern.com/without-context-some-lyrics-inside-the-hello-dolly-plugin-are-degrading-to-women\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2914:\"<p>There have been <a href=\"https://core.trac.wordpress.org/ticket/11538\">many discussions</a> over the years on whether or not <a href=\"https://wordpress.org/plugins/hello-dolly/\">Hello Dolly</a> should be unbundled with WordPress. Seven years ago, it was <a href=\"https://core.trac.wordpress.org/ticket/15769\">argued</a> that the lyrics are copyrighted and could potentially violate the GPL license.</p>

<p>The latest issue with Hello Dolly is that some lyrics that appear in users dashboards with the plugin activated can be degrading to women without context.</p>

<p><blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Find her an empty lap, fellas.<br /><br />Wondering about my <a href=\"https://twitter.com/WordPress?ref_src=twsrc%5Etfw\">@WordPress</a> dashboard. Apparently they\'re lyrics. <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f643.png\" alt=\"🙃\" class=\"wp-smiley\" /> <img src=\"https://s.w.org/images/core/emoji/2.4/72x72/1f644.png\" alt=\"🙄\" class=\"wp-smiley\" /> <a href=\"https://t.co/oxNU9czr5X\">pic.twitter.com/oxNU9czr5X</a></p>&mdash; Michelle Felt (@michellefelt) <a href=\"https://twitter.com/michellefelt/status/974060334502719488?ref_src=twsrc%5Etfw\">March 14, 2018</a></blockquote></p>

<p>Two examples are:</p>

<ul>
    <li>Find her an empty lap, fellas</li>
    <li>Find her a vacant knee, fellas</li>
</ul>

<p>Joe McGill has <a href=\"https://core.trac.wordpress.org/ticket/43555\">created a trac ticket</a> proposing that those two lines be removed. \"The Hello Dolly plugin has been bundled in WordPress for many years, being a simple example of how to build a plugin for WordPress while also adding a bit of whimsy to admin,\" he said.</p>

<p>\"However, there are several passages of text from this song which are inappropriate to display without any context to people using WordPress—particularly as the WordPress project seeks to promote inclusivity for all.\"</p>

<p>The discussion within the ticket suggests creating a black list or replacing the lyrics with less offensive versions. In many of the Google search results for Hello Dolly lyrics by Jerry Herman, shows that the lyrics inside the plugin and those in the song are different.</p>

<p>The lyrics say, \"Find me a vacant knee, fellas.\" In a <a href=\"https://www.youtube.com/watch?v=RETJfq1U_gg\">video on YouTube</a> of Hello Dolly featuring Sarah Gardner singing the lyrics, she clearly says \"Find her an empty lap, fellas.\" In a YouTube video of <a href=\"https://www.youtube.com/watch?v=kmfeKUNDDYs\">Louis Armstrong singing Hello Dolly live</a>, he says \"Find her an empty lap, fellas.\"<br /></p>

<p>Putting aside the debate of which version of the lyrics are used, displaying the text above without context can and is seen as degrading women. At a time when WordPress and its community are doing what it can to be more inclusive, changing or removing the lyrics seems like an easy win. </p>

<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Mar 2018 20:45:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"WPTavern: Watch WordCamp Miami 2018 Via Free Livestream\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78359\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://wptavern.com/watch-wordcamp-miami-2018-via-free-livestream\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:618:\"<p>Tickets for the event may be sold out, but you can watch the event from anywhere thanks to a <a href=\"https://2018.miami.wordcamp.org/live/\">free livestream</a>. The stream starts today and covers both the E-Commerce and developers workshops. The stream begins tomorrow at 8:30AM EDT with separate links to <a href=\"https://bizstreams.fiu.edu/Mediasite/Play/05a25d9473ca4c919b5f29aa426bb0c01d?catalog=f4f4edd3-2dee-4302-91c6-d77c1da5f437\">morning</a> and <a href=\"https://bizstreams.fiu.edu/Mediasite/Play/30c9fdc284ce46648866ed715fd3b90d1d?catalog=f4f4edd3-2dee-4302-91c6-d77c1da5f437\">afternoon</a> sessions. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Mar 2018 16:18:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Let’s Encrypt Wildcard Certificates Are Now Available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78287\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/lets-encrypt-wildcard-certificates-are-now-available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1765:\"<p>In July of last year, <a href=\"https://letsencrypt.org/\">Let&#x27;s Encrypt</a> announced that it would begin <a href=\"https://letsencrypt.org/2017/07/06/wildcard-certificates-coming-jan-2018.html\">issuing Wildcard certificates</a> for free in January of 2018. Although a little late, the organization <a href=\"https://community.letsencrypt.org/t/acme-v2-and-wildcard-certificate-support-is-live/55579\">has announced</a> that Wildcard certificate support is now live.</p>

<p>In addition to these certificates, the organization has updated its <a href=\"https://datatracker.ietf.org/wg/acme/about/\">ACME protocol</a> to version 2.0. ACMEv2 is required for clients that want to use Wildcard certificates.</p>

<p>Wildcard certificates enable site administrators to secure all sub domains with a single certificate. This can be especially convenient for WordPress Multi-site networks.</p>

<p>Let&#x27;s Encrypt is working on transitioning all clients and subscribers to ACMEv2, though it hasn&#x27;t set a time table on when it will expire the ACMEv1 API. </p>

<p>In July of 2017, Let&#x27;s Encrypt was securing 47 million domains. Today, the organization is <a href=\"https://letsencrypt.org/stats/\">securing nearly 70 million domains with 54 million certificates</a>. In the United States, nearly 80% of sites loaded in Firefox are through HTTPS.</p>

<p>Let&#x27;s Encrypt is an open certificate authority that&#x27;s part of the non-profit <a href=\"https://letsencrypt.org/isrg/\">Internet Security Research Group</a>. It&#x27;s mission is to make 100% of the web HTTPS. Operations are financed through sponsors and donations. If this is a mission you believe in, please consider <a href=\"https://letsencrypt.org/donate/\">donating</a> to the project.<br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Mar 2018 17:23:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: WPWeekly Episode 308 – Wildcard SSL Certificates For All\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=78291&preview=true&preview_id=78291\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wptavern.com/wpweekly-episode-308-wildcard-ssl-certificates-for-all\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2349:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I discuss the news of the week including the results from the 2018 Stack Overflow survey, Tech Crunch&#8217;s rebuild, and Let&#8217;s Encrypt adding support for wildcard certificates. We also talk about Google working towards AMP or parts of it becoming official web standards. I ranted about how the mobile experience on the web sucks, and we end the show with some event news.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/stack-overflow-survey-respondents-still-rank-wordpress-among-the-most-dreadful-platforms\">Stack Overflow Survey Respondents Still Rank WordPress Among the Most Dreadful Platforms</a><br />
<a href=\"https://www.theverge.com/2018/3/8/17095078/google-amp-accelerated-mobile-page-announcement-standard-web-packaging-urls\">Inside Google’s plan to make the whole web as fast as AMP</a><br />
<a href=\"https://community.letsencrypt.org/t/acme-v2-and-wildcard-certificate-support-is-live/55579\">ACME v2 and Wildcard Certificate Support is Live</a><br />
<a href=\"https://techcrunch.com/2018/03/13/welcome-to-the-new-techcrunch/\">TechCrunch rebuilt using the REST API</a><br />
<a href=\"https://wptavern.com/wpcampus-scheduled-for-july-12-14-in-st-louis-mo\">WPCampus Scheduled for July 12-14 in St. Louis, MO</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://themeshaper.com/2018/03/07/designing-gutenberg-block-driven-themes-with-sketch/\">Designing Themes with Gutenberg Blocks and Sketch</a></p>
<p><a href=\"https://www.pioneerdj.com/en-us/product/controller/ddj-1000/black/overview/\">DDJ-1000 The 4-channel professional performance DJ controller for rekordbox dj</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, March 21st 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #308:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Mar 2018 01:09:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"HeroPress: A look back: Tamsin Taylor, Freedom Through Blogging\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=2484\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:167:\"https://heropress.com/a-look-back-tamsin-taylor-freedom-through-blogging/#utm_source=rss&utm_medium=rss&utm_campaign=a-look-back-tamsin-taylor-freedom-through-blogging\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3463:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2016/10/100516-2-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: We cannot know the end of any journey until we find ourselves there.\" /><p>In August of 2016 I saw <a href=\"https://wordpress.tv/2016/08/09/tamsin-taylor-a-heros-journey/\">a WordCamp talk on WordPress.tv</a> called &#8220;A Hero&#8217;s Journey&#8221;, and I thought that seemed like something I should know a lot more about.  A short time later I was speaking with Tamsin Taylor on Slack.</p>
<p><img class=\"aligncenter wp-image-2485 size-full\" src=\"https://s20094.pcdn.co/wp-content/uploads/2018/03/Screen-Shot-2018-03-14-at-8.46.22-AM.png\" alt=\"A greeting conversation\" width=\"356\" height=\"201\" /></p>
<p>I love telling stories, but I love hearing them more. Tamsin told me a story grief and loss, and how WordPress provided an outlet for those feelings. I hope her story resonates with you as well.</p>
<blockquote class=\"wp-embedded-content\"><p><a href=\"https://heropress.com/essays/bumpy-journey-becoming/\">The Bumpy Journey of Becoming</a></p></blockquote>
<p></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: A look back: Tamsin Taylor, Freedom Through Blogging\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=A%20look%20back%3A%20Tamsin%20Taylor%2C%20Freedom%20Through%20Blogging&via=heropress&url=https%3A%2F%2Fheropress.com%2Fa-look-back-tamsin-taylor-freedom-through-blogging%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: A look back: Tamsin Taylor, Freedom Through Blogging\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fa-look-back-tamsin-taylor-freedom-through-blogging%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fa-look-back-tamsin-taylor-freedom-through-blogging%2F&title=A+look+back%3A+Tamsin+Taylor%2C+Freedom+Through+Blogging\" rel=\"nofollow\" target=\"_blank\" title=\"Share: A look back: Tamsin Taylor, Freedom Through Blogging\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/a-look-back-tamsin-taylor-freedom-through-blogging/&media=https://heropress.com/wp-content/uploads/2016/10/100516-2-150x150.jpg&description=A look back: Tamsin Taylor, Freedom Through Blogging\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: A look back: Tamsin Taylor, Freedom Through Blogging\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/a-look-back-tamsin-taylor-freedom-through-blogging/\" title=\"A look back: Tamsin Taylor, Freedom Through Blogging\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/a-look-back-tamsin-taylor-freedom-through-blogging/\">A look back: Tamsin Taylor, Freedom Through Blogging</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 14 Mar 2018 12:46:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"WPTavern: Stack Overflow Survey Respondents Still Rank WordPress Among the Most Dreadful Platforms\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78278\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:109:\"https://wptavern.com/stack-overflow-survey-respondents-still-rank-wordpress-among-the-most-dreadful-platforms\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2902:\"<p><a href=\"https://stackoverflow.com/\">Stack Overflow</a>, a Q&amp;A community for developers, has published the results of <a href=\"https://insights.stackoverflow.com/survey/2018/\">its 2018 developer survey</a>. The survey was held between January 8th through the 28th and includes responses from 101,592 software developers from 183 countries across the world. This is nearly twice the amount of responses compared to <a href=\"https://insights.stackoverflow.com/survey/2017#methodology\">last year&#8217;s survey</a>.</p>
<p><a href=\"https://insights.stackoverflow.com/survey/2017#technology-most-loved-dreaded-and-wanted-platforms\">Last year</a>, WordPress was the third most dreaded software platform behind Salesforce and SharePoint. This year, WordPress has improved in the rankings and is the sixth most dreaded platform. Respondents found Windows Phone, Mainframe, Salesforce, Drupal, and SharePoint to be more dreadful.</p>
<img />WordPress is the sixth most dreaded software platform
<p>Despite making headway, WordPress has <a href=\"https://wptavern.com/stack-overflow-developer-survey-ranks-wordpress-as-the-3rd-most-dreaded-technology\">consistently ranked near the top</a> in Stack Overflow&#8217;s survey for most dreadful platform. Asking developers why is probably akin to opening <a href=\"https://en.wikipedia.org/wiki/Pandora%27s_box\">Pandora&#8217;s box</a>.</p>
<p>JavaScript was once again the <a href=\"https://insights.stackoverflow.com/survey/2018/#most-popular-technologies\">most popular technology</a> with HTML, CSS, and SQL following closely behind. Among the various JavaScript frameworks and libraries that exist, <a href=\"https://insights.stackoverflow.com/survey/2018/#technology-frameworks-libraries-and-tools\">Node.js is the most commonly used</a> followed by Angular and React.</p>
<p>The survey introduced a few new topics this year, including questions about <a href=\"https://insights.stackoverflow.com/survey/2018/#technology-and-society\">artificial intelligence</a> and ethics. When <a href=\"https://insights.stackoverflow.com/survey/2018/#work-what-would-developers-do-if-asked-to-write-code-for-an-unethical-purpose\">posed with a hypothetical situation</a> in which a developer was asked if they would write code for unethical purposes, more than half of the respondents said no. Also of note is that <a href=\"https://insights.stackoverflow.com/survey/2018/#developer-profile-contributing-to-open-source\">less than half</a> of the respondents say they contribute to open source.</p>
<p>There are a lot of interesting data points in the survey. I encourage you to <a href=\"https://insights.stackoverflow.com/survey/2018/#overview\">check out the results</a> and let me know in the comments what sticks out to you.</p>
<p><strong>Updated 3/14/2018</strong> Corrected to say that WordPress has improved in the rankings and is therefor, less dreadful than before.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 14 Mar 2018 10:08:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: WPCampus Scheduled for July 12-14 in St. Louis, MO\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78273\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wptavern.com/wpcampus-scheduled-for-july-12-14-in-st-louis-mo\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1138:\"<p><a href=\"https://2018.wpcampus.org/about/\">WPCampus</a>, an in-person conference dedicated to WordPress in higher education <a href=\"https://2018.wpcampus.org/\">has announced</a> its third annual event will be held July 12-14 at <a href=\"https://wustl.edu/\">Washington University</a> in St. Louis, MO. The <a href=\"https://2018.wpcampus.org/call-for-speakers/application/\">call for speakers</a> is open until April 7th. The event is two months after <a href=\"https://2018.stlouis.wordcamp.org/\">WordCamp St. Louis </a>which will also be held at Washington University.</p>
<p>WPCampus held its first event in 2016 in Sarasota, FL, and its second in 2017 in Buffalo, NY. The schedule is not yet finalized but to get an idea on what to expect, check out the <a href=\"http://wpcampus.org/videos/\">video presentations</a> from previous events. Organizers expect about 200 attendees and are accepting <a href=\"https://2018.wpcampus.org/sponsors/\">sponsorship inquiries</a>.</p>
<p>Tickets are not yet available but those interested in attending can sign up to the WPCampus mailing list where ticket information will be distributed first.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 13 Mar 2018 00:12:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"Post Status: Network effects and WordPress — Draft podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=44341\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://poststatus.com/network-effects-wordpress-draft-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2200:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard and co-host Brian Richards.</p>
<p>In this episode, Brian and Brian discuss the power of network effects and how they relate to WordPress’ increasing market share and maturity. WordPress has recently hit two major milestones, turning 15 years old and reaching 30% market share of the top 10 million websites, and we spend this episode reflecting on the innovations that brought us here and where innovations are likely to occur over the next 10 years.</p>
<p>We’ve come quite a long way in these 15 years. From the famous 5-minute install to being entirely pre-installed. From a supportive band of volunteers and vast ecosystem of free software to the commercially supported and highly-polished products that exist today. There is a lot about WordPress to be thankful for, and a lot of great things that will exist in the future because of it. And you can hear a bit about all of that on this episode of the Post Status Draft podcast.</p>
<p></p>
<h3>Links</h3>
<ul>
<li><a href=\"https://medium.com/evergreen-business-weekly/the-power-of-network-effects-why-they-make-such-valuable-companies-and-how-to-harness-them-5d3fbc3659f8\">The Power of Network Effects</a></li>
<li>Mel Choice&#8217;s LoopConf presentation on <a href=\"https://loopconf.com/talk/customizing-the-future/\">Customizing the Future</a></li>
</ul>
<h3>Sponsor: Yoast</h3>
<p>Yoast SEO Premium gives you 24/7 support from a great support team and extra features such as a redirect manager, recommended internal links, tutorial videos and integration with Google Webmaster Tools! Check out <a href=\"https://yoast.com/\">Yoast SEO Premium</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 10 Mar 2018 20:18:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Katie Richards\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: Yoast Launches Fund to Increase Speaker Diversity at Tech Conferences\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=78248\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://wptavern.com/yoast-launches-fund-to-increase-speaker-diversity-at-tech-conferences\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1421:\"<p>In an effort to increase speaker diversity at conferences worldwide, the team at Yoast SEO has <a href=\"https://yoast.com/yoast-diversity-fund/\">launched</a> a diversity fund. The fund will pledge a minimum of €25,000 each year. Its purpose is to remove the financial burdens that can cause minorities or underrepresented groups to speak at conferences.</p>
<p>&#8220;There are WordCamps throughout the world, these are conferences about, by and for the WordPress community,&#8221; Joost de Valk said.</p>
<p>&#8220;While we already sponsor a lot of them, they tend to not have the budget to pay for speakers’ travel and accommodation cost. The same applies to other conferences about open source, certainly those that are not commercially run. We want to take away that particular reason for not having a diverse conference.&#8221;</p>
<p>Eligible candidates will be reimbursed €1,000 for travel and accommodations per event. In order to qualify for the fund, speakers must meet the following requirements:</p>
<ul>
<li>Is a part of – or identifies as part of – a typically underrepresented group.</li>
<li>The conference is not commercial.</li>
<li>The conference targets either the WordPress, Magento, or TYPO3 community.</li>
<li>Has been accepted as a speaker to the conference.</li>
</ul>
<p>To submit an application, email diversity-fund at yoast.com where applications are reviewed within a week.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2018 03:20:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: WPWeekly Episode 307 – Thirty Percent of the Web\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=78242&preview=true&preview_id=78242\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wptavern.com/wpweekly-episode-307-thirty-percent-of-the-web\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2423:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I start with a continued discussion of AMP from last week. We cover the big releases of the week including Jetpack, Genesis, Yoast SEO, and Gutenberg. We discuss a new project that aims to determine Gutenberg compatible plugins, debate the terminology used to describe WordPress&#8217; market share, and a new plugin that makes WordPress updates more secure.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://make.wordpress.org/core/2018/03/02/whats-new-in-gutenberg-2nd-march/\">Gutenberg 2.3, Now With Nested Blocks</a><br />
<a href=\"https://studiopress.blog/genesis-2-6/\">Genesis 2.6</a><br />
<a href=\"https://yoast.com/yoast-seo-7-0/\">Yoast SEO 7.0</a><br />
<a href=\"https://jetpack.com/category/releases/\">Jetpack 5.9</a><br />
<a href=\"https://wptavern.com/4500-plugins-need-your-help-in-determining-gutenberg-compatibility\">4,500 Plugins Need Your Help in Determining Gutenberg Compatibility</a><br />
<a href=\"https://wptavern.com/new-plugin-makes-wordpress-core-updates-more-secure-by-requiring-cryptographic-signature-verification\">New Plugin Makes WordPress Core Updates More Secure by Requiring Cryptographic Signature Verification</a><br />
<a href=\"https://wptavern.com/wordpress-now-used-on-30-of-the-top-10-million-sites\">WordPress Now Used on 30% of the Top 10 Million Sites</a></p>
<h2>Picks of the Week:</h2>
<p>Mel Choyce&#8217;s presentation on <a href=\"https://wptavern.com/conceptual-ideas-on-how-the-customizer-could-integrate-with-gutenberg\">Customizing the Future</a> at LoopConf.</p>
<p>Felix Arntz&#8217;s presentation on a Global Admin, a <a href=\"https://www.youtube.com/watch?v=V085zCBdRfc\">deep dive into multi-network organization</a> at LoopConf.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, February 14th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>
<p><strong>Listen To Episode #307:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Mar 2018 03:39:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 20 Apr 2018 03:59:21 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Fri, 20 Apr 2018 03:45:27 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20180420035603\";}","no");
INSERT INTO `bak_options` VALUES("888","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1524239962","no");
INSERT INTO `bak_options` VALUES("889","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1524196762","no");
INSERT INTO `bak_options` VALUES("890","_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b","1524239962","no");
INSERT INTO `bak_options` VALUES("891","_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2018/04/gdpr-compliance-tools-in-wordpress/\'>GDPR Compliance Tools in WordPress</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/gutenberg-2-7-released-adds-ability-to-edit-permalinks\'>WPTavern: Gutenberg 2.7 Released, Adds Ability to Edit Permalinks</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/wordpress-accessibility-team-is-seeking-contributors-for-its-handbook-project\'>WPTavern: WordPress Accessibility Team Is Seeking Contributors for Its Handbook Project</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/buddypress-3-0-beta-2-released\'>WPTavern: BuddyPress 3.0 Beta 2 Released</a></li></ul></div>","no");
INSERT INTO `bak_options` VALUES("892","_transient_timeout_plugin_slugs","1524283298","no");
INSERT INTO `bak_options` VALUES("893","_transient_plugin_slugs","a:7:{i:0;s:19:\"akismet/akismet.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:9:\"hello.php\";i:4;s:14:\"types/wpcf.php\";i:5;s:31:\"wp-term-order/wp-term-order.php\";i:6;s:24:\"wordpress-seo/wp-seo.php\";}","no");
INSERT INTO `bak_options` VALUES("894","aiowpsec_db_version","1.9","yes");
INSERT INTO `bak_options` VALUES("895","aio_wp_security_configs","a:86:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:19:\"ptson.snh@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"iso6b36cqv0mpdfl22oy\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"ii7y5zs52jmb2173u36b\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";s:1:\"4\";s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";s:1:\"2\";s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:19:\"ptson.snh@gmail.com\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:19:\"ptson.snh@gmail.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";}","yes");
INSERT INTO `bak_options` VALUES("896","_transient_timeout_users_online","1524198697","no");
INSERT INTO `bak_options` VALUES("897","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1524196897;s:10:\"ip_address\";s:9:\"127.0.0.1\";}}","no");


DROP TABLE IF EXISTS `bak_postmeta`;

CREATE TABLE `bak_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=884 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bak_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `bak_postmeta` VALUES("8","7","_wp_types_group_post_types",",,product,");
INSERT INTO `bak_postmeta` VALUES("9","7","_wp_types_group_templates",",,,,,,,");
INSERT INTO `bak_postmeta` VALUES("10","7","_wp_types_group_terms","all");
INSERT INTO `bak_postmeta` VALUES("11","7","_toolset_edit_last","1523595446");
INSERT INTO `bak_postmeta` VALUES("12","7","_wp_types_group_filters_association","any");
INSERT INTO `bak_postmeta` VALUES("13","7","_wp_types_group_fields",",product_display_price,product_sell_price,product_code,num_cook,product_promotion,product_guarantee,show,");
INSERT INTO `bak_postmeta` VALUES("16","10","_wp_attached_file","2018/03/EH-MIX333.jpg");
INSERT INTO `bak_postmeta` VALUES("17","10","_wp_attachment_metadata","a:5:{s:5:\"width\";i:900;s:6:\"height\";i:600;s:4:\"file\";s:21:\"2018/03/EH-MIX333.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"EH-MIX333-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"EH-MIX333-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"EH-MIX333-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("26","13","_wp_attached_file","2018/03/honeybee-01.png");
INSERT INTO `bak_postmeta` VALUES("27","13","_wp_attachment_metadata","a:5:{s:5:\"width\";i:627;s:6:\"height\";i:1108;s:4:\"file\";s:23:\"2018/03/honeybee-01.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"honeybee-01-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"honeybee-01-170x300.png\";s:5:\"width\";i:170;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"honeybee-01-579x1024.png\";s:5:\"width\";i:579;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("31","15","_wp_attached_file","2018/03/in-menu-lau.jpg");
INSERT INTO `bak_postmeta` VALUES("32","15","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1229;s:4:\"file\";s:23:\"2018/03/in-menu-lau.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"in-menu-lau-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"in-menu-lau-300x230.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:230;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"in-menu-lau-768x590.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:590;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:24:\"in-menu-lau-1024x787.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:787;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("41","17","_wp_attached_file","2018/03/in-menu-kem.jpg");
INSERT INTO `bak_postmeta` VALUES("42","17","_wp_attachment_metadata","a:5:{s:5:\"width\";i:960;s:6:\"height\";i:759;s:4:\"file\";s:23:\"2018/03/in-menu-kem.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"in-menu-kem-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"in-menu-kem-300x237.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:237;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"in-menu-kem-768x607.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:607;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("51","19","_wp_attached_file","2018/03/so-sanh-in-menu-chuyen-nghiep.jpg");
INSERT INTO `bak_postmeta` VALUES("52","19","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1100;s:6:\"height\";i:595;s:4:\"file\";s:41:\"2018/03/so-sanh-in-menu-chuyen-nghiep.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"so-sanh-in-menu-chuyen-nghiep-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"so-sanh-in-menu-chuyen-nghiep-300x162.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:162;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:41:\"so-sanh-in-menu-chuyen-nghiep-768x415.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:415;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:42:\"so-sanh-in-menu-chuyen-nghiep-1024x554.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:554;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("97","31","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("98","31","_edit_lock","1520528203:1");
INSERT INTO `bak_postmeta` VALUES("99","31","_wp_page_template","page-articles.php");
INSERT INTO `bak_postmeta` VALUES("107","34","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("108","34","_edit_lock","1520530458:1");
INSERT INTO `bak_postmeta` VALUES("109","34","_wp_page_template","page-products.php");
INSERT INTO `bak_postmeta` VALUES("110","34","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("150","39","_edit_lock","1523595476:1");
INSERT INTO `bak_postmeta` VALUES("151","39","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("152","39","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("158","39","_yoast_wpseo_content_score","90");
INSERT INTO `bak_postmeta` VALUES("159","40","_wp_attached_file","2018/04/bep-tu-doi-chefs-DIH321.png");
INSERT INTO `bak_postmeta` VALUES("160","40","_wp_attachment_metadata","a:5:{s:5:\"width\";i:900;s:6:\"height\";i:600;s:4:\"file\";s:35:\"2018/04/bep-tu-doi-chefs-DIH321.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"bep-tu-doi-chefs-DIH321-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"bep-tu-doi-chefs-DIH321-300x200.png\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"bep-tu-doi-chefs-DIH321-768x512.png\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("161","39","_thumbnail_id","40");
INSERT INTO `bak_postmeta` VALUES("197","45","_edit_lock","1523087149:1");
INSERT INTO `bak_postmeta` VALUES("198","45","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("199","46","_edit_lock","1523519581:1");
INSERT INTO `bak_postmeta` VALUES("200","46","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("201","46","_wp_page_template","page-contact.php");
INSERT INTO `bak_postmeta` VALUES("202","46","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("218","48","_edit_lock","1523532387:1");
INSERT INTO `bak_postmeta` VALUES("219","48","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("220","48","_yoast_wpseo_content_score","60");
INSERT INTO `bak_postmeta` VALUES("221","48","_thumbnail_id","94");
INSERT INTO `bak_postmeta` VALUES("222","49","_edit_lock","1523592520:1");
INSERT INTO `bak_postmeta` VALUES("223","49","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("224","49","_thumbnail_id","102");
INSERT INTO `bak_postmeta` VALUES("225","49","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("226","50","_edit_lock","1523588021:1");
INSERT INTO `bak_postmeta` VALUES("227","50","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("228","50","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("229","51","_edit_lock","1523089221:1");
INSERT INTO `bak_postmeta` VALUES("230","51","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("231","51","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("232","52","_edit_lock","1523089230:1");
INSERT INTO `bak_postmeta` VALUES("233","52","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("234","52","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("235","45","_wp_trash_meta_status","draft");
INSERT INTO `bak_postmeta` VALUES("236","45","_wp_trash_meta_time","1523089496");
INSERT INTO `bak_postmeta` VALUES("237","45","_wp_desired_post_slug","");
INSERT INTO `bak_postmeta` VALUES("238","54","_edit_lock","1524154281:1");
INSERT INTO `bak_postmeta` VALUES("239","54","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("240","54","_wp_page_template","page-qnas.php");
INSERT INTO `bak_postmeta` VALUES("241","54","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("247","39","_yoast_wpseo_metadesc","Nếu bạn mới chuyển từ bếp gas sang dùng bếp từ, và vẫn còn phân vân giữa các dòng bếp, thì bếp từ đôi Chefs EH-DIH321 chính là dòng bếp đáng tham khảo.");
INSERT INTO `bak_postmeta` VALUES("253","56","_wp_attached_file","2018/04/bep-tu-chefs-eh-dih321.png");
INSERT INTO `bak_postmeta` VALUES("254","56","_wp_attachment_metadata","a:5:{s:5:\"width\";i:700;s:6:\"height\";i:468;s:4:\"file\";s:34:\"2018/04/bep-tu-chefs-eh-dih321.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"bep-tu-chefs-eh-dih321-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"bep-tu-chefs-eh-dih321-300x201.png\";s:5:\"width\";i:300;s:6:\"height\";i:201;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("255","57","_wp_attached_file","2018/04/mat-kinh-bep-tu-chefs-eh-dih321.png");
INSERT INTO `bak_postmeta` VALUES("256","57","_wp_attachment_metadata","a:5:{s:5:\"width\";i:700;s:6:\"height\";i:468;s:4:\"file\";s:43:\"2018/04/mat-kinh-bep-tu-chefs-eh-dih321.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"mat-kinh-bep-tu-chefs-eh-dih321-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"mat-kinh-bep-tu-chefs-eh-dih321-300x201.png\";s:5:\"width\";i:300;s:6:\"height\";i:201;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("327","58","_edit_lock","1523595620:1");
INSERT INTO `bak_postmeta` VALUES("328","58","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("329","59","_wp_attached_file","2018/04/bep-tu-nhap-khau-chefs-eh-dih2000a.jpg");
INSERT INTO `bak_postmeta` VALUES("330","59","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:900;s:4:\"file\";s:46:\"2018/04/bep-tu-nhap-khau-chefs-eh-dih2000a.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"bep-tu-nhap-khau-chefs-eh-dih2000a-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:46:\"bep-tu-nhap-khau-chefs-eh-dih2000a-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:46:\"bep-tu-nhap-khau-chefs-eh-dih2000a-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:47:\"bep-tu-nhap-khau-chefs-eh-dih2000a-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("331","60","_wp_attached_file","2018/04/bep-tu-doi-chefs-eh-dih2000a.jpg");
INSERT INTO `bak_postmeta` VALUES("332","60","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1029;s:4:\"file\";s:40:\"2018/04/bep-tu-doi-chefs-eh-dih2000a.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"bep-tu-doi-chefs-eh-dih2000a-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"bep-tu-doi-chefs-eh-dih2000a-300x193.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:193;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"bep-tu-doi-chefs-eh-dih2000a-768x494.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:494;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:41:\"bep-tu-doi-chefs-eh-dih2000a-1024x659.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:659;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("333","58","_thumbnail_id","60");
INSERT INTO `bak_postmeta` VALUES("334","58","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("340","58","_yoast_wpseo_metadesc","Với những tính năng ưu việt và tiện ích, bếp từ đôi Chefs EH-DIH2000A đã và đang được phân phối rộng rãi trên thị trường.");
INSERT INTO `bak_postmeta` VALUES("341","58","_yoast_wpseo_content_score","90");
INSERT INTO `bak_postmeta` VALUES("347","62","_edit_lock","1524160926:1");
INSERT INTO `bak_postmeta` VALUES("348","62","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("349","63","_wp_attached_file","2018/04/bep-tu-cata-ib-722-gia-tot.png");
INSERT INTO `bak_postmeta` VALUES("350","63","_wp_attachment_metadata","a:5:{s:5:\"width\";i:552;s:6:\"height\";i:347;s:4:\"file\";s:38:\"2018/04/bep-tu-cata-ib-722-gia-tot.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"bep-tu-cata-ib-722-gia-tot-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"bep-tu-cata-ib-722-gia-tot-300x189.png\";s:5:\"width\";i:300;s:6:\"height\";i:189;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("351","64","_wp_attached_file","2018/04/bep-tu-cata-ib-772.png");
INSERT INTO `bak_postmeta` VALUES("352","64","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1031;s:4:\"file\";s:30:\"2018/04/bep-tu-cata-ib-772.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"bep-tu-cata-ib-772-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"bep-tu-cata-ib-772-300x193.png\";s:5:\"width\";i:300;s:6:\"height\";i:193;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"bep-tu-cata-ib-772-768x495.png\";s:5:\"width\";i:768;s:6:\"height\";i:495;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"bep-tu-cata-ib-772-1024x660.png\";s:5:\"width\";i:1024;s:6:\"height\";i:660;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("353","65","_wp_attached_file","2018/04/mat-kinh-schott-ceran-cua-cata-ib-772.jpg");
INSERT INTO `bak_postmeta` VALUES("354","65","_wp_attachment_metadata","a:5:{s:5:\"width\";i:961;s:6:\"height\";i:500;s:4:\"file\";s:49:\"2018/04/mat-kinh-schott-ceran-cua-cata-ib-772.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:49:\"mat-kinh-schott-ceran-cua-cata-ib-772-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:49:\"mat-kinh-schott-ceran-cua-cata-ib-772-300x156.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:156;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:49:\"mat-kinh-schott-ceran-cua-cata-ib-772-768x400.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("356","62","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("362","62","_yoast_wpseo_metadesc","Bếp từ Cata IB 772 là chiếc bếp hoàn toàn phù hợp trong những căn bếp mang phong cách Châu Âu độc đáo, sang trọng và tinh tế.");
INSERT INTO `bak_postmeta` VALUES("363","62","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("374","66","_edit_lock","1523595474:1");
INSERT INTO `bak_postmeta` VALUES("375","66","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("376","66","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("377","66","_yoast_wpseo_content_score","90");
INSERT INTO `bak_postmeta` VALUES("378","67","_wp_attached_file","2018/04/Bep-tu-IB-603-BK.jpg");
INSERT INTO `bak_postmeta` VALUES("379","67","_wp_attachment_metadata","a:5:{s:5:\"width\";i:900;s:6:\"height\";i:600;s:4:\"file\";s:28:\"2018/04/Bep-tu-IB-603-BK.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"Bep-tu-IB-603-BK-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"Bep-tu-IB-603-BK-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"Bep-tu-IB-603-BK-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("380","66","_thumbnail_id","67");
INSERT INTO `bak_postmeta` VALUES("385","68","_wp_attached_file","2018/04/uu-diem-bep-tu-cata-ib-630bk.jpg");
INSERT INTO `bak_postmeta` VALUES("386","68","_wp_attachment_metadata","a:5:{s:5:\"width\";i:4329;s:6:\"height\";i:2720;s:4:\"file\";s:40:\"2018/04/uu-diem-bep-tu-cata-ib-630bk.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"uu-diem-bep-tu-cata-ib-630bk-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"uu-diem-bep-tu-cata-ib-630bk-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"uu-diem-bep-tu-cata-ib-630bk-768x483.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:483;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:41:\"uu-diem-bep-tu-cata-ib-630bk-1024x643.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:643;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"6.3\";s:6:\"credit\";s:18:\"jillchen - Fotolia\";s:6:\"camera\";s:11:\"NIKON D7000\";s:7:\"caption\";s:103:\"Woman standing by the stove in the kitchen, cooking and smelling the nice aromas from her meal in a pot\";s:17:\"created_timestamp\";s:10:\"1351209600\";s:9:\"copyright\";s:18:\"jillchen - Fotolia\";s:12:\"focal_length\";s:3:\"120\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:5:\"0.005\";s:5:\"title\";s:37:\"Mix race woman cooking in the kitchen\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:58:{i:0;s:5:\"woman\";i:1;s:6:\"female\";i:2;s:4:\"girl\";i:3;s:8:\"mix race\";i:4;s:9:\"beautiful\";i:5;s:6:\"pretty\";i:6;s:6:\"indian\";i:7;s:5:\"asian\";i:8;s:6:\"latino\";i:9;s:7:\"cooking\";i:10;s:7:\"kitchen\";i:11;s:5:\"happy\";i:12;s:9:\"enjoyment\";i:13;s:4:\"chef\";i:14;s:9:\"housewife\";i:15;s:3:\"pot\";i:16;s:4:\"cook\";i:17;s:4:\"stir\";i:18;s:5:\"stove\";i:19;s:8:\"standing\";i:20;s:7:\"smiling\";i:21;s:5:\"apron\";i:22;s:5:\"steam\";i:23;s:5:\"smell\";i:24;s:5:\"aroma\";i:25;s:4:\"soup\";i:26;s:4:\"stew\";i:27;s:8:\"domestic\";i:28;s:4:\"meal\";i:29;s:5:\"woman\";i:30;s:7:\"cooking\";i:31;s:5:\"smell\";i:32;s:8:\"mix race\";i:33;s:7:\"kitchen\";i:34;s:5:\"happy\";i:35;s:9:\"enjoyment\";i:36;s:5:\"steam\";i:37;s:6:\"female\";i:38;s:4:\"girl\";i:39;s:9:\"beautiful\";i:40;s:6:\"pretty\";i:41;s:6:\"indian\";i:42;s:5:\"asian\";i:43;s:6:\"latino\";i:44;s:4:\"chef\";i:45;s:9:\"housewife\";i:46;s:3:\"pot\";i:47;s:4:\"cook\";i:48;s:4:\"stir\";i:49;s:5:\"stove\";i:50;s:8:\"standing\";i:51;s:7:\"smiling\";i:52;s:5:\"apron\";i:53;s:5:\"aroma\";i:54;s:4:\"soup\";i:55;s:4:\"stew\";i:56;s:8:\"domestic\";i:57;s:4:\"meal\";}}}");
INSERT INTO `bak_postmeta` VALUES("395","66","_yoast_wpseo_metadesc","Bếp từ Cata IB 630 BK ra đời nhằm đáp ứng nhu cầu sử dụng nhiều bếp nấu cùng lúc của các quý bà nội trợ. Độc đáo với 3 vùng nấu.");
INSERT INTO `bak_postmeta` VALUES("396","70","_edit_lock","1523595474:1");
INSERT INTO `bak_postmeta` VALUES("397","70","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("398","71","_wp_attached_file","2018/04/large_bep-tu-bosch-pid675n24e.jpg");
INSERT INTO `bak_postmeta` VALUES("399","71","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:41:\"2018/04/large_bep-tu-bosch-pid675n24e.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"large_bep-tu-bosch-pid675n24e-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"large_bep-tu-bosch-pid675n24e-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:41:\"large_bep-tu-bosch-pid675n24e-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("400","72","_wp_attached_file","2018/04/bep-dien-tu-bosch-pid675n24e.png");
INSERT INTO `bak_postmeta` VALUES("401","72","_wp_attachment_metadata","a:5:{s:5:\"width\";i:458;s:6:\"height\";i:299;s:4:\"file\";s:40:\"2018/04/bep-dien-tu-bosch-pid675n24e.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"bep-dien-tu-bosch-pid675n24e-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"bep-dien-tu-bosch-pid675n24e-300x196.png\";s:5:\"width\";i:300;s:6:\"height\";i:196;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("402","73","_wp_attached_file","2018/04/bep-3-tu-bosch-pid675n24e.png");
INSERT INTO `bak_postmeta` VALUES("403","73","_wp_attachment_metadata","a:5:{s:5:\"width\";i:646;s:6:\"height\";i:355;s:4:\"file\";s:37:\"2018/04/bep-3-tu-bosch-pid675n24e.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"bep-3-tu-bosch-pid675n24e-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"bep-3-tu-bosch-pid675n24e-300x165.png\";s:5:\"width\";i:300;s:6:\"height\";i:165;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("404","70","_thumbnail_id","71");
INSERT INTO `bak_postmeta` VALUES("405","70","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("410","70","_yoast_wpseo_metadesc","Bếp 3 từ PID675N24E đem lại tiện ích cho việc nấu nướng của bạn gấp 3 lần so với những mẫu bếp từ khác.");
INSERT INTO `bak_postmeta` VALUES("411","70","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("416","74","_edit_lock","1523595473:1");
INSERT INTO `bak_postmeta` VALUES("417","74","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("418","75","_wp_attached_file","2018/04/bep-chinh-hang-arber-ab383.jpg");
INSERT INTO `bak_postmeta` VALUES("419","75","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:229;s:4:\"file\";s:38:\"2018/04/bep-chinh-hang-arber-ab383.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"bep-chinh-hang-arber-ab383-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"bep-chinh-hang-arber-ab383-300x115.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:115;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("420","76","_wp_attached_file","2018/04/bep-tu-arber-ab-383.jpg");
INSERT INTO `bak_postmeta` VALUES("421","76","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:600;s:4:\"file\";s:31:\"2018/04/bep-tu-arber-ab-383.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"bep-tu-arber-ab-383-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"bep-tu-arber-ab-383-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("422","74","_thumbnail_id","76");
INSERT INTO `bak_postmeta` VALUES("423","74","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("429","74","_yoast_wpseo_metadesc","Bếp từ Arber AB-383 là dòng sản phẩm phù hợp với đại đa số gia đình Việt hiện nay về cả chất lượng, hình thức lẫn giá thành.");
INSERT INTO `bak_postmeta` VALUES("430","74","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("448","77","_form","<label>[text* your-name placeholder \"Họ tên\"] </label>

<label>[tel* tel-539 placeholder \"Điện thoại\"] </label>

<label> Thông tin cần trao đổi
    [textarea your-message] </label>

[submit \"Send\"]");
INSERT INTO `bak_postmeta` VALUES("449","77","_mail","a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:31:\"Bếp An Khang \"[your-subject]\"\";s:6:\"sender\";s:39:\"[your-name] <wordpress@bepankhang.test>\";s:9:\"recipient\";s:19:\"ptson.snh@gmail.com\";s:4:\"body\";s:175:\"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Bếp An Khang (http://bepankhang.test)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `bak_postmeta` VALUES("450","77","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:31:\"Bếp An Khang \"[your-subject]\"\";s:6:\"sender\";s:42:\"Bếp An Khang <wordpress@bepankhang.test>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:117:\"Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Bếp An Khang (http://bepankhang.test)\";s:18:\"additional_headers\";s:29:\"Reply-To: ptson.snh@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `bak_postmeta` VALUES("451","77","_messages","a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}");
INSERT INTO `bak_postmeta` VALUES("452","77","_additional_settings","");
INSERT INTO `bak_postmeta` VALUES("453","77","_locale","en_US");
INSERT INTO `bak_postmeta` VALUES("457","77","_config_errors","a:1:{s:23:\"mail.additional_headers\";a:1:{i:0;a:2:{s:4:\"code\";i:102;s:4:\"args\";a:3:{s:7:\"message\";s:51:\"Invalid mailbox syntax is used in the %name% field.\";s:6:\"params\";a:1:{s:4:\"name\";s:8:\"Reply-To\";}s:4:\"link\";s:68:\"https://contactform7.com/configuration-errors/invalid-mailbox-syntax\";}}}}");
INSERT INTO `bak_postmeta` VALUES("458","70","_wp_old_slug","bep-dien-tu-bosch-pid675n24e");
INSERT INTO `bak_postmeta` VALUES("464","78","_edit_lock","1523595472:1");
INSERT INTO `bak_postmeta` VALUES("465","78","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("466","79","_wp_attached_file","2018/04/tinh-nang-cua-bep-tu-bosch.jpg");
INSERT INTO `bak_postmeta` VALUES("467","79","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:499;s:4:\"file\";s:38:\"2018/04/tinh-nang-cua-bep-tu-bosch.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"tinh-nang-cua-bep-tu-bosch-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"tinh-nang-cua-bep-tu-bosch-300x187.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:187;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:38:\"tinh-nang-cua-bep-tu-bosch-768x479.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:479;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("468","80","_wp_attached_file","2018/04/bep-tu-Bosch-PID675DC1E.jpg");
INSERT INTO `bak_postmeta` VALUES("469","80","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:352;s:4:\"file\";s:35:\"2018/04/bep-tu-Bosch-PID675DC1E.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"bep-tu-Bosch-PID675DC1E-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"bep-tu-Bosch-PID675DC1E-300x264.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:264;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("470","78","_thumbnail_id","80");
INSERT INTO `bak_postmeta` VALUES("471","78","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("477","78","_yoast_wpseo_metadesc","Bếp Từ Bosch PID675DC1E nhập khẩu chính hãng với bảng điều khiển DirectSelect với truy cập trực tiếp lên đến 17 cấp độ nấu ăn.");
INSERT INTO `bak_postmeta` VALUES("478","78","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("510","81","_edit_lock","1523595472:1");
INSERT INTO `bak_postmeta` VALUES("511","81","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("512","81","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("514","81","_yoast_wpseo_content_score","60");
INSERT INTO `bak_postmeta` VALUES("515","82","_wp_attached_file","2018/04/bang-dieu-khien-cata-i2-plus.jpg");
INSERT INTO `bak_postmeta` VALUES("516","82","_wp_attachment_metadata","a:5:{s:5:\"width\";i:530;s:6:\"height\";i:530;s:4:\"file\";s:40:\"2018/04/bang-dieu-khien-cata-i2-plus.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"bang-dieu-khien-cata-i2-plus-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"bang-dieu-khien-cata-i2-plus-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("517","83","_wp_attached_file","2018/04/bep-tu-cata-i2-plus.jpg");
INSERT INTO `bak_postmeta` VALUES("518","83","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:244;s:4:\"file\";s:31:\"2018/04/bep-tu-cata-i2-plus.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"bep-tu-cata-i2-plus-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"bep-tu-cata-i2-plus-300x183.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:183;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("519","81","_thumbnail_id","83");
INSERT INTO `bak_postmeta` VALUES("526","81","_yoast_wpseo_metadesc","Bếp từ 2 vùng nấu Cata I2 Plus là sản phẩm của thương hiệu Cata, vốn là 1 thương hiệu nỗi tiếng của Tây Ban Nha.");
INSERT INTO `bak_postmeta` VALUES("533","84","_edit_lock","1523595471:1");
INSERT INTO `bak_postmeta` VALUES("534","84","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("535","85","_wp_attached_file","2018/04/chefs-ehmix321.jpg");
INSERT INTO `bak_postmeta` VALUES("536","85","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:333;s:4:\"file\";s:26:\"2018/04/chefs-ehmix321.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"chefs-ehmix321-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"chefs-ehmix321-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("537","86","_wp_attached_file","2018/04/thong-so-Chefs-EH-MIX321.png");
INSERT INTO `bak_postmeta` VALUES("538","86","_wp_attachment_metadata","a:5:{s:5:\"width\";i:987;s:6:\"height\";i:726;s:4:\"file\";s:36:\"2018/04/thong-so-Chefs-EH-MIX321.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"thong-so-Chefs-EH-MIX321-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"thong-so-Chefs-EH-MIX321-300x221.png\";s:5:\"width\";i:300;s:6:\"height\";i:221;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"thong-so-Chefs-EH-MIX321-768x565.png\";s:5:\"width\";i:768;s:6:\"height\";i:565;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("539","84","_thumbnail_id","85");
INSERT INTO `bak_postmeta` VALUES("540","84","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("546","84","_yoast_wpseo_metadesc","Bếp Điện Từ Chefs EHMIX321 là loại bếp tiện lợi có thể sử dụng trên mọi loại chất liệu nồi. Bếp với 2 Vùng Nấu: 1 điện từ và 1 hồng ngoại.");
INSERT INTO `bak_postmeta` VALUES("547","84","_yoast_wpseo_content_score","60");
INSERT INTO `bak_postmeta` VALUES("553","87","_edit_lock","1523595470:1");
INSERT INTO `bak_postmeta` VALUES("554","87","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("555","88","_wp_attached_file","2018/04/bep-dien-tu-bosch-PVS851FB1E.png");
INSERT INTO `bak_postmeta` VALUES("556","88","_wp_attachment_metadata","a:5:{s:5:\"width\";i:900;s:6:\"height\";i:506;s:4:\"file\";s:40:\"2018/04/bep-dien-tu-bosch-PVS851FB1E.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"bep-dien-tu-bosch-PVS851FB1E-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"bep-dien-tu-bosch-PVS851FB1E-300x169.png\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"bep-dien-tu-bosch-PVS851FB1E-768x432.png\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("557","89","_wp_attached_file","2018/04/bep-tu-bosch-PVS851FB1E.jpg");
INSERT INTO `bak_postmeta` VALUES("558","89","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1100;s:6:\"height\";i:1100;s:4:\"file\";s:35:\"2018/04/bep-tu-bosch-PVS851FB1E.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"bep-tu-bosch-PVS851FB1E-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"bep-tu-bosch-PVS851FB1E-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"bep-tu-bosch-PVS851FB1E-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"bep-tu-bosch-PVS851FB1E-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("559","90","_wp_attached_file","2018/04/be-mat-kinh-bep-bosch-PVS851FB1E.png");
INSERT INTO `bak_postmeta` VALUES("560","90","_wp_attachment_metadata","a:5:{s:5:\"width\";i:900;s:6:\"height\";i:506;s:4:\"file\";s:44:\"2018/04/be-mat-kinh-bep-bosch-PVS851FB1E.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"be-mat-kinh-bep-bosch-PVS851FB1E-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"be-mat-kinh-bep-bosch-PVS851FB1E-300x169.png\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"be-mat-kinh-bep-bosch-PVS851FB1E-768x432.png\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("561","87","_thumbnail_id","89");
INSERT INTO `bak_postmeta` VALUES("562","87","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("569","87","_yoast_wpseo_metadesc","Bếp từ Bosch PVS851FB1E thuộc dòng Bosch Series 6 có thiết kế rất hiện đại với 4 vùng nấu riêng biệt. Liên hệ bếp An Khang để có giá tốt nhất.");
INSERT INTO `bak_postmeta` VALUES("570","87","_yoast_wpseo_content_score","30");
INSERT INTO `bak_postmeta` VALUES("571","91","_edit_lock","1523595470:1");
INSERT INTO `bak_postmeta` VALUES("572","91","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("573","92","_wp_attached_file","2018/04/bep-tu-Arber-AB-688.jpg");
INSERT INTO `bak_postmeta` VALUES("574","92","_wp_attachment_metadata","a:5:{s:5:\"width\";i:852;s:6:\"height\";i:509;s:4:\"file\";s:31:\"2018/04/bep-tu-Arber-AB-688.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"bep-tu-Arber-AB-688-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"bep-tu-Arber-AB-688-300x179.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:179;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"bep-tu-Arber-AB-688-768x459.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:459;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("575","91","_thumbnail_id","92");
INSERT INTO `bak_postmeta` VALUES("576","91","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("582","91","_yoast_wpseo_metadesc","Đáp ứng được mọi nhu tầm trung bản của 1 chiếc bếp, bếp từ Arber AB-688 gây được sự chú ý và thiện cảm của người tiêu dùng.");
INSERT INTO `bak_postmeta` VALUES("583","91","_yoast_wpseo_content_score","60");
INSERT INTO `bak_postmeta` VALUES("584","66","_wp_old_slug","bep-tu-cata-ib-630-bk");
INSERT INTO `bak_postmeta` VALUES("590","48","_yoast_wpseo_metadesc","Bếp điện từ rất đẹp và tiện dụng. Thế nhưng liệu dùng bếp điện từ có tốn điện không? Hãy cùng đọc và chia sẻ bài viết này nhé.");
INSERT INTO `bak_postmeta` VALUES("591","50","_wp_old_slug","dac-diem-cua-bep-dien-tu");
INSERT INTO `bak_postmeta` VALUES("592","94","_wp_attached_file","2018/04/bep-dien-tu-nhieu-muc-cong-suat.jpg");
INSERT INTO `bak_postmeta` VALUES("593","94","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:533;s:4:\"file\";s:43:\"2018/04/bep-dien-tu-nhieu-muc-cong-suat.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"bep-dien-tu-nhieu-muc-cong-suat-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"bep-dien-tu-nhieu-muc-cong-suat-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"bep-dien-tu-nhieu-muc-cong-suat-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("594","94","_wp_attachment_image_alt","bep dien tu co nhieu muc cong suat");
INSERT INTO `bak_postmeta` VALUES("595","96","_wp_attached_file","2018/04/uu-diem-bep-dien-tu.png");
INSERT INTO `bak_postmeta` VALUES("596","96","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1608;s:6:\"height\";i:1284;s:4:\"file\";s:31:\"2018/04/uu-diem-bep-dien-tu.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"uu-diem-bep-dien-tu-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"uu-diem-bep-dien-tu-300x240.png\";s:5:\"width\";i:300;s:6:\"height\";i:240;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"uu-diem-bep-dien-tu-768x613.png\";s:5:\"width\";i:768;s:6:\"height\";i:613;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"uu-diem-bep-dien-tu-1024x818.png\";s:5:\"width\";i:1024;s:6:\"height\";i:818;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("597","97","_wp_attached_file","2018/04/bep-dien-tu-dung-nhu-ban-an.jpg");
INSERT INTO `bak_postmeta` VALUES("598","97","_wp_attachment_metadata","a:5:{s:5:\"width\";i:700;s:6:\"height\";i:933;s:4:\"file\";s:39:\"2018/04/bep-dien-tu-dung-nhu-ban-an.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"bep-dien-tu-dung-nhu-ban-an-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"bep-dien-tu-dung-nhu-ban-an-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("599","97","_wp_attachment_image_alt","Dung bep dien tu nhu ban an");
INSERT INTO `bak_postmeta` VALUES("600","98","_wp_attached_file","2018/04/bep-dien-tu-rat-an-toan.jpg");
INSERT INTO `bak_postmeta` VALUES("601","98","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:487;s:4:\"file\";s:35:\"2018/04/bep-dien-tu-rat-an-toan.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"bep-dien-tu-rat-an-toan-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"bep-dien-tu-rat-an-toan-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("602","98","_wp_attachment_image_alt","bep dien tu rat an toan");
INSERT INTO `bak_postmeta` VALUES("603","99","_wp_attached_file","2018/04/uu-diem-cua-bep-dien-tu-de-ve-sinh.jpg");
INSERT INTO `bak_postmeta` VALUES("604","99","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:800;s:4:\"file\";s:46:\"2018/04/uu-diem-cua-bep-dien-tu-de-ve-sinh.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"uu-diem-cua-bep-dien-tu-de-ve-sinh-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:46:\"uu-diem-cua-bep-dien-tu-de-ve-sinh-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:46:\"uu-diem-cua-bep-dien-tu-de-ve-sinh-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:47:\"uu-diem-cua-bep-dien-tu-de-ve-sinh-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:48:\"Woman\'s hand cleaning induction stove with cloth\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:8:\"Bigstock\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:48:\"Woman\'s hand cleaning induction stove with cloth\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("605","99","_wp_attachment_image_alt","de ve sinh la 1 uu diem cua bep dien tu");
INSERT INTO `bak_postmeta` VALUES("606","50","_thumbnail_id","99");
INSERT INTO `bak_postmeta` VALUES("607","50","_yoast_wpseo_metadesc","Đã và đang dần thay thế thị trường bếp gas bởi có rất nhiều tính năng vượt trội. Vậy những ưu điểm của bếp điện từ là gì?");
INSERT INTO `bak_postmeta` VALUES("608","101","_wp_attached_file","2018/04/mat-kinh-Schott-Ceran-do-ben-cao.jpg");
INSERT INTO `bak_postmeta` VALUES("609","101","_wp_attachment_metadata","a:5:{s:5:\"width\";i:766;s:6:\"height\";i:293;s:4:\"file\";s:44:\"2018/04/mat-kinh-Schott-Ceran-do-ben-cao.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"mat-kinh-Schott-Ceran-do-ben-cao-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"mat-kinh-Schott-Ceran-do-ben-cao-300x115.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:115;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("610","101","_wp_attachment_image_alt","mat kinh Schott Ceran co do ben cao");
INSERT INTO `bak_postmeta` VALUES("611","102","_wp_attached_file","2018/04/kinh-nghiem-chon-mua-bep-dien-tu.jpg");
INSERT INTO `bak_postmeta` VALUES("612","102","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1140;s:6:\"height\";i:641;s:4:\"file\";s:44:\"2018/04/kinh-nghiem-chon-mua-bep-dien-tu.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"kinh-nghiem-chon-mua-bep-dien-tu-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"kinh-nghiem-chon-mua-bep-dien-tu-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"kinh-nghiem-chon-mua-bep-dien-tu-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:45:\"kinh-nghiem-chon-mua-bep-dien-tu-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:20:\"sunnysky69 - Fotolia\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:40:\"Woman looking unhappy and showing a pill\";s:17:\"created_timestamp\";s:10:\"1426959658\";s:9:\"copyright\";s:14:\"Deniz AYCI LEU\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:29:\"Woman looking to her medicine\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:30:{i:0;s:9:\"caucasian\";i:1;s:4:\"drug\";i:2;s:5:\"drugs\";i:3;s:6:\"female\";i:4;s:4:\"girl\";i:5;s:6:\"health\";i:6;s:11:\"health care\";i:7;s:7:\"holding\";i:8;s:3:\"ill\";i:9;s:7:\"illness\";i:10;s:7:\"looking\";i:11;s:8:\"medicine\";i:12;s:7:\"package\";i:13;s:4:\"pain\";i:14;s:7:\"painful\";i:15;s:6:\"people\";i:16;s:6:\"person\";i:17;s:14:\"pharmaceutical\";i:18;s:8:\"pharmacy\";i:19;s:5:\"pills\";i:20;s:12:\"prescription\";i:21;s:3:\"sad\";i:22;s:7:\"showing\";i:23;s:4:\"sick\";i:24;s:8:\"sickness\";i:25;s:6:\"suffer\";i:26;s:9:\"suffering\";i:27;s:7:\"unhappy\";i:28;s:9:\"unhealthy\";i:29;s:5:\"woman\";}}}");
INSERT INTO `bak_postmeta` VALUES("613","102","_wp_attachment_image_alt","");
INSERT INTO `bak_postmeta` VALUES("614","49","_wp_old_slug","co-nen-mua-bep-dien-tu-hay-khong");
INSERT INTO `bak_postmeta` VALUES("615","49","_yoast_wpseo_metadesc","Trên thị trường những năm gần đây có rất nhiều dòng bếp điện từ, điều này đòi hỏi bạn cần có kinh nghiệm chọn mua bếp điện từ để tìm ra chiếc bếp phù hợp.");
INSERT INTO `bak_postmeta` VALUES("616","52","_wp_trash_meta_status","publish");
INSERT INTO `bak_postmeta` VALUES("617","52","_wp_trash_meta_time","1523594721");
INSERT INTO `bak_postmeta` VALUES("618","52","_wp_desired_post_slug","uu-nhuoc-diem-cua-bep-hong-ngoai");
INSERT INTO `bak_postmeta` VALUES("619","51","_wp_trash_meta_status","publish");
INSERT INTO `bak_postmeta` VALUES("620","51","_wp_trash_meta_time","1523594721");
INSERT INTO `bak_postmeta` VALUES("621","51","_wp_desired_post_slug","sanh-bep-dien-tu-va-bep-hong-ngoai");
INSERT INTO `bak_postmeta` VALUES("622","91","wpcf-product_display_price","15000000");
INSERT INTO `bak_postmeta` VALUES("623","91","wpcf-product_sell_price","13000000");
INSERT INTO `bak_postmeta` VALUES("624","91","wpcf-product_code","AB-688");
INSERT INTO `bak_postmeta` VALUES("625","91","wpcf-num_cook","2");
INSERT INTO `bak_postmeta` VALUES("626","91","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("627","91","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("628","87","wpcf-product_display_price","32500000");
INSERT INTO `bak_postmeta` VALUES("629","87","wpcf-product_sell_price","29000000");
INSERT INTO `bak_postmeta` VALUES("630","87","wpcf-product_code","PVS851FB1E");
INSERT INTO `bak_postmeta` VALUES("631","87","wpcf-num_cook","4");
INSERT INTO `bak_postmeta` VALUES("632","87","wpcf-product_promotion","Bộ nồi inox");
INSERT INTO `bak_postmeta` VALUES("633","87","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("634","87","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("635","84","wpcf-product_display_price","10200000");
INSERT INTO `bak_postmeta` VALUES("636","84","wpcf-product_sell_price","8900000");
INSERT INTO `bak_postmeta` VALUES("637","84","wpcf-product_code","EH-MIX321");
INSERT INTO `bak_postmeta` VALUES("638","84","wpcf-num_cook","2");
INSERT INTO `bak_postmeta` VALUES("639","84","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("640","84","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("641","81","wpcf-product_display_price","8200000");
INSERT INTO `bak_postmeta` VALUES("642","81","wpcf-product_sell_price","7200000");
INSERT INTO `bak_postmeta` VALUES("643","81","wpcf-product_code","I2 Plus");
INSERT INTO `bak_postmeta` VALUES("644","81","wpcf-num_cook","2");
INSERT INTO `bak_postmeta` VALUES("645","81","wpcf-product_promotion","Chảo chống dính");
INSERT INTO `bak_postmeta` VALUES("646","81","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("647","81","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("648","78","wpcf-product_display_price","21000000");
INSERT INTO `bak_postmeta` VALUES("649","78","wpcf-product_sell_price","19800000");
INSERT INTO `bak_postmeta` VALUES("650","78","wpcf-product_code","PID675DC1E");
INSERT INTO `bak_postmeta` VALUES("651","78","wpcf-num_cook","3");
INSERT INTO `bak_postmeta` VALUES("652","78","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("653","78","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("654","74","wpcf-product_display_price","10800000");
INSERT INTO `bak_postmeta` VALUES("655","74","wpcf-product_sell_price","8500000");
INSERT INTO `bak_postmeta` VALUES("656","74","wpcf-product_code","AB-383");
INSERT INTO `bak_postmeta` VALUES("657","74","wpcf-num_cook","2");
INSERT INTO `bak_postmeta` VALUES("658","74","wpcf-product_promotion","chảo từ chống dính");
INSERT INTO `bak_postmeta` VALUES("659","74","wpcf-product_guarantee","2 năm");
INSERT INTO `bak_postmeta` VALUES("660","74","wpcf-show","a:1:{s:64:\"wpcf-fields-checkboxes-option-5b406ad9d0067f0e18103263d7e1c38e-1\";a:1:{i:0;s:1:\"1\";}}");
INSERT INTO `bak_postmeta` VALUES("661","70","wpcf-product_display_price","23000000");
INSERT INTO `bak_postmeta` VALUES("662","70","wpcf-product_sell_price","20200000");
INSERT INTO `bak_postmeta` VALUES("663","70","wpcf-product_code","PID675N24E");
INSERT INTO `bak_postmeta` VALUES("664","70","wpcf-num_cook","3");
INSERT INTO `bak_postmeta` VALUES("665","70","wpcf-product_guarantee","3 năm theo hãng sản xuất");
INSERT INTO `bak_postmeta` VALUES("666","70","wpcf-show","a:1:{s:64:\"wpcf-fields-checkboxes-option-5b406ad9d0067f0e18103263d7e1c38e-1\";a:1:{i:0;s:1:\"1\";}}");
INSERT INTO `bak_postmeta` VALUES("667","66","wpcf-product_display_price","9900000");
INSERT INTO `bak_postmeta` VALUES("668","66","wpcf-product_sell_price","8900000");
INSERT INTO `bak_postmeta` VALUES("669","66","wpcf-product_code","IB 630 BK");
INSERT INTO `bak_postmeta` VALUES("670","66","wpcf-num_cook","3");
INSERT INTO `bak_postmeta` VALUES("671","66","wpcf-product_guarantee","2 năm");
INSERT INTO `bak_postmeta` VALUES("672","66","wpcf-show","a:1:{s:64:\"wpcf-fields-checkboxes-option-5b406ad9d0067f0e18103263d7e1c38e-1\";a:1:{i:0;s:1:\"1\";}}");
INSERT INTO `bak_postmeta` VALUES("682","58","wpcf-product_display_price","7400000");
INSERT INTO `bak_postmeta` VALUES("683","58","wpcf-product_sell_price","6700000");
INSERT INTO `bak_postmeta` VALUES("684","58","wpcf-product_code","DIH2000A");
INSERT INTO `bak_postmeta` VALUES("685","58","wpcf-num_cook","2");
INSERT INTO `bak_postmeta` VALUES("686","58","wpcf-product_promotion","Tặng bộ nồi Chefs cao cấp");
INSERT INTO `bak_postmeta` VALUES("687","58","wpcf-product_guarantee","3 năm theo hãng sản xuất");
INSERT INTO `bak_postmeta` VALUES("688","58","wpcf-show","a:1:{s:64:\"wpcf-fields-checkboxes-option-5b406ad9d0067f0e18103263d7e1c38e-1\";a:1:{i:0;s:1:\"1\";}}");
INSERT INTO `bak_postmeta` VALUES("689","39","wpcf-product_display_price","9900000");
INSERT INTO `bak_postmeta` VALUES("690","39","wpcf-product_sell_price","8900000");
INSERT INTO `bak_postmeta` VALUES("691","39","wpcf-product_code","EH-DIH321");
INSERT INTO `bak_postmeta` VALUES("692","39","wpcf-num_cook","2");
INSERT INTO `bak_postmeta` VALUES("693","39","wpcf-product_promotion","bộ nồi từ");
INSERT INTO `bak_postmeta` VALUES("694","39","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("695","39","wpcf-show","a:1:{s:64:\"wpcf-fields-checkboxes-option-5b406ad9d0067f0e18103263d7e1c38e-1\";a:1:{i:0;s:1:\"1\";}}");
INSERT INTO `bak_postmeta` VALUES("696","105","_edit_lock","1524155110:1");
INSERT INTO `bak_postmeta` VALUES("697","106","_edit_lock","1524158364:1");
INSERT INTO `bak_postmeta` VALUES("698","106","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("702","106","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("709","106","_yoast_wpseo_metadesc","Bếp từ Cata IB 604 BK là dòng bếp ưu việt với 4 vùng nấu có tổng công suất 6.7kw, 9 mức điều khiển công suất, cảm ứng nhiệt tự động.");
INSERT INTO `bak_postmeta` VALUES("710","106","_yoast_wpseo_content_score","60");
INSERT INTO `bak_postmeta` VALUES("717","108","_edit_lock","1524158337:1");
INSERT INTO `bak_postmeta` VALUES("718","108","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("722","108","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("730","108","_yoast_wpseo_metadesc","Thêm 1 dòng sản phẩm cao cấp của thương hiệu Cata - Bếp từ Cata IB 633X, với nhiều tính năng độc đáo và tiện lợi.");
INSERT INTO `bak_postmeta` VALUES("731","108","_yoast_wpseo_content_score","90");
INSERT INTO `bak_postmeta` VALUES("739","110","_edit_lock","1524158369:1");
INSERT INTO `bak_postmeta` VALUES("740","110","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("743","112","_wp_attached_file","2018/04/Bep-tu-Cata-IB-753-BK.jpg");
INSERT INTO `bak_postmeta` VALUES("744","112","_wp_attachment_metadata","a:5:{s:5:\"width\";i:686;s:6:\"height\";i:353;s:4:\"file\";s:33:\"2018/04/Bep-tu-Cata-IB-753-BK.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"Bep-tu-Cata-IB-753-BK-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"Bep-tu-Cata-IB-753-BK-300x154.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:154;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("745","113","_wp_attached_file","2018/04/su-dung-bep-tu-cata-IB-753.jpg");
INSERT INTO `bak_postmeta` VALUES("746","113","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1523;s:6:\"height\";i:1015;s:4:\"file\";s:38:\"2018/04/su-dung-bep-tu-cata-IB-753.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"su-dung-bep-tu-cata-IB-753-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"su-dung-bep-tu-cata-IB-753-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:38:\"su-dung-bep-tu-cata-IB-753-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:39:\"su-dung-bep-tu-cata-IB-753-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("747","113","_wp_attachment_image_alt","su dung bep tu cata IB 753");
INSERT INTO `bak_postmeta` VALUES("748","114","_wp_attached_file","2018/04/bep-tu-3-vung-nau-cata-IB-753-BK.jpg");
INSERT INTO `bak_postmeta` VALUES("749","114","_wp_attachment_metadata","a:5:{s:5:\"width\";i:988;s:6:\"height\";i:629;s:4:\"file\";s:44:\"2018/04/bep-tu-3-vung-nau-cata-IB-753-BK.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"bep-tu-3-vung-nau-cata-IB-753-BK-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"bep-tu-3-vung-nau-cata-IB-753-BK-300x191.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:191;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"bep-tu-3-vung-nau-cata-IB-753-BK-768x489.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:489;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("750","114","_wp_attachment_image_alt","bep tu 3 vung nau cata IB 753 BK");
INSERT INTO `bak_postmeta` VALUES("751","110","_thumbnail_id","112");
INSERT INTO `bak_postmeta` VALUES("752","110","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("760","110","_yoast_wpseo_metadesc","Cata IB 753 BK là dòng bếp từ mặt kính màu đen/trắng, với 4 vùng nấu và 9 chức năng nấu cho mỗi vùng, thích hợp với gia đình đông người.");
INSERT INTO `bak_postmeta` VALUES("761","110","_yoast_wpseo_content_score","60");
INSERT INTO `bak_postmeta` VALUES("762","110","wpcf-product_display_price","16800000");
INSERT INTO `bak_postmeta` VALUES("763","110","wpcf-product_sell_price","12400000");
INSERT INTO `bak_postmeta` VALUES("764","110","wpcf-product_code","IB 753 BK");
INSERT INTO `bak_postmeta` VALUES("765","110","wpcf-num_cook","4");
INSERT INTO `bak_postmeta` VALUES("766","110","wpcf-product_promotion","Tặng máy hút mùi đến tháng 6/2018");
INSERT INTO `bak_postmeta` VALUES("767","110","wpcf-product_guarantee","4 năm");
INSERT INTO `bak_postmeta` VALUES("768","110","wpcf-show","a:1:{s:64:\"wpcf-fields-checkboxes-option-5b406ad9d0067f0e18103263d7e1c38e-1\";a:1:{i:0;s:1:\"1\";}}");
INSERT INTO `bak_postmeta` VALUES("769","115","_wp_attached_file","2018/04/Bep-tu-Cata-IB-633X.jpg");
INSERT INTO `bak_postmeta` VALUES("770","115","_wp_attachment_metadata","a:5:{s:5:\"width\";i:535;s:6:\"height\";i:478;s:4:\"file\";s:31:\"2018/04/Bep-tu-Cata-IB-633X.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Bep-tu-Cata-IB-633X-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Bep-tu-Cata-IB-633X-300x268.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:268;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("771","115","_wp_attachment_image_alt","bep tu cata ib 633x");
INSERT INTO `bak_postmeta` VALUES("772","108","_thumbnail_id","115");
INSERT INTO `bak_postmeta` VALUES("773","108","wpcf-product_display_price","18000000");
INSERT INTO `bak_postmeta` VALUES("774","108","wpcf-product_sell_price","14500000");
INSERT INTO `bak_postmeta` VALUES("775","108","wpcf-product_code","IB 633X");
INSERT INTO `bak_postmeta` VALUES("776","108","wpcf-num_cook","3");
INSERT INTO `bak_postmeta` VALUES("777","108","wpcf-product_promotion","Bộ nồi từ cao cấp");
INSERT INTO `bak_postmeta` VALUES("778","108","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("779","108","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("780","116","_wp_attached_file","2018/04/Bep-tu-Cata-IB-604-BK.jpg");
INSERT INTO `bak_postmeta` VALUES("781","116","_wp_attachment_metadata","a:5:{s:5:\"width\";i:550;s:6:\"height\";i:481;s:4:\"file\";s:33:\"2018/04/Bep-tu-Cata-IB-604-BK.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"Bep-tu-Cata-IB-604-BK-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"Bep-tu-Cata-IB-604-BK-300x262.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:262;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("782","116","_wp_attachment_image_alt","Bep tu cata ib 604 bk");
INSERT INTO `bak_postmeta` VALUES("783","106","_thumbnail_id","116");
INSERT INTO `bak_postmeta` VALUES("784","106","wpcf-product_display_price","14200000");
INSERT INTO `bak_postmeta` VALUES("785","106","wpcf-product_sell_price","13000000");
INSERT INTO `bak_postmeta` VALUES("786","106","wpcf-product_code","IB 604 BK");
INSERT INTO `bak_postmeta` VALUES("787","106","wpcf-num_cook","4");
INSERT INTO `bak_postmeta` VALUES("788","106","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("789","106","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("790","117","_edit_lock","1524158889:1");
INSERT INTO `bak_postmeta` VALUES("791","117","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("792","118","_wp_attached_file","2018/04/mat-kinh-bep-an-khang.png");
INSERT INTO `bak_postmeta` VALUES("793","118","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1814;s:6:\"height\";i:1248;s:4:\"file\";s:33:\"2018/04/mat-kinh-bep-an-khang.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"mat-kinh-bep-an-khang-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"mat-kinh-bep-an-khang-300x206.png\";s:5:\"width\";i:300;s:6:\"height\";i:206;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"mat-kinh-bep-an-khang-768x528.png\";s:5:\"width\";i:768;s:6:\"height\";i:528;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"mat-kinh-bep-an-khang-1024x704.png\";s:5:\"width\";i:1024;s:6:\"height\";i:704;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("794","119","_wp_attached_file","2018/04/anh-thuc-te-bep-chefs-EH-DIH32B.png");
INSERT INTO `bak_postmeta` VALUES("795","119","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1762;s:6:\"height\";i:1230;s:4:\"file\";s:43:\"2018/04/anh-thuc-te-bep-chefs-EH-DIH32B.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"anh-thuc-te-bep-chefs-EH-DIH32B-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"anh-thuc-te-bep-chefs-EH-DIH32B-300x209.png\";s:5:\"width\";i:300;s:6:\"height\";i:209;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:43:\"anh-thuc-te-bep-chefs-EH-DIH32B-768x536.png\";s:5:\"width\";i:768;s:6:\"height\";i:536;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:44:\"anh-thuc-te-bep-chefs-EH-DIH32B-1024x715.png\";s:5:\"width\";i:1024;s:6:\"height\";i:715;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("796","120","_wp_attached_file","2018/04/bep-tu-chefs-EH-DIH32B.png");
INSERT INTO `bak_postmeta` VALUES("797","120","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1420;s:6:\"height\";i:836;s:4:\"file\";s:34:\"2018/04/bep-tu-chefs-EH-DIH32B.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"bep-tu-chefs-EH-DIH32B-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"bep-tu-chefs-EH-DIH32B-300x177.png\";s:5:\"width\";i:300;s:6:\"height\";i:177;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"bep-tu-chefs-EH-DIH32B-768x452.png\";s:5:\"width\";i:768;s:6:\"height\";i:452;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"bep-tu-chefs-EH-DIH32B-1024x603.png\";s:5:\"width\";i:1024;s:6:\"height\";i:603;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("798","119","_wp_attachment_image_alt","anh thuc te bep chefs EH-DIH32B");
INSERT INTO `bak_postmeta` VALUES("799","117","_thumbnail_id","120");
INSERT INTO `bak_postmeta` VALUES("800","117","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("807","117","_yoast_wpseo_metadesc","Bếp từ Chefs EH-DIH32B ra mắt năm 2017 với công nghệ mới nhất từ E.G.O, có kích thước nhỏ gọn phù hợp với không gian bếp chung cư.");
INSERT INTO `bak_postmeta` VALUES("808","117","_yoast_wpseo_content_score","60");
INSERT INTO `bak_postmeta` VALUES("819","117","wpcf-product_display_price","9900000");
INSERT INTO `bak_postmeta` VALUES("820","117","wpcf-product_sell_price","8900000");
INSERT INTO `bak_postmeta` VALUES("821","117","wpcf-product_code","EH-DIH32B");
INSERT INTO `bak_postmeta` VALUES("822","117","wpcf-num_cook","2");
INSERT INTO `bak_postmeta` VALUES("823","117","wpcf-product_guarantee","2 năm");
INSERT INTO `bak_postmeta` VALUES("824","117","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("825","122","_edit_lock","1524159500:1");
INSERT INTO `bak_postmeta` VALUES("826","122","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("827","123","_wp_attached_file","2018/04/bep-tu-chefs-eh-ih534.png");
INSERT INTO `bak_postmeta` VALUES("828","123","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1682;s:6:\"height\";i:1036;s:4:\"file\";s:33:\"2018/04/bep-tu-chefs-eh-ih534.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"bep-tu-chefs-eh-ih534-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"bep-tu-chefs-eh-ih534-300x185.png\";s:5:\"width\";i:300;s:6:\"height\";i:185;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"bep-tu-chefs-eh-ih534-768x473.png\";s:5:\"width\";i:768;s:6:\"height\";i:473;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"bep-tu-chefs-eh-ih534-1024x631.png\";s:5:\"width\";i:1024;s:6:\"height\";i:631;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("829","124","_wp_attached_file","2018/04/mat-kinh-bep-ba-tu-eh-ih534.jpg");
INSERT INTO `bak_postmeta` VALUES("830","124","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:39:\"2018/04/mat-kinh-bep-ba-tu-eh-ih534.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"mat-kinh-bep-ba-tu-eh-ih534-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"mat-kinh-bep-ba-tu-eh-ih534-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"mat-kinh-bep-ba-tu-eh-ih534-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"mat-kinh-bep-ba-tu-eh-ih534-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("831","122","_thumbnail_id","123");
INSERT INTO `bak_postmeta` VALUES("832","122","_wp_old_slug","bep-tu-eh-ih534");
INSERT INTO `bak_postmeta` VALUES("833","122","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("841","122","_yoast_wpseo_metadesc","Bếp ba từ EH-IH534 là dòng bếp cao cấp của Chefs, với công nghệ mâm từ mới , mặt kính cấu trúc carbon siêu chịu lực có độ sần nhẹ.");
INSERT INTO `bak_postmeta` VALUES("842","122","_yoast_wpseo_content_score","90");
INSERT INTO `bak_postmeta` VALUES("850","122","wpcf-product_display_price","16200000");
INSERT INTO `bak_postmeta` VALUES("851","122","wpcf-product_sell_price","14500000");
INSERT INTO `bak_postmeta` VALUES("852","122","wpcf-product_code","EH-IH534");
INSERT INTO `bak_postmeta` VALUES("853","122","wpcf-num_cook","3");
INSERT INTO `bak_postmeta` VALUES("854","122","wpcf-product_promotion","Bộ nồi từ cao cấp");
INSERT INTO `bak_postmeta` VALUES("855","122","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("856","122","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("857","125","_edit_lock","1524159993:1");
INSERT INTO `bak_postmeta` VALUES("858","125","_edit_last","1");
INSERT INTO `bak_postmeta` VALUES("859","126","_wp_attached_file","2018/04/bep-hon-hop-chefs-Mix534.png");
INSERT INTO `bak_postmeta` VALUES("860","126","_wp_attachment_metadata","a:5:{s:5:\"width\";i:980;s:6:\"height\";i:653;s:4:\"file\";s:36:\"2018/04/bep-hon-hop-chefs-Mix534.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"bep-hon-hop-chefs-Mix534-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"bep-hon-hop-chefs-Mix534-300x200.png\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"bep-hon-hop-chefs-Mix534-768x512.png\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("861","127","_wp_attached_file","2018/04/bep-combo-chefs-EH-MIX534.jpg");
INSERT INTO `bak_postmeta` VALUES("862","127","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:682;s:4:\"file\";s:37:\"2018/04/bep-combo-chefs-EH-MIX534.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"bep-combo-chefs-EH-MIX534-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"bep-combo-chefs-EH-MIX534-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"bep-combo-chefs-EH-MIX534-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"bep-combo-chefs-EH-MIX534-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("863","125","_thumbnail_id","127");
INSERT INTO `bak_postmeta` VALUES("864","125","_yoast_wpseo_primary_product-category","7");
INSERT INTO `bak_postmeta` VALUES("865","125","wpcf-product_display_price","15900000");
INSERT INTO `bak_postmeta` VALUES("866","125","wpcf-product_sell_price","14300000");
INSERT INTO `bak_postmeta` VALUES("867","125","wpcf-product_code","EH-MIX534");
INSERT INTO `bak_postmeta` VALUES("868","125","wpcf-num_cook","3");
INSERT INTO `bak_postmeta` VALUES("869","125","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("870","125","wpcf-show","a:0:{}");
INSERT INTO `bak_postmeta` VALUES("871","125","_yoast_wpseo_metadesc","EH-MIX534 là dòng bếp hỗn hợp của Chefs, là 1 bộ combo giữa bếp 2 bếp từ và 1 bếp hồng ngoại trên cùng 1 chiếc bếp.");
INSERT INTO `bak_postmeta` VALUES("872","125","_yoast_wpseo_content_score","90");
INSERT INTO `bak_postmeta` VALUES("873","128","_wp_attached_file","2018/04/bep-tu-cata-ib-772-1.png");
INSERT INTO `bak_postmeta` VALUES("874","128","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1512;s:6:\"height\";i:918;s:4:\"file\";s:32:\"2018/04/bep-tu-cata-ib-772-1.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"bep-tu-cata-ib-772-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"bep-tu-cata-ib-772-1-300x182.png\";s:5:\"width\";i:300;s:6:\"height\";i:182;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"bep-tu-cata-ib-772-1-768x466.png\";s:5:\"width\";i:768;s:6:\"height\";i:466;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:33:\"bep-tu-cata-ib-772-1-1024x622.png\";s:5:\"width\";i:1024;s:6:\"height\";i:622;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `bak_postmeta` VALUES("875","128","_wp_attachment_image_alt","bep tu cata ib 772");
INSERT INTO `bak_postmeta` VALUES("876","62","_thumbnail_id","128");
INSERT INTO `bak_postmeta` VALUES("877","62","wpcf-product_display_price","14800000");
INSERT INTO `bak_postmeta` VALUES("878","62","wpcf-product_sell_price","13600000");
INSERT INTO `bak_postmeta` VALUES("879","62","wpcf-product_code","IB 772");
INSERT INTO `bak_postmeta` VALUES("880","62","wpcf-num_cook","2");
INSERT INTO `bak_postmeta` VALUES("881","62","wpcf-product_promotion","Bộ nồi inox cao cấp");
INSERT INTO `bak_postmeta` VALUES("882","62","wpcf-product_guarantee","3 năm");
INSERT INTO `bak_postmeta` VALUES("883","62","wpcf-show","a:1:{s:64:\"wpcf-fields-checkboxes-option-5b406ad9d0067f0e18103263d7e1c38e-1\";a:1:{i:0;s:1:\"1\";}}");


DROP TABLE IF EXISTS `bak_posts`;

CREATE TABLE `bak_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bak_posts` VALUES("2","1","2018-01-16 13:58:27","2018-01-16 13:58:27","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href=\"http://bepankhang.com/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!","Sample Page","","publish","closed","open","","sample-page","","","2018-01-16 13:58:27","2018-01-16 13:58:27","","0","http://bepankhang.com/?page_id=2","0","page","","0");
INSERT INTO `bak_posts` VALUES("7","1","2018-03-02 15:33:41","2018-03-02 15:33:41","","Product Fields","","publish","closed","closed","","product-fields","","","2018-04-13 04:57:26","2018-04-13 04:57:26","","0","http://bepankhang.com/wp-types-group/product-fields/","0","wp-types-group","","0");
INSERT INTO `bak_posts` VALUES("10","1","2018-03-02 15:48:46","2018-03-02 15:48:46","","EH-MIX333","","inherit","open","closed","","eh-mix333","","","2018-03-02 15:48:46","2018-03-02 15:48:46","","0","http://bepankhang.com/wp-content/uploads/2018/03/EH-MIX333.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("13","1","2018-03-05 10:07:24","2018-03-05 10:07:24","","honeybee-01","","inherit","open","closed","","honeybee-01","","","2018-03-05 10:07:24","2018-03-05 10:07:24","","0","http://bepankhang.com/wp-content/uploads/2018/03/honeybee-01.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("15","1","2018-03-05 10:59:22","2018-03-05 10:59:22","","in-menu-lau","","inherit","open","closed","","in-menu-lau","","","2018-03-05 10:59:22","2018-03-05 10:59:22","","0","http://bepankhang.com/wp-content/uploads/2018/03/in-menu-lau.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("17","1","2018-03-05 10:59:54","2018-03-05 10:59:54","","in-menu-kem","","inherit","open","closed","","in-menu-kem","","","2018-03-05 10:59:54","2018-03-05 10:59:54","","0","http://bepankhang.com/wp-content/uploads/2018/03/in-menu-kem.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("19","1","2018-03-05 11:01:29","2018-03-05 11:01:29","","so-sanh-in-menu-chuyen-nghiep","","inherit","open","closed","","so-sanh-in-menu-chuyen-nghiep","","","2018-03-05 11:01:29","2018-03-05 11:01:29","","0","http://bepankhang.com/wp-content/uploads/2018/03/so-sanh-in-menu-chuyen-nghiep.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("31","1","2018-03-08 16:56:37","2018-03-08 16:56:37","","Kiến thức liên quan","","publish","closed","closed","","kien-thuc-lien-quan","","","2018-03-08 16:56:42","2018-03-08 16:56:42","","0","http://bepankhang.com/?page_id=31","0","page","","0");
INSERT INTO `bak_posts` VALUES("32","1","2018-03-08 16:56:37","2018-03-08 16:56:37","","Kiến thức liên quan","","inherit","closed","closed","","31-revision-v1","","","2018-03-08 16:56:37","2018-03-08 16:56:37","","31","http://bepankhang.com/2018/03/08/31-revision-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("34","1","2018-03-08 17:34:17","2018-03-08 17:34:17","","Sản phẩm","","publish","closed","closed","","san-pham","","","2018-03-08 17:34:17","2018-03-08 17:34:17","","0","http://bepankhang.com/?page_id=34","0","page","","0");
INSERT INTO `bak_posts` VALUES("35","1","2018-03-08 17:34:17","2018-03-08 17:34:17","","Sản phẩm","","inherit","closed","closed","","34-revision-v1","","","2018-03-08 17:34:17","2018-03-08 17:34:17","","34","http://bepankhang.com/2018/03/08/34-revision-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("39","1","2018-04-06 19:01:21","2018-04-06 19:01:21","<strong><em>Nếu bạn mới chuyển từ bếp gas sang dùng bếp từ, và vẫn còn phân vân giữa các dòng bếp, thì bếp từ đôi Chefs EH-DIH321 chính là dòng bếp đáng tham khảo. Bởi ngoài những tính năng ưu việt, dòng bếp từ đôi này còn vô cùng tiết kiệm điện năng.</em></strong>
<h3>Tính năng sản phẩm</h3>
<ul class=\"features\">
 	<li>Đun nấu <strong>siêu tiết kiệm</strong> với bếp hai từ EH-DIH321</li>
 	<li>Mặt kính ceramic chịu nhiệt Schott Ceran vát cạnh – Germany</li>
 	<li>Mâm từ tự động nhận biết kích cỡ xoong nồi, đường kính 22cm / 2000W</li>
 	<li><strong>Hẹn giờ</strong> độc lập cho từng vùng nấu, thời gian hẹn đến 8.00 giờ</li>
 	<li>Điều khiển công suất / nhiệt độ nhiều mức</li>
 	<li>Bàn <strong>phím</strong> <strong>siêu nhạy</strong> cả khi tay ướt</li>
 	<li>Tự động <strong>chia sẻ công suất</strong> giữa 2 bếp, max 3400W</li>
</ul>
&nbsp;

<img class=\"alignnone size-medium wp-image-56\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-chefs-eh-dih321.png\" alt=\"\" />
<h3>Tính năng an toàn</h3>
<ul class=\"features\">
 	<li>Cảnh báo nhiệt dư vùng nấu Residual heat</li>
 	<li>Khóa an toàn trẻ em Child lock</li>
 	<li>Tự động tắt bếp khi để quên Automatic switching off</li>
 	<li>Tự động tắt bếp khi không có nồi ( trên bếp từ) Pot detection</li>
 	<li>Hệ thống bảo vệ an toàn quá nhiệt, quá áp</li>
</ul>
<h3>Tính năng mặt kính</h3>
<ul class=\"features\">
 	<li>Mặt kính liền nguyên khối, vát cạnh, màu đen sang trọng</li>
 	<li>Bề mặt chống trầy xước, chịu lực cao</li>
 	<li>Khả năng chịu nhiệt lên đến 1000<strong>° </strong>C, chịu sốc nhiệt đến 800<strong>° </strong>C</li>
</ul>
&nbsp;

<img class=\"alignnone size-medium wp-image-57\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-bep-tu-chefs-eh-dih321.png\" alt=\"\" />

&nbsp;

<h3>Bảng thông số bếp từ đôi chefs EH-DIH321</h3>
<table class=\"spec\">    
    <tr>
        <td><i class=\"fas fa-keyboard\"></i> Bảng điều khiển</td>
        <td>Cảm ứng</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-clock\"></i> Chế độ hẹn giờ</td>
        <td>Có</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-volume-up\"></i> Báo động âm thanh</td>
        <td>Có</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-plug\"></i> Nguồn điện</td>
        <td>220/50-60Hz</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-power-off\"></i> Công suất</td>
        <td>4000W</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
        <td>720 x 430 x 80 mm</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
        <td>680 x 400 mm</td>
    </tr>    
</table>


<div class=\"iframe-wrapper\">
    <div class=\"h_iframe\">
<iframe id=\"product-video\" width=\"2\" height=\"2\" src=\"https://www.youtube.com/embed/mS37sKMnzKU\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>
    </div>
</div>

<div id=\"chot-ha\">Bạn có nhu cầu đặt mua sản phẩm, hoặc cần tìm hiểu thêm thông tin về dòng <b>bếp từ đôi Chefs EH-DIH321</b> này, xin vui lòng liên hệ hotline: <a href=\"tel:09xxxxx\">09XXXXXX</a></div>","Bếp từ đôi chefs EH-DIH321","","publish","closed","closed","","bep-tu-doi-chefs-eh-dih321","","","2018-04-13 05:00:07","2018-04-13 05:00:07","","0","http://bepankhang.test/?post_type=product&#038;p=39","0","product","","0");
INSERT INTO `bak_posts` VALUES("40","1","2018-04-06 19:01:40","2018-04-06 19:01:40","","bep-tu-doi-chefs-DIH321","","inherit","open","closed","","bep-tu-doi-chefs-dih321","","","2018-04-06 19:01:40","2018-04-06 19:01:40","","39","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-doi-chefs-DIH321.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("44","1","2018-04-09 15:22:04","2018-04-09 15:22:04","<strong><em>Nếu bạn mới chuyển từ bếp gas sang dùng bếp từ, và vẫn còn phân vân giữa các dòng bếp, thì bếp từ đôi Chefs EH-DIH321 chính là dòng bếp đáng tham khảo. Bởi ngoài những tính năng ưu việt, dòng bếp từ đôi này còn vô cùng tiết kiệm điện năng.</em></strong>
<h3>Tính năng sản phẩm</h3>
<ul class=\"features\">
 	<li>Đun nấu <strong>siêu tiết kiệm</strong> với bếp hai từ EH-DIH321</li>
 	<li>Mặt kính ceramic chịu nhiệt Schott Ceran vát cạnh – Germany</li>
 	<li>Mâm từ tự động nhận biết kích cỡ xoong nồi, đường kính 22cm / 2000W</li>
 	<li><strong>Hẹn giờ</strong> độc lập cho từng vùng nấu, thời gian hẹn đến 8.00 giờ</li>
 	<li>Điều khiển công suất / nhiệt độ nhiều mức</li>
 	<li>Bàn <strong>phím</strong> <strong>siêu nhạy</strong> cả khi tay ướt</li>
 	<li>Tự động <strong>chia sẻ công suất</strong> giữa 2 bếp, max 3400W</li>
</ul>
&nbsp;

<img class=\"alignnone size-medium wp-image-56\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-chefs-eh-dih321.png\" alt=\"\" />
<h3>Tính năng an toàn</h3>
<ul class=\"features\">
 	<li>Cảnh báo nhiệt dư vùng nấu Residual heat</li>
 	<li>Khóa an toàn trẻ em Child lock</li>
 	<li>Tự động tắt bếp khi để quên Automatic switching off</li>
 	<li>Tự động tắt bếp khi không có nồi ( trên bếp từ) Pot detection</li>
 	<li>Hệ thống bảo vệ an toàn quá nhiệt, quá áp</li>
</ul>
<h3>Tính năng mặt kính</h3>
<ul class=\"features\">
 	<li>Mặt kính liền nguyên khối, vát cạnh, màu đen sang trọng</li>
 	<li>Bề mặt chống trầy xước, chịu lực cao</li>
 	<li>Khả năng chịu nhiệt lên đến 1000<strong>° </strong>C, chịu sốc nhiệt đến 800<strong>° </strong>C</li>
</ul>
&nbsp;

<img class=\"alignnone size-medium wp-image-57\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-bep-tu-chefs-eh-dih321.png\" alt=\"\" />

&nbsp;

<h3>Bảng thông số bếp từ đôi chefs EH-DIH321</h3>
<table class=\"spec\">    
    <tr>
        <td><i class=\"fas fa-keyboard\"></i> Bảng điều khiển</td>
        <td>Cảm ứng</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-clock\"></i> Chế độ hẹn giờ</td>
        <td>Có</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-volume-up\"></i> Báo động âm thanh</td>
        <td>Có</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-plug\"></i> Nguồn điện</td>
        <td>220/50-60Hz</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-power-off\"></i> Công suất</td>
        <td>4000W</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
        <td>720 x 430 x 80 mm</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
        <td>680 x 400 mm</td>
    </tr>    
</table>


<div class=\"iframe-wrapper\">
    <div class=\"h_iframe\">
<iframe id=\"product-video\" width=\"2\" height=\"2\" src=\"https://www.youtube.com/embed/mS37sKMnzKU\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>
    </div>
</div>

<div>Bạn có nhu cầu đặt mua sản phẩm, hoặc cần tìm hiểu thêm thông tin về dòng bếp từ đôi Chefs </div>","Bếp từ đôi chefs EH-DIH321","","inherit","closed","closed","","39-autosave-v1","","","2018-04-09 15:22:04","2018-04-09 15:22:04","","39","http://bepankhang.test/39-autosave-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("45","1","2018-04-07 08:24:56","2018-04-07 08:24:56","","Liên Hệ","","trash","closed","closed","","__trashed","","","2018-04-07 08:24:56","2018-04-07 08:24:56","","0","http://bepankhang.test/?page_id=45","0","page","","0");
INSERT INTO `bak_posts` VALUES("46","1","2018-04-07 07:46:10","2018-04-07 07:46:10","","Liên Hệ","","publish","closed","closed","","lien-he","","","2018-04-07 07:46:10","2018-04-07 07:46:10","","0","http://bepankhang.test/?page_id=46","0","page","","0");
INSERT INTO `bak_posts` VALUES("47","1","2018-04-07 07:46:10","2018-04-07 07:46:10","","Liên Hệ","","inherit","closed","closed","","46-revision-v1","","","2018-04-07 07:46:10","2018-04-07 07:46:10","","46","http://bepankhang.test/46-revision-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("48","1","2018-04-07 08:21:55","2018-04-07 08:21:55","<em>Bạn đã thấy những chiếc bếp điện từ  (bếp từ) với nhiều kiểu dáng đẹp và tiện dụng như thế nào. Thế nhưng bạn vẫn còn băn khoăn rằng liệu dùng bếp điện từ có tốn điện không? Bếp An Khang sẽ cùng bạn phân tích để làm rõ vấn đề này.</em>
<h3>Trước hết chúng ta sẽ tìm hiểu về công suất của các dòng bếp điện từ.</h3>
Đại đa số các dòng bếp điện từ ngày nay có công suất trung bình khoảng 2500W. 1 số dòng tầm trung có công suất &lt; 2000W, thường là các dòng bếp đơn hoặc bếp đôi giá rẻ. Cũng có 1 số dòng cao cấp có công suất &gt; 3000W, thậm chí &gt;3500W (chức năng booster - nấu siêu nhanh).

Dù là ở mức công suất nào thì lượng điện năng bỏ ra cũng sẽ gần như nhau, bởi khi sử dụng bếp có công suất càng cao, thì thời gian nấu sẽ càng giảm. Do đó ta tạm lấy con số 2500W làm khung chuẩn cho ví dụ dưới đây.

Giả sử bạn sử dụng 1 bếp từ có công suất ~ 2500W (như <a href=\"/product/bep-tu-cata-i2-plus/\">Cata IB 2 Plus</a>) thì thời gian để nấu sôi 1 lít nước chỉ sẽ chỉ mất khoảng 2 phút. Như vậy trong 2 phút đó bạn chỉ tiêu thụ: 2500x2/60 = 83,3W - tương đương với 0,083KW điện. Có lẽ bạn sẽ khá ngạc nhiên khi chỉ sử dụng 0,083KW điện là đã có thể nấu chín 1 lít nước.

<img class=\"alignnone size-full wp-image-94\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-nhieu-muc-cong-suat.jpg\" alt=\"bep dien tu co nhieu muc cong suat\" />
<h3>Vậy nên sử dụng bếp điện từ có công suất bao nhiêu để tiết kiệm nhất?</h3>
Như Bếp An Khang đã trình bày trên, công suất càng lớn thì thời gian nấu càng giảm, do đó bạn không cần quá quan tâm đến việc tiết kiệm điện năng, thay vào đó hãy chọn dòng bếp nào phù hợp với nhu cầu chế biến món ăn của mình. Vd: Nếu bạn chỉ dùng để hâm nóng nồi lẩu để ăn trực tiếp cùng gia đình, bạn chỉ cần dùng loại bếp từ có công suất nhỏ. Còn nếu bạn muốn dùng ngay chiếc bếp từ đó để nấu lẩu luôn, thì nên sử dụng bếp có công suất lớn.

Ngoài ra trên thị trường hiện nay cũng có rất nhiều dòng bếp có đến 2-3, thậm chí 4 vùng từ (điển hình là <a href=\"/product/bep-tu-bosch-pvs851fb1e/\">BOSCH PVS851FB1E</a>), mỗi vùng từ tương đương với 1 bếp nấu có công suất khác nhau, phù hợp với nhiều hình thức chế biến món ăn: đun sôi, chiên, xào, hấp, nướng,....

<a href=\"http://bepankhang.test/product/bep-tu-bosch-pvs851fb1e/\"><img class=\"alignnone size-large wp-image-89\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-bosch-PVS851FB1E-1024x1024.jpg\" alt=\"\" width=\"1024\" height=\"1024\" /></a>

Như vậy là bạn không cần phải băn khoăn về tính tiết kiệm khi sử dụng bếp điện từ nữa nhé. Bạn có thể liên hệ bếp An Khang để chọn ngay cho mình 1 con bếp phù hợp. Hoặc có thể vào đây để tìm hiểu thêm <a href=\"http://bepankhang.test/qna/uu-nhuoc-diem-cua-bep-hong-ngoai/\">những ưu điểm khác của bếp điện từ</a> nhé.","Dùng bếp điện từ có tốn điện không?","","publish","closed","closed","","dung-bep-dien-tu-co-ton-dien-khong","","","2018-04-12 11:28:49","2018-04-12 11:28:49","","0","http://bepankhang.test/?post_type=qna&#038;p=48","0","qna","","0");
INSERT INTO `bak_posts` VALUES("49","1","2018-04-07 08:22:10","2018-04-07 08:22:10","<em>Trên thị trường những năm gần đây có rất nhiều dòng bếp điện từ, đa dạng về mẫu mã lẫn chức năng, điều này khiến bạn khó có thể chọn ra cho mình 1 chiêc bếp. Hãy cùng tham khảo kinh nghiệm chọn mua bếp điện từ qua bài viết này nhé</em>
<h3>Trước tiên, bạn cần xác định rõ mục đích sử dụng của mình là gì.</h3>
Nếu chỉ muốn dùng bếp từ để hâm nóng lẩu, nấu canh, luộc rau,... bạn có thể chọn 1 dòng bếp từ thông thường. Nếu bạn muốn thay thế hoàn toàn cho bếp gas và thực hiện tất cả các phương thức chế biến như chiên, xào, nướng.... thì bạn cần đến 1 chiếc <a href=\"http://bepankhang.test/product/bep-tu-cata-ib-772/\">bếp từ cao cấp</a> hơn.<br/>

Số lượng vùng từ cũng là 1 tiêu chuẩn khi chọn mua bếp, tùy theo nhu cầu nấu \"nhiều hay ít bếp cùng lúc\" của bạn. Nếu gia đình bạn khá đông người và bạn muốn làm bữa ăn nhanh chóng, thì cùng 1 lúc bạn có thể làm món mặn, món xào, món canh,... bằng cách sử dụng bộ bếp 3 từ hoặc 4 từ<br />

<a href=\"http://bepankhang.test/product/bep-tu-bosch-pid675n24e/\"><img class=\"alignnone size-full wp-image-73\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-3-tu-bosch-pid675n24e.png\" alt=\"bep 3 vung tu\" /></a>

Nếu bạn quan tâm đến độ bền của bếp, bạn có thể chọn những dòng bếp với <strong>mặt kính Schott Ceran</strong> - loại mặt kính cao cấp được sản xuất tại nhà máy của tập đoàn công nghệ quốc tế SCHOTT ở Mainz – Đức. Ưu điểm của mặt kính này là chịu nhiệt cực tốt, gần như không giãn nở vì nhiệt. Độ bền cao và chịu được tác động cơ học từ môi trường ngoài. Tránh tối đa tình trạng nứt vỡ mặt kính. Đặc biệt kính SCHOTT còn rất thân thiện với môi trường bởi nó không chứa các kim loại nặng độc hại như asen và antimon.<br />

<img class=\"alignnone size-full wp-image-101\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-Schott-Ceran-do-ben-cao.jpg\" alt=\"mat kinh Schott Ceran co do ben cao\" />

<strong>Kích thước</strong> cũng là 1 vấn đề hết sức đáng lưu ý khi chọn mua bếp điện từ. Mặc dù nhìn bên ngoài các dòng bếp đều có form khá tương đồng nhau, nhưng thực chất mỗi dòng lại có 1 kích thước riêng. Mỗi chiếc bếp đều có 2 thông số về kích thước là kích thước thực tế của bếp và kích thước vùng cắt đá. Bạn nên đo lại kích thước bếp nhà mình, tính toán kỹ phần cắt đá để chọn ra chiếc bếp từ có kích thước phù hợp nhất, tránh tình trạng hàng mua về đến tận nhà rồi mới phát hiện ra nó không vừa với tủ bếp nhà mình nhé. :)<br /><br />

Về mặt <strong>thương hiệu</strong>, hiện có rất nhiều thương hiệu về bếp điện từ. Tuy nhiên, theo kinh nghiệm chăm sóc khách hàng và bán hàng lâu năm của bếp An Khang, những dòng bếp Cata, Chefs, Bosch,... thường được khách hàng quan tâm và đánh giá cao hơn. Hàng của những hãng này sau khi bán cho nhiều khách được nhận xét rất tốt. Tất nhiên giá của chúng có hơi cao so với giá thành chung của bếp điện từ, nhưng xem xét về mặt lâu dài và ổn định, cũng như chế độ bảo hành, các dòng này vẫn chiếm ưu thế nhiều hơn. Đây đều là những thương hiệu về bếp nổi tiếng tại thị trường châu Âu.<br />

<img class=\"alignnone size-large wp-image-102\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/kinh-nghiem-chon-mua-bep-dien-tu-1024x576.jpg\" alt=\"kinh nghiem chon mua bep dien tu\" width=\"1024\" height=\"576\" />

Hy vọng qua bài viết trên bạn đã có đủ kinh nghiệm để chọn mua bếp điện từ cho gia đình. Nếu còn bất cứ thắc mắc hay phân vân giữa các dòng bếp, xin vui lòng liên hệ Bếp An Khang để được tư vấn cụ thể hơn. Chúc các bạn sớm tìm được một chiếc bếp ưng ý!

&nbsp;","Kinh nghiệm chọn mua bếp điện từ","","publish","closed","closed","","kinh-nghiem-chon-mua-bep-dien-tu","","","2018-04-13 04:09:56","2018-04-13 04:09:56","","0","http://bepankhang.test/?post_type=qna&#038;p=49","0","qna","","0");
INSERT INTO `bak_posts` VALUES("50","1","2018-04-07 08:22:34","2018-04-07 08:22:34","<em>Đã và đang dần thay thế thị trường bếp gas, bếp điện từ có rất nhiều tính năng vượt trội và được nhiều người tin dùng. Vậy những ưu điểm của bếp điện từ là gì?</em>
<h2>Những ưu điểm của bếp điện từ</h2>
Ưu điểm đầu tiên dễ thấy được là <strong>ngoại hình</strong> của những chiếc bếp điện từ rất ưa nhìn. Với vẻ ngoài sang trọng và tinh tế: thân hợp kim cứng cáp, mặt kính chịu nhiệt (có những loại cao cấp hơn với mặt kính schott ceran). Thiết kế phẳng và mỏng theo phong cách Châu Âu, rất vừa mắt khi đặt trong một căn bếp hiện đại.

<img class=\"alignnone size-large wp-image-96\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/uu-diem-bep-dien-tu-1024x818.png\" alt=\"dep la 1 uu diem cua bep dien tu\" />

&nbsp;

Ưu điểm thứ hai của bếp điện từ là <strong>không tỏa nhiệt ra bên ngoài</strong>. Chúng sử dụng điện từ trường để làm nóng thức ăn bên trong các nồi chuyên dụng. Như vậy không gian bếp của bạn sẽ không bị ngột ngạt vì luồng không khí nóng khi nấu ăn như sử dụng bếp gas thông thường. Chính vì đặc tính này mà nhiều người còn gắn trực tiếp bếp tường lên ngay trên bàn ăn gia đình luôn.

&nbsp;

<img class=\"alignnone size-full wp-image-97\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-dung-nhu-ban-an.jpg\" alt=\"Dung bep dien tu nhu ban an\" />

&nbsp;

<b>An toàn</b> là 1 ưu điểm mạnh của bếp điện từ. Bạn có thể yên tâm khi vắng nhà mà không cần lo các sự cố về rò rĩ khí gas, cháy nổ bình gas... như trước đây. Đây là lý do chính khiến rất nhiều người sống tại các chung cư cao tầng đã thay bếp gas thông thường bằng bếp điện từ. Ngoài tính an toàn cháy vừa kể thì bếp cũng an toàn cho trẻ em, bởi nó chỉ làm nóng phần thức ăn đặt trong nồi từ, sau khi sử dụng trẻ có vô ý sờ lên mặt bếp thì cũng sẽ không bị bỏng. Ngoài ra 1 số dòng bếp từ cao cấp còn có chức năng hẹn giờ, báo động,.... tất cả nhằm mục đích bảo đảm an toàn cho gia đình.

&nbsp;

<img class=\"alignnone size-full wp-image-98\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-rat-an-toan.jpg\" alt=\"bep dien tu rat an toan\" />

&nbsp;

Thêm một ưu điểm của bếp điện từ nữa, đó là <strong>dễ vệ sinh</strong>. Do bề mặt là kính thủy tinh chịu nhiệt, bếp sẽ không bị rỉ sét, thậm chí cả khi tiếp xúc với dầu mỡ, bạn chỉ cần lau sơ qua là mặt kính đã trong suốt trở lại. Điều này vô cùng tiện lợi cho các bà nội trợ muốn chăm sóc cho căn bếp gia đình mình.

&nbsp;

<img class=\"alignnone size-large wp-image-99\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/uu-diem-cua-bep-dien-tu-de-ve-sinh.jpg\" alt=\"de ve sinh la 1 uu diem cua bep dien tu\" />

&nbsp;

Nếu bạn quan tâm đến vấn đề tài chính, thì càng nên sử dụng bếp điện từ, bởi chúng <strong>tiết kiệm cả về điện năng lẫn thời gian</strong> cho bạn nữa. Bạn có thể tham khảo bài viết này để tìm hiểu về độ tiết kiệm của chúng: <a href=\"http://bepankhang.test/qna/dung-bep-dien-tu-co-ton-dien-khong/\">Bếp điện từ có tốn điện không?</a>

Trên đây là những ưu điểm của bếp điện từ. Nếu bạn quan tâm và muốn đặt 1 chiếc bếp tuyệt vời như vậy vào không gian bếp nhà mình, hãy liên hệ ngay với <a href=\"http://bepankhang.com/lien-he\">Bếp An Khang</a> để được tư vấn và hỗ trợ nhiệt tình ngay nhé.","Ưu điểm của bếp điện từ?","","publish","closed","closed","","uu-diem-cua-bep-dien-tu","","","2018-04-13 02:34:34","2018-04-13 02:34:34","","0","http://bepankhang.test/?post_type=qna&#038;p=50","0","qna","","0");
INSERT INTO `bak_posts` VALUES("51","1","2018-04-07 08:22:42","2018-04-07 08:22:42","fwfaw","So sánh bếp điện từ và bếp hồng ngoại","","trash","closed","closed","","sanh-bep-dien-tu-va-bep-hong-ngoai__trashed","","","2018-04-13 04:45:21","2018-04-13 04:45:21","","0","http://bepankhang.test/?post_type=qna&#038;p=51","0","qna","","0");
INSERT INTO `bak_posts` VALUES("52","1","2018-04-07 08:22:49","2018-04-07 08:22:49","abwew","Ưu nhược điểm của bếp hồng ngoại","","trash","closed","closed","","uu-nhuoc-diem-cua-bep-hong-ngoai__trashed","","","2018-04-13 04:45:21","2018-04-13 04:45:21","","0","http://bepankhang.test/?post_type=qna&#038;p=52","0","qna","","0");
INSERT INTO `bak_posts` VALUES("53","1","2018-04-07 08:24:56","2018-04-07 08:24:56","","Liên Hệ","","inherit","closed","closed","","45-revision-v1","","","2018-04-07 08:24:56","2018-04-07 08:24:56","","45","http://bepankhang.test/45-revision-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("54","1","2018-04-07 08:25:11","2018-04-07 08:25:11","","Câu hỏi thường gặp","","publish","closed","closed","","qna","","","2018-04-19 16:13:27","2018-04-19 16:13:27","","0","http://bepankhang.test/?page_id=54","0","page","","0");
INSERT INTO `bak_posts` VALUES("55","1","2018-04-07 08:25:11","2018-04-07 08:25:11","","Câu hỏi thường gặp","","inherit","closed","closed","","54-revision-v1","","","2018-04-07 08:25:11","2018-04-07 08:25:11","","54","http://bepankhang.test/54-revision-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("56","1","2018-04-07 09:40:17","2018-04-07 09:40:17","","bep-tu-chefs-eh-dih321","","inherit","open","closed","","bep-tu-chefs-eh-dih321","","","2018-04-07 09:40:17","2018-04-07 09:40:17","","39","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-chefs-eh-dih321.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("57","1","2018-04-07 09:40:31","2018-04-07 09:40:31","","mat-kinh-bep-tu-chefs-eh-dih321","","inherit","open","closed","","mat-kinh-bep-tu-chefs-eh-dih321","","","2018-04-07 09:40:31","2018-04-07 09:40:31","","39","http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-bep-tu-chefs-eh-dih321.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("58","1","2018-04-09 15:48:28","2018-04-09 15:48:28","<strong><em>Một trong những dòng bếp từ nhập khẩu đang hot trên thị trường, với những tính năng ưu việt và tiện ích, bếp từ đôi Chefs EH-DIH2000A đã và đang được phân phối rộng rãi trên khắp các showroom.</em></strong>
<h3>Tính năng sản phẩm</h3>
<ul class=\"features\">
 	<li>Đun nấu siêu tiết kiệm với bếp hai từ EH-DIH2000A</li>
 	<li>Mặt kính ceramic chịu nhiệt NEG vát cạnh, Made in Japan.</li>
 	<li>Mâm từ tự động nhận biết kích cỡ xoong nồi, đường kính 20cm / 2000W</li>
 	<li>Hẹn giờ độc lập cho từng vùng nấu, thời gian hẹn đến 8.00 giờ</li>
 	<li>Điều khiển công suất / nhiệt độ nhiều mức</li>
 	<li>Bàn phím siêu nhạy cả khi tay ướt</li>
 	<li>Tự động chia sẻ công suất giữa 2 bếp, max 3200W</li>
</ul>
&nbsp;

<img class=\"alignnone size-medium wp-image-59\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-nhap-khau-chefs-eh-dih2000a-300x225.jpg\" alt=\"\" width=\"300\" height=\"225\" />
<h3>Tính năng an toàn</h3>
<ul class=\"features\">
 	<li>Cảnh báo nhiệt dư vùng nấu Residual heat</li>
 	<li>Khóa an toàn trẻ em Child lock</li>
 	<li>Tự động tắt bếp khi để quên Automatic switching off</li>
 	<li>Tự động tắt bếp khi không có nồi Pot detection</li>
 	<li>Hệ thống bảo vệ an toàn quá nhiệt, quá áp</li>
</ul>
<h3>Tính năng mặt kính</h3>
<ul class=\"features\">
 	<li>Mặt kính liền nguyên khối, vát cạnh, màu đen sang trọng</li>
 	<li>Bề mặt chống trầy xước, chịu lực cao</li>
 	<li>Khả năng chịu nhiệt lên đến 1000oC, chịu sốc nhiệt đến 800oC</li>
</ul>
&nbsp;
<h3>Bảng thông số bếp từ đôi chefs EH-DIH321</h3>
<table class=\"spec\">
<tbody>
<tr>
<td><i class=\"fas fa-clock\"></i> Chế độ hẹn giờ</td>
<td>Không</td>
</tr>
<tr>
<td><i class=\"fas fa-volume-up\"></i> Báo động âm thanh</td>
<td>Không</td>
</tr>
<tr>
<td><i class=\"fas fa-plug\"></i> Nguồn điện</td>
<td>160-240VAC</td>
</tr>
<tr>
<td><i class=\"fas fa-power-off\"></i> Công suất</td>
<td>0 - 3400W</td>
</tr>
<tr>
<td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
<td>690 x 420 x 80mm</td>
</tr>
<tr>
<td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
<td>670 x 390mm</td>
</tr>
</tbody>
</table>
<div class=\"iframe-wrapper\">
<div class=\"h_iframe\"><iframe id=\"product-video\" src=\"https://www.youtube.com/embed/mS37sKMnzKU\" width=\"2\" height=\"2\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></div>
</div>
<div id=\"chot-ha\">Nếu quý khách đang còn phân vân về <b>bếp từ đôi Chefs EH-DIH2000A</b> này, hãy đến với showroom của <b>bếp An Khang</b> để được tư vấn giải đáp</div>","BẾP TỪ ĐÔI CHEFS EH-DIH2000A","","publish","closed","closed","","bep-tu-doi-chefs-eh-dih2000a","","","2018-04-13 05:00:03","2018-04-13 05:00:03","","0","http://bepankhang.test/?post_type=product&#038;p=58","0","product","","0");
INSERT INTO `bak_posts` VALUES("59","1","2018-04-09 15:38:08","2018-04-09 15:38:08","","bep-tu-nhap-khau-chefs-eh-dih2000a","","inherit","open","closed","","bep-tu-nhap-khau-chefs-eh-dih2000a","","","2018-04-09 15:38:08","2018-04-09 15:38:08","","58","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-nhap-khau-chefs-eh-dih2000a.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("60","1","2018-04-09 15:38:09","2018-04-09 15:38:09","","bep-tu-doi-chefs-eh-dih2000a","","inherit","open","closed","","bep-tu-doi-chefs-eh-dih2000a","","","2018-04-09 15:38:09","2018-04-09 15:38:09","","58","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-doi-chefs-eh-dih2000a.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("61","1","2018-04-09 15:49:30","2018-04-09 15:49:30","<strong><em>Một trong những dòng bếp từ nhập khẩu đang hot trên thị trường, với những tính năng ưu việt và tiện ích, bếp từ đôi Chefs EH-DIH2000A đã và đang được phân phối rộng rãi trên khắp các showroom.</em></strong>
<h3>Tính năng sản phẩm</h3>
<ul class=\"features\">
     <li>Đun nấu siêu tiết kiệm với bếp hai từ EH-DIH2000A </li>
     <li>Mặt kính ceramic chịu nhiệt NEG vát cạnh, Made in Japan. </li>
     <li>Mâm từ tự động nhận biết kích cỡ xoong nồi, đường kính 20cm / 2000W </li>
     <li>Hẹn giờ độc lập cho từng vùng nấu, thời gian hẹn đến 8.00 giờ </li>
     <li>Điều khiển công suất / nhiệt độ nhiều mức </li>
     <li>Bàn phím siêu nhạy cả khi tay ướt </li>
     <li>Tự động chia sẻ công suất giữa 2 bếp, max 3200W </li>
</ul>
&nbsp;

<img src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-nhap-khau-chefs-eh-dih2000a-300x225.jpg\" alt=\"\" width=\"300\" height=\"225\" class=\"alignnone size-medium wp-image-59\" />

<h3>Tính năng an toàn</h3>
<ul class=\"features\">
     <li>Cảnh báo nhiệt dư vùng nấu Residual heat </li>
     <li>Khóa an toàn trẻ em Child lock </li>
     <li>Tự động tắt bếp khi để quên Automatic switching off </li>
     <li>Tự động tắt bếp khi không có nồi Pot detection </li>
     <li>Hệ thống bảo vệ an toàn quá nhiệt, quá áp </li>
</ul>
<h3>Tính năng mặt kính</h3>
<ul class=\"features\">
     <li>Mặt kính liền nguyên khối, vát cạnh, màu đen sang trọng </li>
     <li>Bề mặt chống trầy xước, chịu lực cao </li>
     <li>Khả năng chịu nhiệt lên đến 1000oC, chịu sốc nhiệt đến 800oC </li>
</ul>
&nbsp;


<h3>Bảng thông số bếp từ đôi chefs EH-DIH321</h3>
<table class=\"spec\">        
    <tr>
        <td><i class=\"fas fa-clock\"></i> Chế độ hẹn giờ</td>
        <td>Không</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-volume-up\"></i> Báo động âm thanh</td>
        <td>Không</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-plug\"></i> Nguồn điện</td>
        <td>160-240VAC</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-power-off\"></i> Công suất</td>
        <td>0 - 3400W</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
        <td>690 x 420 x 80mm</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
        <td>670 x 390mm</td>
    </tr>    
</table>


<div class=\"iframe-wrapper\">
    <div class=\"h_iframe\">
<iframe id=\"product-video\" width=\"2\" height=\"2\" src=\"https://www.youtube.com/embed/mS37sKMnzKU\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>
    </div>
</div>

<div id=\"chot-ha\">Nếu quý khách đang còn phân vân về <b>bếp từ đôi Chefs EH-DIH2000A</b> này, hãy đến với showroom của <b>bếp An Khang</b> để được tư vấn giải đáp</div>","BẾP TỪ ĐÔI CHEFS EH-DIH2000A","","inherit","closed","closed","","58-autosave-v1","","","2018-04-09 15:49:30","2018-04-09 15:49:30","","58","http://bepankhang.test/58-autosave-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("62","1","2018-04-09 16:51:17","2018-04-09 16:51:17","<strong><em>Bạn đã setup một không gian bếp ấm cúng với nội thất sang trọng, và bạn muốn đặt vào đó 1 chiếc bếp tương xứng với nhà bếp của mình? Bếp từ đôi Cata IB 772 chính là dòng sản phẩm bạn đang tìm kiếm, bởi ngoài các chức năng độc đáo, nó còn khoác lên mình vẻ đẹp tinh tế với đường cong và mặt kính sáng bóng.</em></strong>
<h3>Tính năng bếp từ Cata IB 772</h3>
<ul class=\"features\">
 	<li>Bảng điều khiển slider độc đáo, ngoài sự tiện lợi còn đem đến cho sản phẩm này 1 vẻ đẹp khác biệt. Cata đã thành công trong việc tối giản thiết kế cho IB 772  khiến nó trở nên độc đáo hơn so với các dòng sản phẩm tương đương. Tất nhiên bạn cũng không cần phải lo về độ nhạy của slider này. Nó có thể nhận tín hiệu với những cái chạm nhẹ nhất.</li>
 	<li>Với 9 mức nhiệt độ phù hợp với mọi cách chế biến món ăn,  và 1 chế độ booster cho phép nấu siêu nhanh. Giúp tiết kiệm tối đa thời gian chuẩn bị bữa ăn ngon cho gia đình nhà bạn.</li>
 	<li>Ngoài ra vùng nấu của chiếc bếp từ Cata IB 772 này cũng đã được tinh chỉnh rất phù hợp với thói quen nấu nướng của đại đa số các bà nội trợ: 2 vùng từ chia làm nhiều kích thước nấu khác nhau, cho phép sử dụng nhiều kích cỡ nồi, tiện lợi cho việc chế biến nhanh 1 bữa ăn với nhiều món.</li>
 	<li>Mặt kính cũng là 1 điểm cộng khác của IB 772, mặt kính Schott ceran nổi tiếng tại Tây Ban Nha, phủ lên trên phần thân bọc thép phủ sơn tĩnh điện, giúp chiếc bếp từ mang 1 vẻ đẹp khỏe khoắn.</li>
</ul>
<img class=\"alignnone size-medium wp-image-65\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-schott-ceran-cua-cata-ib-772-300x156.jpg\" alt=\"bep tu cata ib 772 so huu mat kinh schott ceran\" />

&nbsp;
<ul class=\"features\">
 	<li>Không chỉ dừng lại ở đó, chiếc <b>bếp từ nhập khẩu CATA IB 772</b> còn được trang bị thêm những chức năng an toàn: chế độ khóa trẻ em, chuông báo động, hẹn giờ tắt,.... Tất cả nhằm tạo sự yên tâm và thoải mái trong không gian bếp - nơi đem lại sự đầm ấm trong mỗi gia đình</li>
 	<li>Điểm hạn chế duy nhất của Cata IB 772 nếu có thì có lẽ chỉ là ở kích thước. Nó tương đối hơi to so với những dòng sản phẩm cùng phân khúc. Để chắc chắn kệ bếp của bạn phù hợp, vui lòng xem qua bảng thông số bên dưới, hoặc liên hệ trực tiếp qua hotline <a href=\"http://bepankhang.com\">Bếp An Khang</a></li>
</ul>
<h3>Bảng thông số của bếp từ Cata IB 772</h3>
<table class=\"spec\">
<tbody>
<tr>
<td><i class=\"fas fa-keyboard\"></i> Bảng điều khiển</td>
<td>Cảm ứng</td>
</tr>
<tr>
<td><i class=\"fas fa-clock\"></i> Chế độ hẹn giờ</td>
<td>Có</td>
</tr>
<tr>
<td><i class=\"fas fa-volume-up\"></i> Báo động âm thanh</td>
<td>Có</td>
</tr>
<tr>
<td><i class=\"fas fa-power-off\"></i> Công suất</td>
<td>6.0 kW với 2 vùng nấu từ siêu tốc</td>
</tr>
<tr>
<td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
<td>770x 450 mm</td>
</tr>
<tr>
<td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
<td>710 x 410 mm</td>
</tr>
</tbody>
</table>
<div class=\"iframe-wrapper\">
<div class=\"h_iframe\"><iframe id=\"product-video\" src=\"https://www.youtube.com/embed/mS37sKMnzKU\" width=\"2\" height=\"2\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></div>
</div>
<div id=\"chot-ha\">Bếp từ Cata IB 772 là chiếc bếp hoàn toàn phù hợp trong những căn bếp mang phong cách Châu Âu độc đáo, sang trọng và tinh tế. Nếu bạn còn thắc mắc hoặc cần thêm thông tin gì về siêu phẩm này, xin vui lòng <a href=\"tel:0999999\">liên hệ</a> ngay Bếp An Khang để được tư vấn và chia sẻ thông tin nhé.</div>","Bếp từ Cata IB 772","","publish","closed","closed","","bep-tu-cata-ib-772","","","2018-04-19 18:04:24","2018-04-19 18:04:24","","0","http://bepankhang.test/?post_type=product&#038;p=62","0","product","","0");
INSERT INTO `bak_posts` VALUES("63","1","2018-04-09 16:05:09","2018-04-09 16:05:09","","bep-tu-cata-ib-722-gia-tot","","inherit","open","closed","","bep-tu-cata-ib-722-gia-tot","","","2018-04-09 16:05:09","2018-04-09 16:05:09","","62","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-cata-ib-722-gia-tot.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("64","1","2018-04-09 16:05:09","2018-04-09 16:05:09","","bep-tu-cata-ib-772","","inherit","open","closed","","bep-tu-cata-ib-772","","","2018-04-09 16:05:09","2018-04-09 16:05:09","","62","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-cata-ib-772.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("65","1","2018-04-09 16:36:21","2018-04-09 16:36:21","","mat-kinh-schott-ceran-cua-cata-ib-772","","inherit","open","closed","","mat-kinh-schott-ceran-cua-cata-ib-772","","","2018-04-09 16:36:21","2018-04-09 16:36:21","","62","http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-schott-ceran-cua-cata-ib-772.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("66","1","2018-04-09 17:34:16","2018-04-09 17:34:16","<strong><em>Bếp từ Cata IB 603 BK ra đời nhằm đáp ứng nhu cầu sử dụng nhiều bếp nấu cùng lúc của các quý bà nội trợ. Bạn có thể vừa xào rau, vừa kho thịt, trong khi đang hầm xương cho món canh.</em></strong>
<h3>Tính năng Bếp từ Cata IB 603 BK</h3>
<ul class=\"features\">
 	<li>Độc đáo với 3 vùng nấu, công suất tổng là 5000W. Giúp bạn tiết kiệm thời gian cho việc chuẩn bị bữa ăn cho gia đình.</li>
 	<li>Tiết kiệm điện năng với công nghệ inverter cao cấp: thông qua một bo mạch vi xử lí kiểm soát và phân bổ nhiệt lượng đồng đều hiệu quả, nhiệt độ luôn tập trung vùng đáy nồi, tránh thất thoát hao phí.</li>
 	<li>Có đến 17 mức nhiệt độ giúp bạn dễ dàng thực hiện các hình thức chế biến: chiên, xào, luộc, rang, hấp,...</li>
</ul>
<img class=\"alignnone size-large wp-image-68\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/uu-diem-bep-tu-cata-ib-630bk.jpg\" alt=\"uu diem cua bep tu cata ib 630bk\" />
<h3>Bảng thông số bếp từ Cata IB 603 BK</h3>
<table class=\"spec\">
<tbody>
<tr>
<td><i class=\"fas fa-clock\"></i> Chế độ hẹn giờ</td>
<td>Có</td>
</tr>
<tr>
<td><i class=\"fas fa-plus\"></i> Tiết kiệm điện</td>
<td>Inverter</td>
</tr>
<tr>
<td><i class=\"fas fa-volume-up\"></i> Báo động âm thanh</td>
<td>Có</td>
</tr>
<tr>
<td><i class=\"fas fa-power-off\"></i> Công suất</td>
<td>6,7kW</td>
</tr>
<tr>
<td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
<td>590 x 520</td>
</tr>
<tr>
<td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
<td>560 x 490</td>
</tr>
</tbody>
</table>
<div class=\"iframe-wrapper\">
<div class=\"h_iframe\"><iframe id=\"product-video\" src=\"https://www.youtube.com/embed/mS37sKMnzKU\" width=\"2\" height=\"2\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></div>
</div>
<div id=\"chot-ha\">Tặng ngay bộ nồi inox khi mua bếp từ 3 vùng nấu <b>Cata IB 603 BK</b>. Liên hệ hotline bếp An Khang để biết thêm chi tiết: <a href=\"tel:0933333\">09xxxxx</a></div>","Bếp từ Cata IB 603 BK","","publish","closed","closed","","bep-tu-cata-ib-603-bk","","","2018-04-13 04:58:47","2018-04-13 04:58:47","","0","http://bepankhang.test/?post_type=product&#038;p=66","0","product","","0");
INSERT INTO `bak_posts` VALUES("67","1","2018-04-09 17:34:41","2018-04-09 17:34:41","","Bep-tu-IB-603-BK","","inherit","open","closed","","bep-tu-ib-603-bk","","","2018-04-09 17:34:41","2018-04-09 17:34:41","","66","http://bepankhang.test/wp-content/uploads/2018/04/Bep-tu-IB-603-BK.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("68","1","2018-04-09 17:44:21","2018-04-09 17:44:21","","","","inherit","open","closed","","mix-race-woman-cooking-in-the-kitchen","","","2018-04-09 17:44:31","2018-04-09 17:44:31","","66","http://bepankhang.test/wp-content/uploads/2018/04/uu-diem-bep-tu-cata-ib-630bk.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("69","1","2018-04-09 17:49:14","2018-04-09 17:49:14","<strong><em>Bếp từ Cata IB 630 BK ra đời nhằm đáp ứng nhu cầu sử dụng nhiều bếp nấu cùng lúc của các quý bà nội trợ. Bạn có thể vừa xào rau, vừa kho thịt, trong khi đang hầm xương cho món canh.</em></strong>

<h3>Tính năng Bếp từ Cata IB 630 BK</h3>
<ul class=\"features\">
     <li>Độc đáo với 3 vùng nấu, công suất tổng là 5000W. Giúp bạn tiết kiệm thời gian cho việc chuẩn bị bữa ăn cho gia đình.</li>    
     <li>Tiết kiệm điện năng với công nghệ inverter cao cấp: thông qua một bo mạch vi xử lí kiểm soát và phân bổ nhiệt lượng đồng đều hiệu quả, nhiệt độ luôn tập trung vùng đáy nồi, tránh thất thoát hao phí.</li>
     <li>Có đến 17 mức nhiệt độ giúp bạn dễ dàng thực hiện các hình thức chế biến: chiên, xào, luộc, rang, hấp,...</li>     
</ul>
<img src=\"http://bepankhang.test/wp-content/uploads/2018/04/uu-diem-bep-tu-cata-ib-630bk.jpg\" alt=\"uu diem cua bep tu cata ib 630bk\" class=\"alignnone size-large wp-image-68\" />
&nbsp;

<h3>Bảng thông số bếp từ Cata IB 630 BK</h3>
<table class=\"spec\">        
    <tr>
        <td><i class=\"fas fa-clock\"></i> Chế độ hẹn giờ</td>
        <td>Có</td>
    </tr>
<tr>
        <td><i class=\"fas fa-plus\"></i> Tiết kiệm điện</td>
        <td>Inverter</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-volume-up\"></i> Báo động âm thanh</td>
        <td>Có</td>
    </tr>  
    <tr>
        <td><i class=\"fas fa-power-off\"></i> Công suất</td>
        <td>6,7kW</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
        <td>590 x 520</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
        <td>560 x 490</td>
    </tr>    
</table>


<div class=\"iframe-wrapper\">
    <div class=\"h_iframe\">
<iframe id=\"product-video\" width=\"2\" height=\"2\" src=\"https://www.youtube.com/embed/mS37sKMnzKU\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>
    </div>
</div>

<div id=\"chot-ha\">Tặng ngay bộ nồi inox khi mua bếp từ 3 vùng nấu <b>Cata IB 630 BK</b>. Liên hệ hotline bếp An Khang để biết thêm chi tiết: <a href=\"tel:0933333\">09xxxxx</a></div>","Bếp từ Cata IB 630 BK","","inherit","closed","closed","","66-autosave-v1","","","2018-04-09 17:49:14","2018-04-09 17:49:14","","66","http://bepankhang.test/66-autosave-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("70","1","2018-04-09 18:17:40","2018-04-09 18:17:40","<strong><em>Được nhập khẩu từ Tây Ban Nha, Bosch PID675N24E là dòng sản phẩm bếp 3 từ tích hợp chức năng xào rán mặc định, giúp cho bếp phát nhiệt luôn đều giúp việc chiên rán của bạn trở nên ngon hơn so với các sản phẩm bếp điện từ thông thường</em></strong>

Bếp 3 từ PID675N24E đem lại tiện ích cho việc nấu nướng của bạn gấp 3 lần so với những mẫu bếp từ khác. Những bà nội trợ được trải nghiệm sản phẩm này đều đưa ra phản hồi tích cực và đều mong muốn được sử dụng mẫu bếp này trong phòng bếp của mình.
<h3>Đánh giá tổng quan bếp 3 từ PID675N24E</h3>
<ul class=\"features\">
 	<li><strong>1. Mặt kính:</strong> Kính Schott-ceran là dòng gốm kính đặc biệt mà bếp sử dụng có khả năng chịu lực chịu nhiệt cao chống trầy xước. Chịu nhiệt độ lên 1000 0C, chịu sốc nhiệt 800 0C, chịu sức nặng trên bề mặt 50kg</li>
 	<li><strong>2. Bo viền nhôm: </strong>2 cạnh bên được bo viền nhôm dày 0,5 ly có tác dụng hạn chế tối đa việc mặt kính bị sứt mép. Tạo sự sang trọng cho không gian bếp</li>
 	<li><strong>3. Điều khiển:</strong> Bàn phím điều khiển cảm biến quang nhạy và nhanh hơn so với phím bấm điện xung, các tiếp điểm của rắc cắm làm bằng đồng giúp truyền tín hiệu hiệu quả, chính xác. Bếp cho phép bạn điều khiển 17 cấp độ nấu nướng, chia nhỏ công suất sẽ phù hợp với việc kiểm soát nhiệt độ với từng món ăn khác nhau</li>
 	<li><strong>4. Quạt gió:</strong> 3 bếp nấu sử dụng 1 quạt gió dạng lồng sóc, không cần đến kích thước quạt to hay số lượng quạt nhiều như bếp từ Trung Quốc. Quạt dạng lồng sóc có khả năng tản nhiệt nhanh chóng, độ ồn thấp không khiến  bạn cảm thấy khó chịu khi đứng nấu</li>
 	<li><strong>5. Khung vỏ: </strong>Sự kết hợp của tôn trắng cứng mạ kẽm và nhựa cứng cao cấp. Phần tôn thì bao bọc mâm từm bảng điều khiển, phần nhựa bao bọc quạt gió và bảng mạch. Thiết kế khung đặc trưng của các sản phẩm bếp từ Châu Âu</li>
 	<li><strong>6. Bếp nấu kích thước siêu lớn:</strong> Vùng nấu có kích thước lớn 32cm bạn có thể dùng nồi luộc gà kích thước to hay rán bằng những chiếc chảo cực lớn.</li>
</ul>
<img class=\"alignnone size-full wp-image-72\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-bosch-pid675n24e.png\" alt=\"bep-dien-tu-bosch-pid675n24e.png\" />
<h3>Chi tiết tính năng</h3>
<ul>
 	<li><strong>1. Tự động nhận diện kích thước</strong> xoong nồi và ra nhiệt thích hợp theo đáy nồi. Phát ra sóng từ phù hợp với nồi nấu như tôi đã nói ở trên</li>
 	<li><strong>2. Tự động tắt bếp khi để quên</strong>: Chức năng này giúp bạn hoàn toàn yên tâm về bếp, nếu như bạn vô tình để quên bếp mà không có ở nhà. Hoặc khi bạn chọn bếp mà không có nồi nấu thì bếp cũng sẽ tự động tắt sau 10p.</li>
 	<li><strong>3. chức năng chống trào:</strong> khi bếp phát hiện có hiện tượng tràn trong khu vực điều khiển bếp sẽ tự động ngắt và có âm thanh cảnh báo. Sau đó bạn có thể lau sạch chúng dễ dàng mà không lo bị bỏng</li>
 	<li><strong>4. Khóa trẻ em</strong> : Có thể bảo vệ tránh cho bếp không bị bật lên 1 cách vô tình để đảm bảo trẻ nhỏ không khởi động được các bộ phận của bếp.</li>
 	<li><strong>5. Booster:</strong> khi bạn sử dụng chức năng này sẽ giúp bạn tăng khả năng làm nóng của vùng bếp lớn lên 50%.  Chức năng này chỉ hoạt động được 10 phút và bạn có thể sử dụng nó cho cả 3 bếp nấu.</li>
 	<li><strong>6. Chức năng tạm dừng – khởi động lại: </strong>Chức năng này giúp tạm dừng hoạt động của bếp, nếu bạn bận việc trong khi nấu thì có thể sử dụng chức năng này. Sau đó bạn có thể tiếp tục nấu nướng mà bếp không hề thay đổi chế độ nấu bạn đã chọn.</li>
 	<li><strong>7. Cảnh báo nhiệt dư</strong>: thời gian cảnh báo này phụ thuộc theo mức nhiệt do sensor đo tại vùng nấu mặt kính. Sau khi tắt bếp nếu nhiệt độ mặt kính &gt; 65 0C thì vẫn có cảnh báo chữ “H”. Khi nhiệt độ xuống dưới 65 0C cảnh báo này biến mất.</li>
 	<li><strong>8. Xào rán trên bếp từ:</strong> Có 4 mức độ xào rán mặc định cho bạn lựa chọn, với chức năng này nhiệt độ sẽ được mặc định theo từng mức từ 140-240 giúp bạn rán trên bếp từ mà không thua kém bất kỳ loại bếp nào khác. Trên thị trường hiện nay mới chỉ có bếp từ Bosch và bếp từ Panasonic mới có chức năng này.</li>
 	<li><strong>9. Hẹn giờ:</strong> hẹn giờ từ 0 đến 99 phút, sau khi thời gian được cài đặt màn hình hiển thị của bếp sẽ xuất hiện dấu chấm. Bạn muốn hẹn giờ với bếp nào thì chọn vào bếp đó. Khi bếp chạy hết thời gian hẹn thì bếp sẽ tự động tắt. Bếp chỉ có thể hẹn giờ 1 trong 3 vùng nấu tại 1 thời điểm.</li>
 	<li><strong>10. 17 mức điều chỉnh công suất:</strong> Dải công suất nấu được chia nhỏ hơn hẳn so với nhiều dòng bếp khác, mặc đinh là 9 mức điều khiển từ P1-P9, nhưng giữa những cấp độ đó bạn vẫn có thể lựa chọn để nấu được như 2,5 ; 3.5…</li>
</ul>
<img class=\"alignnone size-full wp-image-73\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-3-tu-bosch-pid675n24e.png\" alt=\"bep 3 tu bosch\" />","Bếp từ Bosch PID675N24E","","publish","closed","closed","","bep-tu-bosch-pid675n24e","","","2018-04-13 04:58:39","2018-04-13 04:58:39","","0","http://bepankhang.test/?post_type=product&#038;p=70","0","product","","0");
INSERT INTO `bak_posts` VALUES("71","1","2018-04-09 18:15:48","2018-04-09 18:15:48","","large_bep-tu-bosch-pid675n24e","","inherit","open","closed","","large_bep-tu-bosch-pid675n24e","","","2018-04-09 18:15:48","2018-04-09 18:15:48","","70","http://bepankhang.test/wp-content/uploads/2018/04/large_bep-tu-bosch-pid675n24e.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("72","1","2018-04-09 18:16:11","2018-04-09 18:16:11","","bep-dien-tu-bosch-pid675n24e","","inherit","open","closed","","bep-dien-tu-bosch-pid675n24e-2","","","2018-04-09 18:16:11","2018-04-09 18:16:11","","70","http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-bosch-pid675n24e.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("73","1","2018-04-09 18:16:38","2018-04-09 18:16:38","","bep-3-tu-bosch-pid675n24e","","inherit","open","closed","","bep-3-tu-bosch-pid675n24e","","","2018-04-09 18:16:38","2018-04-09 18:16:38","","70","http://bepankhang.test/wp-content/uploads/2018/04/bep-3-tu-bosch-pid675n24e.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("74","1","2018-04-09 18:30:28","2018-04-09 18:30:28","<strong>Bếp từ Arber AB-383 là dòng sản phẩm phù hợp với đại đa số gia đình Việt hiện nay, bởi kích thước tương đối nhỏ gọn, cũng như giá thành ổn so với mặt bằng bếp chung.</strong>

- Bếp từ Arber AB-383 sử dụng mặt kính Schott Ceran , đây là dòng mặt kính có khả năng chịu được nhiệt độ cao, lực va
đập mạnh. Đặc biệt dòng mặt kính này có khả năng cách điện và tản nhiệt tốt nên tuyệt đối an toàn cho người sử dụng. Khả năng chịu nhiệt của mặt kính này lên đến 1000 Độ C, khả năng chịu sốc nhiệt là 800 Độ C. Khả năng chịu lực lên đến 50kg. Mâm từ đường kính 22cm, có khả năng tự nhận diện trực tiếp nồi nấu tương thích và diện tích tiếp xúc giữa vùng nấu và đáy nồi để sinh nhiệt, tránh làm nhiệt lượng bị thất thoát ra ngoài. Với công suất của bếp là 2000W cho cả hai bếp. Tổng công suất tối đa của cả hai bếp là 3600W.
- Bếp từ cao cấp này sử dụng bảng điều khiển cảm ứng siêu nhạy, hiển thị bằng đèn led. Bếp từ Arber AB-383 có tính năng san nhiệt, Giúp ổn định nguồn điện, không bị quá tải và tiết kiệm điện. Công suất tối đa của bếp là 3600W.

<img src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-chinh-hang-arber-ab383.jpg\" alt=\"bep chinh hang Arber AB383\" class=\"alignnone size-full wp-image-75\" />

- Với kích thước thông dụng, vì thế nếu thay thế bếp từ Arber AB-383 cho bếp ga cũ cũng rất dễ dàng. Cụ thể kích thước của bếp là:
+ Kích thước mặt kính: 720 x 425 x 100 mm
+ Kích thước lắp đặt: 680 x 400 mm
- Cũng như những dòng bếp cao cấp khác, mẫu bếp từ này có những tính năng sau:
<ul class=\"features\">
<li>Hẹn giờ độc lập cho từng vùng nấu, thời gian hẹn đến 9.30 phút</li>
<li>Cảnh báo nhiệt dư vùng nấu Residual heat</li>
<li>Khóa an toàn trẻ em Child lock</li>
<li>Tự động tắt bếp khi không có nồi ( trên bếp từ)</li>
<li>Hệ thống bảo vệ an toàn quá nhiệt, quá áp</li>
</ul>","Bếp từ Arber AB-383","","publish","closed","closed","","bep-tu-arber-ab-383","","","2018-04-13 04:58:29","2018-04-13 04:58:29","","0","http://bepankhang.test/?post_type=product&#038;p=74","0","product","","0");
INSERT INTO `bak_posts` VALUES("75","1","2018-04-09 18:29:20","2018-04-09 18:29:20","","bep-chinh-hang-arber-ab383","","inherit","open","closed","","bep-chinh-hang-arber-ab383","","","2018-04-09 18:29:20","2018-04-09 18:29:20","","74","http://bepankhang.test/wp-content/uploads/2018/04/bep-chinh-hang-arber-ab383.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("76","1","2018-04-09 18:29:20","2018-04-09 18:29:20","","bep-tu-arber-ab-383","","inherit","open","closed","","bep-tu-arber-ab-383","","","2018-04-09 18:29:20","2018-04-09 18:29:20","","74","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-arber-ab-383.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("77","1","2018-04-12 07:17:39","2018-04-12 07:17:39","<label>[text* your-name placeholder \"Họ tên\"] </label>

<label>[tel* tel-539 placeholder \"Điện thoại\"] </label>

<label> Thông tin cần trao đổi
    [textarea your-message] </label>

[submit \"Send\"]
1
Bếp An Khang \"[your-subject]\"
[your-name] <wordpress@bepankhang.test>
ptson.snh@gmail.com
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Bếp An Khang (http://bepankhang.test)
Reply-To: [your-email]




Bếp An Khang \"[your-subject]\"
Bếp An Khang <wordpress@bepankhang.test>
[your-email]
Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Bếp An Khang (http://bepankhang.test)
Reply-To: ptson.snh@gmail.com



Thank you for your message. It has been sent.
There was an error trying to send your message. Please try again later.
One or more fields have an error. Please check and try again.
There was an error trying to send your message. Please try again later.
You must accept the terms and conditions before sending your message.
The field is required.
The field is too long.
The field is too short.
The date format is incorrect.
The date is before the earliest one allowed.
The date is after the latest one allowed.
There was an unknown error uploading the file.
You are not allowed to upload files of this type.
The file is too big.
There was an error uploading the file.
The number format is invalid.
The number is smaller than the minimum allowed.
The number is larger than the maximum allowed.
The answer to the quiz is incorrect.
Your entered code is incorrect.
The e-mail address entered is invalid.
The URL is invalid.
The telephone number is invalid.","Contact form 1","","publish","closed","closed","","contact-form-1","","","2018-04-12 07:30:45","2018-04-12 07:30:45","","0","http://bepankhang.test/?post_type=wpcf7_contact_form&#038;p=77","0","wpcf7_contact_form","","0");
INSERT INTO `bak_posts` VALUES("78","1","2018-04-12 08:45:54","2018-04-12 08:45:54","Bếp từ Bosch PID675DC1E với tính năng kiểm soát nhiệt độ dầu ăn: Giúp bạn có món chiên xào chín tới hoàn hảo nhờ cảm biến tự động
<ul class=\"features\">
 	<li>DirectSelect Premium – Chọn Trực tiếp thế hệ mới: Giúp bạn dễ dàng trực tiếp chọn vùng nấu, mức công suất và tính năng bổ sung chỉ với 1 thao tác bấm chọn.</li>
 	<li>Cảm biến tự động kiểm soát nhiệt độ dầu ăn: Giúp bạn chọn mức nhiệt mong muốn với 5 cấp độ linh hoạt, chảo chiên xào sẽ làm nóng đến nhiệt độ lý tưởng để thả thức ăn vào.</li>
 	<li>Vùng nấu đường kính tối đa 32 cm: Ba đường kính nấu ăn 21, 26, 32 cm đáp ứng mọi kích thước nồi nấu.</li>
 	<li>Thiết kế Premium ComfortProfile: Làm đẹp cho căn bếp của bạn trở nên sang trọng và nổi bật với thiết kế mặt kính vát viền, bo viền kim loại ở cạnh bên.</li>
 	<li>Cài đặt sẵn thời gian nấu thông minh: Giúp bạn tắt vùng nấu đã chọn sau một khoảng thời gian đã định</li>
</ul>
<img class=\"alignnone size-full wp-image-79\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/tinh-nang-cua-bep-tu-bosch.jpg\" alt=\"tinh nang doc dao cua bep tu Bosch\" />
<h3 class=\"dtit\">Đánh giá chi tiết Bếp từ Bosch PID675DC1E</h3>
Bếp Từ Bosch <strong>PID675DC1E</strong> nhập khẩu chính hãng với bảng điều khiển DirectSelect với truy cập trực tiếp lên đến 17 cấp độ nấu ăn.

3 khu của cảm ứng với chức năng Sprint và chức năng Sprint Chiên:

- 1 vùng nấu lớn diện tích 32 cm.

- 1 vùng 21 cm.

- 1 vùng nấu nhỏ 15cm

Mặt kính của bếp được thiết kế màu đen sang trọng <strong>SCHOTT CERAN</strong> sản xuất tại Mainz - Đức, một loại gốm kính cao cấp được làm từ gốm sứ thủy tinh đặc biệt có khả năng chịu lực, chịu nhiệt và khả năng va đập tốt, chống lại những cú sốc nhiệt đột ngột lên đến 750°C và đặc biệt không chứa các kim loại nặng độc hại asen và antimon rất thân thiện với môi trường.

+ Vùng nấu 32 cm khổng lồ: để nấu ăn với các nồi, chảo có kích thước lớn.

+ Chức năng Sprint giảm thời gian làm nóng lên đến 50%.","Bếp Từ Bosch PID675DC1E","","publish","closed","closed","","bep-tu-bosch-pid675dc1e","","","2018-04-13 04:58:23","2018-04-13 04:58:23","","0","http://bepankhang.test/?post_type=product&#038;p=78","0","product","","0");
INSERT INTO `bak_posts` VALUES("79","1","2018-04-12 08:44:27","2018-04-12 08:44:27","","tinh-nang-cua-bep-tu-bosch","","inherit","open","closed","","tinh-nang-cua-bep-tu-bosch","","","2018-04-12 08:44:27","2018-04-12 08:44:27","","78","http://bepankhang.test/wp-content/uploads/2018/04/tinh-nang-cua-bep-tu-bosch.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("80","1","2018-04-12 08:44:27","2018-04-12 08:44:27","","bep-tu-Bosch-PID675DC1E","","inherit","open","closed","","bep-tu-bosch-pid675dc1e","","","2018-04-12 08:44:27","2018-04-12 08:44:27","","78","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-Bosch-PID675DC1E.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("81","1","2018-04-12 09:05:04","2018-04-12 09:05:04","Bếp từ 2 vùng nấu Cata I2 Plus là sản phẩm của thương hiệu Cata, vốn là 1 thương hiệu nỗi tiếng của Tây Ban Nha. Bếp có hệ thống điều khiển cảm ứng Touch Control, mặt gốm Vitroceramic an toàn và dễ vệ sinh, chức năng hẹn giờ thông minh. Ngoài ra Cata I2 Plus còn có 9 mức tốc độ công suất và chức năng khóa trẻ em an toàn bếp.
<h3>Bếp Từ Cata I2 Plus có thiết kế đơn giản, nhỏ gọn phù hợp với gia đình ít người</h3>
<ul class=\"features\">
 	<li>Bếp từ Cata <strong>I2 Plus</strong> gồm 2 vùng nấu từ: Vùng nấu trái Ø22 cm, công suất là 2300W; vùng nấu phải Ø 180 mm, công suất 1400W</li>
 	<li>Tổng công suất của Cata I2 Plus: 3.7 KW.</li>
 	<li>Mặt kính của bếp từ Bếp từ Cata <strong>I2 Plus</strong> thiết kế màu đen sang trọng tới từ thương hiệu SCHOTT CERAN sản xuất tại Mainz - Đức, một loại gốm kính cao cấp được làm từ gốm sứ thủy tinh đặc biệt có khả năng chịu lực, chịu nhiệt và khả năng va đập tốt, chống lại những cú sốc nhiệt đột ngột lên đến 750°C và đặc biệt không chứa các kim loại nặng độc hại asen và antimon rất thân thiện với môi trường.</li>
 	<li>Bếp được thiết kế với bảng điều khiển Touch Control dạng phím cộng trừ giúp điều chỉnh tăng giảm nhiệt dễ dàng tiện lợi với 9 cấp độ nhiệt được chia nhỏ phù hợp cho nhiều món ăn nấu khác nhau.</li>
</ul>
<img class=\"alignnone size-full wp-image-82\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bang-dieu-khien-cata-i2-plus.jpg\" alt=\"bang dieu khien bep tu Cata I2 plus\"  />

<h3>Một số chức năng ưu việt của bếp từ Cata I2 Plus:</h3>
<ul class=\"features\">
 	<li>Chức năng khóa trẻ em an toàn, sản phẩm bếp từ này sẽ là sự lựa chọn hoàn hảo cho những gia đình có trẻ nhỏ hiếu động.</li>
 	<li>Bếp từ Cata I2 Plus có chức năng nấu độc lập cho mỗi vùng nấu, có thể nấu song song 2 bếp với 2 chế độ nấu khác nhau</li>
 	<li>Sản phẩm Bếp từ cao cấp Cata I2 Plus tương thích với mọi kích cỡ nồi nhờ khả năng nhận diện đáy nồi tự động thông minh</li>
 	<li>Cảnh báo nhiệt dư vùng nấu bằng âm thành kết hợp đèn led</li>
 	<li>Bếp từ có hệ thống làm mát linh kiện tự động hoạt động sau khi nấu xong</li>
 	<li>Tự động ngắt nguồn khi có sự cố nhiệt điện- Bếp từ có hệ thống làm mát linh kiện tự động hoạt động sau khi nấu xong</li>
 	<li>Tự động ngắt nguồn khi có sự cố nhiệt điện</li>
</ul>","Bếp Từ Cata I2 Plus","","publish","closed","closed","","bep-tu-cata-i2-plus","","","2018-04-13 04:58:09","2018-04-13 04:58:09","","0","http://bepankhang.test/?post_type=product&#038;p=81","0","product","","0");
INSERT INTO `bak_posts` VALUES("82","1","2018-04-12 09:06:18","2018-04-12 09:06:18","","bang-dieu-khien-cata-i2-plus","","inherit","open","closed","","bang-dieu-khien-cata-i2-plus","","","2018-04-12 09:06:18","2018-04-12 09:06:18","","81","http://bepankhang.test/wp-content/uploads/2018/04/bang-dieu-khien-cata-i2-plus.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("83","1","2018-04-12 09:06:18","2018-04-12 09:06:18","","bep-tu-cata-i2-plus","","inherit","open","closed","","bep-tu-cata-i2-plus-2","","","2018-04-12 09:06:18","2018-04-12 09:06:18","","81","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-cata-i2-plus.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("84","1","2018-04-12 09:31:28","2018-04-12 09:31:28","<em>Bếp Điện Từ Chefs EHMIX321 là loại bếp tiện lợi có thể sử dụng trên mọi loại chất liệu nồi. Bếp với 2 Vùng Nấu: 1 điện từ và 1 hồng ngoại.</em>
Bảng điều khiển dạng phím cộng trừ giúp điều chỉnh tăng giảm nhiệt dễ dàng tiện lợi. Hệ thống bảng điều khiển siêu nhạy ngay cả khi tay còn đang ướt. Tự động nhận biết kích thước xoong nồi. Chức năng hẹn giờ nấu cho từng bếp. Chức năng chia sẻ công suất tự động. Có cảnh báo nhiệt dư. Khóa trẻ em an toàn tự động. Tự động tắt bếp khi để quên. Tự động tắt bếp khi không có nồi.

<h3>Tổng quan chung Bếp Điện Từ Chefs EH-MIX321</h3>
Bếp Điện Từ Chefs EH-MIX321 kích thước 70cm với thiết kế hình chữ nhật, gồm 2 bếp kết hợp điện và từ đun nấu tiện lợi
- Bếp nấu điện bên trái gồm 2 vòng nấu kích thước14/22 cm với công suất 1 kW /2kW.
- Bếp nấu từ bên phải kích thước 22cm với công suất max 2kW
Mặt kính Schottceran - Đức  sang trọng hiện đại, Mặt kính liền nguyên khối thiết kế vát cạnh màu đen sang trọng , bề mặt bếp có khả năng chống trầy xước, chịu lực cao, chịu nhiệt lớn lên đến 1000°C và chịu sốc nhiệt lên đến 800°C.
- Với bếp nấu từ:
       + Khi bếp hiện thị theo công suất thì dải điều chỉnh từ 100 - 2200W
       + Khi bếp hiện thị theo nhiệt độ thì dải điều chỉnh từ 60 - 280°C.
- Với bếp nấu điện: dải điều chỉnh từ 100 - 2200W

<img src=\"http://bepankhang.test/wp-content/uploads/2018/04/thong-so-Chefs-EH-MIX321.png\" alt=\"bang thong so bep chefs EH-MIX321\" class=\"alignnone size-full wp-image-86\" />

<h3>Chức năng của Bếp Điện Từ Chefs EH-MIX321:</h3>
<ul class=\"features\">
<li>Vùng nấu từ tự động nhận biết kích thước xoong nồi. </li>
<li>Chức năng hẹn giờ nấu cho từng bếp nấu có báo âm thanh.</li>
<li>Chức năng chia sẻ công suất tự động giữa 2 bếp nấu.</li>
<li>Có cảnh báo nhiệt dư vùng nấu.</li>
<li>Khóa trẻ em an toàn tự động hoặc bằng tay.</li>
<li>Tự động tắt bếp khi để quên: Sau thời gian đun nấu dài mà không có sự thay đổi cài đặt nào thì bếp sẽ tự động được tắt.</li>
<li>Tự động tắt bếp khi không có nồi( trên bếp từ ).</li>
<li>Hệ thống bảo vệ an toàn quá nhiệt, quá áp.</li>
<li> Đáy bếp thiết kế vững chắc có hệ thống quạt tản nhiệt giúp bếp không bị nóng trong quá trình sử dụng.</li>
</ul>","Bếp Điện Từ Chefs EH-MIX321","","publish","closed","closed","","bep-dien-tu-chefs-eh-mix321","","","2018-04-13 04:58:04","2018-04-13 04:58:04","","0","http://bepankhang.test/?post_type=product&#038;p=84","0","product","","0");
INSERT INTO `bak_posts` VALUES("85","1","2018-04-12 09:30:13","2018-04-12 09:30:13","","chefs-ehmix321","","inherit","open","closed","","chefs-ehmix321","","","2018-04-12 09:30:13","2018-04-12 09:30:13","","84","http://bepankhang.test/wp-content/uploads/2018/04/chefs-ehmix321.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("86","1","2018-04-12 09:30:14","2018-04-12 09:30:14","","thong-so-Chefs-EH-MIX321","","inherit","open","closed","","thong-so-chefs-eh-mix321","","","2018-04-12 09:30:14","2018-04-12 09:30:14","","84","http://bepankhang.test/wp-content/uploads/2018/04/thong-so-Chefs-EH-MIX321.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("87","1","2018-04-12 09:47:10","2018-04-12 09:47:10","<em>Bếp từ Bosch PVS851FB1E có bảng điều khiển DirectControl dạng bo mạch số với 17 cấp độ nhiệt được chia nhỏ phù hợp cho nhiều món ăn nấu khác nhau. Điều chỉnh tăng giảm nhiệt chính xác, nhanh chóng và tiện lợi, chỉ cần bấm trực tiếp vào cấp độ nhiệt mong muốn, có thể điều khiển cách số mà không cần theo thứ tự tăng dần.</em>
<h4>Bếp từ Bosch PVS851FB1E thuộc dòng Bosch Series 6 có thiết kế rất hiện đại với 4 vùng nấu riêng biệt. Sản phẩm có 2 khu nấu nhỏ và 2 khu nấu siêu lớn với kích thước phù hợp với các loại nồi chảo lớn</h4>
Bếp được trang bị những tính năng hiện đại như kiểm soát nhiệt độ dầu, lập trình thời gian nấu, khóa trẻ em an toàn ... giúp cho những món ăn của gia đình hoàn hảo hơn mà vẫn đảm bảo được sự an toàn tuyệt đối. Ngoài ra với kiểu dáng thiết kế đạt tính thẩm mỹ cao của bếp, không gian gia đình bạn sẽ trở nên sang trọng và quý phái hơn. <em>    </em>

Bếp từ Bosch PVS851FB1E có chức năng chiên xào rán dễ dàng cho bạn nấu nhiều món ăn hơn và có thể tắt vùng nấu đã chọn khi thiết lập thời gian đã trôi qua với tính năng lập trình thời gian nấu.

<img class=\"alignnone size-full wp-image-88\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-bosch-PVS851FB1E.png\" alt=\"bep tu bosch PVS851FB1E gia re\"  />

<strong>Bếp từ Bosch PVS851FB1E cao cấp</strong> được trang bị bảng điều khiển dạng bo mạch số với 17 cấp độ nhiệt được chia nhỏ phù hợp cho nhiều món ăn nấu khác nhau. Người dùng có thể điều chỉnh tăng giảm nhiệt chính xác, nhanh chóng và tiện lợi, chỉ cần bấm trực tiếp vào cấp độ nhiệt mong muốn, có thể điều khiển cách số mà không cần theo thứ tự tăng dần.

Bếp từ Bosch PVS851FB1E có 4 vùng nấu có tổng công suất 7.4 kw

- 2 Vùng nấu  210 mm, 2.2 kW ( booster 3,7 kw )
- 1 vùng nấu 145 mm công suất 1.4 kW
- 1 vùng nấu 280 mm công suất 2.6 kW ( booster 3.7 kw )

Sự an toàn luôn là yếu tố hàng đầu của những chị em nội trợ khi lựa chọn bếp. <strong>Bếp Bosch PVS851FB1E</strong> có khóa trẻ em an toàn tự động hoặc bằng tay ngăn ngừa sự vô tình bật bếp đảm bảo an toàn cho trẻ em. Bên cạnh đó, cảnh báo nhiệt dư hai cấp độ (H/h) giúp bạn điều chỉnh được nhiệt độ khi quá tải.

<img class=\"alignnone size-full wp-image-90\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/be-mat-kinh-bep-bosch-PVS851FB1E.png\" alt=\"be mat kinh bep bosch PVS851FB1E\" />","Bếp từ Bosch PVS851FB1E","","publish","closed","closed","","bep-tu-bosch-pvs851fb1e","","","2018-04-13 04:57:59","2018-04-13 04:57:59","","0","http://bepankhang.test/?post_type=product&#038;p=87","0","product","","0");
INSERT INTO `bak_posts` VALUES("88","1","2018-04-12 09:44:00","2018-04-12 09:44:00","","bep-dien-tu-bosch-PVS851FB1E","","inherit","open","closed","","bep-dien-tu-bosch-pvs851fb1e","","","2018-04-12 09:44:00","2018-04-12 09:44:00","","87","http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-bosch-PVS851FB1E.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("89","1","2018-04-12 09:44:00","2018-04-12 09:44:00","","bep-tu-bosch-PVS851FB1E","","inherit","open","closed","","bep-tu-bosch-pvs851fb1e","","","2018-04-12 09:44:00","2018-04-12 09:44:00","","87","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-bosch-PVS851FB1E.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("90","1","2018-04-12 09:44:58","2018-04-12 09:44:58","","be-mat-kinh-bep-bosch-PVS851FB1E","","inherit","open","closed","","be-mat-kinh-bep-bosch-pvs851fb1e","","","2018-04-12 09:44:58","2018-04-12 09:44:58","","87","http://bepankhang.test/wp-content/uploads/2018/04/be-mat-kinh-bep-bosch-PVS851FB1E.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("91","1","2018-04-12 10:22:30","2018-04-12 10:22:30","<em>Đáp ứng được mọi nhu tầm trung bản của 1 chiếc bếp, bếp từ Arber AB-688 gây được sự chú ý và thiện cảm của người tiêu dùng. Hơn nữa mức giá khá tốt so với những dòng bếp có tính năng inverter lại là 1 điểm cộng khác của Arber AB-688</em>
<h3><strong>Bếp từ Arber AB-688 sử dụng những linh kiện tốt nhất</strong></h3>
Mặt kính Schottceran sử dụng cho model bếp từ đôi nhập khẩu Arber AB-688 được nhập nguyên khối từ Đức, có mã số riêng, do Tập đoàn Schott sản xuất- tập đoàn chuyên sản xuất mặt kính cho bếp từ, bếp điện từ tại Mainz – Đức. Có lẽ, những ưu điểm nổi bật của mặt kính Schottceran sử dụng cho bếp từ Arber AB-688 sẽ khiến bạn phải ngạc nhiên, đồng thời cho thấy nó thật sự phù hợp để tạo nên những chiếc bếp từ bền bỉ và hoàn hảo nhất:
<ul class=\"features\">
 	<li>Chống lại những cú sốc nhiệt độ đột ngột lên đến 750° C.</li>
 	<li>Schottceran thân thiện với môi trường không chứa các kim loại nặng độc hại asen và antimon.</li>
 	<li>Bản chât là hỗn hợp gốm thủy tinh, rất cứng, bền và chống va đập; khả năng chịu lực, chịu nhiệt vượt ngưỡng tiêu chuẩn</li>
</ul>
Cũng giống như các mẫu bếp từ nhập khẩu nguyên chiếc từ châu Âu, bếp từ Arber AB-688 sử dụng chất liệu thép trắng cho phần thân bếp, đảm bảo hiệu quả chống oxi hóa, độ bền gấp 2 lần so với chất liệu sắt sơn tĩnh điện hay nhựa như các dòng bếp thông thường.

Mâm từ sử dụng cho model bếp từ inverter Arber AB-688 làm bằng cuộn dây đồng xếp khít nhau, tích hợp công nghệ 2 vòng từ thông minh cho phép khả năng nhận diện đáy nồi chính xác hơn, tiết kiệm đáng kể lượng điện năng tiêu thụ.

<img class=\"alignnone size-full wp-image-92\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-Arber-AB-688.jpg\" alt=\"\" width=\"852\" height=\"509\" />
<h3>Những tính năng độc đáo của bếp từ Aber AB-688</h3>
Rất nhiều chị em tỏ ra thích thú với khả năng tiết kiệm điện vượt trội của bếp từ  Arber AB-688 cao cấp nhờ ứng dụng công nghệ inverter thông minh, trước đây chỉ có trên dòng bếp nhập khẩu nguyên chiếc từ Đức hoặc Tây Ban Nha.

Bạn muốn nấu ăn nhanh hơn hãy khám phá chức năng nấu Booster trên bếp từ đôi Arber AB-688 mang lại khả năng nấu ăn siêu tốc. Chị em có thể hoàn thành những món ăn ngon chỉ bằng thao tác đơn giản đồng thời không mất quá nhiều thời gian.

Điều đặc biệt giúp model bếp từ Arber Ab-688 đánh bật được những đối thủ nặng kí khác nhờ khắc phục được nhược điểm rán xào không ngon ở bếp từ thông thường.

Ngoài ra, bếp từ chính hãng Arber AB-688 đồng thời sở hữu các chức năng: khóa trẻ em, 09 chế độ công suất, hẹn giờ nấu tự động tắt khi hết thời gian cài đặt, cảm biến chống trào, tự động nhận diện đáy nồi,…
<h2>Bảng thông số bếp từ Arber AB 688</h2>
<table class=\"spec\">
<tbody>
<tr>
<td><i class=\"fas fa-power-off\"></i> Công suất</td>
<td>max 3600W ( Phải: 2000W ,Trái: 2000W)</td>
</tr>
<tr>
<td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
<td>720 x 430 x 100mm</td>
</tr>
<tr>
<td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
<td>680 x 390mm</td>
</tr>
</tbody>
</table>","Bếp từ Arber AB-688","","publish","closed","closed","","bep-tu-arber-ab-688","","","2018-04-13 04:57:51","2018-04-13 04:57:51","","0","http://bepankhang.test/?post_type=product&#038;p=91","0","product","","0");
INSERT INTO `bak_posts` VALUES("92","1","2018-04-12 10:17:56","2018-04-12 10:17:56","","bep-tu-Arber-AB-688","","inherit","open","closed","","bep-tu-arber-ab-688-2","","","2018-04-12 10:17:56","2018-04-12 10:17:56","","91","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-Arber-AB-688.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("93","1","2018-04-12 11:28:45","2018-04-12 11:28:45","<em>Bạn đã thấy những chiếc bếp điện từ  (bếp từ) với nhiều kiểu dáng đẹp và tiện dụng như thế nào. Thế nhưng bạn vẫn còn băn khoăn rằng liệu dùng bếp điện từ có tốn điện không? Bếp An Khang sẽ cùng bạn phân tích để làm rõ vấn đề này.</em>
<h3>Trước hết chúng ta sẽ tìm hiểu về công suất của các dòng bếp điện từ.</h3>
Đại đa số các dòng bếp điện từ ngày nay có công suất trung bình khoảng 2500W. 1 số dòng tầm trung có công suất &lt; 2000W, thường là các dòng bếp đơn hoặc bếp đôi giá rẻ. Cũng có 1 số dòng cao cấp có công suất &gt; 3000W, thậm chí &gt;3500W (chức năng booster - nấu siêu nhanh).

Dù là ở mức công suất nào thì lượng điện năng bỏ ra cũng sẽ gần như nhau, bởi khi sử dụng bếp có công suất càng cao, thì thời gian nấu sẽ càng giảm. Do đó ta tạm lấy con số 2500W làm khung chuẩn cho ví dụ dưới đây.

Giả sử bạn sử dụng 1 bếp từ có công suất ~ 2500W (như <a href=\"/product/bep-tu-cata-i2-plus/\">Cata IB 2 Plus</a>) thì thời gian để nấu sôi 1 lít nước chỉ sẽ chỉ mất khoảng 2 phút. Như vậy trong 2 phút đó bạn chỉ tiêu thụ: 2500x2/60 = 83,3W - tương đương với 0,083KW điện. Có lẽ bạn sẽ khá ngạc nhiên khi chỉ sử dụng 0,083KW điện là đã có thể nấu chín 1 lít nước.

<img class=\"alignnone size-full wp-image-94\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-nhieu-muc-cong-suat.jpg\" alt=\"bep dien tu co nhieu muc cong suat\" />
<h3>Vậy nên sử dụng bếp điện từ có công suất bao nhiêu để tiết kiệm nhất?</h3>
Như Bếp An Khang đã trình bày trên, công suất càng lớn thì thời gian nấu càng giảm, do đó bạn không cần quá quan tâm đến việc tiết kiệm điện năng, thay vào đó hãy chọn dòng bếp nào phù hợp với nhu cầu chế biến món ăn của mình. Vd: Nếu bạn chỉ dùng để hâm nóng nồi lẩu để ăn trực tiếp cùng gia đình, bạn chỉ cần dùng loại bếp từ có công suất nhỏ. Còn nếu bạn muốn dùng ngay chiếc bếp từ đó để nấu lẩu luôn, thì nên sử dụng bếp có công suất lớn.

Ngoài ra trên thị trường hiện nay cũng có rất nhiều dòng bếp có đến 2-3, thậm chí 4 vùng từ (điển hình là <a href=\"/product/bep-tu-bosch-pvs851fb1e/\">BOSCH PVS851FB1E</a>), mỗi vùng từ tương đương với 1 bếp nấu có công suất khác nhau, phù hợp với nhiều hình thức chế biến món ăn: đun sôi, chiên, xào, hấp, nướng,....

<a href=\"http://bepankhang.test/product/bep-tu-bosch-pvs851fb1e/\"><img class=\"alignnone size-large wp-image-89\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-bosch-PVS851FB1E-1024x1024.jpg\" alt=\"\" width=\"1024\" height=\"1024\" /></a>

Như vậy là bạn không cần phải băn khoăn về tính tiết kiệm khi sử dụng bếp điện từ nữa nhé. Bạn có thể liên hệ bếp An Khang để chọn ngay cho mình 1 con bếp phù hợp. Hoặc có thể vào đây để tìm hiểu thêm <a href=\"http://bepankhang.test/qna/uu-nhuoc-diem-cua-bep-hong-ngoai/\">những ưu điểm khác của bếp điện từ</a> nhé.","Dùng bếp điện từ có tốn điện không?","","inherit","closed","closed","","48-autosave-v1","","","2018-04-12 11:28:45","2018-04-12 11:28:45","","48","http://bepankhang.test/48-autosave-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("94","1","2018-04-12 11:27:02","2018-04-12 11:27:02","","bep-dien-tu-nhieu-muc-cong-suat","","inherit","open","closed","","bep-dien-tu-nhieu-muc-cong-suat","","","2018-04-12 11:27:10","2018-04-12 11:27:10","","48","http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-nhieu-muc-cong-suat.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("95","1","2018-04-13 02:32:37","2018-04-13 02:32:37","<em>Đã và đang dần thay thế thị trường bếp gas, bếp điện từ có rất nhiều tính năng vượt trội và được nhiều người tin dùng. Vậy những ưu điểm của bếp điện từ là gì?</em>
<h2>Những ưu điểm của bếp điện từ</h2>
Ưu điểm đầu tiên dễ thấy được là <strong>ngoại hình</strong> của những chiếc bếp điện từ rất ưa nhìn. Với vẻ ngoài sang trọng và tinh tế: thân hợp kim cứng cáp, mặt kính chịu nhiệt (có những loại cao cấp hơn với mặt kính schott ceran). Thiết kế phẳng và mỏng theo phong cách Châu Âu, rất vừa mắt khi đặt trong một căn bếp hiện đại.

<img class=\"alignnone size-large wp-image-96\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/uu-diem-bep-dien-tu-1024x818.png\" alt=\"dep la 1 uu diem cua bep dien tu\" />

Ưu điểm thứ hai của bếp điện từ là <strong>không tỏa nhiệt ra bên ngoài</strong>. Chúng sử dụng điện từ trường để làm nóng thức ăn bên trong các nồi chuyên dụng. Như vậy không gian bếp của bạn sẽ không bị ngột ngạt vì luồng không khí nóng khi nấu ăn như sử dụng bếp gas thông thường. Chính vì đặc tính này mà nhiều người còn gắn trực tiếp bếp tường lên ngay trên bàn ăn gia đình luôn.

<img class=\"alignnone size-full wp-image-97\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-dung-nhu-ban-an.jpg\" alt=\"Dung bep dien tu nhu ban an\" />

<b>An toàn</b> là 1 ưu điểm mạnh của bếp điện từ. Bạn có thể yên tâm khi vắng nhà mà không cần lo các sự cố về rò rĩ khí gas, cháy nổ bình gas... như trước đây. Đây là lý do chính khiến rất nhiều người sống tại các chung cư cao tầng đã thay bếp gas thông thường bằng bếp điện từ. Ngoài tính an toàn cháy vừa kể thì bếp cũng an toàn cho trẻ em, bởi nó chỉ làm nóng phần thức ăn đặt trong nồi từ, sau khi sử dụng trẻ có vô ý sờ lên mặt bếp thì cũng sẽ không bị bỏng. Ngoài ra 1 số dòng bếp từ cao cấp còn có chức năng hẹn giờ, báo động,.... tất cả nhằm mục đích bảo đảm an toàn cho gia đình.

<img class=\"alignnone size-full wp-image-98\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-rat-an-toan.jpg\" alt=\"bep dien tu rat an toan\" />

Thêm một ưu điểm của bếp điện từ nữa, đó là <strong>dễ vệ sinh</strong>. Do bề mặt là kính thủy tinh chịu nhiệt, bếp sẽ không bị rỉ sét, thậm chí cả khi tiếp xúc với dầu mỡ, bạn chỉ cần lau sơ qua là mặt kính đã trong suốt trở lại. Điều này vô cùng tiện lợi cho các bà nội trợ muốn chăm sóc cho căn bếp gia đình mình.

<img class=\"alignnone size-large wp-image-99\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/uu-diem-cua-bep-dien-tu-de-ve-sinh.jpg\" alt=\"de ve sinh la 1 uu diem cua bep dien tu\" />

Nếu bạn quan tâm đến vấn đề tài chính, thì càng nên sử dụng bếp điện từ, bởi chúng <strong>tiết kiệm cả về điện năng lẫn thời gian</strong> cho bạn nữa. Bạn có thể tham khảo bài viết này để tìm hiểu về độ tiết kiệm của chúng: <a href=\"http://bepankhang.test/qna/dung-bep-dien-tu-co-ton-dien-khong/\">Bếp điện từ có tốn điện không?</a>

Trên đây là những ưu điểm của bếp điện từ. Nếu bạn quan tâm và muốn đặt 1 chiếc bếp tuyệt vời như vậy vào không gian bếp nhà mình, hãy liên hệ ngay với Bếp An Khang để được tư vấn và hỗ trợ nhiệt tình nhé.","Ưu điểm của bếp điện từ?","","inherit","closed","closed","","50-autosave-v1","","","2018-04-13 02:32:37","2018-04-13 02:32:37","","50","http://bepankhang.test/50-autosave-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("96","1","2018-04-13 01:58:11","2018-04-13 01:58:11","","uu-diem-bep-dien-tu","","inherit","open","closed","","uu-diem-bep-dien-tu","","","2018-04-13 01:58:11","2018-04-13 01:58:11","","50","http://bepankhang.test/wp-content/uploads/2018/04/uu-diem-bep-dien-tu.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("97","1","2018-04-13 02:05:44","2018-04-13 02:05:44","","bep-dien-tu-dung-nhu-ban-an","","inherit","open","closed","","bep-dien-tu-dung-nhu-ban-an","","","2018-04-13 02:05:52","2018-04-13 02:05:52","","50","http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-dung-nhu-ban-an.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("98","1","2018-04-13 02:16:35","2018-04-13 02:16:35","","bep-dien-tu-rat-an-toan","","inherit","open","closed","","bep-dien-tu-rat-an-toan","","","2018-04-13 02:16:42","2018-04-13 02:16:42","","50","http://bepankhang.test/wp-content/uploads/2018/04/bep-dien-tu-rat-an-toan.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("99","1","2018-04-13 02:22:48","2018-04-13 02:22:48","","","","inherit","open","closed","","womans-hand-cleaning-induction-stove-with-cloth","","","2018-04-13 02:23:04","2018-04-13 02:23:04","","50","http://bepankhang.test/wp-content/uploads/2018/04/uu-diem-cua-bep-dien-tu-de-ve-sinh.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("100","1","2018-04-13 04:06:44","2018-04-13 04:06:44","<em>Trên thị trường những năm gần đây có rất nhiều dòng bếp điện từ, đa dạng về mẫu mã lẫn chức năng, điều này khiến bạn khó có thể chọn ra cho mình 1 chiêc bếp. Hãy cùng tham khảo kinh nghiệm chọn mua bếp điện từ qua bài viết này nhé</em>

Trước tiên, bạn cần xác định rõ mục đích sử dụng của mình là gì.

Nếu chỉ muốn dùng bếp từ để hâm nóng lẩu, nấu canh, luộc rau,... bạn có thể chọn 1 dòng bếp từ thông thường. Nếu bạn muốn thay thế hoàn toàn cho bếp gas và thực hiện tất cả các phương thức chế biến như chiên, xào, nướng.... thì bạn cần đến 1 chiếc <a href=\"http://bepankhang.test/product/bep-tu-cata-ib-772/\">bếp từ cao cấp</a> hơn.

Số lượng vùng từ cũng là 1 tiêu chuẩn khi chọn mua bếp, tùy theo nhu cầu nấu \"nhiều hay ít bếp cùng lúc\" của bạn. Nếu gia đình bạn khá đông người và bạn muốn làm bữa ăn nhanh chóng, thì cùng 1 lúc bạn có thể làm món mặn, món xào, món canh,... bằng cách sử dụng bộ bếp 3 từ hoặc 4 từ

<a href=\"http://bepankhang.test/product/bep-tu-bosch-pid675n24e/\"><img class=\"alignnone size-full wp-image-73\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-3-tu-bosch-pid675n24e.png\" alt=\"bep 3 vung tu\" /></a>

Nếu bạn quan tâm đến độ bền của bếp, bạn có thể chọn những dòng bếp với <strong>mặt kính Schott Ceran</strong> - loại mặt kính cao cấp được sản xuất tại nhà máy của tập đoàn công nghệ quốc tế SCHOTT ở Mainz – Đức. Ưu điểm của mặt kính này là chịu nhiệt cực tốt, gần như không giãn nở vì nhiệt. Độ bền cao và chịu được tác động cơ học từ môi trường ngoài. Tránh tối đa tình trạng nứt vỡ mặt kính. Đặc biệt kính SCHOTT còn rất thân thiện với môi trường bởi nó không chứa các kim loại nặng độc hại như asen và antimon.

<img class=\"alignnone size-full wp-image-101\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-Schott-Ceran-do-ben-cao.jpg\" alt=\"mat kinh Schott Ceran co do ben cao\" width=\"766\" height=\"293\" />

<strong>Kích thước</strong> cũng là 1 vấn đề hết sức đáng lưu ý khi chọn mua bếp điện từ. Mặc dù nhìn bên ngoài các dòng bếp đều có form khá tương đồng nhau, nhưng thực chất mỗi dòng lại có 1 kích thước riêng. Mỗi chiếc bếp đều có 2 thông số về kích thước là kích thước thực tế của bếp và kích thước vùng cắt đá. Bạn nên đo lại kích thước bếp nhà mình, tính toán kỹ phần cắt đá để chọn ra chiếc bếp từ có kích thước phù hợp nhất, tránh tình trạng hàng mua về đến tận nhà rồi mới phát hiện ra nó không vừa với tủ bếp nhà mình nhé. :)

Về mặt <strong>thương hiệu</strong>, hiện có rất nhiều thương hiệu về bếp điện từ. Tuy nhiên, theo kinh nghiệm chăm sóc khách hàng và bán hàng lâu năm của bếp An Khang, những dòng bếp Cata, Chefs, Bosch,... thường được khách hàng quan tâm và đánh giá cao hơn. Hàng của những hãng này sau khi bán cho nhiều khách được nhận xét rất tốt. Tất nhiên giá của chúng có hơi cao so với giá thành chung của bếp điện từ, nhưng xem xét về mặt lâu dài và ổn định, cũng như chế độ bảo hành, các dòng này vẫn chiếm ưu thế nhiều hơn. Đây đều là những thương hiệu về bếp nổi tiếng tại thị trường châu Âu.

<img class=\"alignnone size-large wp-image-102\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/kinh-nghiem-chon-mua-bep-dien-tu-1024x576.jpg\" alt=\"kinh nghiem chon mua bep dien tu\" width=\"1024\" height=\"576\" />

Hy vọng qua bài viết trên bạn đã có đủ kinh nghiệm để chọn mua bếp điện từ cho gia đình. Nếu còn bất cứ thắc mắc hay phân vân giữa các dòng bếp, xin vui lòng liên hệ Bếp An Khang để được tư vấn cụ thể hơn. Chúc các bạn sớm tìm được một chiếc bếp ưng ý!

&nbsp;","Kinh nghiệm chọn mua bếp điện từ","","inherit","closed","closed","","49-autosave-v1","","","2018-04-13 04:06:44","2018-04-13 04:06:44","","49","http://bepankhang.test/49-autosave-v1/","0","revision","","0");
INSERT INTO `bak_posts` VALUES("101","1","2018-04-13 03:34:44","2018-04-13 03:34:44","","mat-kinh-Schott-Ceran-do-ben-cao","","inherit","open","closed","","mat-kinh-schott-ceran-do-ben-cao","","","2018-04-13 03:37:03","2018-04-13 03:37:03","","49","http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-Schott-Ceran-do-ben-cao.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("102","1","2018-04-13 04:00:54","2018-04-13 04:00:54","","kinh nghiem chon mua bep dien tu","","inherit","open","closed","","woman-looking-to-her-medicine","","","2018-04-13 04:01:09","2018-04-13 04:01:09","","49","http://bepankhang.test/wp-content/uploads/2018/04/kinh-nghiem-chon-mua-bep-dien-tu.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("104","1","2018-04-19 15:29:34","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2018-04-19 15:29:34","0000-00-00 00:00:00","","0","http://bepankhang.test/?p=104","0","post","","0");
INSERT INTO `bak_posts` VALUES("105","1","2018-04-19 16:17:42","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2018-04-19 16:17:42","0000-00-00 00:00:00","","0","http://bepankhang.test/?page_id=105","0","page","","0");
INSERT INTO `bak_posts` VALUES("106","1","2018-04-19 16:39:35","2018-04-19 16:39:35","<b>Bếp từ Cata IB 604 BK có 04 vùng nấu, với tổng công suất 6.7kw, 09 mức điều khiển công suất, cảm ứng nhiệt tự động.</b>
<ul class=\"features\">
 	<li>4 mặt bếp nấu: 2 mặt bếp nấu lớn với chức năng nấu nhanh (booster) Ø220, 1.85 kW (max. 2.1 kW) &amp; Ø180, 1.4 kW (max. 1.85 kW),2 mặt bếp nấu Ø180, 1.4 kW</li>
 	<li>Chức năng xác định vùng đặt nồi tự động</li>
 	<li>9 mức nấu trên mỗi mặt bếp</li>
 	<li>Khóa an toàn</li>
 	<li>Chức năng hẹn giờ nấu trên từng bếp</li>
 	<li>Báo nhiệt dư trên mặt bếp sau khi nấu</li>
 	<li>Chức năng tự động tắt bếp khi không sử dụng</li>
 	<li>Mặt kính đen / trắng</li>
 	<li>Tổng công suất tối đa: 6.7 KW</li>
 	<li>Xuất xứ: Tây Ban Nha</li>
</ul>","Bếp từ Cata IB 604 BK","","publish","closed","closed","","bep-tu-cata-ib-604-bk","","","2018-04-19 17:21:47","2018-04-19 17:21:47","","0","http://bepankhang.test/?post_type=product&#038;p=106","0","product","","0");
INSERT INTO `bak_posts` VALUES("108","1","2018-04-19 16:56:36","2018-04-19 16:56:36","<strong>Thêm 1 dòng sản phẩm cao cấp của thương hiệu Cata - Bếp từ Cata IB 633X, với nhiều tính năng độc đáo và tiện lợi.</strong>
<ul class=\"features\">
 	<li>3 Vùng điều khiển độc lập cho từng mặt bếp</li>
 	<li>3 mặt bếp nấu: 1 mặt bếp nấu lớn có chức năng nấu nhanh (Booster) ø300, 2.8 Kw (Max. 3.6KW), 1 mặt bếp nấu trung có chức năng nấu nhanh (Booster) ø225, 2.2 Kw (Max. 3.1KW), 1 mặt bếp nấu nhỏ có chức năng nấu nhanh (Booster) ø180, 1.8 Kw (Max. 2.2KW),</li>
 	<li>11 mức công suất nấu và chức năng nấu nhanh (Booster)</li>
 	<li>Khóa an toàn</li>
 	<li>Hẹn giờ trên từng vùng bếp</li>
 	<li>Cảnh báo nhiệt dư</li>
 	<li>Chức năng tự động tắt bếp khi không sử dụng</li>
 	<li>Chức năng xác định vùng đặt nồi tự động</li>
 	<li>Khung viền inox</li>
 	<li>Tổng công xuất: 7.2 KW</li>
 	<li>Xuất xứ: Tây Ban Nha</li>
</ul>
<h3>Bảng thông số bếp từ Cata IB 633X</h3>
&nbsp;
<table class=\"spec\">
<tbody>
<tr>
<td><i class=\"fas fa-clock\"></i> Chế độ hẹn giờ</td>
<td>Hẹn giờ trên từng vùng bếp</td>
</tr>
<tr>
<td><i class=\"fas fa-volume-up\"></i> Báo động âm thanh</td>
<td>Nhiệt dư</td>
</tr>
<tr>
<td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
<td>590 x 520mm</td>
</tr>
<tr>
<td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
<td>560 x 490mm</td>
</tr>
</tbody>
</table>
&nbsp;

<iframe src=\"https://www.youtube.com/embed/quJZW0mdX4Y\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe>","Bếp từ Cata IB 633X","","publish","closed","closed","","bep-tu-cata-ib-633x","","","2018-04-19 17:21:17","2018-04-19 17:21:17","","0","http://bepankhang.test/?post_type=product&#038;p=108","0","product","","0");
INSERT INTO `bak_posts` VALUES("110","1","2018-04-19 17:15:19","2018-04-19 17:15:19","<em>Cata IB 753 BK là dòng bếp từ mặt kính màu đen/trắng, với 4 vùng nấu và 9 chức năng nấu cho mỗi vùng, thích hợp với gia đình đông người để chuẩn bị bữa ăn nhanh chóng tiện lợi hơn.</em>

<strong>Bếp từ Cata I 753 BK</strong> sử dụng chip điều khiển công nghệ cao của Siemens Đức, cung cấp khả năng điêu khiển nhiệt độ linh hoạt ( tới 9 - 10 mức độ khác nhau ), các tính năng ngắt, cảnh báo rất an toàn và khả năng hẹn giờ. Hệ thống điều khiển dạng trượt, rất tiện lợi và dễ sử dụng. Bếp thích hợp với những môi trường khí hậu ẩm , nồm tại khu vực châu á, bởi bếp được thiết kế các bo mạch điện tử, mâm từ được phủ hợp kim có khả năng chống lại tác nhân gây hại của khí hậu nóng ẩm mưa nhiều giúp người dùng.

<img class=\"alignnone size-large wp-image-113\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/su-dung-bep-tu-cata-IB-753-1024x682.jpg\" alt=\"su dung bep tu cata IB 753\" width=\"1024\" height=\"682\" />

Bếp sử dụng toàn bộ linh kiện của Đức có tuổi thọ và độ bền cao,  do đó bạn hoàn toàn có thể yên tâm sử dụng sản phẩm. Mặt kính sử dụng cho bếp là loại mặt kính nhập khẩu nguyên chiếc từ Đức, đây là loại mặt kính tốt nhất trên thị trường hiện nay, có khả năng chịu lực, chịu sốc nhiệt lớn, tản nhiệt nhanh giúp hạn chế các trường hợp kính bị rạn nứt do quá lực quá nhiệt. Kinh là vật liệu cách điện nên bạn cũng không cần lo lắng đến vấn đề bị điện giật kể cả trong quá trình đun nấu.

<img class=\"alignnone size-full wp-image-114\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-3-vung-nau-cata-IB-753-BK.jpg\" alt=\"bep tu 3 vung nau cata IB 753 BK\" width=\"988\" height=\"629\" />
<ul class=\"features\">
 	<li>3 mặt bếp nấu: 1 mặt bếp nấu lớn với chức năng nấu nhanh (booster) Ø270, 2.3 kW (max. 3 kW), 1 mặt bếp nấu chức năng nấu nhanh</li>
 	<li>(booster) Ø220, 2.3 kW (max. 3 kW)</li>
 	<li>1 mặt bếp nấu Ø180, 1.4 kW</li>
 	<li>Chức năng xác định vùng đặt nồi tự động</li>
 	<li>9 mức nấu trên mỗi mặt bếp</li>
</ul>
&nbsp;
<h3>Bảng thông số bếp từ Cata IB 753 BK</h3>
&nbsp;
<table class=\"spec\">
<tbody>
<tr>
<td><i class=\"fas fa-keyboard\"></i> Bảng điều khiển</td>
<td>Cảm ứng</td>
</tr>
<tr>
<td><i class=\"fas fa-clock\"></i> Chế độ hẹn giờ</td>
<td>Có</td>
</tr>
<tr>
<td><i class=\"fas fa-volume-up\"></i> Báo động âm thanh</td>
<td>Có</td>
</tr>
<tr>
<td><i class=\"fas fa-lock\"></i> Khóa an toàn</td>
<td>Có</td>
</tr>
<tr>
<td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
<td>770 x 390 mm</td>
</tr>
<tr>
<td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
<td> 750 x 370 mm</td>
</tr>
</tbody>
</table>","Bếp từ Cata IB 753 BK","","publish","closed","closed","","bep-tu-cata-ib-753-bk","","","2018-04-19 17:15:47","2018-04-19 17:15:47","","0","http://bepankhang.test/?post_type=product&#038;p=110","0","product","","0");
INSERT INTO `bak_posts` VALUES("112","1","2018-04-19 17:05:28","2018-04-19 17:05:28","","Bep-tu-Cata-IB-753-BK","","inherit","open","closed","","bep-tu-cata-ib-753-bk-2","","","2018-04-19 17:05:28","2018-04-19 17:05:28","","110","http://bepankhang.test/wp-content/uploads/2018/04/Bep-tu-Cata-IB-753-BK.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("113","1","2018-04-19 17:08:13","2018-04-19 17:08:13","","su-dung-bep-tu-cata-IB-753","","inherit","open","closed","","su-dung-bep-tu-cata-ib-753","","","2018-04-19 17:08:30","2018-04-19 17:08:30","","110","http://bepankhang.test/wp-content/uploads/2018/04/su-dung-bep-tu-cata-IB-753.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("114","1","2018-04-19 17:09:37","2018-04-19 17:09:37","","bep-tu-3-vung-nau-cata-IB-753-BK","","inherit","open","closed","","bep-tu-3-vung-nau-cata-ib-753-bk","","","2018-04-19 17:09:56","2018-04-19 17:09:56","","110","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-3-vung-nau-cata-IB-753-BK.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("115","1","2018-04-19 17:21:02","2018-04-19 17:21:02","","Bep-tu-Cata-IB-633X","","inherit","open","closed","","bep-tu-cata-ib-633x-2","","","2018-04-19 17:21:14","2018-04-19 17:21:14","","108","http://bepankhang.test/wp-content/uploads/2018/04/Bep-tu-Cata-IB-633X.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("116","1","2018-04-19 17:21:30","2018-04-19 17:21:30","","Bep-tu-Cata-IB-604-BK","","inherit","open","closed","","bep-tu-cata-ib-604-bk-2","","","2018-04-19 17:21:42","2018-04-19 17:21:42","","106","http://bepankhang.test/wp-content/uploads/2018/04/Bep-tu-Cata-IB-604-BK.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("117","1","2018-04-19 17:26:30","2018-04-19 17:26:30","<em>Bếp từ Chefs EH-DIH32B ra mắt năm 2017 với công nghệ mới nhất từ E.G.O, có kích thước nhỏ gọn phù hợp với không gian bếp chung cư.</em>

<strong>Tính năng sản phẩm</strong>
<ul class=\"features\">
 	<li>Đun nấu <strong>siêu tiết kiệm</strong> với bếp hai từ EH-DIH32B</li>
 	<li>Mặt kính ceramic chịu nhiệt Schott Ceran vát cạnh, Made in Germany</li>
 	<li>Bếp trên đường kính 22cm, hỗ trợ tính năng nấu nhanh Booster – max 2000W</li>
 	<li>Bếp dưới đường kính 18cm, công suất booster 1600W</li>
 	<li>Tính năng hẹn giờ cho từng vùng nấu, thời gian hẹn đến 99 phút</li>
 	<li>Bàn phím cảm ứng, điều khiển công suất 9 mức + booster</li>
 	<li>Tự động chia sẻ công suất giữa hai bếp</li>
</ul>
<img class=\"alignnone size-large wp-image-119\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/anh-thuc-te-bep-chefs-EH-DIH32B-1024x715.png\" alt=\"anh thuc te bep chefs EH-DIH32B\" width=\"1024\" height=\"715\" />

<strong>Tính năng an toàn</strong>
<ul class=\"features\">
 	<li>Cảnh báo nhiệt dư vùng nấu Residual heat</li>
 	<li>Khóa an toàn trẻ em Child lock</li>
 	<li>Tự động tắt bếp khi để quên Automatic switching off</li>
 	<li>Tự động tắt bếp khi không có nồi ( trên bếp từ) Pot detection</li>
 	<li>Hệ thống bảo vệ an toàn quá nhiệt, quá áp</li>
</ul>
<strong>Tính năng mặt kính</strong>
<ul class=\"features\">
 	<li>Mặt kính liền nguyên khối, vát cạnh, màu đen sang trọng</li>
 	<li>Bề mặt chống trầy xước, chịu lực cao</li>
 	<li>Khả năng chịu nhiệt lên đến 1000oC, chịu sốc nhiệt đến 800oC</li>
</ul>","Bếp từ Chefs EH-DIH32B","","publish","closed","closed","","bep-tu-chefs-eh-dih32b","","","2018-04-19 17:30:30","2018-04-19 17:30:30","","0","http://bepankhang.test/?post_type=product&#038;p=117","0","product","","0");
INSERT INTO `bak_posts` VALUES("118","1","2018-04-19 17:25:40","2018-04-19 17:25:40","","mat-kinh-bep-an-khang","","inherit","open","closed","","mat-kinh-bep-an-khang","","","2018-04-19 17:25:40","2018-04-19 17:25:40","","117","http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-bep-an-khang.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("119","1","2018-04-19 17:25:41","2018-04-19 17:25:41","","anh-thuc-te-bep-chefs-EH-DIH32B","","inherit","open","closed","","anh-thuc-te-bep-chefs-eh-dih32b","","","2018-04-19 17:25:55","2018-04-19 17:25:55","","117","http://bepankhang.test/wp-content/uploads/2018/04/anh-thuc-te-bep-chefs-EH-DIH32B.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("120","1","2018-04-19 17:25:43","2018-04-19 17:25:43","","bep-tu-chefs-EH-DIH32B","","inherit","open","closed","","bep-tu-chefs-eh-dih32b","","","2018-04-19 17:25:43","2018-04-19 17:25:43","","117","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-chefs-EH-DIH32B.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("122","1","2018-04-19 17:36:51","2018-04-19 17:36:51","<em>Bếp ba từ Chefs EH-IH534 là dòng bếp cao cấp của Chefs, với công nghệ mâm từ mới nhất từ thương hiệu E.G.O, mặt kính cấu trúc carbon siêu chịu lực, với đồ sần nhẹ.</em>

<strong>Tính năng sản phẩm</strong>
<ul class=\"features\">
 	<li>Sử dụng đa năng với bếp hồng ngoại kết hợp từ EH-MIX545</li>
 	<li>Mặt kính ceramic chịu nhiệt Schott Ceran vát cạnh – Germany</li>
 	<li>Mâm nhiệt EGO Hi-light, 3 vòng nhiệt (14 / 20 / 25 cm ) – Germany</li>
 	<li>Mâm từ đường kính 16 / 22cm, hỗ trợ tính năng nấu nhanh Booster – max 2000W</li>
 	<li>Tính năng cài đặt chương trình nấu linh hoạt trên bếp hồng ngoại</li>
 	<li>Tính năng hẹn giờ cho từng vùng nấu, thời gian hẹn đến 99 phút</li>
 	<li>Bàn phím cảm ứng, điều khiển công suất 9 mức + booster</li>
</ul>
<strong>Tính năng an toàn</strong>
<ul class=\"features\">
 	<li>Cảnh báo nhiệt dư vùng nấu <strong>Residual heat</strong></li>
 	<li>Khóa an toàn trẻ em <strong>Child lock</strong></li>
 	<li>Tính năng tắt bếp an toàn khi để quên <strong>Automatic switching off</strong></li>
 	<li>Tự động tắt bếp khi không có nồi ( trên bếp từ) <strong>Pot detection</strong></li>
 	<li>Cơ chế bảo vệ quá tải</li>
 	<li>Hệ thống bảo vệ an toàn quá nhiệt, quá áp</li>
</ul>

<img src=\"http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-bep-ba-tu-eh-ih534-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" class=\"alignnone size-large wp-image-124\" />
<strong>Tính năng mặt kính</strong>
<ul class=\"features\">
 	<li>Mặt kính liền nguyên khối, vát cạnh, màu đen sang trọng</li>
 	<li>Bề mặt chống trầy xước, chịu lực cao</li>
 	<li>Khả năng chịu nhiệt lên đến 1000° C, chịu sốc nhiệt đến 800° C</li>
</ul>

<h3>Thông số kỹ thuật bếp Chefs EH-IH534</h3>
<table class=\"spec\">    
    <tr>
        <td><i class=\"fas fa-power-off\"></i> Công suất</td>
        <td>max 5500W</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square-full\"></i> Kích thước bề mặt</td>
        <td>750 x 450 x 60mm</td>
    </tr>
    <tr>
        <td><i class=\"fas fa-square\"></i> Kích thước khoét đá</td>
        <td>720 x 390mm</td>
    </tr>    
</table>","Bếp từ Chefs EH-IH534","","publish","closed","closed","","bep-tu-chefs-eh-ih534","","","2018-04-19 17:40:42","2018-04-19 17:40:42","","0","http://bepankhang.test/?post_type=product&#038;p=122","0","product","","0");
INSERT INTO `bak_posts` VALUES("123","1","2018-04-19 17:36:23","2018-04-19 17:36:23","","bep-tu-chefs-eh-ih534","","inherit","open","closed","","bep-tu-chefs-eh-ih534","","","2018-04-19 17:36:23","2018-04-19 17:36:23","","122","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-chefs-eh-ih534.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("124","1","2018-04-19 17:36:45","2018-04-19 17:36:45","","mat-kinh-bep-ba-tu-eh-ih534","","inherit","open","closed","","mat-kinh-bep-ba-tu-eh-ih534","","","2018-04-19 17:36:45","2018-04-19 17:36:45","","122","http://bepankhang.test/wp-content/uploads/2018/04/mat-kinh-bep-ba-tu-eh-ih534.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("125","1","2018-04-19 17:48:54","2018-04-19 17:48:54","<strong>EH-MIX534 là dòng bếp hỗn hợp của Chefs, là 1 bộ combo giữa bếp 2 bếp từ và 1 bếp hồng ngoại trên cùng 1 chiếc bếp.</strong>
<h3>Tính năng sản phẩm bếp hỗn hợp Chef’s EH-MIX534</h3>
<ul>
 	<li>Sử dụng đa năng với bếp hồng ngoại kết hợp từ EH-MIX534</li>
 	<li>Mặt kính ceramic chịu nhiệt Schott Ceran vát cạnh – Germany</li>
 	<li>Bếp trái 23cm / booster 3000W, bếp giữa 15cm / 1400W, bếp trái hồng ngoại 2 vòng nhiệt 14/ 20cm</li>
 	<li>Kiểu dáng dài sang trọng, dễ dàng thao tác khi nấu bếp</li>
 	<li>Bàn phím điều khiển dạng trượt slide, 9 mức công suất + booster</li>
 	<li>Hẹn giờ độc lập cho từng vùng nấu, thời gian hẹn đến 9 giờ 30 phút</li>
 	<li>Tự động chia sẻ công suất giữa 2 bếp, max 5500W</li>
</ul>
<img class=\"alignnone size-full wp-image-126\" src=\"http://bepankhang.test/wp-content/uploads/2018/04/bep-hon-hop-chefs-Mix534.png\" alt=\"\" width=\"980\" height=\"653\" />
<h3>Tính năng an toàn</h3>
<ul>
 	<li>Cảnh báo nhiệt dư vùng nấu Residual heat</li>
 	<li>Khóa an toàn trẻ em Child lock</li>
 	<li>Tự động tắt bếp khi để quên Automatic switching off</li>
 	<li>Tự động tắt bếp khi không có nồi ( trên bếp từ) Pot detection</li>
 	<li>Hệ thống bảo vệ an toàn quá nhiệt, quá áp</li>
</ul>
<h3>Tính năng mặt kính</h3>
<ul>
 	<li>Mặt kính liền nguyên khối, vát cạnh, sơn nghệ thuật sang trọng</li>
 	<li>Bề mặt chống trầy xước, chịu lực cao</li>
 	<li>Khả năng chịu nhiệt lên đến 1000°C, chịu sốc nhiệt đến 800°C</li>
</ul>","Bếp hỗn hợp EH-MIX534","","publish","closed","closed","","bep-hon-hop-eh-mix534","","","2018-04-19 17:48:54","2018-04-19 17:48:54","","0","http://bepankhang.test/?post_type=product&#038;p=125","0","product","","0");
INSERT INTO `bak_posts` VALUES("126","1","2018-04-19 17:47:52","2018-04-19 17:47:52","","bep-hon-hop-chefs-Mix534","","inherit","open","closed","","bep-hon-hop-chefs-mix534","","","2018-04-19 17:47:52","2018-04-19 17:47:52","","125","http://bepankhang.test/wp-content/uploads/2018/04/bep-hon-hop-chefs-Mix534.png","0","attachment","image/png","0");
INSERT INTO `bak_posts` VALUES("127","1","2018-04-19 17:47:52","2018-04-19 17:47:52","","bep-combo-chefs-EH-MIX534","","inherit","open","closed","","bep-combo-chefs-eh-mix534","","","2018-04-19 17:47:52","2018-04-19 17:47:52","","125","http://bepankhang.test/wp-content/uploads/2018/04/bep-combo-chefs-EH-MIX534.jpg","0","attachment","image/jpeg","0");
INSERT INTO `bak_posts` VALUES("128","1","2018-04-19 18:04:12","2018-04-19 18:04:12","","bep-tu-cata-ib-772","","inherit","open","closed","","bep-tu-cata-ib-772-2","","","2018-04-19 18:04:21","2018-04-19 18:04:21","","62","http://bepankhang.test/wp-content/uploads/2018/04/bep-tu-cata-ib-772-1.png","0","attachment","image/png","0");


DROP TABLE IF EXISTS `bak_term_relationships`;

CREATE TABLE `bak_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bak_term_relationships` VALUES("39","7","0");
INSERT INTO `bak_term_relationships` VALUES("39","10","0");
INSERT INTO `bak_term_relationships` VALUES("58","7","0");
INSERT INTO `bak_term_relationships` VALUES("58","10","0");
INSERT INTO `bak_term_relationships` VALUES("62","7","0");
INSERT INTO `bak_term_relationships` VALUES("62","14","0");
INSERT INTO `bak_term_relationships` VALUES("66","7","0");
INSERT INTO `bak_term_relationships` VALUES("66","14","0");
INSERT INTO `bak_term_relationships` VALUES("70","7","0");
INSERT INTO `bak_term_relationships` VALUES("70","11","0");
INSERT INTO `bak_term_relationships` VALUES("74","7","0");
INSERT INTO `bak_term_relationships` VALUES("74","13","0");
INSERT INTO `bak_term_relationships` VALUES("78","7","0");
INSERT INTO `bak_term_relationships` VALUES("78","11","0");
INSERT INTO `bak_term_relationships` VALUES("81","7","0");
INSERT INTO `bak_term_relationships` VALUES("81","14","0");
INSERT INTO `bak_term_relationships` VALUES("84","7","0");
INSERT INTO `bak_term_relationships` VALUES("84","8","0");
INSERT INTO `bak_term_relationships` VALUES("84","10","0");
INSERT INTO `bak_term_relationships` VALUES("87","7","0");
INSERT INTO `bak_term_relationships` VALUES("87","11","0");
INSERT INTO `bak_term_relationships` VALUES("91","7","0");
INSERT INTO `bak_term_relationships` VALUES("91","13","0");
INSERT INTO `bak_term_relationships` VALUES("106","7","0");
INSERT INTO `bak_term_relationships` VALUES("106","14","0");
INSERT INTO `bak_term_relationships` VALUES("108","7","0");
INSERT INTO `bak_term_relationships` VALUES("108","14","0");
INSERT INTO `bak_term_relationships` VALUES("110","7","0");
INSERT INTO `bak_term_relationships` VALUES("110","14","0");
INSERT INTO `bak_term_relationships` VALUES("117","7","0");
INSERT INTO `bak_term_relationships` VALUES("117","10","0");
INSERT INTO `bak_term_relationships` VALUES("122","7","0");
INSERT INTO `bak_term_relationships` VALUES("122","10","0");
INSERT INTO `bak_term_relationships` VALUES("125","7","0");
INSERT INTO `bak_term_relationships` VALUES("125","8","0");
INSERT INTO `bak_term_relationships` VALUES("125","10","0");


DROP TABLE IF EXISTS `bak_term_taxonomy`;

CREATE TABLE `bak_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bak_term_taxonomy` VALUES("1","1","category","","0","0","0");
INSERT INTO `bak_term_taxonomy` VALUES("4","4","post_tag","","0","0","0");
INSERT INTO `bak_term_taxonomy` VALUES("5","5","post_tag","","0","0","0");
INSERT INTO `bak_term_taxonomy` VALUES("6","6","category","","0","0","0");
INSERT INTO `bak_term_taxonomy` VALUES("7","7","product-category","","0","17","0");
INSERT INTO `bak_term_taxonomy` VALUES("8","8","product-category","","0","2","0");
INSERT INTO `bak_term_taxonomy` VALUES("9","9","product-category","","0","0","0");
INSERT INTO `bak_term_taxonomy` VALUES("10","10","brand","","0","6","2");
INSERT INTO `bak_term_taxonomy` VALUES("11","11","brand","","0","3","3");
INSERT INTO `bak_term_taxonomy` VALUES("13","13","brand","Thương hiệu bếp từ Arber của Ý nổi tiếng trên thị trường và hiện đang là dòng được rất nhiều khách hàng tin tưởng và sử dụng. Hãng bếp từ Arber không ngừng phát triển để cho ra đời nhiều dòng sản phẩm với kiểu dáng giá thành khác nhau để quý khách hàng lựa chọn","0","2","4");
INSERT INTO `bak_term_taxonomy` VALUES("14","14","brand","","0","6","1");


DROP TABLE IF EXISTS `bak_termmeta`;

CREATE TABLE `bak_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_terms`;

CREATE TABLE `bak_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bak_terms` VALUES("1","Uncategorized","uncategorized","0");
INSERT INTO `bak_terms` VALUES("4","bếp hồng ngoại","bep-hong-ngoai","0");
INSERT INTO `bak_terms` VALUES("5","bếp điện từ","bep-dien-tu","0");
INSERT INTO `bak_terms` VALUES("6","Sidebar","sidebar","0");
INSERT INTO `bak_terms` VALUES("7","Bếp điện từ","bep-dien-tu","0");
INSERT INTO `bak_terms` VALUES("8","Bếp hồng ngoại","bep-hong-ngoai","0");
INSERT INTO `bak_terms` VALUES("9","Phụ kiện bếp","phu-kien-bep","0");
INSERT INTO `bak_terms` VALUES("10","Chefs","chefs","0");
INSERT INTO `bak_terms` VALUES("11","Bosch","bosch","0");
INSERT INTO `bak_terms` VALUES("13","Arber","arber","0");
INSERT INTO `bak_terms` VALUES("14","Cata","cata","0");


DROP TABLE IF EXISTS `bak_toolset_post_guid_id`;

CREATE TABLE `bak_toolset_post_guid_id` (
  `guid` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_id` bigint(20) NOT NULL,
  UNIQUE KEY `post_id` (`post_id`),
  KEY `guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `bak_usermeta`;

CREATE TABLE `bak_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bak_usermeta` VALUES("1","1","nickname","root");
INSERT INTO `bak_usermeta` VALUES("2","1","first_name","");
INSERT INTO `bak_usermeta` VALUES("3","1","last_name","");
INSERT INTO `bak_usermeta` VALUES("4","1","description","");
INSERT INTO `bak_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `bak_usermeta` VALUES("6","1","comment_shortcuts","false");
INSERT INTO `bak_usermeta` VALUES("7","1","admin_color","fresh");
INSERT INTO `bak_usermeta` VALUES("8","1","use_ssl","0");
INSERT INTO `bak_usermeta` VALUES("9","1","show_admin_bar_front","true");
INSERT INTO `bak_usermeta` VALUES("10","1","bak_capabilities","a:13:{s:13:\"administrator\";b:1;s:26:\"wpcf_custom_post_type_view\";b:1;s:26:\"wpcf_custom_post_type_edit\";b:1;s:33:\"wpcf_custom_post_type_edit_others\";b:1;s:25:\"wpcf_custom_taxonomy_view\";b:1;s:25:\"wpcf_custom_taxonomy_edit\";b:1;s:32:\"wpcf_custom_taxonomy_edit_others\";b:1;s:22:\"wpcf_custom_field_view\";b:1;s:22:\"wpcf_custom_field_edit\";b:1;s:29:\"wpcf_custom_field_edit_others\";b:1;s:25:\"wpcf_user_meta_field_view\";b:1;s:25:\"wpcf_user_meta_field_edit\";b:1;s:32:\"wpcf_user_meta_field_edit_others\";b:1;}");
INSERT INTO `bak_usermeta` VALUES("11","1","bak_user_level","10");
INSERT INTO `bak_usermeta` VALUES("12","1","dismissed_wp_pointers","");
INSERT INTO `bak_usermeta` VALUES("13","1","show_welcome_panel","1");
INSERT INTO `bak_usermeta` VALUES("15","1","bak_dashboard_quick_press_last_post_id","104");
INSERT INTO `bak_usermeta` VALUES("16","1","toolset_admin_notices_manager","a:1:{s:17:\"dismissed-notices\";a:2:{s:26:\"how-to-design-with-toolset\";b:1;s:31:\"types_free_version_support_ends\";b:1;}}");
INSERT INTO `bak_usermeta` VALUES("17","1","closedpostboxes_toolset_page_wpcf-edit-type","a:0:{}");
INSERT INTO `bak_usermeta` VALUES("18","1","metaboxhidden_toolset_page_wpcf-edit-type","a:1:{i:0;s:12:\"field_groups\";}");
INSERT INTO `bak_usermeta` VALUES("19","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `bak_usermeta` VALUES("20","1","closedpostboxes_toolset_page_wpcf-edit-tax","a:0:{}");
INSERT INTO `bak_usermeta` VALUES("21","1","closedpostboxes_toolset_page_wpcf-edit-usermeta","a:0:{}");
INSERT INTO `bak_usermeta` VALUES("22","1","metaboxhidden_toolset_page_wpcf-edit-usermeta","a:0:{}");
INSERT INTO `bak_usermeta` VALUES("23","1","_types_feedback_dont_show_until","1527780772");
INSERT INTO `bak_usermeta` VALUES("24","1","closedpostboxes_toolset_page_wpcf-edit","a:5:{i:0;s:40:\"types-custom-field-product_display_price\";i:1;s:37:\"types-custom-field-product_sell_price\";i:2;s:31:\"types-custom-field-product_code\";i:3;s:36:\"types-custom-field-product_promotion\";i:4;s:36:\"types-custom-field-product_guarantee\";}");
INSERT INTO `bak_usermeta` VALUES("25","1","metaboxhidden_toolset_page_wpcf-edit","a:0:{}");
INSERT INTO `bak_usermeta` VALUES("26","1","meta-box-order_product","a:3:{s:4:\"side\";s:79:\"wpcf-group-product-fields,postimagediv,nhom-san-phamdiv,tagsdiv-brand,submitdiv\";s:6:\"normal\";s:18:\"wpseo_meta,slugdiv\";s:8:\"advanced\";s:0:\"\";}");
INSERT INTO `bak_usermeta` VALUES("27","1","screen_layout_product","2");
INSERT INTO `bak_usermeta` VALUES("28","1","bak_user-settings","libraryContent=browse&editor=tinymce&imgsize=large");
INSERT INTO `bak_usermeta` VALUES("29","1","bak_user-settings-time","1524160130");
INSERT INTO `bak_usermeta` VALUES("31","1","bak_yoast_notifications","a:3:{i:0;a:2:{s:7:\"message\";s:130:\"Since you are new to Yoast SEO you can configure the <a href=\"http://bepankhang.test/wp-admin/?page=wpseo_configurator\">plugin</a>\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:31:\"wpseo-dismiss-onboarding-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.8000000000000000444089209850062616169452667236328125;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:14:\"manage_options\";s:16:\"capability_check\";s:3:\"all\";}}i:1;a:2:{s:7:\"message\";s:735:\"We\'ve noticed you\'ve been using Yoast SEO for some time now; we hope you love it!
			
			We\'d be thrilled if you could <a href=\'https://yoa.st/rate-yoast-seo\'>give us a 5* rating on WordPress.org</a>! If you are experiencing issues, <a href=\'https://yoa.st/bugreport\'>please file a bug report</a> and we\'ll do our best to help you out.
			
			By the way, did you know we also have a <a href=\'https://yoa.st/premium-notification\'>Premium plugin</a>? It offers advanced features, like a redirect manager and support for multiple keywords. It also comes with 24/7 personal support.

			<a class=\'button\' href=\' http://bepankhang.test/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell \'>Please don\'t show me this notification anymore</a>\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:19:\"wpseo-upsell-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.8000000000000000444089209850062616169452667236328125;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:14:\"manage_options\";s:16:\"capability_check\";s:3:\"all\";}}i:2;a:2:{s:7:\"message\";s:165:\"Don\'t miss your crawl errors: <a href=\"http://bepankhang.test/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">connect with Google Search Console here</a>.\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:14:\"manage_options\";s:16:\"capability_check\";s:3:\"all\";}}}");
INSERT INTO `bak_usermeta` VALUES("32","1","metaboxhidden_toolset_page_wpcf-edit-tax","a:0:{}");
INSERT INTO `bak_usermeta` VALUES("33","1","closedpostboxes_product","a:0:{}");
INSERT INTO `bak_usermeta` VALUES("34","1","metaboxhidden_product","a:1:{i:0;s:7:\"slugdiv\";}");
INSERT INTO `bak_usermeta` VALUES("35","1","_yoast_wpseo_profile_updated","1520620489");
INSERT INTO `bak_usermeta` VALUES("36","1","wpseo_title","");
INSERT INTO `bak_usermeta` VALUES("37","1","wpseo_metadesc","");
INSERT INTO `bak_usermeta` VALUES("38","1","wpseo_metakey","");
INSERT INTO `bak_usermeta` VALUES("39","1","wpseo_excludeauthorsitemap","");
INSERT INTO `bak_usermeta` VALUES("40","1","wpseo_content_analysis_disable","");
INSERT INTO `bak_usermeta` VALUES("41","1","wpseo_keyword_analysis_disable","");
INSERT INTO `bak_usermeta` VALUES("42","1","syntax_highlighting","true");
INSERT INTO `bak_usermeta` VALUES("43","1","locale","");
INSERT INTO `bak_usermeta` VALUES("44","1","googleplus","");
INSERT INTO `bak_usermeta` VALUES("45","1","twitter","");
INSERT INTO `bak_usermeta` VALUES("46","1","facebook","");
INSERT INTO `bak_usermeta` VALUES("47","2","nickname","baokhang");
INSERT INTO `bak_usermeta` VALUES("48","2","first_name","");
INSERT INTO `bak_usermeta` VALUES("49","2","last_name","");
INSERT INTO `bak_usermeta` VALUES("50","2","description","");
INSERT INTO `bak_usermeta` VALUES("51","2","rich_editing","true");
INSERT INTO `bak_usermeta` VALUES("52","2","syntax_highlighting","true");
INSERT INTO `bak_usermeta` VALUES("53","2","comment_shortcuts","false");
INSERT INTO `bak_usermeta` VALUES("54","2","admin_color","fresh");
INSERT INTO `bak_usermeta` VALUES("55","2","use_ssl","0");
INSERT INTO `bak_usermeta` VALUES("56","2","show_admin_bar_front","true");
INSERT INTO `bak_usermeta` VALUES("57","2","locale","");
INSERT INTO `bak_usermeta` VALUES("58","2","bak_capabilities","a:1:{s:6:\"editor\";b:1;}");
INSERT INTO `bak_usermeta` VALUES("59","2","bak_user_level","7");
INSERT INTO `bak_usermeta` VALUES("60","2","_yoast_wpseo_profile_updated","1520620554");
INSERT INTO `bak_usermeta` VALUES("61","2","dismissed_wp_pointers","");
INSERT INTO `bak_usermeta` VALUES("62","3","wp_capabilities","a:1:{s:13:\"administrator\";s:1:\"1\";}");
INSERT INTO `bak_usermeta` VALUES("63","3","wp_user_level","10");
INSERT INTO `bak_usermeta` VALUES("67","1","wpcf-group-form-toggle","a:1:{i:-1;a:1:{s:30:\"checkboxes-fieldset-1069095823\";i:1;}}");
INSERT INTO `bak_usermeta` VALUES("68","1","meta-box-order_toolset_page_wpcf-edit","a:4:{i:0;s:236:\"types-custom-field-product_display_price,types-custom-field-product_sell_price,types-custom-field-product_code,types-custom-field-num_cook,types-custom-field-product_promotion,types-custom-field-product_guarantee,types-custom-field-show\";s:4:\"side\";s:9:\"submitdiv\";s:6:\"normal\";s:23:\"types-information-table\";s:8:\"advanced\";s:0:\"\";}");
INSERT INTO `bak_usermeta` VALUES("69","1","screen_layout_toolset_page_wpcf-edit","2");
INSERT INTO `bak_usermeta` VALUES("70","1","session_tokens","a:1:{s:64:\"7a471b304b944fa458b6825109e81705cae4163b4ed6aeb27509a177b00348f8\";a:4:{s:10:\"expiration\";i:1524327092;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36\";s:5:\"login\";i:1524154292;}}");
INSERT INTO `bak_usermeta` VALUES("71","1","meta-box-order_page","a:3:{s:4:\"side\";s:36:\"pageparentdiv,submitdiv,postimagediv\";s:6:\"normal\";s:56:\"wpseo_meta,postcustom,commentstatusdiv,slugdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}");
INSERT INTO `bak_usermeta` VALUES("72","1","screen_layout_page","2");


DROP TABLE IF EXISTS `bak_users`;

CREATE TABLE `bak_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bak_users` VALUES("1","root","$P$B418GBGR32bO6bXbr1KWscYWhbcNO60","root","ptson.snh@gmail.com","","2018-01-16 13:58:27","","0","root");
INSERT INTO `bak_users` VALUES("2","baokhang","$P$BwqqlH5pVMgM/NGBtI83alzlmaPuSR.","baokhang","trondoibenem8902@gmail.com","","2018-03-09 18:35:54","1520620555:$P$BlrYHigd12f4wt0OS9VACe01tzXLrX.","0","baokhang");
INSERT INTO `bak_users` VALUES("3","wp.service.controller.63Ts4","$P$BxWoqq0wbCmoO0V2wi.X242IBNIYdx1","Service","","","0000-00-00 00:00:00","","0","Service");


